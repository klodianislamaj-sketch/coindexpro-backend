## coindex-graph-engine — Phase 9

The relationship-intelligence engine. It turns **real observed activity** (trades,
transfers, positions, labels) into a typed, confidence-bearing graph of wallets
and tokens, then derives clusters, influence, and funding attribution from that
graph. Nothing is inferred without a provable basis, and **every edge carries a
confidence value and a certainty tag**.

### Architecture

```
sources (real)                         graph engine                     storage (Postgres)
─────────────                          ────────────                     ──────────────────
ClickHouse wallet_trades   ─┐          builder.BuildOnce()  ─┐          graph_nodes
ClickHouse transfers       ─┼─► reads ─► wallet_graph         ├─ upsert ─► graph_edges
ClickHouse wallet_positions─┤          ► token_graph          │          wallet_clusters(+members)
ClickHouse smart_money     ─┤          ► funding              │          wallet_influence
Postgres   wallet_labels   ─┘          ► cluster / influence ─┘          token_correlations
                                       ► traversal (API)
```

A build runs on a schedule (default every 10m over a 168h lookback) and/or is
nudged by Kafka activity (debounced). Kafka messages are only a "something
changed" signal — the rebuild always reads the real source tables, so no message
payload is ever trusted as graph truth. The API reads the stored graph.

These tables are **distinct from the Phase 2 `graph.*` scaffold** (no name
collision); this engine is the authoritative graph store.

### Graph model

Nodes are `"<chain>:<address>"` with `kind ∈ {wallet, token}`. Edges are directed
and typed; symmetric relations (co-buy, same-block, …) are stored once under a
canonical `src < dst` ordering to avoid `(a,b)`/`(b,a)` duplication.

### Edge types

| Category | Types |
|---|---|
| wallet → token | `buy`, `sell`, `repeated_buy`, `repeated_sell`, `high_conviction` |
| wallet → wallet | `co_buy`, `co_sell`, `same_block`, `same_tx`, `funding_transfer`, `cluster_overlap` |
| wallet → funding source | `exchange_funded`, `insider_funded`, `vc_funded`, `dev_funded`, `funded_unknown` |
| token → token | `co_held`, `co_bought`, `rotation`, `sector_linked` |

### Confidence model (the integrity core)

Every edge has `confidence ∈ [0,1]` (DB-enforced) and `certainty`:

| Relation | certainty | confidence basis |
|---|---|---|
| `same_tx` | definitive | exact co-occurrence in one transaction → 1.0 |
| `same_block` | definitive | same token, same block → 0.9 |
| `buy`/`sell`/`repeated_*` | definitive | observed fills → 1.0 |
| `co_buy`/`co_sell` | **probable** | same token+side+time-bucket; confidence = `1 − 1/(1+shared_tokens)` (a coefficient, not a guess) |
| `funding_*` | definitive transfer; attribution = label confidence | the transfer is observed (1.0); the *attribution* inherits the source label's confidence, and drops to `probable` when < 1.0 |
| `co_held` (token↔token) | provable | Jaccard of real holder sets; `coefficient = confidence` |

Probable edges always carry the coefficient/shared-count in `evidence`. The engine
will not construct an edge without a confidence and certainty.

### Cluster model

Clustering is **connected components** over wallet-wallet edges whose confidence
≥ `min_edge_confidence` (default 0.8), computed with union-find. A cluster is, by
definition, a maximal connected set — membership is **mathematically provable**,
not inferred. Singletons are dropped. Each cluster exposes the required fields:
`size` (node count), `edge_count` (internal edges), and `confidence` (mean internal
edge confidence). `algorithm` is recorded (`connected_components`).

### Influence scoring

A weighted **PageRank** (damping 0.85) runs over the real wallet-wallet edge graph
(edge weight = `weight × confidence`, with dangling-mass redistribution). The
converged centrality is min-max normalized and blended with real measured signals:

```
score = 0.50·centrality + 0.25·pnl + 0.15·conviction + 0.10·repetition
```

`pnl` (realized, from `wallet_positions`), `conviction` (from `smart_money_events`),
and `repetition` (buy counts) are each min-max normalized across the wallet set.
Every result exposes `score`, `rank`, and a `factors` object containing all four
normalized components plus the blend formula — so the score is fully reproducible.
No reputation is invented; every input is measured.

### Funding source tracing

`funding.BuildFundingEdges` reads **observed transfers** (`to = funded wallet`) and
attributes the source via Postgres `wallet_labels`: exchange/cex → `exchange_funded`,
vc → `vc_funded`, dev/team → `dev_funded`, insider → `insider_funded`. An **unlabeled
source becomes `funded_unknown`** — the observed funding is recorded without
inventing an attribution. Attribution confidence is the label's confidence.

### Traversal & depth limits

`/graph/path` builds an in-memory adjacency from the stored wallet-wallet edges and
runs BFS for the fewest-hop path, bounded by `max_depth` (default 6, hard cap 8).
`Expand` (depth-limited BFS) filters by edge confidence so expansion follows only
well-supported relationships. An unreachable target returns
`{available:false, reason:"no path within depth"}` — never a fabricated link.

### API routes

| Route | Returns |
|---|---|
| `GET /graph/wallet/:address` | all edges touching the wallet (or `available:false`) |
| `GET /graph/token/:token` | token correlations (or `available:false`) |
| `GET /graph/cluster/:id` | cluster with `size`, `edge_count`, `confidence`, `members` |
| `GET /graph/influence/:address` | `score`, `rank`, `factors` (or `available:false`) |
| `GET /graph/funding/:address` | funding-source edges (or `available:false`) |
| `GET /graph/path/:from/:to` | shortest path or `available:false` |

`:address`/`:token` accept a bare `0x…` (chain via `?chain=`, default ethereum) or a
full `"<chain>:<address>"` id. Ops: `/healthz`, `/readyz`, `/metrics`.

### Storage model & idempotency / replay

All writes are idempotent. `graph_edges` upserts on its PK `(src, dst, edge_type)`
via `ON CONFLICT … DO UPDATE`, so re-running a build converges rather than
duplicating. `wallet_clusters` and `token_correlations`/`wallet_influence` are
replaced/upserted per cycle inside transactions. A rebuild over the same window
produces the same graph (deterministic algorithms over the same observed data).

### Scaling notes

- Co-occurrence pair generation is bounded by `max_pairs_per_group` (default 200)
  per `(token, bucket)` so a popular token cannot explode the pair count; the bound
  is recorded in evidence.
- Builds are windowed (`lookback`) and capped (`max_trades`, `max_tokens`).
- `graph_edges` is indexed on `(src, edge_type)`, `(dst, edge_type)`, and
  `(edge_type, confidence)`; clusters/influence/correlations are indexed for the API.
- Hot API responses are cached in Redis with a short TTL.

### Honesty boundaries

- **Real, production-shaped code, NOT compiled or run here** (no Go toolchain, no
  ClickHouse/Postgres/Redis/Kafka, no network in the authoring environment).
  Statically reviewed; import cycle resolved (`db` does not import `graph`);
  union-find, PageRank (sums to 1.0), and Jaccard (0.4) verified by simulation.
  Before production: `go build` + `vet` + lint and an integration run.
- **Only as real as the source data.** A wallet with no observed relationships
  returns `available:false`; an unreachable path returns `available:false`.
- **No inferred links.** same-tx/same-block/funding are definitive observations;
  co-buy/co-sell are explicitly `probable` with a coefficient; token correlations
  are exact Jaccard. The engine never emits a relationship it cannot ground in
  observed data, and never fabricates a cluster, funding path, or influence score.
- **Funding attribution depends on labels.** No label → `funded_unknown`, not a
  guessed exchange/VC tag.
