// Package config loads graph-engine configuration from YAML with ${ENV} expansion.
package config

import (
	"fmt"
	"os"
	"time"

	"gopkg.in/yaml.v3"
)

type Config struct {
	Server     ServerConfig     `yaml:"server"`
	ClickHouse ClickHouseConfig `yaml:"clickhouse"`
	Postgres   PostgresConfig   `yaml:"postgres"`
	Redis      RedisConfig      `yaml:"redis"`
	Kafka      KafkaConfig      `yaml:"kafka"`
	Build      BuildConfig      `yaml:"build"`
	Log        LogConfig        `yaml:"log"`
}

type ServerConfig struct {
	APIAddr     string `yaml:"api_addr"`
	MetricsAddr string `yaml:"metrics_addr"`
}
type ClickHouseConfig struct {
	Addrs    []string `yaml:"addrs"`
	Database string   `yaml:"database"`
	Username string   `yaml:"username"`
	Password string   `yaml:"password"`
}
type PostgresConfig struct {
	DSN string `yaml:"dsn"`
}
type RedisConfig struct {
	Addr string `yaml:"addr"`
}
type KafkaConfig struct {
	Enabled  bool          `yaml:"enabled"`
	Brokers  []string      `yaml:"brokers"`
	GroupID  string        `yaml:"group_id"`
	Topics   []string      `yaml:"topics"`
	Debounce time.Duration `yaml:"debounce"`
}
type BuildConfig struct {
	Enabled        bool          `yaml:"enabled"`
	Interval       time.Duration `yaml:"interval"`
	Lookback       time.Duration `yaml:"lookback"`
	MaxTrades      int           `yaml:"max_trades"`
	MaxTokens      int           `yaml:"max_tokens"`
	MaxPairsPerGrp int           `yaml:"max_pairs_per_group"`
	MinEdgeConf    float64       `yaml:"min_edge_confidence"`
	MinCoHolders   int           `yaml:"min_co_holders"`
	PageRankIters  int           `yaml:"pagerank_iterations"`
	CacheTTL       time.Duration `yaml:"cache_ttl"`
}
type LogConfig struct {
	Level string `yaml:"level"`
}

func Load(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}
	var c Config
	if err := yaml.Unmarshal([]byte(os.Expand(string(raw), os.Getenv)), &c); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}
	c.defaults()
	return &c, c.validate()
}

func (c *Config) defaults() {
	if c.Server.APIAddr == "" {
		c.Server.APIAddr = ":8095"
	}
	if c.Server.MetricsAddr == "" {
		c.Server.MetricsAddr = ":9107"
	}
	if c.Build.Interval == 0 {
		c.Build.Interval = 10 * time.Minute
	}
	if c.Build.Lookback == 0 {
		c.Build.Lookback = 7 * 24 * time.Hour
	}
	if c.Build.MaxTrades == 0 {
		c.Build.MaxTrades = 500000
	}
	if c.Build.MaxTokens == 0 {
		c.Build.MaxTokens = 5000
	}
	if c.Build.MaxPairsPerGrp == 0 {
		c.Build.MaxPairsPerGrp = 200
	}
	if c.Build.MinEdgeConf == 0 {
		c.Build.MinEdgeConf = 0.8
	}
	if c.Build.MinCoHolders == 0 {
		c.Build.MinCoHolders = 3
	}
	if c.Build.PageRankIters == 0 {
		c.Build.PageRankIters = 30
	}
	if c.Build.CacheTTL == 0 {
		c.Build.CacheTTL = 30 * time.Second
	}
	if c.Kafka.GroupID == "" {
		c.Kafka.GroupID = "coindex-graph-engine"
	}
}

func (c *Config) validate() error {
	if len(c.ClickHouse.Addrs) == 0 {
		return fmt.Errorf("clickhouse.addrs empty")
	}
	if c.Postgres.DSN == "" {
		return fmt.Errorf("postgres.dsn empty")
	}
	if c.Redis.Addr == "" {
		return fmt.Errorf("redis.addr empty")
	}
	if c.Kafka.Enabled && len(c.Kafka.Brokers) == 0 {
		return fmt.Errorf("kafka.enabled but brokers empty")
	}
	return nil
}
