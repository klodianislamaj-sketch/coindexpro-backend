// Package metrics holds the graph-engine's Prometheus instruments.
package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	Builds = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_graph_builds_total", Help: "Graph build cycles by result.",
	}, []string{"result"})

	BuildDuration = promauto.NewHistogram(prometheus.HistogramOpts{
		Name: "coindex_graph_build_seconds", Help: "Graph build duration.",
		Buckets: []float64{0.5, 1, 5, 15, 30, 60, 120, 300},
	})

	EventsSeen = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_graph_events_seen_total", Help: "Source events observed by the consumer.",
	})

	EdgesWritten = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_graph_edges_written_total", Help: "Edges upserted.",
	})

	APILatency = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name: "coindex_graph_api_seconds", Help: "API latency by route + status.",
		Buckets: prometheus.DefBuckets,
	}, []string{"route", "status"})

	DBErrors = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_graph_db_errors_total", Help: "DB errors.",
	})
)
