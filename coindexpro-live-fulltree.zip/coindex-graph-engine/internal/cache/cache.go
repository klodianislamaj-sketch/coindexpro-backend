// Package cache stores rendered graph query responses in Redis for hot nodes.
package cache

import (
	"context"
	"time"

	"github.com/redis/go-redis/v9"
)

type Cache struct {
	rdb *redis.Client
	ttl time.Duration
}

func New(rdb *redis.Client, ttl time.Duration) *Cache {
	if ttl == 0 {
		ttl = 30 * time.Second
	}
	return &Cache{rdb: rdb, ttl: ttl}
}

func (c *Cache) Get(ctx context.Context, key string) ([]byte, bool) {
	b, err := c.rdb.Get(ctx, "graph:"+key).Bytes()
	if err != nil {
		return nil, false
	}
	return b, true
}

func (c *Cache) Set(ctx context.Context, key string, body []byte) {
	_ = c.rdb.Set(ctx, "graph:"+key, body, c.ttl).Err()
}

func (c *Cache) Ping(ctx context.Context) error { return c.rdb.Ping(ctx).Err() }
func (c *Cache) Close() error                   { return c.rdb.Close() }
