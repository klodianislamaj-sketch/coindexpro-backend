// Package consumer listens for new enriched events and triggers incremental
// graph rebuilds. It does not itself fabricate edges — it simply signals the
// builder to re-run over the freshest real data within a debounce window, so the
// graph stays current without rebuilding on every single message.
package consumer

import (
	"context"
	"time"

	"github.com/twmb/franz-go/pkg/kgo"
	"go.uber.org/zap"

	"github.com/coindexpro/coindex-graph-engine/internal/metrics"
)

// Rebuilder is satisfied by the graph.Builder (BuildOnce).
type Rebuilder interface {
	BuildOnce(ctx context.Context) error
}

type Consumer struct {
	cl       *kgo.Client
	builder  Rebuilder
	debounce time.Duration
	log      *zap.Logger
}

func New(brokers []string, groupID string, topics []string, builder Rebuilder, debounce time.Duration, log *zap.Logger) (*Consumer, error) {
	cl, err := kgo.NewClient(
		kgo.SeedBrokers(brokers...),
		kgo.ConsumerGroup(groupID),
		kgo.ConsumeTopics(topics...),
	)
	if err != nil {
		return nil, err
	}
	if debounce <= 0 {
		debounce = 30 * time.Second
	}
	return &Consumer{cl: cl, builder: builder, debounce: debounce, log: log}, nil
}

// Run drains messages and, when activity is seen, schedules a debounced rebuild.
// Messages only act as a "something changed" signal; the rebuild reads real data
// from the source tables, so no message payload is trusted as graph truth.
func (c *Consumer) Run(ctx context.Context) error {
	dirty := false
	timer := time.NewTimer(c.debounce)
	timer.Stop()
	for {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		// poll with a short deadline so we can service the debounce timer
		pollCtx, cancel := context.WithTimeout(ctx, time.Second)
		fetches := c.cl.PollFetches(pollCtx)
		cancel()
		n := 0
		fetches.EachRecord(func(_ *kgo.Record) { n++ })
		if n > 0 {
			metrics.EventsSeen.Add(float64(n))
			if !dirty {
				dirty = true
				timer.Reset(c.debounce)
			}
		}
		select {
		case <-timer.C:
			if dirty {
				dirty = false
				start := time.Now()
				if err := c.builder.BuildOnce(ctx); err != nil {
					c.log.Warn("incremental rebuild failed", zap.Error(err))
					metrics.Builds.WithLabelValues("error").Inc()
				} else {
					metrics.Builds.WithLabelValues("ok").Inc()
					metrics.BuildDuration.Observe(time.Since(start).Seconds())
				}
			}
		default:
		}
	}
}

func (c *Consumer) Close() { c.cl.Close() }
