package db

import (
	"context"
	"encoding/json"
	"strings"
	"time"

	"github.com/ClickHouse/clickhouse-go/v2"
	"github.com/ClickHouse/clickhouse-go/v2/lib/driver"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

)

type Store struct {
	ch driver.Conn
	pg *pgxpool.Pool
}

func Open(ctx context.Context, chAddrs []string, chDB, chUser, chPass, pgDSN string) (*Store, error) {
	ch, err := clickhouse.Open(&clickhouse.Options{
		Addr: chAddrs,
		Auth: clickhouse.Auth{Database: chDB, Username: chUser, Password: chPass},
	})
	if err != nil {
		return nil, err
	}
	if err := ch.Ping(ctx); err != nil {
		return nil, err
	}
	pg, err := pgxpool.New(ctx, pgDSN)
	if err != nil {
		return nil, err
	}
	if err := pg.Ping(ctx); err != nil {
		return nil, err
	}
	return &Store{ch: ch, pg: pg}, nil
}

func (s *Store) Close() {
	_ = s.ch.Close()
	s.pg.Close()
}
func (s *Store) Ping(ctx context.Context) error {
	if err := s.ch.Ping(ctx); err != nil {
		return err
	}
	return s.pg.Ping(ctx)
}

// ---------- Sources (reads of real data) ----------

func (s *Store) RecentTrades(ctx context.Context, since time.Time, limit int) ([]TradeEvent, error) {
	const q = `
		SELECT chain, wallet, token, side, tx_hash, block_number, toUnixTimestamp(block_time)
		FROM coindex.wallet_trades
		WHERE block_time >= ?
		ORDER BY block_time DESC
		LIMIT ?`
	rows, err := s.ch.Query(ctx, q, since, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []TradeEvent
	for rows.Next() {
		var t TradeEvent
		var ts int64
		if err := rows.Scan(&t.Chain, &t.Wallet, &t.Token, &t.Side, &t.TxHash, &t.Block, &ts); err != nil {
			return nil, err
		}
		t.BucketTS = ts / 3600 // 1-hour co-occurrence bucket
		out = append(out, t)
	}
	return out, rows.Err()
}

func (s *Store) TokenHolderSets(ctx context.Context, since time.Time, maxTokens int) ([]TokenHolders, error) {
	// real holder/buyer sets from wallet_trades (buy side) within the window
	const q = `
		SELECT chain, token, wallet
		FROM coindex.wallet_trades
		WHERE block_time >= ? AND side = 'buy'
		LIMIT 2000000`
	rows, err := s.ch.Query(ctx, q, since)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	idx := map[string]*TokenHolders{}
	for rows.Next() {
		var chain, token, wallet string
		if err := rows.Scan(&chain, &token, &wallet); err != nil {
			return nil, err
		}
		key := chain + ":" + token
		th := idx[key]
		if th == nil {
			th = &TokenHolders{Chain: chain, Token: token, Wallets: map[string]bool{}}
			idx[key] = th
		}
		th.Wallets[wallet] = true
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	out := make([]TokenHolders, 0, len(idx))
	for _, th := range idx {
		out = append(out, *th)
		if len(out) >= maxTokens && maxTokens > 0 {
			break
		}
	}
	return out, nil
}

func (s *Store) FundingTransfers(ctx context.Context, since time.Time, limit int) ([]FundingTransfer, error) {
	// native/token transfers that funded a wallet (to = wallet). Real transfers.
	const q = `
		SELECT chain, from_address, to_address, tx_hash, coalesce(amount_usd, 0)
		FROM coindex.transfers
		WHERE block_time >= ?
		ORDER BY block_time DESC
		LIMIT ?`
	rows, err := s.ch.Query(ctx, q, since, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []FundingTransfer
	for rows.Next() {
		var f FundingTransfer
		if err := rows.Scan(&f.Chain, &f.From, &f.To, &f.TxHash, &f.AmountUSD); err != nil {
			return nil, err
		}
		out = append(out, f)
	}
	return out, rows.Err()
}

// WalletSignals pulls real PnL / conviction / repeat-buy signals for nodes.
func (s *Store) WalletSignals(ctx context.Context, nodeIDs []string) (map[string]WalletSignal, error) {
	out := map[string]WalletSignal{}
	if len(nodeIDs) == 0 {
		return out, nil
	}
	// realized PnL from wallet_positions; conviction from smart_money_events;
	// repeat buys from wallet_trades. Keyed by node id "<chain>:<wallet>".
	// We query per-chain-wallet via ClickHouse using the address list.
	addrByChain := map[string][]string{}
	for _, id := range nodeIDs {
		chain, addr := splitID(id)
		addrByChain[chain] = append(addrByChain[chain], addr)
	}
	for chain, addrs := range addrByChain {
		// realized PnL
		pnl, err := s.sumPnL(ctx, chain, addrs)
		if err != nil {
			return nil, err
		}
		conv, err := s.maxConviction(ctx, chain, addrs)
		if err != nil {
			return nil, err
		}
		rep, err := s.repeatBuys(ctx, chain, addrs)
		if err != nil {
			return nil, err
		}
		for _, a := range addrs {
			id := chain + ":" + a
			out[id] = WalletSignal{
				RealizedPnlUSD: pnl[a], Conviction: conv[a], RepeatBuys: rep[a],
			}
		}
	}
	return out, nil
}

func (s *Store) sumPnL(ctx context.Context, chain string, addrs []string) (map[string]float64, error) {
	const q = `SELECT wallet, sum(realized_usd) FROM coindex.wallet_positions FINAL
		WHERE chain = ? AND wallet IN (?) GROUP BY wallet`
	rows, err := s.ch.Query(ctx, q, chain, addrs)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	m := map[string]float64{}
	for rows.Next() {
		var w string
		var v float64
		if err := rows.Scan(&w, &v); err != nil {
			return nil, err
		}
		m[w] = v
	}
	return m, rows.Err()
}

func (s *Store) maxConviction(ctx context.Context, chain string, addrs []string) (map[string]int, error) {
	const q = `SELECT wallet, max(conviction) FROM coindex.smart_money_events
		WHERE chain = ? AND wallet IN (?) GROUP BY wallet`
	rows, err := s.ch.Query(ctx, q, chain, addrs)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	m := map[string]int{}
	for rows.Next() {
		var w string
		var v uint8
		if err := rows.Scan(&w, &v); err != nil {
			return nil, err
		}
		m[w] = int(v)
	}
	return m, rows.Err()
}

func (s *Store) repeatBuys(ctx context.Context, chain string, addrs []string) (map[string]int, error) {
	const q = `SELECT wallet, count() FROM coindex.wallet_trades
		WHERE chain = ? AND wallet IN (?) AND side='buy' GROUP BY wallet`
	rows, err := s.ch.Query(ctx, q, chain, addrs)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	m := map[string]int{}
	for rows.Next() {
		var w string
		var v uint64
		if err := rows.Scan(&w, &v); err != nil {
			return nil, err
		}
		m[w] = int(v)
	}
	return m, rows.Err()
}

// SourceLabel resolves a funding source's label from Postgres wallet_labels.
// Returns ok=false when unlabeled (caller emits funded_unknown — no fabrication).
func (s *Store) SourceLabel(chain, addr string) (SourceLabel, bool) {
	const q = `SELECT label_type, confidence FROM wallet_labels
		WHERE chain=$1 AND address=$2 AND active ORDER BY confidence DESC LIMIT 1`
	var class string
	var conf float64
	err := s.pg.QueryRow(context.Background(), q, chain, strings.ToLower(addr)).Scan(&class, &conf)
	if err != nil {
		return SourceLabel{}, false
	}
	return SourceLabel{Class: class, Confidence: conf}, true
}

// ---------- Sink (idempotent writes) ----------

func (s *Store) UpsertNodesFromEdges(ctx context.Context, edges []Edge) error {
	seen := map[string]bool{}
	tx, err := s.pg.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	for _, e := range edges {
		for _, id := range []string{e.Src, e.Dst} {
			if seen[id] {
				continue
			}
			seen[id] = true
			chain, addr := splitID(id)
			kind := "wallet"
			// token nodes are the dst of buy/sell/co_held edges
			if isTokenNodeContext(e, id) {
				kind = "token"
			}
			const q = `INSERT INTO graph_nodes (id, chain, address, kind) VALUES ($1,$2,$3,$4)
				ON CONFLICT (id) DO UPDATE SET updated_at = now()`
			if _, err := tx.Exec(ctx, q, id, chain, addr, kind); err != nil {
				return err
			}
		}
	}
	return tx.Commit(ctx)
}

func (s *Store) UpsertEdges(ctx context.Context, edges []Edge) error {
	if len(edges) == 0 {
		return nil
	}
	tx, err := s.pg.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	for _, e := range edges {
		ev, _ := json.Marshal(e.Evidence)
		const q = `
			INSERT INTO graph_edges (src, dst, edge_type, weight, confidence, certainty, observations, evidence, updated_at)
			VALUES ($1,$2,$3,$4,$5,$6,$7,$8, now())
			ON CONFLICT (src, dst, edge_type) DO UPDATE SET
				weight=$4, confidence=$5, certainty=$6, observations=$7, evidence=$8, updated_at=now()`
		if _, err := tx.Exec(ctx, q, e.Src, e.Dst, e.EdgeType, e.Weight, e.Confidence,
			e.Certainty, e.Observations, ev); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

func (s *Store) ReplaceClusters(ctx context.Context, chain string, clusters []ClusterResult) error {
	tx, err := s.pg.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	if _, err := tx.Exec(ctx, `DELETE FROM wallet_clusters WHERE chain=$1`, chain); err != nil {
		return err
	}
	for _, c := range clusters {
		members, _ := json.Marshal(c.Members)
		var id int64
		if err := tx.QueryRow(ctx,
			`INSERT INTO wallet_clusters (chain, algorithm, size, edge_count, confidence, members)
			 VALUES ($1,'connected_components',$2,$3,$4,$5) RETURNING id`,
			chain, c.Size, c.EdgeCount, c.Confidence, members).Scan(&id); err != nil {
			return err
		}
		for _, m := range c.Members {
			if _, err := tx.Exec(ctx,
				`INSERT INTO wallet_cluster_members (node_id, cluster_id) VALUES ($1,$2)
				 ON CONFLICT (node_id) DO UPDATE SET cluster_id=$2`, m, id); err != nil {
				return err
			}
		}
	}
	return tx.Commit(ctx)
}

func (s *Store) ReplaceInfluence(ctx context.Context, results []InfluenceResult, chainOf func(string) (string, string)) error {
	tx, err := s.pg.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	for _, r := range results {
		chain, addr := chainOf(r.NodeID)
		factors, _ := json.Marshal(r.Factors)
		const q = `
			INSERT INTO wallet_influence (node_id, chain, address, score, rank, factors, updated_at)
			VALUES ($1,$2,$3,$4,$5,$6, now())
			ON CONFLICT (node_id) DO UPDATE SET score=$4, rank=$5, factors=$6, updated_at=now()`
		if _, err := tx.Exec(ctx, q, r.NodeID, chain, addr, r.Score, r.Rank, factors); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

func (s *Store) ReplaceTokenCorrelations(ctx context.Context, corrs []TokenCorrelation) error {
	tx, err := s.pg.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	for _, c := range corrs {
		const q = `
			INSERT INTO token_correlations (token_a, token_b, corr_type, coefficient, co_holders, confidence, updated_at)
			VALUES ($1,$2,$3,$4,$5,$6, now())
			ON CONFLICT (token_a, token_b, corr_type) DO UPDATE SET
				coefficient=$4, co_holders=$5, confidence=$6, updated_at=now()`
		if _, err := tx.Exec(ctx, q, c.TokenA, c.TokenB, c.CorrType, c.Coefficient, c.CoHolders, c.Confidence); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

// ---------- API reads ----------

func (s *Store) WalletEdges(ctx context.Context, nodeID string, limit int) ([]Edge, error) {
	const q = `
		SELECT src, dst, edge_type, weight, confidence, certainty, observations, evidence
		FROM graph_edges WHERE (src=$1 OR dst=$1)
		ORDER BY confidence DESC, weight DESC LIMIT $2`
	return s.queryEdges(ctx, q, nodeID, limit)
}

func (s *Store) TokenCorrelations(ctx context.Context, tokenID string, limit int) ([]TokenCorrelation, error) {
	const q = `
		SELECT token_a, token_b, corr_type, coefficient, co_holders, confidence
		FROM token_correlations WHERE token_a=$1 OR token_b=$1
		ORDER BY coefficient DESC LIMIT $2`
	rows, err := s.pg.Query(ctx, q, tokenID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []TokenCorrelation
	for rows.Next() {
		var c TokenCorrelation
		if err := rows.Scan(&c.TokenA, &c.TokenB, &c.CorrType, &c.Coefficient, &c.CoHolders, &c.Confidence); err != nil {
			return nil, err
		}
		out = append(out, c)
	}
	return out, rows.Err()
}

func (s *Store) Cluster(ctx context.Context, id int64) (Cluster, bool, error) {
	const q = `SELECT id, chain, algorithm, size, edge_count, confidence, members FROM wallet_clusters WHERE id=$1`
	var c Cluster
	var members []byte
	err := s.pg.QueryRow(ctx, q, id).Scan(&c.ID, &c.Chain, &c.Algorithm, &c.Size, &c.EdgeCount, &c.Confidence, &members)
	if err == pgx.ErrNoRows {
		return Cluster{}, false, nil
	}
	if err != nil {
		return Cluster{}, false, err
	}
	_ = json.Unmarshal(members, &c.Members)
	return c, true, nil
}

func (s *Store) Influence(ctx context.Context, nodeID string) (Influence, bool, error) {
	const q = `SELECT node_id, chain, address, score, rank, factors FROM wallet_influence WHERE node_id=$1`
	var inf Influence
	var factors []byte
	err := s.pg.QueryRow(ctx, q, nodeID).Scan(&inf.NodeID, &inf.Chain, &inf.Address, &inf.Score, &inf.Rank, &factors)
	if err == pgx.ErrNoRows {
		return Influence{}, false, nil
	}
	if err != nil {
		return Influence{}, false, err
	}
	_ = json.Unmarshal(factors, &inf.Factors)
	return inf, true, nil
}

func (s *Store) FundingEdges(ctx context.Context, nodeID string, limit int) ([]Edge, error) {
	const q = `
		SELECT src, dst, edge_type, weight, confidence, certainty, observations, evidence
		FROM graph_edges
		WHERE src=$1 AND edge_type IN ('exchange_funded','insider_funded','vc_funded','dev_funded','funded_unknown')
		ORDER BY weight DESC LIMIT $2`
	return s.queryEdges(ctx, q, nodeID, limit)
}

func (s *Store) AllWalletEdges(ctx context.Context, limit int) ([]Edge, error) {
	const q = `
		SELECT src, dst, edge_type, weight, confidence, certainty, observations, evidence
		FROM graph_edges
		WHERE edge_type IN ('co_buy','co_sell','same_block','same_tx','funding_transfer','cluster_overlap')
		ORDER BY confidence DESC LIMIT $1`
	rows, err := s.pg.Query(ctx, q, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanEdges(rows)
}

func (s *Store) queryEdges(ctx context.Context, q, arg string, limit int) ([]Edge, error) {
	rows, err := s.pg.Query(ctx, q, arg, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanEdges(rows)
}

func scanEdges(rows pgx.Rows) ([]Edge, error) {
	var out []Edge
	for rows.Next() {
		var e Edge
		var ev []byte
		if err := rows.Scan(&e.Src, &e.Dst, &e.EdgeType, &e.Weight, &e.Confidence, &e.Certainty, &e.Observations, &ev); err != nil {
			return nil, err
		}
		_ = json.Unmarshal(ev, &e.Evidence)
		out = append(out, e)
	}
	return out, rows.Err()
}

func splitID(id string) (string, string) {
	for i := 0; i < len(id); i++ {
		if id[i] == ':' {
			return id[:i], id[i+1:]
		}
	}
	return "", id
}

func isTokenNodeContext(e Edge, id string) bool {
	// token is the dst of wallet->token edges
	switch e.EdgeType {
	case EdgeBuy, EdgeSell, EdgeRepeatedBuy, EdgeRepeatedSell, EdgeHighConviction:
		return id == e.Dst
	case EdgeCoHeld, EdgeCoBought, EdgeRotation, EdgeSectorLinked:
		return true
	}
	return false
}
