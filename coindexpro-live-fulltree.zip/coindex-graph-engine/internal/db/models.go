// Package db holds the graph persistence layer and the shared types that flow
// through it. Every Edge carries a confidence in [0,1] and a certainty tag
// (definitive | probable) — the engine refuses to construct an edge without one.
package db

import "time"

// Certainty levels. Definitive edges come from exact co-occurrence (same tx,
// same block, an observed transfer). Probable edges come from statistical
// co-occurrence (co-buy across shared tokens) and always carry a coefficient.
const (
	Definitive = "definitive"
	Probable   = "probable"
)

// Edge types.
const (
	// wallet -> token
	EdgeBuy            = "buy"
	EdgeSell           = "sell"
	EdgeRepeatedBuy    = "repeated_buy"
	EdgeRepeatedSell   = "repeated_sell"
	EdgeHighConviction = "high_conviction"
	// wallet -> wallet
	EdgeCoBuy          = "co_buy"
	EdgeCoSell         = "co_sell"
	EdgeSameBlock      = "same_block"
	EdgeSameTx         = "same_tx"
	EdgeFundingTransfer = "funding_transfer"
	EdgeClusterOverlap = "cluster_overlap"
	// wallet -> funding source
	EdgeExchangeFunded = "exchange_funded"
	EdgeInsiderFunded  = "insider_funded"
	EdgeVCFunded       = "vc_funded"
	EdgeDevFunded      = "dev_funded"
	EdgeFundedUnknown  = "funded_unknown"
	// token -> token
	EdgeCoHeld       = "co_held"
	EdgeCoBought     = "co_bought"
	EdgeRotation     = "rotation"
	EdgeSectorLinked = "sector_linked"
)

type Node struct {
	ID      string         `json:"id"`   // "<chain>:<address>"
	Chain   string         `json:"chain"`
	Address string         `json:"address"`
	Kind    string         `json:"kind"` // wallet | token
	Props   map[string]any `json:"props,omitempty"`
}

// Edge is a directed, typed, confidence-bearing relationship.
type Edge struct {
	Src          string         `json:"src"`
	Dst          string         `json:"dst"`
	EdgeType     string         `json:"edge_type"`
	Weight       float64        `json:"weight"`
	Confidence   float64        `json:"confidence"` // REQUIRED, [0,1]
	Certainty    string         `json:"certainty"`  // definitive | probable
	Observations int64          `json:"observations"`
	Evidence     map[string]any `json:"evidence,omitempty"`
}

type Cluster struct {
	ID         int64     `json:"id"`
	Chain      string    `json:"chain"`
	Algorithm  string    `json:"algorithm"`
	Size       int       `json:"size"`
	EdgeCount  int       `json:"edge_count"`
	Confidence float64   `json:"confidence"`
	Members    []string  `json:"members"`
	UpdatedAt  time.Time `json:"updated_at,omitempty"`
}

type Influence struct {
	NodeID  string         `json:"node_id"`
	Chain   string         `json:"chain"`
	Address string         `json:"address"`
	Score   float64        `json:"score"`
	Rank    int            `json:"rank"`
	Factors map[string]any `json:"factors"` // centrality, pnl_weight, conviction_weight, repetition_weight
}

type TokenCorrelation struct {
	TokenA      string  `json:"token_a"`
	TokenB      string  `json:"token_b"`
	CorrType    string  `json:"corr_type"`
	Coefficient float64 `json:"coefficient"`
	CoHolders   int     `json:"co_holders"`
	Confidence  float64 `json:"confidence"`
}

// NodeID builds the canonical node id.
func NodeID(chain, address string) string { return chain + ":" + address }

// ---- algorithm input/output types (shared; live here so graph depends on db
// one-directionally and there is no import cycle) ----

// TradeEvent is one real fill used for graph construction.
type TradeEvent struct {
	Chain    string
	Wallet   string
	Token    string
	Side     string
	TxHash   string
	Block    uint64
	BucketTS int64
}

// TokenHolders is a token's real holder/buyer set.
type TokenHolders struct {
	Chain   string
	Token   string
	Wallets map[string]bool
}

// FundingTransfer is a real observed funding transfer (from -> to).
type FundingTransfer struct {
	Chain     string
	From      string
	To        string
	TxHash    string
	AmountUSD float64
}

// SourceLabel is a funding source's resolved label.
type SourceLabel struct {
	Class      string
	Confidence float64
}

// WalletSignal carries real per-wallet inputs for influence weighting.
type WalletSignal struct {
	RealizedPnlUSD float64
	Conviction     int
	RepeatBuys     int
}

// ClusterResult is one connected component with exposed metadata.
type ClusterResult struct {
	Members    []string
	Size       int
	EdgeCount  int
	Confidence float64
}

// InfluenceResult is a wallet's influence with explainable factors.
type InfluenceResult struct {
	NodeID  string
	Score   float64
	Rank    int
	Factors map[string]any
}

// Neighbor / ExpandResult are traversal outputs.
type Neighbor struct {
	Node       string  `json:"node"`
	EdgeType   string  `json:"edge_type"`
	Confidence float64 `json:"confidence"`
}
type ExpandResult struct {
	Node       string  `json:"node"`
	Depth      int     `json:"depth"`
	ViaType    string  `json:"via_edge_type"`
	Confidence float64 `json:"confidence"`
}
