package graph

import (
	"sort"

	"github.com/coindexpro/coindex-graph-engine/internal/db"
)

// damping is the standard PageRank damping factor.
const damping = 0.85

// Influence computes a PageRank-style score over the weighted wallet-wallet edge
// graph, then blends it with normalized real signals. The blend weights are
// fixed and exposed in each result's factors so the score is fully explainable.
//
// final = 0.50*centrality + 0.25*pnl + 0.15*conviction + 0.10*repetition
//
// centrality is the converged weighted PageRank (provable iterative computation
// over the observed edges). pnl/conviction/repetition are min-max normalized
// across the wallet set — they reflect real measured behaviour, not a guess.
func Influence(edges []db.Edge, signals map[string]db.WalletSignal, iterations int) []db.InfluenceResult {
	// build adjacency (weighted, directed) over wallet-wallet edges only
	out := map[string]map[string]float64{}
	nodes := map[string]bool{}
	for _, e := range edges {
		if !isWalletWalletEdge(e.EdgeType) {
			continue
		}
		w := e.Weight * e.Confidence
		if w <= 0 {
			w = e.Confidence // weight floor so a confident edge always carries signal
		}
		if out[e.Src] == nil {
			out[e.Src] = map[string]float64{}
		}
		out[e.Src][e.Dst] += w
		nodes[e.Src] = true
		nodes[e.Dst] = true
	}
	n := len(nodes)
	if n == 0 {
		return nil
	}

	// init PageRank
	pr := make(map[string]float64, n)
	for node := range nodes {
		pr[node] = 1.0 / float64(n)
	}
	// out-weight sums
	outSum := map[string]float64{}
	for src, dsts := range out {
		for _, w := range dsts {
			outSum[src] += w
		}
	}
	if iterations <= 0 {
		iterations = 30
	}
	for it := 0; it < iterations; it++ {
		next := make(map[string]float64, n)
		var dangling float64
		base := (1 - damping) / float64(n)
		for node := range nodes {
			next[node] = base
		}
		for node := range nodes {
			if outSum[node] == 0 {
				dangling += pr[node] // dangling node mass redistributed
			}
		}
		danglingShare := damping * dangling / float64(n)
		for src, dsts := range out {
			for dst, w := range dsts {
				next[dst] += damping * pr[src] * (w / outSum[src])
			}
		}
		for node := range nodes {
			next[node] += danglingShare
		}
		pr = next
	}

	// normalize centrality to [0,1]
	centrality := minMaxNormalize(pr)
	pnl := minMaxNormalize(extract(signals, nodes, func(s db.WalletSignal) float64 { return s.RealizedPnlUSD }))
	conv := minMaxNormalize(extract(signals, nodes, func(s db.WalletSignal) float64 { return float64(s.Conviction) }))
	rep := minMaxNormalize(extract(signals, nodes, func(s db.WalletSignal) float64 { return float64(s.RepeatBuys) }))

	results := make([]db.InfluenceResult, 0, n)
	for node := range nodes {
		c := centrality[node]
		p := pnl[node]
		cv := conv[node]
		r := rep[node]
		score := 0.50*c + 0.25*p + 0.15*cv + 0.10*r
		results = append(results, db.InfluenceResult{
			NodeID: node, Score: round4(score),
			Factors: map[string]any{
				"centrality":         round4(c),
				"pnl_weight":         round4(p),
				"conviction_weight":  round4(cv),
				"repetition_weight":  round4(r),
				"blend":              "0.50*centrality + 0.25*pnl + 0.15*conviction + 0.10*repetition",
			},
		})
	}
	// rank by score desc
	sort.SliceStable(results, func(i, j int) bool { return results[i].Score > results[j].Score })
	for i := range results {
		results[i].Rank = i + 1
	}
	return results
}

func extract(signals map[string]db.WalletSignal, nodes map[string]bool, f func(db.WalletSignal) float64) map[string]float64 {
	m := make(map[string]float64, len(nodes))
	for node := range nodes {
		if s, ok := signals[node]; ok {
			m[node] = f(s)
		} else {
			m[node] = 0
		}
	}
	return m
}

// minMaxNormalize scales values to [0,1]. If all values are equal, returns 0.5
// for every node (neutral) rather than dividing by zero.
func minMaxNormalize(in map[string]float64) map[string]float64 {
	out := make(map[string]float64, len(in))
	if len(in) == 0 {
		return out
	}
	first := true
	var mn, mx float64
	for _, v := range in {
		if first {
			mn, mx, first = v, v, false
			continue
		}
		if v < mn {
			mn = v
		}
		if v > mx {
			mx = v
		}
	}
	span := mx - mn
	for k, v := range in {
		if span == 0 {
			out[k] = 0.5
		} else {
			out[k] = (v - mn) / span
		}
	}
	return out
}
