// Package graph holds the relationship-construction algorithms. Everything here
// operates on REAL observed edges. Clustering uses connected components — a
// cluster is, by definition, a maximal set of nodes connected by edges at or
// above a confidence threshold, so membership is mathematically provable rather
// than inferred.
package graph

import (
	"sort"

	"github.com/coindexpro/coindex-graph-engine/internal/db"
)

// unionFind is a disjoint-set structure for connected-components clustering.
type unionFind struct {
	parent map[string]string
	rank   map[string]int
}

func newUnionFind() *unionFind {
	return &unionFind{parent: map[string]string{}, rank: map[string]int{}}
}

func (u *unionFind) find(x string) string {
	if _, ok := u.parent[x]; !ok {
		u.parent[x] = x
		return x
	}
	for u.parent[x] != x {
		u.parent[x] = u.parent[u.parent[x]] // path compression
		x = u.parent[x]
	}
	return x
}

func (u *unionFind) union(a, b string) {
	ra, rb := u.find(a), u.find(b)
	if ra == rb {
		return
	}
	if u.rank[ra] < u.rank[rb] {
		ra, rb = rb, ra
	}
	u.parent[rb] = ra
	if u.rank[ra] == u.rank[rb] {
		u.rank[ra]++
	}
}

// Cluster groups nodes into connected components using only edges whose
// confidence >= minConfidence. Cluster confidence is the mean confidence of the
// internal edges (a real, explainable measure of how strongly the component is
// connected). Singletons are dropped (a cluster needs >= 2 members).
func Cluster(edges []db.Edge, minConfidence float64) []db.ClusterResult {
	uf := newUnionFind()
	type pair struct {
		conf float64
	}
	// only wallet-wallet edges participate in wallet clustering
	internal := make([]db.Edge, 0, len(edges))
	for _, e := range edges {
		if !isWalletWalletEdge(e.EdgeType) {
			continue
		}
		if e.Confidence < minConfidence {
			continue
		}
		uf.union(e.Src, e.Dst)
		internal = append(internal, e)
	}

	// gather components
	comp := map[string][]string{}
	seen := map[string]bool{}
	for _, e := range internal {
		for _, n := range []string{e.Src, e.Dst} {
			if seen[n] {
				continue
			}
			seen[n] = true
			root := uf.find(n)
			comp[root] = append(comp[root], n)
		}
	}

	// per-component edge count + confidence sum
	edgeCount := map[string]int{}
	confSum := map[string]float64{}
	for _, e := range internal {
		root := uf.find(e.Src)
		edgeCount[root]++
		confSum[root] += e.Confidence
	}

	var out []db.ClusterResult
	for root, members := range comp {
		if len(members) < 2 {
			continue // not a cluster
		}
		sort.Strings(members)
		ec := edgeCount[root]
		conf := 0.0
		if ec > 0 {
			conf = confSum[root] / float64(ec)
		}
		out = append(out, db.ClusterResult{
			Members: members, Size: len(members), EdgeCount: ec, Confidence: round4(conf),
		})
	}
	// largest clusters first
	sort.SliceStable(out, func(i, j int) bool { return out[i].Size > out[j].Size })
	return out
}

func isWalletWalletEdge(t string) bool {
	switch t {
	case db.EdgeCoBuy, db.EdgeCoSell, db.EdgeSameBlock, db.EdgeSameTx,
		db.EdgeFundingTransfer, db.EdgeClusterOverlap:
		return true
	}
	return false
}

func round4(x float64) float64 { return float64(int(x*10000+0.5)) / 10000 }
