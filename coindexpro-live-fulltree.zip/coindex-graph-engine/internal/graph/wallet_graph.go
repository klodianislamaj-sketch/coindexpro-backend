package graph

import (
	"fmt"

	"github.com/coindexpro/coindex-graph-engine/internal/db"
)

// BuildWalletEdges constructs wallet→wallet edges from real trades. Edges are
// only created from OBSERVED co-occurrence:
//   - same_tx    (definitive): two wallets in the same transaction
//   - same_block (definitive): two wallets trading the same token in the same block
//   - co_buy / co_sell (probable): two wallets on the same side of the same token
//     within the same time bucket; confidence scales with how many distinct
//     tokens they co-traded (a coefficient, never a guess).
//
// maxPerGroup bounds pair generation per (token,bucket) so a popular token cannot
// explode the pair count; the bound is recorded in evidence for honesty.
func BuildWalletEdges(trades []db.TradeEvent, maxPerGroup int) []db.Edge {
	if maxPerGroup <= 0 {
		maxPerGroup = 200
	}
	edgeAgg := map[string]*db.Edge{} // key: src|dst|type

	addObs := func(src, dst, etype, certainty string, conf float64, ev map[string]any) {
		if src == dst {
			return
		}
		if src > dst { // canonical undirected ordering for symmetric relations
			src, dst = dst, src
		}
		key := src + "|" + dst + "|" + etype
		if e, ok := edgeAgg[key]; ok {
			e.Observations++
			if conf > e.Confidence {
				e.Confidence = conf
			}
			e.Weight = float64(e.Observations)
			return
		}
		edgeAgg[key] = &db.Edge{
			Src: src, Dst: dst, EdgeType: etype, Weight: 1, Confidence: conf,
			Certainty: certainty, Observations: 1, Evidence: ev,
		}
	}

	// --- same_tx (definitive): group by tx hash ---
	byTx := map[string][]db.TradeEvent{}
	for _, t := range trades {
		if t.TxHash != "" {
			byTx[t.Chain+":"+t.TxHash] = append(byTx[t.Chain+":"+t.TxHash], t)
		}
	}
	for _, grp := range byTx {
		wallets := distinctWallets(grp)
		genPairs(wallets, maxPerGroup, func(a, b string) {
			addObs(node(grp[0].Chain, a), node(grp[0].Chain, b), db.EdgeSameTx, db.Definitive, 1.0,
				map[string]any{"basis": "same transaction"})
		})
	}

	// --- same_block (definitive): same token + same block ---
	byBlock := map[string][]db.TradeEvent{}
	for _, t := range trades {
		k := fmt.Sprintf("%s:%s:%d", t.Chain, t.Token, t.Block)
		byBlock[k] = append(byBlock[k], t)
	}
	for _, grp := range byBlock {
		wallets := distinctWallets(grp)
		if len(wallets) < 2 {
			continue
		}
		genPairs(wallets, maxPerGroup, func(a, b string) {
			addObs(node(grp[0].Chain, a), node(grp[0].Chain, b), db.EdgeSameBlock, db.Definitive, 0.9,
				map[string]any{"basis": "same token same block", "token": grp[0].Token, "block": grp[0].Block})
		})
	}

	// --- co_buy / co_sell (probable): same token + same side + same time bucket ---
	type grpKey struct {
		chain, token, side string
		bucket             int64
	}
	bySide := map[grpKey][]string{}
	for _, t := range trades {
		k := grpKey{t.Chain, t.Token, t.Side, t.BucketTS}
		bySide[k] = appendDistinct(bySide[k], t.Wallet)
	}
	// count distinct co-traded tokens per wallet pair to form the coefficient
	pairTokens := map[string]map[string]bool{} // pairKey -> set of tokens
	pairSide := map[string]string{}
	pairChain := map[string]string{}
	for k, wallets := range bySide {
		if len(wallets) < 2 {
			continue
		}
		genPairs(wallets, maxPerGroup, func(a, b string) {
			src, dst := node(k.chain, a), node(k.chain, b)
			if src > dst {
				src, dst = dst, src
			}
			pk := src + "|" + dst + "|" + k.side
			if pairTokens[pk] == nil {
				pairTokens[pk] = map[string]bool{}
			}
			pairTokens[pk][k.token] = true
			pairSide[pk] = k.side
			pairChain[pk] = k.chain
		})
	}
	for pk, tokens := range pairTokens {
		shared := len(tokens)
		// confidence coefficient: more shared tokens => stronger (asymptotic to 1)
		conf := 1 - 1.0/float64(1+shared)
		etype := db.EdgeCoBuy
		if pairSide[pk] == "sell" {
			etype = db.EdgeCoSell
		}
		// pk is "src|dst|side"
		var src, dst string
		parts := splitPipe(pk)
		if len(parts) >= 2 {
			src, dst = parts[0], parts[1]
		}
		edgeAgg[pk] = &db.Edge{
			Src: src, Dst: dst, EdgeType: etype, Weight: float64(shared),
			Confidence: round4(conf), Certainty: db.Probable, Observations: int64(shared),
			Evidence: map[string]any{"shared_tokens": shared, "coefficient": round4(conf),
				"basis": "same token, same side, same time bucket"},
		}
	}

	out := make([]db.Edge, 0, len(edgeAgg))
	for _, e := range edgeAgg {
		out = append(out, *e)
	}
	return out
}

func node(chain, addr string) string { return db.NodeID(chain, addr) }

func distinctWallets(g []db.TradeEvent) []string {
	seen := map[string]bool{}
	var out []string
	for _, t := range g {
		if !seen[t.Wallet] {
			seen[t.Wallet] = true
			out = append(out, t.Wallet)
		}
	}
	return out
}

func appendDistinct(s []string, v string) []string {
	for _, x := range s {
		if x == v {
			return s
		}
	}
	return append(s, v)
}

// genPairs yields unordered pairs, capped at maxPer pairs to bound cost.
func genPairs(items []string, maxPer int, fn func(a, b string)) {
	count := 0
	for i := 0; i < len(items); i++ {
		for j := i + 1; j < len(items); j++ {
			if count >= maxPer {
				return
			}
			fn(items[i], items[j])
			count++
		}
	}
}

func splitPipe(s string) []string {
	var out []string
	cur := ""
	for _, c := range s {
		if c == '|' {
			out = append(out, cur)
			cur = ""
			continue
		}
		cur += string(c)
	}
	out = append(out, cur)
	return out
}
