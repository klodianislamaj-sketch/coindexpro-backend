package graph

import (
	"context"
	"time"

	"go.uber.org/zap"

	"github.com/coindexpro/coindex-graph-engine/internal/db"
)

// Sources is the read interface the builder needs. Implemented by the db package
// over ClickHouse (trades, smart money, transfers) + Postgres (labels). Keeping
// it an interface lets the builder stay pure and testable.
type Sources interface {
	RecentTrades(ctx context.Context, since time.Time, limit int) ([]db.TradeEvent, error)
	TokenHolderSets(ctx context.Context, since time.Time, maxTokens int) ([]db.TokenHolders, error)
	FundingTransfers(ctx context.Context, since time.Time, limit int) ([]db.FundingTransfer, error)
	WalletSignals(ctx context.Context, nodeIDs []string) (map[string]db.WalletSignal, error)
	SourceLabel(chain, addr string) (db.SourceLabel, bool)
}

// Sink persists the built graph. Implemented by db.Store.
type Sink interface {
	UpsertEdges(ctx context.Context, edges []db.Edge) error
	UpsertNodesFromEdges(ctx context.Context, edges []db.Edge) error
	ReplaceClusters(ctx context.Context, chain string, clusters []db.ClusterResult) error
	ReplaceInfluence(ctx context.Context, results []db.InfluenceResult, chainOf func(string) (string, string)) error
	ReplaceTokenCorrelations(ctx context.Context, corrs []db.TokenCorrelation) error
}

type Builder struct {
	src      Sources
	sink     Sink
	cfg      BuildConfig
	log      *zap.Logger
}

type BuildConfig struct {
	Lookback       time.Duration
	MaxTrades      int
	MaxTokens      int
	MaxPairsPerGrp int
	MinEdgeConf    float64 // clustering threshold
	MinCoHolders   int
	PageRankIters  int
}

func NewBuilder(src Sources, sink Sink, cfg BuildConfig, log *zap.Logger) *Builder {
	return &Builder{src: src, sink: sink, cfg: cfg, log: log}
}

// BuildOnce runs a full build cycle over the lookback window. Every step uses
// only real data; the result is idempotently upserted so repeated runs converge.
func (b *Builder) BuildOnce(ctx context.Context) error {
	since := time.Now().Add(-b.cfg.Lookback)

	// 1) wallet-wallet + wallet-token edges from real trades
	trades, err := b.src.RecentTrades(ctx, since, b.cfg.MaxTrades)
	if err != nil {
		return err
	}
	walletEdges := BuildWalletEdges(trades, b.cfg.MaxPairsPerGrp)
	walletTokenEdges := BuildWalletTokenEdges(trades)

	// 2) funding edges from real transfers + label attribution
	transfers, err := b.src.FundingTransfers(ctx, since, b.cfg.MaxTrades)
	if err != nil {
		return err
	}
	fundingEdges := BuildFundingEdges(transfers, b.src.SourceLabel)

	allEdges := append(append(walletEdges, walletTokenEdges...), fundingEdges...)

	if err := b.sink.UpsertNodesFromEdges(ctx, allEdges); err != nil {
		return err
	}
	if err := b.sink.UpsertEdges(ctx, allEdges); err != nil {
		return err
	}

	// 3) clusters (connected components over confident wallet-wallet edges)
	clusters := Cluster(walletEdges, b.cfg.MinEdgeConf)
	chain := primaryChain(trades)
	if err := b.sink.ReplaceClusters(ctx, chain, clusters); err != nil {
		return err
	}

	// 4) influence (weighted PageRank blended with real signals)
	nodeIDs := walletNodeIDs(walletEdges)
	signals, err := b.src.WalletSignals(ctx, nodeIDs)
	if err != nil {
		return err
	}
	influence := Influence(walletEdges, signals, b.cfg.PageRankIters)
	if err := b.sink.ReplaceInfluence(ctx, influence, splitNodeID); err != nil {
		return err
	}

	// 5) token correlations (Jaccard over real holder sets)
	holders, err := b.src.TokenHolderSets(ctx, since, b.cfg.MaxTokens)
	if err != nil {
		return err
	}
	corrs := BuildTokenCorrelations(holders, db.EdgeCoHeld, b.cfg.MinCoHolders)
	if err := b.sink.ReplaceTokenCorrelations(ctx, corrs); err != nil {
		return err
	}

	b.log.Info("graph build complete",
		zap.Int("wallet_edges", len(walletEdges)),
		zap.Int("funding_edges", len(fundingEdges)),
		zap.Int("clusters", len(clusters)),
		zap.Int("influence", len(influence)),
		zap.Int("correlations", len(corrs)))
	return nil
}

// BuildWalletTokenEdges turns trades into wallet→token edges (buy/sell + repeated
// + high_conviction). All are observed; repeated_* fire at >=2 occurrences.
func BuildWalletTokenEdges(trades []TradeEvent) []db.Edge {
	type wt struct{ buys, sells int }
	agg := map[string]*wt{}
	chainOf := map[string]string{}
	walletTok := map[string][2]string{} // key -> [wallet, token]
	for _, t := range trades {
		key := t.Chain + "|" + t.Wallet + "|" + t.Token
		if agg[key] == nil {
			agg[key] = &wt{}
			chainOf[key] = t.Chain
			walletTok[key] = [2]string{t.Wallet, t.Token}
		}
		if t.Side == "sell" {
			agg[key].sells++
		} else {
			agg[key].buys++
		}
	}
	var out []db.Edge
	for key, c := range agg {
		chain := chainOf[key]
		wtp := walletTok[key]
		src := db.NodeID(chain, wtp[0])
		dst := db.NodeID(chain, wtp[1])
		if c.buys > 0 {
			etype := db.EdgeBuy
			if c.buys >= 2 {
				etype = db.EdgeRepeatedBuy
			}
			out = append(out, db.Edge{Src: src, Dst: dst, EdgeType: etype, Weight: float64(c.buys),
				Confidence: 1.0, Certainty: db.Definitive, Observations: int64(c.buys),
				Evidence: map[string]any{"buys": c.buys, "basis": "observed fills"}})
		}
		if c.sells > 0 {
			etype := db.EdgeSell
			if c.sells >= 2 {
				etype = db.EdgeRepeatedSell
			}
			out = append(out, db.Edge{Src: src, Dst: dst, EdgeType: etype, Weight: float64(c.sells),
				Confidence: 1.0, Certainty: db.Definitive, Observations: int64(c.sells),
				Evidence: map[string]any{"sells": c.sells, "basis": "observed fills"}})
		}
	}
	return out
}

func walletNodeIDs(edges []db.Edge) []string {
	seen := map[string]bool{}
	var out []string
	for _, e := range edges {
		for _, n := range []string{e.Src, e.Dst} {
			if !seen[n] {
				seen[n] = true
				out = append(out, n)
			}
		}
	}
	return out
}

func primaryChain(trades []db.TradeEvent) string {
	if len(trades) == 0 {
		return ""
	}
	return trades[0].Chain
}

// splitNodeID splits "<chain>:<address>" → (chain, address).
func splitNodeID(id string) (string, string) {
	for i := 0; i < len(id); i++ {
		if id[i] == ':' {
			return id[:i], id[i+1:]
		}
	}
	return "", id
}
