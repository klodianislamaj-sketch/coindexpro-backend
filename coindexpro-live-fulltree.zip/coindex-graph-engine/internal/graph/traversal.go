package graph

import "github.com/coindexpro/coindex-graph-engine/internal/db"

// Adjacency is a lightweight in-memory view of edges for traversal.
type Adjacency struct {
	out map[string][]db.Neighbor
}

// BuildAdjacency indexes edges for traversal (undirected view for wallet graph).
func BuildAdjacency(edges []db.Edge) *Adjacency {
	a := &Adjacency{out: map[string][]db.Neighbor{}}
	for _, e := range edges {
		a.out[e.Src] = append(a.out[e.Src], db.Neighbor{Node: e.Dst, EdgeType: e.EdgeType, Confidence: e.Confidence})
		a.out[e.Dst] = append(a.out[e.Dst], db.Neighbor{Node: e.Src, EdgeType: e.EdgeType, Confidence: e.Confidence})
	}
	return a
}

// Expand does a depth-limited BFS from seed, returning reached nodes with the
// depth and the edge confidence by which they were first reached. minConfidence
// filters weak edges so expansion follows only well-supported relationships.
func (a *Adjacency) Expand(seed string, maxDepth int, minConfidence float64) []db.ExpandResult {
	if maxDepth <= 0 {
		maxDepth = 2
	}
	visited := map[string]bool{seed: true}
	frontier := []string{seed}
	var out []db.ExpandResult
	for depth := 1; depth <= maxDepth; depth++ {
		var next []string
		for _, n := range frontier {
			for _, nb := range a.out[n] {
				if nb.Confidence < minConfidence || visited[nb.Node] {
					continue
				}
				visited[nb.Node] = true
				out = append(out, db.ExpandResult{Node: nb.Node, Depth: depth, ViaType: nb.EdgeType, Confidence: nb.Confidence})
				next = append(next, nb.Node)
			}
		}
		frontier = next
		if len(frontier) == 0 {
			break
		}
	}
	return out
}

// ShortestPath returns the highest-confidence shortest path from->to using BFS
// (fewest hops; among equal hops, the first found). Returns nil if unreachable
// within maxDepth — we report "no path", never a fabricated connection.
func (a *Adjacency) ShortestPath(from, to string, maxDepth int) []db.Neighbor {
	if maxDepth <= 0 {
		maxDepth = 6
	}
	if from == to {
		return []db.Neighbor{}
	}
	type state struct {
		node string
		path []db.Neighbor
	}
	visited := map[string]bool{from: true}
	queue := []state{{node: from}}
	for len(queue) > 0 && len(queue[0].path) < maxDepth {
		cur := queue[0]
		queue = queue[1:]
		for _, nb := range a.out[cur.node] {
			if visited[nb.Node] {
				continue
			}
			newPath := append(append([]db.Neighbor{}, cur.path...), nb)
			if nb.Node == to {
				return newPath
			}
			visited[nb.Node] = true
			queue = append(queue, state{node: nb.Node, path: newPath})
		}
	}
	return nil
}
