package graph

import (
	"github.com/coindexpro/coindex-graph-engine/internal/db"
)

// BuildFundingEdges turns observed transfers into wallet→source edges, attributed
// by the source's REAL label. The transfer itself is definitive (it happened);
// the attribution confidence comes from the label's confidence. An unlabeled
// source yields a 'funded_unknown' edge — we record the observed funding without
// inventing an attribution.
func BuildFundingEdges(transfers []db.FundingTransfer, labelOf func(chain, addr string) (db.SourceLabel, bool)) []db.Edge {
	agg := map[string]*db.Edge{}
	for _, t := range transfers {
		src := db.NodeID(t.Chain, t.To)     // the funded wallet
		dst := db.NodeID(t.Chain, t.From)   // the funding source
		etype := db.EdgeFundedUnknown
		conf := 1.0 // the funding transfer is observed; certainty definitive
		certainty := db.Definitive
		ev := map[string]any{"basis": "observed transfer", "tx": t.TxHash, "amount_usd": t.AmountUSD}

		if lbl, ok := labelOf(t.Chain, t.From); ok && lbl.Class != "" {
			switch lbl.Class {
			case "exchange", "cex_hot":
				etype = db.EdgeExchangeFunded
			case "vc":
				etype = db.EdgeVCFunded
			case "dev", "team":
				etype = db.EdgeDevFunded
			case "insider":
				etype = db.EdgeInsiderFunded
			default:
				etype = db.EdgeFundedUnknown
			}
			// attribution confidence is the label's confidence (probable unless 1.0)
			conf = lbl.Confidence
			if conf < 1.0 {
				certainty = db.Probable
			}
			ev["source_label"] = lbl.Class
			ev["label_confidence"] = lbl.Confidence
		}

		key := src + "|" + dst + "|" + etype
		if e, ok := agg[key]; ok {
			e.Observations++
			e.Weight += t.AmountUSD
			continue
		}
		agg[key] = &db.Edge{
			Src: src, Dst: dst, EdgeType: etype, Weight: t.AmountUSD,
			Confidence: round4(conf), Certainty: certainty, Observations: 1, Evidence: ev,
		}
	}
	out := make([]db.Edge, 0, len(agg))
	for _, e := range agg {
		out = append(out, *e)
	}
	return out
}
