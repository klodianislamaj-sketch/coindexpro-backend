package graph

import (
	"sort"

	"github.com/coindexpro/coindex-graph-engine/internal/db"
)

// BuildTokenCorrelations computes co_held / co_bought correlations between tokens
// via Jaccard( holdersA, holdersB ). Only pairs with at least minCoHolders shared
// wallets are emitted (below that the signal is too thin to be meaningful, so we
// stay silent rather than emit a weak guess). coefficient == confidence here
// because Jaccard is itself the exact, provable measure.
func BuildTokenCorrelations(tokens []db.TokenHolders, corrType string, minCoHolders int) []db.TokenCorrelation {
	if minCoHolders < 1 {
		minCoHolders = 3
	}
	var out []db.TokenCorrelation
	for i := 0; i < len(tokens); i++ {
		for j := i + 1; j < len(tokens); j++ {
			a, b := tokens[i], tokens[j]
			inter, uni := jaccard(a.Wallets, b.Wallets)
			if inter < minCoHolders || uni == 0 {
				continue
			}
			coef := float64(inter) / float64(uni)
			ta := db.NodeID(a.Chain, a.Token)
			tb := db.NodeID(b.Chain, b.Token)
			if ta > tb { // canonical ordering (token_a < token_b per schema CHECK)
				ta, tb = tb, ta
			}
			out = append(out, db.TokenCorrelation{
				TokenA: ta, TokenB: tb, CorrType: corrType,
				Coefficient: round4(coef), CoHolders: inter, Confidence: round4(coef),
			})
		}
	}
	sort.SliceStable(out, func(i, j int) bool { return out[i].Coefficient > out[j].Coefficient })
	return out
}

func jaccard(a, b map[string]bool) (inter, union int) {
	if len(a) > len(b) {
		a, b = b, a
	}
	for w := range a {
		if b[w] {
			inter++
		}
	}
	union = len(a) + len(b) - inter
	return inter, union
}
