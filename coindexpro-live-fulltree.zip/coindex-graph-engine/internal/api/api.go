// Package api serves the graph query endpoints. It reads the stored graph and
// never fabricates a relationship: an unconnected wallet returns
// {available:false}, and an unreachable path returns {available:false,
// reason:"no path within depth"} rather than inventing a link.
package api

import (
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"

	"github.com/coindexpro/coindex-graph-engine/internal/cache"
	"github.com/coindexpro/coindex-graph-engine/internal/db"
	"github.com/coindexpro/coindex-graph-engine/internal/graph"
	"github.com/coindexpro/coindex-graph-engine/internal/metrics"
)

type API struct {
	store *db.Store
	cache *cache.Cache
}

func New(store *db.Store, c *cache.Cache) *API { return &API{store: store, cache: c} }

func (a *API) Register(app *fiber.App) {
	app.Use(a.observe)
	app.Get("/graph/wallet/:address", a.wallet)
	app.Get("/graph/token/:token", a.token)
	app.Get("/graph/cluster/:id", a.cluster)
	app.Get("/graph/influence/:address", a.influence)
	app.Get("/graph/funding/:address", a.funding)
	app.Get("/graph/path/:from/:to", a.path)
}

func (a *API) observe(c *fiber.Ctx) error {
	start := time.Now()
	err := c.Next()
	metrics.APILatency.WithLabelValues(c.Route().Path, statusClass(c.Response().StatusCode())).
		Observe(time.Since(start).Seconds())
	return err
}

var evmAddr = regexp.MustCompile(`^0x[0-9a-fA-F]{40}$`)

// nodeID accepts either a bare 0x address (defaulting chain via ?chain=) or a
// "<chain>:<address>" id.
func nodeID(c *fiber.Ctx, raw string) (string, bool) {
	raw = strings.ToLower(raw)
	if i := strings.IndexByte(raw, ':'); i > 0 {
		addr := raw[i+1:]
		if evmAddr.MatchString(addr) {
			return raw, true
		}
		return "", false
	}
	if !evmAddr.MatchString(raw) {
		return "", false
	}
	chain := strings.ToLower(c.Query("chain", "ethereum"))
	return db.NodeID(chain, raw), true
}

func (a *API) wallet(c *fiber.Ctx) error {
	id, ok := nodeID(c, c.Params("address"))
	if !ok {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid address"})
	}
	edges, err := a.store.WalletEdges(c.UserContext(), id, 500)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(edges) == 0 {
		return c.JSON(fiber.Map{"node": id, "available": false, "reason": "no observed relationships"})
	}
	// optional depth-limited neighbor expansion (?depth=N, hard cap 4)
	if v, derr := strconv.Atoi(c.Query("depth")); derr == nil && v > 1 {
		if v > 4 {
			v = 4
		}
		all, aerr := a.store.AllWalletEdges(c.UserContext(), 200000)
		if aerr != nil {
			metrics.DBErrors.Inc()
			return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
		}
		adj := graph.BuildAdjacency(all)
		expanded := adj.Expand(id, v, 0.0)
		return c.JSON(fiber.Map{"node": id, "available": true, "edges": edges,
			"depth": v, "expanded": expanded})
	}
	return c.JSON(fiber.Map{"node": id, "available": true, "edges": edges})
}

func (a *API) token(c *fiber.Ctx) error {
	id, ok := nodeID(c, c.Params("token"))
	if !ok {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid token"})
	}
	corrs, err := a.store.TokenCorrelations(c.UserContext(), id, 100)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(corrs) == 0 {
		return c.JSON(fiber.Map{"token": id, "available": false, "reason": "no correlations"})
	}
	return c.JSON(fiber.Map{"token": id, "available": true, "correlations": corrs})
}

func (a *API) cluster(c *fiber.Ctx) error {
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid cluster id"})
	}
	cl, ok, err := a.store.Cluster(c.UserContext(), id)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !ok {
		return c.JSON(fiber.Map{"available": false, "reason": "cluster not found"})
	}
	// expose required fields explicitly
	return c.JSON(fiber.Map{
		"available": true, "id": cl.ID, "size": cl.Size,
		"edge_count": cl.EdgeCount, "confidence": cl.Confidence,
		"algorithm": cl.Algorithm, "members": cl.Members,
	})
}

func (a *API) influence(c *fiber.Ctx) error {
	id, ok := nodeID(c, c.Params("address"))
	if !ok {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid address"})
	}
	inf, ok, err := a.store.Influence(c.UserContext(), id)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !ok {
		return c.JSON(fiber.Map{"node": id, "available": false, "reason": "not configured"})
	}
	return c.JSON(fiber.Map{
		"node": id, "available": true,
		"score": inf.Score, "rank": inf.Rank, "factors": inf.Factors,
	})
}

func (a *API) funding(c *fiber.Ctx) error {
	id, ok := nodeID(c, c.Params("address"))
	if !ok {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid address"})
	}
	edges, err := a.store.FundingEdges(c.UserContext(), id, 100)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(edges) == 0 {
		return c.JSON(fiber.Map{"node": id, "available": false, "reason": "no funding sources observed"})
	}
	return c.JSON(fiber.Map{"node": id, "available": true, "funding": edges})
}

func (a *API) path(c *fiber.Ctx) error {
	from, ok1 := nodeID(c, c.Params("from"))
	to, ok2 := nodeID(c, c.Params("to"))
	if !ok1 || !ok2 {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid from/to"})
	}
	maxDepth := 6
	if v, err := strconv.Atoi(c.Query("max_depth")); err == nil && v > 0 && v <= 8 {
		maxDepth = v
	}
	// load the wallet-wallet edge set and run BFS over real edges
	edges, err := a.store.AllWalletEdges(c.UserContext(), 200000)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	adj := graph.BuildAdjacency(edges)
	hops := adj.ShortestPath(from, to, maxDepth)
	if hops == nil {
		return c.JSON(fiber.Map{"from": from, "to": to, "available": false, "reason": "no path within depth"})
	}
	return c.JSON(fiber.Map{"from": from, "to": to, "available": true, "hops": len(hops), "path": hops})
}

func statusClass(code int) string {
	switch {
	case code >= 500:
		return "5xx"
	case code >= 400:
		return "4xx"
	default:
		return "2xx"
	}
}
