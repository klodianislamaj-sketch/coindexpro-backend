-- =============================================================================
-- CoinDex Graph Engine — PostgreSQL schema (Phase 9)
-- =============================================================================
-- Relationship intelligence storage. Every edge REQUIRES a confidence value and
-- records how many real observations support it. Edges are only written from
-- observed data (trades, transfers, same-tx/same-block co-occurrence); nothing
-- is inferred without a provable basis. These tables are distinct from the Phase 2
-- `graph.*` scaffold (no collision); this engine is the authoritative graph store.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- graph_nodes — wallets and tokens that participate in the graph
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS graph_nodes (
    id         text        PRIMARY KEY,             -- "<chain>:<address>"
    chain      text        NOT NULL,
    address    text        NOT NULL CHECK (address = lower(address)),
    kind       text        NOT NULL CHECK (kind IN ('wallet','token')),
    props      jsonb       NOT NULL DEFAULT '{}'::jsonb,
    updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_gn_kind ON graph_nodes (chain, kind);

-- -----------------------------------------------------------------------------
-- graph_edges — directed, typed, CONFIDENCE-REQUIRED relationships
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS graph_edges (
    src         text       NOT NULL,
    dst         text       NOT NULL,
    edge_type   text       NOT NULL CHECK (edge_type IN (
        -- wallet -> token
        'buy','sell','repeated_buy','repeated_sell','high_conviction',
        -- wallet -> wallet
        'co_buy','co_sell','same_block','same_tx','funding_transfer','cluster_overlap',
        -- wallet -> funding source
        'exchange_funded','insider_funded','vc_funded','dev_funded','funded_unknown',
        -- token -> token
        'co_held','co_bought','rotation','sector_linked'
    )),
    weight      numeric    NOT NULL DEFAULT 0,
    confidence  numeric    NOT NULL CHECK (confidence BETWEEN 0 AND 1),  -- REQUIRED on every edge
    certainty   text       NOT NULL CHECK (certainty IN ('definitive','probable')),
    observations bigint    NOT NULL DEFAULT 1 CHECK (observations >= 1),
    evidence    jsonb      NOT NULL DEFAULT '{}'::jsonb,
    updated_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (src, dst, edge_type)
);
CREATE INDEX IF NOT EXISTS idx_ge_src ON graph_edges (src, edge_type);
CREATE INDEX IF NOT EXISTS idx_ge_dst ON graph_edges (dst, edge_type);
CREATE INDEX IF NOT EXISTS idx_ge_conf ON graph_edges (edge_type, confidence DESC);

-- -----------------------------------------------------------------------------
-- wallet_clusters — connected components (provable) with required metadata
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS wallet_clusters (
    id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    chain       text        NOT NULL,
    algorithm   text        NOT NULL CHECK (algorithm IN ('connected_components','louvain')),
    size        integer     NOT NULL CHECK (size >= 1),     -- node count
    edge_count  integer     NOT NULL CHECK (edge_count >= 0),
    confidence  numeric     NOT NULL CHECK (confidence BETWEEN 0 AND 1),  -- avg internal edge confidence
    members     jsonb       NOT NULL,                       -- array of node ids
    updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_wc_chain ON wallet_clusters (chain, size DESC);
-- membership lookup table for fast "which cluster is this wallet in"
CREATE TABLE IF NOT EXISTS wallet_cluster_members (
    node_id    text   NOT NULL,
    cluster_id bigint NOT NULL REFERENCES wallet_clusters(id) ON DELETE CASCADE,
    PRIMARY KEY (node_id)
);
CREATE INDEX IF NOT EXISTS idx_wcm_cluster ON wallet_cluster_members (cluster_id);

-- -----------------------------------------------------------------------------
-- wallet_influence — PageRank-style score with rank + explainable factors
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS wallet_influence (
    node_id    text        PRIMARY KEY,
    chain      text        NOT NULL,
    address    text        NOT NULL,
    score      numeric     NOT NULL CHECK (score BETWEEN 0 AND 1),
    rank       integer     NOT NULL,
    factors    jsonb       NOT NULL,                 -- {centrality, pnl_weight, conviction_weight, repetition_weight}
    updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_wi_rank ON wallet_influence (chain, rank);

-- -----------------------------------------------------------------------------
-- token_correlations — provable co-occurrence between tokens
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS token_correlations (
    token_a     text       NOT NULL,
    token_b     text       NOT NULL,
    corr_type   text       NOT NULL CHECK (corr_type IN ('co_held','co_bought','rotation','sector_linked')),
    coefficient numeric    NOT NULL CHECK (coefficient BETWEEN 0 AND 1),  -- e.g. Jaccard of holder sets
    co_holders  integer    NOT NULL DEFAULT 0,
    confidence  numeric    NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    updated_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (token_a, token_b, corr_type),
    CHECK (token_a < token_b)   -- canonical ordering avoids duplicate (a,b)/(b,a)
);
CREATE INDEX IF NOT EXISTS idx_tc_a ON token_correlations (token_a, coefficient DESC);
