// Command provider-trust is the Phase 5 service entrypoint. It ingests provider
// observations (Kafka and/or HTTP), recomputes trust scores on a schedule,
// publishes weights for the consensus engine, and serves the read API.
package main

import (
	"context"
	"errors"
	"flag"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/compress"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"github.com/redis/go-redis/v9"
	"go.uber.org/zap"

	"github.com/coindexpro/coindex-provider-trust/internal/api"
	"github.com/coindexpro/coindex-provider-trust/internal/cache"
	"github.com/coindexpro/coindex-provider-trust/internal/config"
	"github.com/coindexpro/coindex-provider-trust/internal/consumer"
	"github.com/coindexpro/coindex-provider-trust/internal/db"
	"github.com/coindexpro/coindex-provider-trust/internal/scorer"
)

func main() {
	cfgPath := flag.String("config", "config/config.yaml", "config path")
	flag.Parse()

	cfg, err := config.Load(*cfgPath)
	if err != nil {
		panic(err)
	}
	log, _ := zap.NewProduction()
	defer func() { _ = log.Sync() }()
	log.Info("starting provider-trust")

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	store, err := db.Open(ctx, cfg.Postgres.DSN)
	if err != nil {
		log.Fatal("postgres open failed", zap.Error(err))
	}
	defer store.Close()

	rdb := redis.NewClient(&redis.Options{Addr: cfg.Redis.Addr})
	if err := rdb.Ping(ctx).Err(); err != nil {
		log.Fatal("redis ping failed", zap.Error(err))
	}
	defer func() { _ = rdb.Close() }()
	c := cache.New(rdb, cfg.Scoring.WeightsTTL)

	// Scoring job.
	job := scorer.NewJob(store, c, cfg.Scoring.Window, cfg.Scoring.Interval, cfg.Scoring.Retention, log)
	go job.Run(ctx)

	// Optional Kafka consumer (HTTP ingest always available as a fallback).
	var cons *consumer.Consumer
	if cfg.Kafka.Enabled {
		cons, err = consumer.New(cfg.Kafka.Brokers, cfg.Kafka.GroupID, cfg.Kafka.Topic, store, 500, 2*time.Second, log)
		if err != nil {
			log.Fatal("kafka consumer init failed", zap.Error(err))
		}
		go func() {
			if err := cons.Run(ctx); err != nil && !errors.Is(err, context.Canceled) {
				log.Error("consumer stopped", zap.Error(err))
			}
		}()
		defer cons.Close()
	}

	// API.
	app := fiber.New(fiber.Config{AppName: "coindex-provider-trust"})
	app.Use(compress.New())
	api.New(store, c).Register(app)
	go func() {
		log.Info("api listening", zap.String("addr", cfg.Server.APIAddr))
		if err := app.Listen(cfg.Server.APIAddr); err != nil {
			log.Error("api stopped", zap.Error(err))
		}
	}()

	// Ops server.
	go serveOps(cfg.Server.MetricsAddr, store, rdb, log)

	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
	<-sig
	log.Info("shutting down")
	cancel()
	sc, scCancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer scCancel()
	_ = app.ShutdownWithContext(sc)
}

func serveOps(addr string, store *db.Store, rdb *redis.Client, log *zap.Logger) {
	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ok"))
	})
	mux.HandleFunc("/readyz", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), 3*time.Second)
		defer cancel()
		if err := store.Ping(ctx); err != nil {
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte("postgres down"))
			return
		}
		if err := rdb.Ping(ctx).Err(); err != nil {
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte("redis down"))
			return
		}
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ready"))
	})
	mux.Handle("/metrics", promhttp.Handler())
	srv := &http.Server{Addr: addr, Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Error("ops server failed", zap.Error(err))
	}
}
