package db

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

type Store struct{ pool *pgxpool.Pool }

func Open(ctx context.Context, dsn string) (*Store, error) {
	pool, err := pgxpool.New(ctx, dsn)
	if err != nil {
		return nil, fmt.Errorf("pgx pool: %w", err)
	}
	if err := pool.Ping(ctx); err != nil {
		return nil, fmt.Errorf("pg ping: %w", err)
	}
	return &Store{pool: pool}, nil
}

func (s *Store) Close() { s.pool.Close() }

func (s *Store) Ping(ctx context.Context) error { return s.pool.Ping(ctx) }

// InsertObservations writes a batch of raw observations via COPY for throughput.
// Unknown providers are dropped (the CHECK would reject them anyway) so a bad
// caller cannot poison the table.
func (s *Store) InsertObservations(ctx context.Context, obs []Observation) (int64, error) {
	rows := make([][]any, 0, len(obs))
	for _, o := range obs {
		if !IsProvider(o.Provider) {
			continue
		}
		ts := o.TS
		if ts.IsZero() {
			ts = time.Now().UTC()
		}
		rows = append(rows, []any{
			o.Provider, ts, o.Success, o.TimedOut, o.Errored, o.Stale,
			o.Outlier, o.Disagreed, o.LatencyMS, nullable(o.Chain), nullable(o.Token),
		})
	}
	if len(rows) == 0 {
		return 0, nil
	}
	return s.pool.CopyFrom(ctx,
		pgx.Identifier{"provider_metrics"},
		[]string{"provider", "ts", "success", "timed_out", "errored", "stale",
			"outlier", "disagreed", "latency_ms", "chain", "token"},
		pgx.CopyFromRows(rows))
}

// WindowObservations returns the raw observations for a provider within the
// rolling window, newest first. Latency samples come from these rows so the
// percentiles are exact (not pre-bucketed approximations).
func (s *Store) WindowObservations(ctx context.Context, provider string, window time.Duration) ([]Observation, error) {
	const q = `
		SELECT success, timed_out, errored, stale, outlier, disagreed, latency_ms
		FROM provider_metrics
		WHERE provider = $1 AND ts >= $2`
	rows, err := s.pool.Query(ctx, q, provider, time.Now().Add(-window))
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []Observation
	for rows.Next() {
		var o Observation
		if err := rows.Scan(&o.Success, &o.TimedOut, &o.Errored, &o.Stale,
			&o.Outlier, &o.Disagreed, &o.LatencyMS); err != nil {
			return nil, err
		}
		out = append(out, o)
	}
	return out, rows.Err()
}

// UpsertScore writes the latest score for a provider and appends to history.
func (s *Store) UpsertScore(ctx context.Context, sc Score) error {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)

	const up = `
		INSERT INTO provider_scores (provider, window_seconds, samples,
			uptime_score, freshness_score, accuracy_score, latency_score, total_weight,
			p50_ms, p95_ms, p99_ms, stale_rate, disagreement_rate, outlier_rate,
			timeout_rate, error_rate, computed_at)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16, now())
		ON CONFLICT (provider) DO UPDATE SET
			window_seconds=$2, samples=$3, uptime_score=$4, freshness_score=$5,
			accuracy_score=$6, latency_score=$7, total_weight=$8, p50_ms=$9, p95_ms=$10,
			p99_ms=$11, stale_rate=$12, disagreement_rate=$13, outlier_rate=$14,
			timeout_rate=$15, error_rate=$16, computed_at=now()`
	if _, err := tx.Exec(ctx, up, sc.Provider, sc.WindowSeconds, sc.Samples,
		sc.UptimeScore, sc.FreshnessScore, sc.AccuracyScore, sc.LatencyScore, sc.TotalWeight,
		sc.P50MS, sc.P95MS, sc.P99MS, sc.StaleRate, sc.DisagreementRate, sc.OutlierRate,
		sc.TimeoutRate, sc.ErrorRate); err != nil {
		return err
	}
	const hist = `
		INSERT INTO provider_score_history (provider, total_weight, uptime_score, accuracy_score)
		VALUES ($1,$2,$3,$4)`
	if _, err := tx.Exec(ctx, hist, sc.Provider, sc.TotalWeight, sc.UptimeScore, sc.AccuracyScore); err != nil {
		return err
	}
	return tx.Commit(ctx)
}

// Scores returns the latest score for every provider that has one.
func (s *Store) Scores(ctx context.Context) ([]Score, error) {
	const q = `
		SELECT provider, window_seconds, samples, uptime_score, freshness_score,
		       accuracy_score, latency_score, total_weight, p50_ms, p95_ms, p99_ms,
		       stale_rate, disagreement_rate, outlier_rate, timeout_rate, error_rate, computed_at
		FROM provider_scores ORDER BY total_weight DESC`
	rows, err := s.pool.Query(ctx, q)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []Score
	for rows.Next() {
		sc, e := scanScore(rows)
		if e != nil {
			return nil, e
		}
		out = append(out, sc)
	}
	return out, rows.Err()
}

// Score returns one provider's score (ok=false if none computed yet).
func (s *Store) Score(ctx context.Context, provider string) (Score, bool, error) {
	const q = `
		SELECT provider, window_seconds, samples, uptime_score, freshness_score,
		       accuracy_score, latency_score, total_weight, p50_ms, p95_ms, p99_ms,
		       stale_rate, disagreement_rate, outlier_rate, timeout_rate, error_rate, computed_at
		FROM provider_scores WHERE provider = $1`
	rows, err := s.pool.Query(ctx, q, provider)
	if err != nil {
		return Score{}, false, err
	}
	defer rows.Close()
	if !rows.Next() {
		return Score{}, false, nil
	}
	sc, e := scanScore(rows)
	return sc, e == nil, e
}

// OpenIncident opens an incident if one of this (provider, kind) is not already
// open (enforced by the partial unique index → ON CONFLICT DO NOTHING).
func (s *Store) OpenIncident(ctx context.Context, in Incident) error {
	detail, _ := json.Marshal(in.Detail)
	const q = `
		INSERT INTO provider_incidents (provider, kind, severity, detail)
		VALUES ($1,$2,$3,$4)
		ON CONFLICT (provider, kind) WHERE closed_at IS NULL DO NOTHING`
	_, err := s.pool.Exec(ctx, q, in.Provider, in.Kind, in.Severity, detail)
	return err
}

// CloseIncidents closes any open incidents of the given kinds for a provider
// (used when the provider recovers).
func (s *Store) CloseIncidents(ctx context.Context, provider string, kinds []string) error {
	const q = `
		UPDATE provider_incidents SET closed_at = now()
		WHERE provider = $1 AND kind = ANY($2) AND closed_at IS NULL`
	_, err := s.pool.Exec(ctx, q, provider, kinds)
	return err
}

// Prune deletes raw observations older than the retention window.
func (s *Store) Prune(ctx context.Context, retention time.Duration) (int64, error) {
	ct, err := s.pool.Exec(ctx, `DELETE FROM provider_metrics WHERE ts < $1`, time.Now().Add(-retention))
	if err != nil {
		return 0, err
	}
	return ct.RowsAffected(), nil
}

func scanScore(rows pgx.Rows) (Score, error) {
	var sc Score
	err := rows.Scan(&sc.Provider, &sc.WindowSeconds, &sc.Samples, &sc.UptimeScore,
		&sc.FreshnessScore, &sc.AccuracyScore, &sc.LatencyScore, &sc.TotalWeight,
		&sc.P50MS, &sc.P95MS, &sc.P99MS, &sc.StaleRate, &sc.DisagreementRate,
		&sc.OutlierRate, &sc.TimeoutRate, &sc.ErrorRate, &sc.ComputedAt)
	return sc, err
}

func nullable(s string) any {
	if s == "" {
		return nil
	}
	return s
}
