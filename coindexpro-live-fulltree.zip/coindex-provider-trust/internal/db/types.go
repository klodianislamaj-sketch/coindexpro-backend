// Package db holds the persistence layer and the shared data types that flow
// through it: Observation (raw telemetry recorded per provider call), Aggregate
// (computed rates + latency percentiles over a window), and Score (the weighted
// trust output). Keeping the structs here lets every package depend on db
// without import cycles.
package db

import "time"

// Providers is the canonical, fixed provider set. The CHECK constraint in the
// migration mirrors this; nothing outside it is accepted (no placeholder
// providers).
var Providers = []string{
	"dexscreener", "geckoterminal", "coingecko", "birdeye", "dextools", "rpc_fallback",
}

// IsProvider reports whether name is a known provider.
func IsProvider(name string) bool {
	for _, p := range Providers {
		if p == name {
			return true
		}
	}
	return false
}

// Observation is one provider call's outcome — the real telemetry unit recorded
// by the consensus engine in Phase 4. Every field is observed, never inferred.
type Observation struct {
	Provider  string    `json:"provider"`
	TS        time.Time `json:"ts"`
	Success   bool      `json:"success"`    // returned a usable price
	TimedOut  bool      `json:"timed_out"`
	Errored   bool      `json:"errored"`
	Stale     bool      `json:"stale"`      // value older than the freshness window
	Outlier   bool      `json:"outlier"`    // rejected by consensus (>10% from median)
	Disagreed bool      `json:"disagreed"`  // differed from consensus but not rejected
	LatencyMS int       `json:"latency_ms"`
	Chain     string    `json:"chain,omitempty"`
	Token     string    `json:"token,omitempty"`
}

// Aggregate is the per-provider summary over a scoring window.
type Aggregate struct {
	Provider         string
	WindowSeconds    int
	Samples          int64
	Successes        int64
	UptimeRate       float64 // successes / samples
	StaleRate        float64
	DisagreementRate float64
	OutlierRate      float64
	TimeoutRate      float64
	ErrorRate        float64
	P50MS            int
	P95MS            int
	P99MS            int
}

// Score is the weighted trust output persisted to provider_scores.
type Score struct {
	Provider         string    `json:"provider"`
	WindowSeconds    int       `json:"window_seconds"`
	Samples          int64     `json:"samples"`
	UptimeScore      float64   `json:"uptime_score"`
	FreshnessScore   float64   `json:"freshness_score"`
	AccuracyScore    float64   `json:"accuracy_score"`
	LatencyScore     float64   `json:"latency_score"`
	TotalWeight      float64   `json:"total_weight"`
	P50MS            int       `json:"p50_ms"`
	P95MS            int       `json:"p95_ms"`
	P99MS            int       `json:"p99_ms"`
	StaleRate        float64   `json:"stale_rate"`
	DisagreementRate float64   `json:"disagreement_rate"`
	OutlierRate      float64   `json:"outlier_rate"`
	TimeoutRate      float64   `json:"timeout_rate"`
	ErrorRate        float64   `json:"error_rate"`
	ComputedAt       time.Time `json:"computed_at"`
}

// Incident is a detected provider degradation.
type Incident struct {
	Provider string         `json:"provider"`
	Kind     string         `json:"kind"`     // down|degraded|stale|high_latency|high_outlier
	Severity string         `json:"severity"` // warning|critical
	Detail   map[string]any `json:"detail"`
}
