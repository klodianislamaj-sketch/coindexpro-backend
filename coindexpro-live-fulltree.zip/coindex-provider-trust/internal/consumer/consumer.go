// Package consumer ingests provider Observations from Kafka (published by the
// Phase 4 enricher's consensus engine) and batch-writes them to provider_metrics.
// Observations are append-only telemetry: re-delivery simply appends duplicate
// rows which the aggregator treats as additional samples — there is no unique
// key to violate, and scoring is over rates, so at-least-once is safe here.
package consumer

import (
	"context"
	"encoding/json"
	"time"

	"github.com/twmb/franz-go/pkg/kgo"
	"go.uber.org/zap"

	"github.com/coindexpro/coindex-provider-trust/internal/db"
	"github.com/coindexpro/coindex-provider-trust/internal/metrics"
)

type Consumer struct {
	cl    *kgo.Client
	store *db.Store
	log   *zap.Logger
	batch int
	flush time.Duration
}

func New(brokers []string, groupID, topic string, store *db.Store, batch int, flush time.Duration, log *zap.Logger) (*Consumer, error) {
	cl, err := kgo.NewClient(
		kgo.SeedBrokers(brokers...),
		kgo.ConsumerGroup(groupID),
		kgo.ConsumeTopics(topic),
		kgo.DisableAutoCommit(),
	)
	if err != nil {
		return nil, err
	}
	if batch <= 0 {
		batch = 500
	}
	if flush <= 0 {
		flush = 2 * time.Second
	}
	return &Consumer{cl: cl, store: store, log: log, batch: batch, flush: flush}, nil
}

// Run polls, accumulates a batch, writes it, then checkpoints. A write failure
// does NOT commit, so the batch is redelivered (safe: observations are additive).
func (c *Consumer) Run(ctx context.Context) error {
	buf := make([]db.Observation, 0, c.batch)
	ticker := time.NewTicker(c.flush)
	defer ticker.Stop()

	flush := func() {
		if len(buf) == 0 {
			return
		}
		if _, err := c.store.InsertObservations(ctx, buf); err != nil {
			metrics.IngestErrors.Inc()
			c.log.Warn("insert observations failed; will retry batch", zap.Error(err))
			return // do not commit; redeliver
		}
		for _, o := range buf {
			metrics.ObservationsIngested.WithLabelValues(o.Provider).Inc()
		}
		if err := c.cl.CommitUncommittedOffsets(ctx); err != nil {
			c.log.Warn("commit failed", zap.Error(err))
		}
		buf = buf[:0]
	}

	for {
		if ctx.Err() != nil {
			flush()
			return ctx.Err()
		}
		fetches := c.cl.PollFetches(ctx)
		fetches.EachRecord(func(r *kgo.Record) {
			var o db.Observation
			if json.Unmarshal(r.Value, &o) != nil || !db.IsProvider(o.Provider) {
				return // drop malformed / unknown-provider silently (counted via ingest errors upstream)
			}
			buf = append(buf, o)
			if len(buf) >= c.batch {
				flush()
			}
		})
		select {
		case <-ticker.C:
			flush()
		default:
		}
	}
}

func (c *Consumer) Close() {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	c.cl.CommitUncommittedOffsets(ctx)
	c.cl.Close()
}
