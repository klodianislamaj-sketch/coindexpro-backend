// Package aggregator turns a window of raw Observations into an Aggregate:
// uptime + the various rates + exact latency percentiles. All arithmetic is over
// real samples; an empty window yields an Aggregate with Samples=0 (the scorer
// then refuses to invent a score).
package aggregator

import (
	"sort"

	"github.com/coindexpro/coindex-provider-trust/internal/db"
)

// Compute folds observations into an Aggregate. window is recorded for context.
func Compute(provider string, windowSeconds int, obs []db.Observation) db.Aggregate {
	a := db.Aggregate{Provider: provider, WindowSeconds: windowSeconds, Samples: int64(len(obs))}
	if len(obs) == 0 {
		return a
	}

	var success, stale, disagreed, outlier, timeout, errored int64
	latencies := make([]int, 0, len(obs))
	for _, o := range obs {
		if o.Success {
			success++
		}
		if o.Stale {
			stale++
		}
		if o.Disagreed {
			disagreed++
		}
		if o.Outlier {
			outlier++
		}
		if o.TimedOut {
			timeout++
		}
		if o.Errored {
			errored++
		}
		// only successful calls contribute a meaningful latency sample
		if o.Success && o.LatencyMS >= 0 {
			latencies = append(latencies, o.LatencyMS)
		}
	}
	n := float64(len(obs))
	a.Successes = success
	a.UptimeRate = float64(success) / n
	a.StaleRate = float64(stale) / n
	a.DisagreementRate = float64(disagreed) / n
	a.OutlierRate = float64(outlier) / n
	a.TimeoutRate = float64(timeout) / n
	a.ErrorRate = float64(errored) / n

	a.P50MS = percentile(latencies, 0.50)
	a.P95MS = percentile(latencies, 0.95)
	a.P99MS = percentile(latencies, 0.99)
	return a
}

// percentile returns the p-th percentile (nearest-rank) of the samples, or 0 if
// there are none. Nearest-rank is exact and deterministic over the real data.
func percentile(samples []int, p float64) int {
	if len(samples) == 0 {
		return 0
	}
	s := append([]int(nil), samples...)
	sort.Ints(s)
	if p <= 0 {
		return s[0]
	}
	if p >= 1 {
		return s[len(s)-1]
	}
	// nearest-rank: rank = ceil(p * N), 1-indexed
	rank := int(p*float64(len(s)) + 0.999999)
	if rank < 1 {
		rank = 1
	}
	if rank > len(s) {
		rank = len(s)
	}
	return s[rank-1]
}
