// Package client is the integration surface for Phase 4. It provides:
//   - Recorder: the enricher's consensus engine calls Record(...) once per
//     provider call to publish an Observation to Kafka (fire-and-forget, never
//     blocks pricing).
//   - WeightProvider: the consensus engine calls Weights() to read the current
//     provider trust weights from Redis and weight each source accordingly.
//
// This package has NO dependency on the service internals (db/store) so Phase 4
// can import it without pulling the whole service.
package client

import (
	"context"
	"encoding/json"
	"time"

	"github.com/redis/go-redis/v9"
	"github.com/twmb/franz-go/pkg/kgo"
)

// Observation mirrors the service's telemetry type (kept local so importers do
// not depend on the service's db package).
type Observation struct {
	Provider  string    `json:"provider"`
	TS        time.Time `json:"ts"`
	Success   bool      `json:"success"`
	TimedOut  bool      `json:"timed_out"`
	Errored   bool      `json:"errored"`
	Stale     bool      `json:"stale"`
	Outlier   bool      `json:"outlier"`
	Disagreed bool      `json:"disagreed"`
	LatencyMS int       `json:"latency_ms"`
	Chain     string    `json:"chain,omitempty"`
	Token     string    `json:"token,omitempty"`
}

// Recorder publishes observations to the trust service's Kafka topic.
type Recorder struct {
	cl    *kgo.Client
	topic string
}

func NewRecorder(brokers []string, topic string) (*Recorder, error) {
	cl, err := kgo.NewClient(kgo.SeedBrokers(brokers...), kgo.ProducerLinger(50*time.Millisecond))
	if err != nil {
		return nil, err
	}
	return &Recorder{cl: cl, topic: topic}, nil
}

// Record publishes one observation. Fire-and-forget: errors are ignored so a
// telemetry hiccup never affects the pricing hot path.
func (r *Recorder) Record(o Observation) {
	if o.TS.IsZero() {
		o.TS = time.Now().UTC()
	}
	b, err := json.Marshal(o)
	if err != nil {
		return
	}
	r.cl.Produce(context.Background(), &kgo.Record{Topic: r.topic, Key: []byte(o.Provider), Value: b}, nil)
}

func (r *Recorder) Close() { r.cl.Close() }

// WeightProvider reads provider trust weights from Redis (published by the
// scoring job). The consensus engine multiplies each provider's vote by its
// weight; an absent weight means "unweighted" (treated as 1.0 by convention),
// never a fabricated value.
type WeightProvider struct{ rdb *redis.Client }

func NewWeightProvider(rdb *redis.Client) *WeightProvider { return &WeightProvider{rdb: rdb} }

// Weights returns provider→weight. Empty map when none published yet.
func (w *WeightProvider) Weights(ctx context.Context) (map[string]float64, error) {
	b, err := w.rdb.Get(ctx, "provider:weights").Bytes()
	if err == redis.Nil {
		return map[string]float64{}, nil
	}
	if err != nil {
		return nil, err
	}
	var m map[string]float64
	if err := json.Unmarshal(b, &m); err != nil {
		return nil, err
	}
	return m, nil
}
