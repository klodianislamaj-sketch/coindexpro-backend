package scorer

import (
	"context"
	"time"

	"go.uber.org/zap"

	"github.com/coindexpro/coindex-provider-trust/internal/aggregator"
	"github.com/coindexpro/coindex-provider-trust/internal/cache"
	"github.com/coindexpro/coindex-provider-trust/internal/db"
	"github.com/coindexpro/coindex-provider-trust/internal/metrics"
)

// Job periodically recomputes provider scores from the rolling observation
// window and publishes them to the cache for the consensus engine to consume.
type Job struct {
	store     *db.Store
	cache     *cache.Cache
	window    time.Duration
	interval  time.Duration
	retention time.Duration
	log       *zap.Logger
}

func NewJob(store *db.Store, c *cache.Cache, window, interval, retention time.Duration, log *zap.Logger) *Job {
	return &Job{store: store, cache: c, window: window, interval: interval, retention: retention, log: log}
}

// Run executes one cycle immediately, then every interval until ctx is done.
func (j *Job) Run(ctx context.Context) {
	j.cycle(ctx)
	t := time.NewTicker(j.interval)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			j.cycle(ctx)
		}
	}
}

func (j *Job) cycle(ctx context.Context) {
	windowSecs := int(j.window.Seconds())
	weights := make(map[string]float64)

	for _, provider := range db.Providers {
		obs, err := j.store.WindowObservations(ctx, provider, j.window)
		if err != nil {
			j.log.Warn("window query failed", zap.String("provider", provider), zap.Error(err))
			continue
		}
		agg := aggregator.Compute(provider, windowSecs, obs)

		// reconcile incidents regardless of whether we can score
		open, closeKinds := Incidents(agg)
		for _, in := range open {
			if err := j.store.OpenIncident(ctx, in); err != nil {
				j.log.Warn("open incident failed", zap.Error(err))
			}
			metrics.IncidentsOpen.WithLabelValues(provider, in.Kind).Set(1)
		}
		if len(closeKinds) > 0 {
			_ = j.store.CloseIncidents(ctx, provider, closeKinds)
			for _, k := range closeKinds {
				metrics.IncidentsOpen.WithLabelValues(provider, k).Set(0)
			}
		}

		sc, ok := Score(agg)
		if !ok {
			// too few samples — do NOT write a synthetic score; leave provider
			// without a weight so the consensus engine treats it as unweighted.
			metrics.ProvidersScored.WithLabelValues(provider, "skipped_thin").Inc()
			continue
		}
		if err := j.store.UpsertScore(ctx, sc); err != nil {
			j.log.Warn("upsert score failed", zap.String("provider", provider), zap.Error(err))
			continue
		}
		weights[provider] = sc.TotalWeight
		metrics.ProviderWeight.WithLabelValues(provider).Set(sc.TotalWeight)
		metrics.ProvidersScored.WithLabelValues(provider, "ok").Inc()
	}

	// publish the weight map for the consensus engine (cache + fast read path)
	if len(weights) > 0 {
		j.cache.SetWeights(ctx, weights)
	}

	// prune raw observations beyond retention
	if n, err := j.store.Prune(ctx, j.retention); err == nil && n > 0 {
		j.log.Info("pruned observations", zap.Int64("rows", n))
	}
}
