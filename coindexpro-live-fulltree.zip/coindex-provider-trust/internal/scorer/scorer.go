// Package scorer turns an Aggregate into a Score using the fixed weight formula,
// and decides which incidents to open/close. It never fabricates a score: an
// Aggregate with zero samples returns ok=false, and the caller leaves the
// provider without a score row (the API then reports it unavailable).
package scorer

import (
	"github.com/coindexpro/coindex-provider-trust/internal/db"
)

// Weights are fixed by the Phase 5 spec. Kept as named constants so the formula
// is auditable and cannot silently drift.
const (
	WUptime    = 0.25
	WFreshness = 0.20
	WAccuracy  = 0.35
	WLatency   = 0.20
)

// LatencyFloorMS / LatencyCeilMS bound the latency→score mapping. A p95 at or
// below the floor scores 1.0; at or above the ceiling scores 0.0; linear between.
const (
	LatencyFloorMS = 150
	LatencyCeilMS  = 3000
)

// Thresholds for incident detection (all over real rates, no guessing).
const (
	DownUptime        = 0.50 // uptime below this with samples => provider down
	DegradedUptime    = 0.85
	HighStaleRate     = 0.30
	HighOutlierRate   = 0.25
	HighLatencyP95MS  = 2500
	MinSamplesToScore = 5 // below this the window is too thin to score honestly
)

// Score applies the formula. ok=false when the window is too thin to score
// (fewer than MinSamplesToScore real samples) — we do not invent a weight.
func Score(a db.Aggregate) (db.Score, bool) {
	if a.Samples < MinSamplesToScore {
		return db.Score{}, false
	}

	uptime := clamp01(a.UptimeRate)
	freshness := clamp01(1 - a.StaleRate)
	// accuracy penalizes being the rejected outlier most, disagreement less.
	accuracy := clamp01(1 - (a.OutlierRate*0.7 + a.DisagreementRate*0.3))
	latency := latencyScore(a.P95MS)

	weight := uptime*WUptime + freshness*WFreshness + accuracy*WAccuracy + latency*WLatency

	return db.Score{
		Provider:         a.Provider,
		WindowSeconds:    a.WindowSeconds,
		Samples:          a.Samples,
		UptimeScore:      round4(uptime),
		FreshnessScore:   round4(freshness),
		AccuracyScore:    round4(accuracy),
		LatencyScore:     round4(latency),
		TotalWeight:      round4(clamp01(weight)),
		P50MS:            a.P50MS,
		P95MS:            a.P95MS,
		P99MS:            a.P99MS,
		StaleRate:        round4(a.StaleRate),
		DisagreementRate: round4(a.DisagreementRate),
		OutlierRate:      round4(a.OutlierRate),
		TimeoutRate:      round4(a.TimeoutRate),
		ErrorRate:        round4(a.ErrorRate),
	}, true
}

// Incidents returns the incidents that should be OPEN for this aggregate, plus
// the incident kinds that should be CLOSED (recovered). Caller reconciles with
// the DB (open-if-absent, close-if-recovered).
func Incidents(a db.Aggregate) (open []db.Incident, closeKinds []string) {
	all := []string{"down", "degraded", "stale", "high_latency", "high_outlier"}
	if a.Samples < MinSamplesToScore {
		return nil, nil // not enough data to assert health either way
	}
	active := map[string]bool{}

	switch {
	case a.UptimeRate < DownUptime:
		open = append(open, db.Incident{Provider: a.Provider, Kind: "down", Severity: "critical",
			Detail: map[string]any{"uptime": a.UptimeRate, "samples": a.Samples}})
		active["down"] = true
	case a.UptimeRate < DegradedUptime:
		open = append(open, db.Incident{Provider: a.Provider, Kind: "degraded", Severity: "warning",
			Detail: map[string]any{"uptime": a.UptimeRate}})
		active["degraded"] = true
	}
	if a.StaleRate > HighStaleRate {
		open = append(open, db.Incident{Provider: a.Provider, Kind: "stale", Severity: "warning",
			Detail: map[string]any{"stale_rate": a.StaleRate}})
		active["stale"] = true
	}
	if a.OutlierRate > HighOutlierRate {
		open = append(open, db.Incident{Provider: a.Provider, Kind: "high_outlier", Severity: "warning",
			Detail: map[string]any{"outlier_rate": a.OutlierRate}})
		active["high_outlier"] = true
	}
	if a.P95MS > HighLatencyP95MS {
		open = append(open, db.Incident{Provider: a.Provider, Kind: "high_latency", Severity: "warning",
			Detail: map[string]any{"p95_ms": a.P95MS}})
		active["high_latency"] = true
	}
	for _, k := range all {
		if !active[k] {
			closeKinds = append(closeKinds, k)
		}
	}
	return open, closeKinds
}

func latencyScore(p95 int) float64 {
	if p95 <= LatencyFloorMS {
		return 1
	}
	if p95 >= LatencyCeilMS {
		return 0
	}
	return 1 - float64(p95-LatencyFloorMS)/float64(LatencyCeilMS-LatencyFloorMS)
}

func clamp01(x float64) float64 {
	if x < 0 {
		return 0
	}
	if x > 1 {
		return 1
	}
	return x
}

func round4(x float64) float64 {
	return float64(int(x*10000+0.5)) / 10000
}
