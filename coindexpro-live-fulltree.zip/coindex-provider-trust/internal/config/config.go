// Package config loads provider-trust configuration from YAML with ${ENV} expansion.
package config

import (
	"fmt"
	"os"
	"time"

	"gopkg.in/yaml.v3"
)

type Config struct {
	Server  ServerConfig  `yaml:"server"`
	Postgres PostgresConfig `yaml:"postgres"`
	Redis   RedisConfig   `yaml:"redis"`
	Kafka   KafkaConfig   `yaml:"kafka"`
	Scoring ScoringConfig `yaml:"scoring"`
	Log     LogConfig     `yaml:"log"`
}

type ServerConfig struct {
	APIAddr     string `yaml:"api_addr"`
	MetricsAddr string `yaml:"metrics_addr"`
}
type PostgresConfig struct {
	DSN string `yaml:"dsn"`
}
type RedisConfig struct {
	Addr string `yaml:"addr"`
}
type KafkaConfig struct {
	Brokers []string `yaml:"brokers"`
	GroupID string   `yaml:"group_id"`
	Topic   string   `yaml:"topic"`
	Enabled bool     `yaml:"enabled"`
}
type ScoringConfig struct {
	Window     time.Duration `yaml:"window"`     // rolling window scored over
	Interval   time.Duration `yaml:"interval"`   // how often scores recompute
	Retention  time.Duration `yaml:"retention"`  // raw observation retention
	WeightsTTL time.Duration `yaml:"weights_ttl"`
}
type LogConfig struct {
	Level string `yaml:"level"`
}

func Load(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}
	var c Config
	if err := yaml.Unmarshal([]byte(os.Expand(string(raw), os.Getenv)), &c); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}
	c.defaults()
	return &c, c.validate()
}

func (c *Config) defaults() {
	if c.Server.APIAddr == "" {
		c.Server.APIAddr = ":8091"
	}
	if c.Server.MetricsAddr == "" {
		c.Server.MetricsAddr = ":9103"
	}
	if c.Scoring.Window == 0 {
		c.Scoring.Window = time.Hour
	}
	if c.Scoring.Interval == 0 {
		c.Scoring.Interval = time.Minute
	}
	if c.Scoring.Retention == 0 {
		c.Scoring.Retention = 14 * 24 * time.Hour
	}
	if c.Scoring.WeightsTTL == 0 {
		c.Scoring.WeightsTTL = 2 * time.Minute
	}
	if c.Kafka.GroupID == "" {
		c.Kafka.GroupID = "coindex-provider-trust"
	}
	if c.Kafka.Topic == "" {
		c.Kafka.Topic = "provider.observations"
	}
}

func (c *Config) validate() error {
	if c.Postgres.DSN == "" {
		return fmt.Errorf("postgres.dsn empty")
	}
	if c.Redis.Addr == "" {
		return fmt.Errorf("redis.addr empty")
	}
	if c.Kafka.Enabled && len(c.Kafka.Brokers) == 0 {
		return fmt.Errorf("kafka.enabled but kafka.brokers empty")
	}
	return nil
}
