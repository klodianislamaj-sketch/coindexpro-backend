// Package metrics holds the provider-trust service's Prometheus instruments.
package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	ObservationsIngested = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_pt_observations_ingested_total", Help: "Observations ingested by provider.",
	}, []string{"provider"})

	IngestErrors = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_pt_ingest_errors_total", Help: "Observation ingest failures.",
	})

	ProviderWeight = promauto.NewGaugeVec(prometheus.GaugeOpts{
		Name: "coindex_pt_provider_weight", Help: "Computed total trust weight (0..1) per provider.",
	}, []string{"provider"})

	ProvidersScored = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_pt_providers_scored_total", Help: "Scoring outcomes per provider.",
	}, []string{"provider", "result"})

	IncidentsOpen = promauto.NewGaugeVec(prometheus.GaugeOpts{
		Name: "coindex_pt_incident_open", Help: "1 when an incident of a kind is open for a provider.",
	}, []string{"provider", "kind"})

	APILatency = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name: "coindex_pt_api_seconds", Help: "API latency by route + status.",
		Buckets: prometheus.DefBuckets,
	}, []string{"route", "status"})
)
