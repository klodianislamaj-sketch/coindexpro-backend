// Package cache stores the latest provider weight map in Redis so the Phase 4
// consensus engine can read trust weights with a single fast lookup instead of
// querying Postgres on every price computation.
package cache

import (
	"context"
	"encoding/json"
	"time"

	"github.com/redis/go-redis/v9"
)

const weightsKey = "provider:weights"

type Cache struct {
	rdb *redis.Client
	ttl time.Duration
}

func New(rdb *redis.Client, ttl time.Duration) *Cache {
	if ttl == 0 {
		ttl = 2 * time.Minute
	}
	return &Cache{rdb: rdb, ttl: ttl}
}

// SetWeights publishes the provider→weight map. TTL is a safety net; the scoring
// job refreshes well within it, so a stale map never lingers.
func (c *Cache) SetWeights(ctx context.Context, weights map[string]float64) {
	b, err := json.Marshal(weights)
	if err != nil {
		return
	}
	_ = c.rdb.Set(ctx, weightsKey, b, c.ttl).Err()
}

// GetWeights returns the published map (empty map if none/expired — callers then
// treat every provider as equally weighted rather than failing).
func (c *Cache) GetWeights(ctx context.Context) (map[string]float64, error) {
	b, err := c.rdb.Get(ctx, weightsKey).Bytes()
	if err == redis.Nil {
		return map[string]float64{}, nil
	}
	if err != nil {
		return nil, err
	}
	var m map[string]float64
	if err := json.Unmarshal(b, &m); err != nil {
		return nil, err
	}
	return m, nil
}
