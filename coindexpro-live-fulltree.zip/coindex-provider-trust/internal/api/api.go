// Package api serves the provider-trust read endpoints and an HTTP ingest
// fallback (for callers that prefer POST over Kafka). It never invents data: a
// provider with no computed score returns {available:false, reason:"not configured"}.
package api

import (
	"time"

	"github.com/gofiber/fiber/v2"

	"github.com/coindexpro/coindex-provider-trust/internal/cache"
	"github.com/coindexpro/coindex-provider-trust/internal/db"
	"github.com/coindexpro/coindex-provider-trust/internal/metrics"
)

type API struct {
	store *db.Store
	cache *cache.Cache
}

func New(store *db.Store, c *cache.Cache) *API { return &API{store: store, cache: c} }

// Register wires routes onto the Fiber app.
func (a *API) Register(app *fiber.App) {
	app.Use(a.observe)
	app.Get("/providers", a.listProviders)
	app.Get("/providers/weights", a.weights) // declared before :name so it isn't captured as a name
	app.Get("/providers/:name", a.getProvider)
	app.Post("/observations", a.ingest)
}

func (a *API) observe(c *fiber.Ctx) error {
	start := time.Now()
	err := c.Next()
	metrics.APILatency.WithLabelValues(c.Route().Path, statusClass(c.Response().StatusCode())).
		Observe(time.Since(start).Seconds())
	return err
}

// GET /providers — every provider with a computed score.
func (a *API) listProviders(c *fiber.Ctx) error {
	scores, err := a.store.Scores(c.UserContext())
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	// Include known providers that have NO score yet, marked unavailable, so the
	// response is complete and honest about coverage.
	have := map[string]bool{}
	for _, s := range scores {
		have[s.Provider] = true
	}
	missing := []fiber.Map{}
	for _, p := range db.Providers {
		if !have[p] {
			missing = append(missing, fiber.Map{"provider": p, "available": false, "reason": "not configured"})
		}
	}
	return c.JSON(fiber.Map{"scored": scores, "unscored": missing})
}

// GET /providers/:name — one provider's full score, or unavailable.
func (a *API) getProvider(c *fiber.Ctx) error {
	name := c.Params("name")
	if !db.IsProvider(name) {
		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{"available": false, "reason": "unknown provider"})
	}
	sc, ok, err := a.store.Score(c.UserContext(), name)
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !ok {
		return c.JSON(fiber.Map{"provider": name, "available": false, "reason": "not configured"})
	}
	return c.JSON(sc)
}

// GET /providers/weights — the provider→weight map consumed by the consensus
// engine. Reads the cache (fast path); empty map when nothing computed yet.
func (a *API) weights(c *fiber.Ctx) error {
	w, err := a.cache.GetWeights(c.UserContext())
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	return c.JSON(fiber.Map{"weights": w})
}

// POST /observations — HTTP ingest fallback (alternative to Kafka). Accepts a
// single observation or an array. Unknown providers are rejected.
func (a *API) ingest(c *fiber.Ctx) error {
	var batch []db.Observation
	if err := c.BodyParser(&batch); err != nil {
		var single db.Observation
		if err2 := c.BodyParser(&single); err2 != nil {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid body"})
		}
		batch = []db.Observation{single}
	}
	n, err := a.store.InsertObservations(c.UserContext(), batch)
	if err != nil {
		metrics.IngestErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "ingest failed"})
	}
	for _, o := range batch {
		if db.IsProvider(o.Provider) {
			metrics.ObservationsIngested.WithLabelValues(o.Provider).Inc()
		}
	}
	return c.Status(fiber.StatusAccepted).JSON(fiber.Map{"ingested": n})
}

func statusClass(code int) string {
	switch {
	case code >= 500:
		return "5xx"
	case code >= 400:
		return "4xx"
	default:
		return "2xx"
	}
}
