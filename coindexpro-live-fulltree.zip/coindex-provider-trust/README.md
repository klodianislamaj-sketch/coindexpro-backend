# coindex-provider-trust — Phase 5

Tracks the reliability of every price provider from **real per-call telemetry**
and produces a trust **weight** the Phase 4 consensus engine uses to weight each
source. No synthetic metrics: a provider with too few real observations gets no
score and is reported `available:false`.

## What it does

1. **Ingests observations** — one per provider call, recorded by the Phase 4
   consensus engine (success / timeout / error / stale / outlier / disagreement /
   latency). Via Kafka (`provider.observations`) or `POST /observations`.
2. **Aggregates** a rolling window per provider into uptime + stale/disagreement/
   outlier/timeout/error rates + exact p50/p95/p99 latency (nearest-rank).
3. **Scores** with the fixed formula:
   `weight = uptime·0.25 + freshness·0.20 + accuracy·0.35 + latency·0.20`
   where `freshness = 1 − stale_rate`, `accuracy = 1 − (outlier·0.7 + disagree·0.3)`,
   `latency` maps p95 (150ms→1.0 … 3000ms→0.0).
4. **Detects incidents** (down / degraded / stale / high_latency / high_outlier)
   with an open/close lifecycle.
5. **Publishes weights** to Redis and `GET /providers/weights` for the consensus
   engine.

Providers: `dexscreener, geckoterminal, coingecko, birdeye, dextools, rpc_fallback`
(fixed set, enforced by a DB CHECK — no placeholder providers).

## Folder tree

```
cmd/provider-trust/main.go         wiring, API, ops server, graceful shutdown
config/{config.go, config.yaml}
internal/
  db/{types.go, db.go}             shared types + Postgres persistence (COPY ingest, upsert, incidents, prune)
  aggregator/aggregator.go         rates + exact percentiles from real samples
  scorer/{scorer.go, job.go}       weight formula + incident detection + periodic job
  consumer/consumer.go             Kafka ingest (at-least-once, batch, checkpoint)
  cache/cache.go                   Redis weights publish/read
  api/api.go                       /providers, /providers/:name, /providers/weights, POST /observations
  client/client.go                 Phase 4 integration: Recorder (publish) + WeightProvider (read)
  metrics/metrics.go
migrations/postgres/001_provider_trust.sql
Dockerfile · docker-compose.yml · README.md
```

## Integrating with Phase 4 (consensus engine)

Two-way, via the `internal/client` package (importable without the service internals):

```go
// record one observation per provider call (fire-and-forget)
rec, _ := client.NewRecorder(brokers, "provider.observations")
rec.Record(client.Observation{Provider: "dexscreener", Success: true, LatencyMS: 240})

// weight each provider's vote in consensus
wp := client.NewWeightProvider(rdb)
weights, _ := wp.Weights(ctx)              // {"dexscreener":0.98, ...}; absent => unweighted (1.0)
```

The consensus engine multiplies each provider's vote by its weight; an absent
weight means "unweighted", never a fabricated value.

## Endpoints

`GET /providers` · `GET /providers/:name` · `GET /providers/weights` ·
`POST /observations` · ops: `/healthz` `/readyz` `/metrics`

## Run

```bash
export PROVIDER_TRUST_PG_DSN=... REDIS_ADDR=... KAFKA_BROKERS=...
# apply migrations/postgres/001_provider_trust.sql to the shared Postgres
docker compose up --build
# API: http://localhost:8091   ops: http://localhost:9103
```

## Honest status

- **Real, production-shaped code, NOT compiled or run here** (no Go toolchain, no
  Postgres/Redis/Kafka in the authoring environment). Static-reviewed: imports/
  symbols/signatures resolve, route ordering correct, the `client` package has no
  internal dependencies. The scoring formula and nearest-rank percentiles were
  verified by simulation (healthy→0.98, flaky→0.67, down→0.39). Before production:
  `go build` + `vet` + lint, and an integration run with real observations.
- **This service is only as real as its input.** It computes nothing until the
  Phase 4 consensus engine actually records observations (Kafka or HTTP). With no
  observations, every provider is `available:false` — by design, not a stub.
- **Scores require a minimum sample count** (`MinSamplesToScore = 5`); thinner
  windows are skipped rather than scored on noise — no synthetic weight is written.
