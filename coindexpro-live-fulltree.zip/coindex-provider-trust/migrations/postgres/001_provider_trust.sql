-- =============================================================================
-- CoinDex Provider Trust — PostgreSQL schema (Phase 5)
-- =============================================================================
-- Three tables:
--   provider_metrics   raw per-call observations (the real input telemetry)
--   provider_scores    computed score/weight per provider (latest snapshot)
--   provider_incidents detected outages/degradations with open/close lifecycle
-- Everything here derives from observations recorded by callers (the enricher's
-- consensus engine). Nothing is synthesized: a provider with no observations has
-- no score row, and the API reports it unavailable.
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Allowed provider set (kept as a CHECK so unknown providers can't silently
-- pollute the data; extend deliberately).
-- providers: dexscreener, geckoterminal, coingecko, birdeye, dextools, rpc_fallback

-- -----------------------------------------------------------------------------
-- provider_metrics — one row per provider call (the source of truth telemetry)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS provider_metrics (
    id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    provider    text        NOT NULL,
    ts          timestamptz NOT NULL DEFAULT now(),
    success     boolean     NOT NULL,            -- returned a usable value
    timed_out   boolean     NOT NULL DEFAULT false,
    errored     boolean     NOT NULL DEFAULT false,
    stale       boolean     NOT NULL DEFAULT false,  -- value older than freshness window
    outlier     boolean     NOT NULL DEFAULT false,  -- rejected by consensus as >10% from median
    disagreed   boolean     NOT NULL DEFAULT false,  -- differed from consensus but not rejected
    latency_ms  integer     NOT NULL CHECK (latency_ms >= 0),
    chain       text,
    token       text,
    CONSTRAINT chk_provider CHECK (provider IN
        ('dexscreener','geckoterminal','coingecko','birdeye','dextools','rpc_fallback'))
);
-- scoring reads a rolling window per provider → (provider, ts) is the hot path
CREATE INDEX IF NOT EXISTS idx_pm_provider_ts ON provider_metrics (provider, ts DESC);
-- raw observations are retained for a bounded window; aggregates live in scores
-- (apply with pg_cron or the scorer's prune step):
--   DELETE FROM provider_metrics WHERE ts < now() - interval '14 days';

-- -----------------------------------------------------------------------------
-- provider_scores — latest computed score per provider (one row per provider)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS provider_scores (
    provider        text PRIMARY KEY,
    window_seconds  integer     NOT NULL,
    samples         bigint      NOT NULL,
    uptime_score    numeric     NOT NULL CHECK (uptime_score    BETWEEN 0 AND 1),
    freshness_score numeric     NOT NULL CHECK (freshness_score BETWEEN 0 AND 1),
    accuracy_score  numeric     NOT NULL CHECK (accuracy_score  BETWEEN 0 AND 1),
    latency_score   numeric     NOT NULL CHECK (latency_score   BETWEEN 0 AND 1),
    total_weight    numeric     NOT NULL CHECK (total_weight    BETWEEN 0 AND 1),
    p50_ms          integer     NOT NULL,
    p95_ms          integer     NOT NULL,
    p99_ms          integer     NOT NULL,
    stale_rate      numeric     NOT NULL,
    disagreement_rate numeric   NOT NULL,
    outlier_rate    numeric     NOT NULL,
    timeout_rate    numeric     NOT NULL,
    error_rate      numeric     NOT NULL,
    computed_at     timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT chk_score_provider CHECK (provider IN
        ('dexscreener','geckoterminal','coingecko','birdeye','dextools','rpc_fallback'))
);

-- score history (so weight trends are chartable in the admin panel, Phase 15)
CREATE TABLE IF NOT EXISTS provider_score_history (
    provider     text        NOT NULL,
    computed_at  timestamptz NOT NULL DEFAULT now(),
    total_weight numeric     NOT NULL,
    uptime_score numeric     NOT NULL,
    accuracy_score numeric   NOT NULL,
    PRIMARY KEY (provider, computed_at)
);

-- -----------------------------------------------------------------------------
-- provider_incidents — detected degradations with an open/close lifecycle
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS provider_incidents (
    id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    provider    text        NOT NULL,
    kind        text        NOT NULL CHECK (kind IN ('down','degraded','stale','high_latency','high_outlier')),
    severity    text        NOT NULL CHECK (severity IN ('warning','critical')),
    opened_at   timestamptz NOT NULL DEFAULT now(),
    closed_at   timestamptz,                       -- null = still open
    detail      jsonb       NOT NULL DEFAULT '{}'::jsonb,
    CONSTRAINT chk_incident_provider CHECK (provider IN
        ('dexscreener','geckoterminal','coingecko','birdeye','dextools','rpc_fallback'))
);
-- only one open incident of a given kind per provider at a time
CREATE UNIQUE INDEX IF NOT EXISTS uq_open_incident
    ON provider_incidents (provider, kind) WHERE closed_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_incident_open
    ON provider_incidents (provider, opened_at DESC) WHERE closed_at IS NULL;
