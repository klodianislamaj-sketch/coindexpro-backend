-- =============================================================================
-- CoinDex Replay / Backtest Engine — PostgreSQL migration (Phase 17)
-- =============================================================================
-- Replays a transparent, parameterized trading rule over REAL historical prices
-- and records what it WOULD have returned — using only prices that actually
-- occurred on-chain.
--
-- Real substrate (verified on disk):
--   * wallet_trades.price_usd / block_time (Phase 2, ClickHouse) — the real
--     observed price series for a token over time. Every backtest entry/exit price
--     is one of these real prices; nothing is interpolated or synthesized.
--   * token_registry.symbol (Phase 2) — display only.
--
-- HONESTY RULES enforced by this schema + its writers:
--   * A run is only produced when real priced trades exist in the window; a token
--     with none yields {available:false, reason:"not indexed"} (no row written).
--   * Every backtest_trades row stores a REAL entry_price and exit_price that came
--     from wallet_trades — never a modeled or guessed fill.
--   * data_coverage (count-derived) is exposed so a thin-history backtest is never
--     presented as a robust one.
--   * Any trading cost is an explicit ASSUMPTION (assumptions jsonb), defaulting to
--     zero; it is never a hidden adjustment to real prices.
--
-- All NEW tables (collision-checked); idempotent.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- backtest_runs — one recorded backtest. rule_params + assumptions are stored
-- verbatim so the run is fully reproducible and auditable. Metrics are derived
-- only from the real round-trip trades in backtest_trades.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS backtest_runs (
    run_id        text        PRIMARY KEY,             -- deterministic hash of (chain,token,window,rule,assumptions)
    chain         text        NOT NULL,
    token         text        NOT NULL CHECK (token = lower(token)),
    symbol        text,                                -- token_registry.symbol (may be NULL)
    window_start  timestamptz NOT NULL,
    window_end    timestamptz NOT NULL,
    rule_params   jsonb       NOT NULL,                -- {lookback, entry_threshold_pct, trailing_stop_pct, take_profit_pct, max_hold}
    assumptions   jsonb       NOT NULL DEFAULT '{}'::jsonb, -- {fee_bps} — explicit, not hidden
    price_points  integer     NOT NULL CHECK (price_points >= 0), -- count of REAL prices replayed
    trades        integer     NOT NULL DEFAULT 0 CHECK (trades >= 0),
    wins          integer     NOT NULL DEFAULT 0 CHECK (wins >= 0),
    win_rate      numeric     CHECK (win_rate IS NULL OR (win_rate BETWEEN 0 AND 1)), -- NULL when 0 trades
    total_return  numeric,                             -- compounded; NULL when 0 trades
    avg_return    numeric,                             -- mean per-trade; NULL when 0 trades
    max_drawdown  numeric     CHECK (max_drawdown IS NULL OR max_drawdown <= 0), -- <=0 (a loss depth)
    exposure      numeric     CHECK (exposure IS NULL OR (exposure BETWEEN 0 AND 1)), -- fraction of points in-position
    data_coverage numeric     NOT NULL DEFAULT 0 CHECK (data_coverage BETWEEN 0 AND 1), -- real-data sufficiency
    rationale     text        NOT NULL,
    created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_btr_token ON backtest_runs (chain, token, created_at DESC);

-- -----------------------------------------------------------------------------
-- backtest_trades — the real round-trip trades produced by the replay. Each row's
-- entry_price and exit_price are REAL observed prices from wallet_trades.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS backtest_trades (
    run_id      text        NOT NULL REFERENCES backtest_runs(run_id) ON DELETE CASCADE,
    seq         integer     NOT NULL,
    entry_time  timestamptz NOT NULL,
    entry_price numeric     NOT NULL CHECK (entry_price > 0),
    exit_time   timestamptz NOT NULL,
    exit_price  numeric     NOT NULL CHECK (exit_price > 0),
    return_pct  numeric     NOT NULL,                  -- exit/entry - 1 - fee assumption
    exit_reason text        NOT NULL CHECK (exit_reason IN
                  ('trailing_stop','take_profit','max_hold','series_end')),
    PRIMARY KEY (run_id, seq)
);
CREATE INDEX IF NOT EXISTS idx_btt_run ON backtest_trades (run_id, seq);
