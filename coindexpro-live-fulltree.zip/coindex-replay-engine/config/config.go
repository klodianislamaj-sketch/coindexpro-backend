// Package config loads replay-engine configuration from YAML with ${ENV} expansion.
package config

import (
	"fmt"
	"os"
	"time"

	"gopkg.in/yaml.v3"
)

type Config struct {
	Server     ServerConfig     `yaml:"server"`
	Postgres   PostgresConfig   `yaml:"postgres"`
	ClickHouse ClickHouseConfig `yaml:"clickhouse"`
	Redis      RedisConfig      `yaml:"redis"`
	Backtest   BacktestConfig   `yaml:"backtest"`
	Refresh    RefreshConfig    `yaml:"refresh"`
	Log        LogConfig        `yaml:"log"`
}

type ServerConfig struct {
	APIAddr     string `yaml:"api_addr"`
	MetricsAddr string `yaml:"metrics_addr"`
}
type PostgresConfig struct {
	DSN string `yaml:"dsn"`
}
type ClickHouseConfig struct {
	Addrs    []string `yaml:"addrs"`
	Database string   `yaml:"database"`
	Username string   `yaml:"username"`
	Password string   `yaml:"password"`
}
type RedisConfig struct {
	Addr     string        `yaml:"addr"`
	CacheTTL time.Duration `yaml:"cache_ttl"`
}
type BacktestConfig struct {
	MaxPricePoints int           `yaml:"max_price_points"` // bound per-backtest memory/scan
	DefaultWindow  time.Duration `yaml:"default_window"`   // backtest window when caller omits one
}
type RefreshConfig struct {
	Enabled  bool          `yaml:"enabled"`
	Interval time.Duration `yaml:"interval"`
	Limit    int           `yaml:"limit"`
}
type LogConfig struct {
	Level string `yaml:"level"`
}

func Load(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}
	var c Config
	if err := yaml.Unmarshal([]byte(os.Expand(string(raw), os.Getenv)), &c); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}
	c.defaults()
	return &c, c.validate()
}

func (c *Config) defaults() {
	if c.Server.APIAddr == "" {
		c.Server.APIAddr = ":8103"
	}
	if c.Server.MetricsAddr == "" {
		c.Server.MetricsAddr = ":9115"
	}
	if c.Redis.CacheTTL == 0 {
		c.Redis.CacheTTL = 60 * time.Second
	}
	if c.Backtest.MaxPricePoints == 0 {
		c.Backtest.MaxPricePoints = 50000
	}
	if c.Backtest.DefaultWindow == 0 {
		c.Backtest.DefaultWindow = 30 * 24 * time.Hour
	}
	if c.Refresh.Interval == 0 {
		c.Refresh.Interval = 15 * time.Minute
	}
	if c.Refresh.Limit == 0 {
		c.Refresh.Limit = 200
	}
}

func (c *Config) validate() error {
	if c.Postgres.DSN == "" {
		return fmt.Errorf("postgres.dsn empty")
	}
	if len(c.ClickHouse.Addrs) == 0 {
		return fmt.Errorf("clickhouse.addrs empty")
	}
	if c.Redis.Addr == "" {
		return fmt.Errorf("redis.addr empty")
	}
	return nil
}
