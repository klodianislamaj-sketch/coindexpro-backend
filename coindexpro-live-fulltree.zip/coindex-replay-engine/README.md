## coindex-replay-engine — Phase 17

Replay / backtest engine. It replays a transparent, parameterized trading rule over
**real historical prices** and reports what the rule **would have returned** — using
only prices that actually occurred on-chain. It ingests nothing new; it reads
existing tables.

### The hard honesty core (rules 3 + 9)

Every entry and exit price in a backtest is a **real observed trade price** from
`wallet_trades`. The engine never interpolates, synthesizes, or models a fill price:

- The price series is exactly the priced trades (`price_usd > 0`) in the window,
  ordered by time.
- A token with **no (or too few) real priced trades** in the window returns
  `{available:false, reason:"not indexed"}` — no result is produced.
- "Rule did not fire" is distinct from "not indexed": if real prices exist but the
  rule never triggered, the result is available with **0 trades** (an honest
  "replayed N real prices, no trades").
- Any trading cost is an **explicit assumption** (`fee_bps`, default 0) surfaced on
  every result — it is never a hidden adjustment to the real prices.
- `data_coverage` (derived from the real point count) is exposed so a thin-history
  backtest is never presented as robust. This is a real measured quantity, not a
  fabricated confidence.

### Source-of-truth mapping (verified on disk)

| Input / output | Real source |
|---|---|
| price series | Phase 2 `wallet_trades` (`block_time`, `price_usd > 0`) |
| token symbol | Phase 2 `token_registry.symbol` (display only) |
| backtest PnL | computed from real entry/exit prices that occurred |

### The rule (transparent + reproducible)

A breakout / trailing-stop rule, fully described by `rule_params`:

- **Entry**: enter when price rises `entry_threshold_pct` vs the price `lookback`
  points earlier (momentum breakout).
- **Exit**: whichever fires first — `take_profit_pct` vs entry, `trailing_stop_pct`
  from the peak, or `max_hold` points elapsed; an open position at series end is
  closed at the last real price (`series_end`).

The rule parameters are **user choices** (request inputs), not upstream data. They
are stored verbatim with each run so it is fully reproducible. `run_id` is a
deterministic hash of (chain, token, window, rule, assumptions), so re-running the
same backtest updates in place rather than duplicating.

### Metrics (all from real round-trips)

`trades`, `wins`, `win_rate`, `total_return` (compounded over real round-trips),
`avg_return`, `max_drawdown` (≤ 0, over the equity curve), and `exposure` (fraction
of real points spent in-position). With zero trades the round-trip metrics are null,
not zero-dressed-as-real.

### API

| Route | Purpose |
|---|---|
| `POST /replay/backtest/:chain/:token` | run a backtest (rule params via query); result or not indexed |
| `GET /replay/run/:run_id` | a stored run + its real round-trip trades |
| `GET /replay/explain/:run_id` | rule + assumptions + real per-trade prices + data_coverage |
| `GET /replay/runs/:chain/:token` | recent runs for a token |

Static routes are registered before parameterized ones. Ops: `/healthz`, `/readyz`,
`/metrics`. A scheduler periodically re-runs stored backtests against the latest real
prices so saved results stay current as new real trades land.

### Idempotency & replay

`backtest_runs` upserts on the deterministic `run_id`; `backtest_trades` is replaced
per run inside a transaction. Re-running the same backtest (or the scheduled refresh)
is safe and converges to the same result for the same real history.

### Honest runtime limitations

- **Real, production-shaped code, NOT compiled or run here** (no Go toolchain, no
  Postgres/ClickHouse/Redis, no network). Statically reviewed: imports/symbols/
  interfaces resolve, no import cycle (`db` and `replay` depend only on `models`),
  routes ordered, metrics symbols match references, no dead code, no orphaned
  upstream reads. The rule, exit conditions, metrics, the unavailable path, and the
  "every fill is a real price" invariant were verified by simulation. Before
  production: `go build` + `vet` + lint and an integration run.
- **A backtest is a model of the past, not a promise about the future.** It measures
  how a rule would have performed on the real prices that occurred; it does not
  predict returns.
- **Fills are at observed trade prices, not modeled execution.** The backtest does
  not simulate slippage, partial fills, or market impact beyond the optional explicit
  `fee_bps` assumption — real execution would differ. (Phase 14 models slippage for
  live sizing; it is intentionally not folded into historical fills here, because
  per-moment historical liquidity is not part of this real substrate and modeling it
  would mean inventing it.)
- **Survivorship / coverage caveat.** The price series is whatever the trade index
  actually recorded; a token or period with sparse indexing yields low
  `data_coverage`, which is surfaced rather than hidden. No price is fabricated to
  fill gaps.
- **No fabricated prices, risk, confidence, or fills.** Absent real data is reported
  as `not indexed`; assumptions are explicit; coverage is a real count-derived value.
