// Package api serves the replay/backtest endpoints. A backtest over a token with
// no real priced trades returns {available:false, reason:"not indexed"} — never a
// simulated result on fabricated prices. Rule parameters come from the request
// (they are user choices, not data); every price the backtest acts on is real.
package api

import (
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"

	"github.com/coindexpro/coindex-replay-engine/internal/db"
	"github.com/coindexpro/coindex-replay-engine/internal/metrics"
	"github.com/coindexpro/coindex-replay-engine/internal/models"
	"github.com/coindexpro/coindex-replay-engine/internal/replay"
)

type API struct {
	store      *db.Store
	engine     *replay.Engine
	defaultWin time.Duration
}

func New(store *db.Store, engine *replay.Engine, defaultWindow time.Duration) *API {
	if defaultWindow <= 0 {
		defaultWindow = 30 * 24 * time.Hour
	}
	return &API{store: store, engine: engine, defaultWin: defaultWindow}
}

// Register orders static routes before parameterized ones.
func (a *API) Register(app *fiber.App) {
	app.Use(a.observe)
	app.Get("/replay/run/:run_id", a.run)
	app.Get("/replay/explain/:run_id", a.explain)
	app.Get("/replay/runs/:chain/:token", a.runsForToken)
	app.Post("/replay/backtest/:chain/:token", a.backtest)
}

func (a *API) observe(c *fiber.Ctx) error {
	start := time.Now()
	err := c.Next()
	metrics.APILatency.WithLabelValues(c.Route().Path, statusClass(c.Response().StatusCode())).
		Observe(time.Since(start).Seconds())
	return err
}

var evmAddr = regexp.MustCompile(`^0x[0-9a-fA-F]{40}$`)

func tokenParams(c *fiber.Ctx) (chain, token string, ok bool) {
	chain = strings.ToLower(c.Params("chain"))
	token = strings.ToLower(c.Params("token"))
	if chain == "" || !evmAddr.MatchString(token) {
		return "", "", false
	}
	return chain, token, true
}

func notIndexed(c *fiber.Ctx, extra fiber.Map) error {
	m := fiber.Map{"available": false, "reason": "not indexed"}
	for k, v := range extra {
		m[k] = v
	}
	return c.JSON(m)
}

// parseRule builds rule params + assumptions from query (all user choices, with
// transparent defaults). These are NOT upstream data — they configure the rule.
func parseRule(c *fiber.Ctx) (models.RuleParams, models.Assumptions) {
	rule := models.RuleParams{
		Lookback:          qInt(c, "lookback", 20, 1, 5000),
		EntryThresholdPct: qFloat(c, "entry_threshold_pct", 5, 0, 1000),
		TrailingStopPct:   qFloat(c, "trailing_stop_pct", 10, 0, 100),
		TakeProfitPct:     qFloat(c, "take_profit_pct", 0, 0, 100000),
		MaxHold:           qInt(c, "max_hold", 0, 0, 1000000),
	}
	asm := models.Assumptions{FeeBps: qFloat(c, "fee_bps", 0, 0, 10000)}
	return rule, asm
}

// POST /replay/backtest/:chain/:token
func (a *API) backtest(c *fiber.Ctx) error {
	chain, token, ok := tokenParams(c)
	if !ok {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid chain or token"})
	}
	end := time.Now().UTC()
	start := end.Add(-a.defaultWin)
	if v := c.Query("start"); v != "" {
		if t, err := time.Parse(time.RFC3339, v); err == nil {
			start = t.UTC()
		}
	}
	if v := c.Query("end"); v != "" {
		if t, err := time.Parse(time.RFC3339, v); err == nil {
			end = t.UTC()
		}
	}
	if !end.After(start) {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "end must be after start"})
	}
	rule, asm := parseRule(c)

	res, ok, err := a.engine.RunBacktest(c.UserContext(), chain, token, start, end, rule, asm)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !ok {
		return notIndexed(c, fiber.Map{"chain": chain, "token": token,
			"detail": "no/too-few real priced trades in window to replay"})
	}
	return c.JSON(fiber.Map{"available": true, "result": res})
}

// GET /replay/run/:run_id
func (a *API) run(c *fiber.Ctx) error {
	id := c.Params("run_id")
	res, found, err := a.store.RunByID(c.UserContext(), id)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !found {
		return notIndexed(c, fiber.Map{"run_id": id})
	}
	return c.JSON(fiber.Map{"available": true, "result": res})
}

// GET /replay/explain/:run_id — full breakdown incl. real per-trade prices + assumptions
func (a *API) explain(c *fiber.Ctx) error {
	id := c.Params("run_id")
	res, found, err := a.store.RunByID(c.UserContext(), id)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !found {
		return notIndexed(c, fiber.Map{"run_id": id})
	}
	return c.JSON(fiber.Map{"available": true,
		"run_id": res.RunID, "rule": res.Rule, "assumptions": res.Assumptions,
		"price_points": res.PricePoints, "data_coverage": res.DataCoverage,
		"trades": res.TradesList, "rationale": res.Rationale})
}

// GET /replay/runs/:chain/:token
func (a *API) runsForToken(c *fiber.Ctx) error {
	chain, token, ok := tokenParams(c)
	if !ok {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid chain or token"})
	}
	limit := qInt(c, "limit", 50, 1, 200)
	runs, err := a.store.RunsForToken(c.UserContext(), chain, token, limit)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(runs) == 0 {
		return notIndexed(c, fiber.Map{"chain": chain, "token": token})
	}
	return c.JSON(fiber.Map{"available": true, "runs": runs})
}

func qInt(c *fiber.Ctx, key string, def, lo, hi int) int {
	v := c.Query(key)
	if v == "" {
		return def
	}
	n, err := strconv.Atoi(v)
	if err != nil {
		return def
	}
	if n < lo {
		return lo
	}
	if n > hi {
		return hi
	}
	return n
}

func qFloat(c *fiber.Ctx, key string, def, lo, hi float64) float64 {
	v := c.Query(key)
	if v == "" {
		return def
	}
	f, err := strconv.ParseFloat(v, 64)
	if err != nil {
		return def
	}
	if f < lo {
		return lo
	}
	if f > hi {
		return hi
	}
	return f
}

func statusClass(code int) string {
	switch {
	case code >= 500:
		return "5xx"
	case code >= 400:
		return "4xx"
	default:
		return "2xx"
	}
}
