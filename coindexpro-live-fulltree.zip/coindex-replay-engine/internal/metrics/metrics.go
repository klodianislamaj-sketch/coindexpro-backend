// Package metrics holds the replay-engine's Prometheus instruments. The symbol set
// matches exactly what internal/replay/engine.go and the api reference.
package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	Backtests = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_replay_backtests_total", Help: "Backtests computed over real prices.",
	})
	TradesProduced = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_replay_trades_total", Help: "Real round-trip trades produced by backtests.",
	})
	Skipped = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_replay_skipped_total", Help: "Backtests skipped (no/too-few real prices) by reason.",
	}, []string{"reason"})
	Refreshes = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_replay_refreshes_total", Help: "Stored-backtest refresh cycles.",
	})
	RefreshDuration = promauto.NewHistogram(prometheus.HistogramOpts{
		Name: "coindex_replay_refresh_seconds", Help: "Stored-backtest refresh duration.",
		Buckets: []float64{0.1, 0.5, 1, 5, 15, 30, 60, 120},
	})
	APILatency = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name: "coindex_replay_api_seconds", Help: "API latency by route + status.",
		Buckets: prometheus.DefBuckets,
	}, []string{"route", "status"})
	DBErrors = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_replay_db_errors_total", Help: "DB errors.",
	})
)
