package replay

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"strconv"
	"time"

	"go.uber.org/zap"

	"github.com/coindexpro/coindex-replay-engine/internal/metrics"
	"github.com/coindexpro/coindex-replay-engine/internal/models"
)

// Sources reads real upstream inputs (implemented by db.Store).
type Sources interface {
	PriceSeries(ctx context.Context, chain, token string, start, end time.Time) ([]models.PricePoint, error)
	Symbol(ctx context.Context, chain, token string) (string, error)
	StoredRunDefs(ctx context.Context, limit int) ([]models.BacktestResult, error)
}

// Sink persists backtest outputs (implemented by db.Store).
type Sink interface {
	SaveRun(ctx context.Context, res models.BacktestResult, trades []models.BacktestTrade) error
}

type Engine struct {
	src  Sources
	sink Sink
	log  *zap.Logger
}

func NewEngine(src Sources, sink Sink, log *zap.Logger) *Engine {
	return &Engine{src: src, sink: sink, log: log}
}

// RunBacktest loads the REAL price series for (chain, token) in [start,end], replays
// the rule, and persists the result. ok=false when there is no real price history to
// replay (caller reports not indexed). It never fabricates a price series.
func (e *Engine) RunBacktest(ctx context.Context, chain, token string, start, end time.Time, rule models.RuleParams, asm models.Assumptions) (models.BacktestResult, bool, error) {
	series, err := e.src.PriceSeries(ctx, chain, token, start, end)
	if err != nil {
		return models.BacktestResult{}, false, err
	}
	res, trades, ok := Run(series, rule, asm)
	if !ok {
		metrics.Skipped.WithLabelValues("insufficient_real_prices").Inc()
		return models.BacktestResult{}, false, nil
	}

	sym, err := e.src.Symbol(ctx, chain, token)
	if err != nil {
		return models.BacktestResult{}, false, err
	}
	res.Chain, res.Token, res.Symbol = chain, token, sym
	res.WindowStart, res.WindowEnd = start, end
	res.RunID = RunID(chain, token, start, end, rule, asm)
	res.CreatedAt = time.Now().UTC()
	res.TradesList = trades

	if err := e.sink.SaveRun(ctx, res, trades); err != nil {
		return models.BacktestResult{}, false, err
	}
	metrics.Backtests.Inc()
	metrics.TradesProduced.Add(float64(len(trades)))
	return res, true, nil
}

// RefreshStored re-runs stored backtest definitions against the latest real price
// history, so a saved backtest stays current as new real trades land. Each stored
// run carries its own rule + window, so re-running is well-defined and real.
func (e *Engine) RefreshStored(ctx context.Context, limit int) error {
	defs, err := e.src.StoredRunDefs(ctx, limit)
	if err != nil {
		return err
	}
	t0 := time.Now()
	refreshed := 0
	for _, d := range defs {
		if _, ok, err := e.RunBacktest(ctx, d.Chain, d.Token, d.WindowStart, d.WindowEnd, d.Rule, d.Assumptions); err != nil {
			return err
		} else if ok {
			refreshed++
		}
	}
	metrics.Refreshes.Inc()
	metrics.RefreshDuration.Observe(time.Since(t0).Seconds())
	e.log.Info("stored backtests refreshed", zap.Int("definitions", len(defs)), zap.Int("refreshed", refreshed))
	return nil
}

// RunID is a deterministic id for a backtest: the same inputs always map to the same
// run, so re-running updates in place rather than duplicating.
func RunID(chain, token string, start, end time.Time, rule models.RuleParams, asm models.Assumptions) string {
	h := sha256.New()
	fmt.Fprintf(h, "%s|%s|%d|%d|", chain, token, start.Unix(), end.Unix())
	fmt.Fprintf(h, "lb=%d;et=%s;ts=%s;tp=%s;mh=%d;fee=%s",
		rule.Lookback,
		strconv.FormatFloat(rule.EntryThresholdPct, 'f', -1, 64),
		strconv.FormatFloat(rule.TrailingStopPct, 'f', -1, 64),
		strconv.FormatFloat(rule.TakeProfitPct, 'f', -1, 64),
		rule.MaxHold,
		strconv.FormatFloat(asm.FeeBps, 'f', -1, 64),
	)
	return "bt_" + hex.EncodeToString(h.Sum(nil))[:24]
}
