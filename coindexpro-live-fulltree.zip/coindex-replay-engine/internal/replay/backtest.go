// Package replay holds the backtest engine. It replays a transparent rule over a
// REAL price series (observed wallet_trades prices) and reports what the rule WOULD
// have returned. Every entry and exit price is a real observed price; the only
// non-real input is the explicit, surfaced cost Assumption (default 0). Nothing is
// interpolated or fabricated. A series with too few real points yields ok=false so
// the caller can report it not indexed rather than a meaningless result.
package replay

import (
	"math"

	"github.com/coindexpro/coindex-replay-engine/internal/models"
)

// MinPoints is the minimum number of real price points required to attempt a
// backtest. Below this there is not enough real history to replay meaningfully.
const MinPoints = 10

// CoverageTarget is the point count at which data_coverage reaches 1.0. It scales
// the honesty signal: a backtest over few real points reports low coverage.
const CoverageTarget = 500

// Run replays the rule over a real price series. ok=false when there are too few
// real prices. When the rule never fires, it still returns ok=true with zero
// trades (a real, honest "ran over N prices, no trades") — that is distinct from
// "not indexed" (no real prices at all).
func Run(series []models.PricePoint, rule models.RuleParams, asm models.Assumptions) (models.BacktestResult, []models.BacktestTrade, bool) {
	n := len(series)
	if n < MinPoints {
		return models.BacktestResult{}, nil, false
	}

	feeFrac := asm.FeeBps / 10000.0
	var trades []models.BacktestTrade

	inPos := false
	var entryIdx int
	var entryPrice, peak float64
	pointsInPos := 0
	seq := 0

	for i := 0; i < n; i++ {
		price := series[i].Price
		if price <= 0 {
			continue // defensive: only real positive prices participate
		}

		if !inPos {
			// breakout entry: price rose >= threshold vs the price `lookback` points ago
			if rule.Lookback > 0 && i >= rule.Lookback {
				ref := series[i-rule.Lookback].Price
				if ref > 0 && (price/ref-1)*100 >= rule.EntryThresholdPct {
					inPos = true
					entryIdx = i
					entryPrice = price
					peak = price
					pointsInPos = 1
				}
			}
			continue
		}

		// in position: update peak, count exposure, test exits at the REAL price
		pointsInPos++
		if price > peak {
			peak = price
		}
		exit, reason := shouldExit(price, entryPrice, peak, i-entryIdx, rule)
		if exit {
			seq++
			ret := price/entryPrice - 1 - feeFrac
			trades = append(trades, models.BacktestTrade{
				Seq: seq, EntryTime: series[entryIdx].T, EntryPrice: entryPrice,
				ExitTime: series[i].T, ExitPrice: price, ReturnPct: round6(ret), ExitReason: reason,
			})
			inPos = false
		}
	}

	// close any open position at the last real price (series_end)
	if inPos {
		last := series[n-1]
		seq++
		ret := last.Price/entryPrice - 1 - feeFrac
		trades = append(trades, models.BacktestTrade{
			Seq: seq, EntryTime: series[entryIdx].T, EntryPrice: entryPrice,
			ExitTime: last.T, ExitPrice: last.Price, ReturnPct: round6(ret), ExitReason: models.ExitSeriesEnd,
		})
	}

	res := summarize(series, trades, pointsInPos, rule, asm)
	return res, trades, true
}

// shouldExit decides whether to close at the current REAL price.
func shouldExit(price, entry, peak float64, held int, rule models.RuleParams) (bool, string) {
	if rule.TakeProfitPct > 0 && (price/entry-1)*100 >= rule.TakeProfitPct {
		return true, models.ExitTakeProfit
	}
	if rule.TrailingStopPct > 0 && peak > 0 && (1-price/peak)*100 >= rule.TrailingStopPct {
		return true, models.ExitTrailingStop
	}
	if rule.MaxHold > 0 && held >= rule.MaxHold {
		return true, models.ExitMaxHold
	}
	return false, ""
}

// summarize computes the metrics from the REAL round-trip trades + the equity curve.
func summarize(series []models.PricePoint, trades []models.BacktestTrade, pointsInPos int, rule models.RuleParams, asm models.Assumptions) models.BacktestResult {
	n := len(series)
	res := models.BacktestResult{
		Chain: "", Token: "",
		WindowStart: series[0].T, WindowEnd: series[n-1].T,
		Rule: rule, Assumptions: asm,
		PricePoints:  n,
		Trades:       len(trades),
		DataCoverage: round4(coverage(n)),
	}

	if len(trades) == 0 {
		res.Rationale = "rule did not trigger over the real price series"
		// exposure is 0 with no trades; expose it as a real measured value
		zero := 0.0
		res.Exposure = &zero
		return res
	}

	// equity curve over compounded real round-trip returns -> max drawdown
	equity := 1.0
	peakEq := 1.0
	maxDD := 0.0
	var sum float64
	wins := 0
	for _, t := range trades {
		equity *= (1 + t.ReturnPct)
		if equity > peakEq {
			peakEq = equity
		}
		dd := equity/peakEq - 1 // <= 0
		if dd < maxDD {
			maxDD = dd
		}
		sum += t.ReturnPct
		if t.ReturnPct > 0 {
			wins++
		}
	}
	total := equity - 1
	avg := sum / float64(len(trades))
	wr := float64(wins) / float64(len(trades))
	exp := float64(pointsInPos) / float64(n)
	if exp > 1 {
		exp = 1
	}

	res.Wins = wins
	res.WinRate = ptr(round4(wr))
	res.TotalReturn = ptr(round6(total))
	res.AvgReturn = ptr(round6(avg))
	res.MaxDrawdown = ptr(round6(maxDD))
	res.Exposure = ptr(round4(exp))
	res.Rationale = "replayed transparent breakout/trailing-stop rule over real observed prices"
	return res
}

// coverage maps real point count to [0,1] (sufficiency of real history).
func coverage(points int) float64 {
	if points <= 0 {
		return 0
	}
	c := float64(points) / float64(CoverageTarget)
	if c > 1 {
		return 1
	}
	return c
}

func ptr(f float64) *float64 { return &f }
func round4(x float64) float64 { return math.Round(x*10000) / 10000 }
func round6(x float64) float64 { return math.Round(x*1e6) / 1e6 }
