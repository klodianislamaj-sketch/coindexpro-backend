// Package db is the replay-engine persistence layer. It reads the REAL price
// series from ClickHouse wallet_trades (Phase 2) and token symbols from Postgres
// token_registry (Phase 2), and persists backtest runs + their real round-trip
// trades. The price series is exactly the observed prices; this package never
// fabricates or interpolates a price. Imports only the models package (no cycle).
package db

import (
	"context"
	"encoding/json"
	"errors"
	"strings"
	"time"

	"github.com/ClickHouse/clickhouse-go/v2"
	"github.com/ClickHouse/clickhouse-go/v2/lib/driver"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/coindexpro/coindex-replay-engine/internal/models"
)

type Store struct {
	pg        *pgxpool.Pool
	ch        driver.Conn
	maxPoints int // cap on price points pulled per backtest (bounded memory)
}

func Open(ctx context.Context, pgDSN string, chAddrs []string, chDB, chUser, chPass string, maxPoints int) (*Store, error) {
	pg, err := pgxpool.New(ctx, pgDSN)
	if err != nil {
		return nil, err
	}
	if err := pg.Ping(ctx); err != nil {
		return nil, err
	}
	ch, err := clickhouse.Open(&clickhouse.Options{
		Addr: chAddrs,
		Auth: clickhouse.Auth{Database: chDB, Username: chUser, Password: chPass},
	})
	if err != nil {
		return nil, err
	}
	if err := ch.Ping(ctx); err != nil {
		return nil, err
	}
	if maxPoints <= 0 {
		maxPoints = 50000
	}
	return &Store{pg: pg, ch: ch, maxPoints: maxPoints}, nil
}

func (s *Store) Close() {
	s.pg.Close()
	_ = s.ch.Close()
}
func (s *Store) Ping(ctx context.Context) error {
	if err := s.pg.Ping(ctx); err != nil {
		return err
	}
	return s.ch.Ping(ctx)
}

// ---------- sources ----------

// PriceSeries returns the REAL observed price series for a token in [start,end]:
// every priced wallet_trade (price_usd > 0), ordered by time. Returns an empty
// slice when there are no real priced trades (caller then reports not indexed).
func (s *Store) PriceSeries(ctx context.Context, chain, token string, start, end time.Time) ([]models.PricePoint, error) {
	token = strings.ToLower(token)
	const q = `
		SELECT block_time, price_usd
		FROM coindex.wallet_trades
		WHERE chain = ? AND token = ? AND price_usd > 0
		  AND block_time >= ? AND block_time <= ?
		ORDER BY block_time ASC
		LIMIT ?`
	rows, err := s.ch.Query(ctx, q, chain, token, start, end, s.maxPoints)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.PricePoint
	for rows.Next() {
		var t time.Time
		var price float64
		if err := rows.Scan(&t, &price); err != nil {
			return nil, err
		}
		if price > 0 {
			out = append(out, models.PricePoint{T: t, Price: price})
		}
	}
	return out, rows.Err()
}

// Symbol reads the token's display symbol (Postgres token_registry); "" if unknown.
func (s *Store) Symbol(ctx context.Context, chain, token string) (string, error) {
	const q = `SELECT symbol FROM token_registry WHERE chain=$1 AND address=$2`
	var sym *string
	err := s.pg.QueryRow(ctx, q, chain, strings.ToLower(token)).Scan(&sym)
	if errors.Is(err, pgx.ErrNoRows) {
		return "", nil
	}
	if err != nil {
		return "", err
	}
	if sym == nil {
		return "", nil
	}
	return *sym, nil
}

// StoredRunDefs returns recent stored runs as definitions to refresh (rule + window
// + chain/token), most recent first.
func (s *Store) StoredRunDefs(ctx context.Context, limit int) ([]models.BacktestResult, error) {
	const q = `
		SELECT chain, token, window_start, window_end, rule_params, assumptions
		FROM backtest_runs ORDER BY created_at DESC LIMIT $1`
	rows, err := s.pg.Query(ctx, q, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.BacktestResult
	for rows.Next() {
		var r models.BacktestResult
		var ruleB, asmB []byte
		if err := rows.Scan(&r.Chain, &r.Token, &r.WindowStart, &r.WindowEnd, &ruleB, &asmB); err != nil {
			return nil, err
		}
		_ = json.Unmarshal(ruleB, &r.Rule)
		_ = json.Unmarshal(asmB, &r.Assumptions)
		out = append(out, r)
	}
	return out, rows.Err()
}

// ---------- sink ----------

// SaveRun upserts a run and replaces its trades in one tx. run_id is deterministic,
// so re-running the same backtest updates in place (idempotent).
func (s *Store) SaveRun(ctx context.Context, res models.BacktestResult, trades []models.BacktestTrade) error {
	ruleB, _ := json.Marshal(res.Rule)
	asmB, _ := json.Marshal(res.Assumptions)

	tx, err := s.pg.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)

	const upsert = `
		INSERT INTO backtest_runs
			(run_id, chain, token, symbol, window_start, window_end, rule_params, assumptions,
			 price_points, trades, wins, win_rate, total_return, avg_return, max_drawdown, exposure,
			 data_coverage, rationale)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18)
		ON CONFLICT (run_id) DO UPDATE SET
			symbol=$4, price_points=$9, trades=$10, wins=$11, win_rate=$12, total_return=$13,
			avg_return=$14, max_drawdown=$15, exposure=$16, data_coverage=$17, rationale=$18,
			created_at=now()`
	if _, err := tx.Exec(ctx, upsert,
		res.RunID, res.Chain, res.Token, nullStr(res.Symbol), res.WindowStart, res.WindowEnd, ruleB, asmB,
		res.PricePoints, res.Trades, res.Wins, res.WinRate, res.TotalReturn, res.AvgReturn, res.MaxDrawdown, res.Exposure,
		res.DataCoverage, res.Rationale); err != nil {
		return err
	}
	if _, err := tx.Exec(ctx, `DELETE FROM backtest_trades WHERE run_id=$1`, res.RunID); err != nil {
		return err
	}
	for _, t := range trades {
		const ins = `
			INSERT INTO backtest_trades
				(run_id, seq, entry_time, entry_price, exit_time, exit_price, return_pct, exit_reason)
			VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`
		if _, err := tx.Exec(ctx, ins, res.RunID, t.Seq, t.EntryTime, t.EntryPrice,
			t.ExitTime, t.ExitPrice, t.ReturnPct, t.ExitReason); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

// ---------- API reads ----------

// RunByID loads a stored run plus its real round-trip trades.
func (s *Store) RunByID(ctx context.Context, runID string) (models.BacktestResult, bool, error) {
	const q = `
		SELECT run_id, chain, token, coalesce(symbol,''), window_start, window_end, rule_params, assumptions,
		       price_points, trades, wins, win_rate, total_return, avg_return, max_drawdown, exposure,
		       data_coverage, rationale, created_at
		FROM backtest_runs WHERE run_id=$1`
	var r models.BacktestResult
	var ruleB, asmB []byte
	err := s.pg.QueryRow(ctx, q, runID).Scan(&r.RunID, &r.Chain, &r.Token, &r.Symbol, &r.WindowStart, &r.WindowEnd,
		&ruleB, &asmB, &r.PricePoints, &r.Trades, &r.Wins, &r.WinRate, &r.TotalReturn, &r.AvgReturn,
		&r.MaxDrawdown, &r.Exposure, &r.DataCoverage, &r.Rationale, &r.CreatedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return models.BacktestResult{}, false, nil
	}
	if err != nil {
		return models.BacktestResult{}, false, err
	}
	_ = json.Unmarshal(ruleB, &r.Rule)
	_ = json.Unmarshal(asmB, &r.Assumptions)

	r.TradesList, err = s.tradesFor(ctx, runID)
	if err != nil {
		return models.BacktestResult{}, false, err
	}
	return r, true, nil
}

func (s *Store) tradesFor(ctx context.Context, runID string) ([]models.BacktestTrade, error) {
	const q = `
		SELECT seq, entry_time, entry_price, exit_time, exit_price, return_pct, exit_reason
		FROM backtest_trades WHERE run_id=$1 ORDER BY seq`
	rows, err := s.pg.Query(ctx, q, runID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.BacktestTrade
	for rows.Next() {
		var t models.BacktestTrade
		if err := rows.Scan(&t.Seq, &t.EntryTime, &t.EntryPrice, &t.ExitTime, &t.ExitPrice, &t.ReturnPct, &t.ExitReason); err != nil {
			return nil, err
		}
		out = append(out, t)
	}
	return out, rows.Err()
}

// RunsForToken lists recent runs for a token (summary, no trades).
func (s *Store) RunsForToken(ctx context.Context, chain, token string, limit int) ([]models.BacktestResult, error) {
	const q = `
		SELECT run_id, chain, token, coalesce(symbol,''), window_start, window_end,
		       price_points, trades, wins, win_rate, total_return, max_drawdown, data_coverage, created_at
		FROM backtest_runs WHERE chain=$1 AND token=$2 ORDER BY created_at DESC LIMIT $3`
	rows, err := s.pg.Query(ctx, q, chain, strings.ToLower(token), limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.BacktestResult
	for rows.Next() {
		var r models.BacktestResult
		if err := rows.Scan(&r.RunID, &r.Chain, &r.Token, &r.Symbol, &r.WindowStart, &r.WindowEnd,
			&r.PricePoints, &r.Trades, &r.Wins, &r.WinRate, &r.TotalReturn, &r.MaxDrawdown, &r.DataCoverage, &r.CreatedAt); err != nil {
			return nil, err
		}
		out = append(out, r)
	}
	return out, rows.Err()
}

func nullStr(s string) any {
	if s == "" {
		return nil
	}
	return s
}
