// Package consumer drives stored-backtest refreshes. A backtest is request-driven,
// but a SAVED backtest should stay current as new real trades extend the price
// history — so the scheduler periodically re-runs stored run definitions against
// the latest real prices. It does no fabrication: it only replays real data through
// the same deterministic rule the run was created with.
package consumer

import (
	"context"
	"time"

	"go.uber.org/zap"
)

// Refresher is satisfied by replay.Engine.
type Refresher interface {
	RefreshStored(ctx context.Context, limit int) error
}

// Scheduler re-runs stored backtests on an interval.
type Scheduler struct {
	r        Refresher
	interval time.Duration
	limit    int
	log      *zap.Logger
}

func NewScheduler(r Refresher, interval time.Duration, limit int, log *zap.Logger) *Scheduler {
	if interval <= 0 {
		interval = 15 * time.Minute
	}
	if limit <= 0 {
		limit = 200
	}
	return &Scheduler{r: r, interval: interval, limit: limit, log: log}
}

func (s *Scheduler) Run(ctx context.Context) error {
	t := time.NewTicker(s.interval)
	defer t.Stop()
	s.once(ctx)
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-t.C:
			s.once(ctx)
		}
	}
}

func (s *Scheduler) once(ctx context.Context) {
	if err := s.r.RefreshStored(ctx, s.limit); err != nil {
		s.log.Warn("stored-backtest refresh failed", zap.Error(err))
	}
}
