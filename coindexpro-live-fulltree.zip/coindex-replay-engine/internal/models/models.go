// Package models holds the replay-engine's shared domain types. The honesty
// contract is structural: a BacktestTrade always carries a REAL EntryPrice and
// ExitPrice taken from the observed price series; metrics that need round-trips are
// pointers that stay nil when no trade fired; and DataCoverage / PricePoints make
// the amount of real history behind a result explicit, so a thin backtest is never
// presented as robust.
package models

import "time"

// PricePoint is one REAL observed price from wallet_trades (price_usd at block_time).
type PricePoint struct {
	T     time.Time
	Price float64
}

// RuleParams is the transparent, reproducible backtest rule. All thresholds are
// percentages; all windows are in price-point counts. There is no hidden state.
type RuleParams struct {
	Lookback          int     `json:"lookback"`            // points back to measure breakout
	EntryThresholdPct float64 `json:"entry_threshold_pct"` // enter when price rises this % vs lookback
	TrailingStopPct   float64 `json:"trailing_stop_pct"`   // exit when price falls this % from peak
	TakeProfitPct     float64 `json:"take_profit_pct"`     // exit when price rises this % vs entry (0 = off)
	MaxHold           int     `json:"max_hold"`            // exit after this many points (0 = off)
}

// Assumptions are EXPLICIT modeling assumptions, surfaced on every result. They are
// not real upstream data; FeeBps defaults to 0 so real-price PnL is unmodified
// unless the caller opts into a cost assumption.
type Assumptions struct {
	FeeBps float64 `json:"fee_bps"` // round-trip cost assumption in basis points
}

// Exit reasons.
const (
	ExitTrailingStop = "trailing_stop"
	ExitTakeProfit   = "take_profit"
	ExitMaxHold      = "max_hold"
	ExitSeriesEnd    = "series_end"
)

// BacktestTrade is one real round-trip. entry/exit prices are REAL observed prices.
type BacktestTrade struct {
	Seq        int       `json:"seq"`
	EntryTime  time.Time `json:"entry_time"`
	EntryPrice float64   `json:"entry_price"`
	ExitTime   time.Time `json:"exit_time"`
	ExitPrice  float64   `json:"exit_price"`
	ReturnPct  float64   `json:"return_pct"`
	ExitReason string    `json:"exit_reason"`
}

// BacktestResult is the full explainable outcome.
type BacktestResult struct {
	RunID        string          `json:"run_id"`
	Chain        string          `json:"chain"`
	Token        string          `json:"token"`
	Symbol       string          `json:"symbol,omitempty"`
	WindowStart  time.Time       `json:"window_start"`
	WindowEnd    time.Time       `json:"window_end"`
	Rule         RuleParams      `json:"rule"`
	Assumptions  Assumptions     `json:"assumptions"`
	PricePoints  int             `json:"price_points"` // count of REAL prices replayed
	Trades       int             `json:"trades"`
	Wins         int             `json:"wins"`
	WinRate      *float64        `json:"win_rate,omitempty"`     // nil when 0 trades
	TotalReturn  *float64        `json:"total_return,omitempty"` // nil when 0 trades
	AvgReturn    *float64        `json:"avg_return,omitempty"`   // nil when 0 trades
	MaxDrawdown  *float64        `json:"max_drawdown,omitempty"` // <=0; nil when 0 trades
	Exposure     *float64        `json:"exposure,omitempty"`     // fraction of points in-position
	DataCoverage float64         `json:"data_coverage"`          // real-data sufficiency 0..1
	Rationale    string          `json:"rationale"`
	TradesList   []BacktestTrade `json:"trades_list,omitempty"`
	CreatedAt    time.Time       `json:"created_at,omitempty"`
}

// TokenRef is a lightweight subject reference drawn from real tables.
type TokenRef struct {
	Chain string
	Token string
}
