// k6-api.js — load profile for the public API gateway (real Phase 3 routes).
// Measures p50/p95/p99 latency, throughput, and error rate with saturation
// thresholds. Run: k6 run -e BASE=http://api.coindex.svc.cluster.local:8090 \
//                        -e CHAIN=eth -e TOKEN=0x... load/k6-api.js
import http from 'k6/http';
import { check } from 'k6';
import { Rate, Trend } from 'k6/metrics';

const errors = new Rate('errors');
const latency = new Trend('endpoint_latency', true);

const BASE  = __ENV.BASE  || 'http://api.coindex.svc.cluster.local:8090';
const CHAIN = __ENV.CHAIN || 'eth';
const TOKEN = __ENV.TOKEN || '0x0000000000000000000000000000000000000000';

export const options = {
  scenarios: {
    steady: { executor: 'ramping-vus', startVUs: 1,
      stages: [
        { duration: '30s', target: 20 },
        { duration: '1m',  target: 50 },
        { duration: '30s', target: 0 },
      ] },
  },
  // saturation thresholds — the run FAILS if these are breached (no false-green).
  thresholds: {
    http_req_duration: ['p(50)<150', 'p(95)<500', 'p(99)<1000'],
    errors: ['rate<0.01'],
    http_req_failed: ['rate<0.01'],
  },
};

const ENDPOINTS = [
  `/token/${CHAIN}/${TOKEN}`,
  `/token/${CHAIN}/${TOKEN}/risk`,
  `/token/${CHAIN}/${TOKEN}/liquidity`,
  `/markets/trending`,
  `/markets/gainers`,
  `/flows/exchanges`,
];

export default function () {
  for (const e of ENDPOINTS) {
    const res = http.get(`${BASE}${e}`);
    latency.add(res.timings.duration, { endpoint: e });
    // a 200 OR a well-formed {available:false} are both honest, non-error responses;
    // 5xx and timeouts are real errors.
    const okStatus = res.status === 200 || res.status === 404; // 404 = not indexed envelope on some routes
    check(res, { 'status ok/honest': () => okStatus });
    errors.add(!okStatus);
  }
}

export function handleSummary(data) {
  return { 'artifacts/perf-api.json': JSON.stringify(data, null, 2) };
}
