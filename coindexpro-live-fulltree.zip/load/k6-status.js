// k6-status.js — load for the Phase 18 status-engine (real routes).
import http from 'k6/http';
import { check } from 'k6';
import { Rate } from 'k6/metrics';
const errors = new Rate('errors');
const BASE = __ENV.BASE || 'http://status-engine.coindex.svc.cluster.local:8104';
export const options = {
  scenarios: { steady: { executor: 'constant-vus', vus: 15, duration: '1m' } },
  thresholds: { http_req_duration: ['p(50)<100','p(95)<300','p(99)<600'], http_req_failed: ['rate<0.01'], errors: ['rate<0.01'] },
};
const ENDPOINTS = [`/status`, `/integrity`, `/launch-check`];
export default function () {
  for (const e of ENDPOINTS) {
    const res = http.get(`${BASE}${e}`);
    // /launch-check returns 503 when not all services are up — that is an HONEST
    // non-green result, not a load error; treat 200 and 503 as valid responses.
    const okStatus = res.status === 200 || res.status === 503;
    check(res, { 'responded honestly': () => okStatus });
    errors.add(!okStatus);
  }
}
export function handleSummary(d){ return { 'artifacts/perf-status.json': JSON.stringify(d, null, 2) }; }
