// k6-strategy.js — load for the Phase 13 strategy-engine (real routes).
import http from 'k6/http';
import { check } from 'k6';
import { Rate } from 'k6/metrics';
const errors = new Rate('errors');
const BASE  = __ENV.BASE  || 'http://strategy-engine.coindex.svc.cluster.local:8099';
const CHAIN = __ENV.CHAIN || 'eth';
const TOKEN = __ENV.TOKEN || '0x0000000000000000000000000000000000000000';
export const options = {
  scenarios: { steady: { executor: 'constant-vus', vus: 25, duration: '2m' } },
  thresholds: { http_req_duration: ['p(50)<200','p(95)<800','p(99)<1500'], http_req_failed: ['rate<0.01'], errors: ['rate<0.01'] },
};
const ENDPOINTS = [`/strategy/feed`, `/strategy/opportunities`, `/strategy/token/${CHAIN}/${TOKEN}`];
export default function () {
  for (const e of ENDPOINTS) {
    const res = http.get(`${BASE}${e}`);
    const okStatus = res.status === 200 || res.status === 404;
    check(res, { 'honest status': () => okStatus });
    errors.add(!okStatus);
  }
}
export function handleSummary(d){ return { 'artifacts/perf-strategy.json': JSON.stringify(d, null, 2) }; }
