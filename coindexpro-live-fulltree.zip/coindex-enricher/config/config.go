// Package config loads enricher configuration from YAML with ${ENV} expansion.
package config

import (
	"fmt"
	"os"
	"time"

	"gopkg.in/yaml.v3"
)

type Config struct {
	Kafka      KafkaConfig      `yaml:"kafka"`
	ClickHouse ClickHouseConfig `yaml:"clickhouse"`
	Timescale  TimescaleConfig  `yaml:"timescale"`
	Redis      RedisConfig      `yaml:"redis"`
	Providers  ProvidersConfig  `yaml:"providers"`
	Cache      CacheConfig      `yaml:"cache"`
	Whale      WhaleConfig      `yaml:"whale"`
	Ops        OpsConfig        `yaml:"ops"`
	Log        LogConfig        `yaml:"log"`
}

type KafkaConfig struct {
	Brokers       []string `yaml:"brokers"`
	GroupID       string   `yaml:"group_id"`
	Topics        Topics   `yaml:"topics"`
	DLQTopic      string   `yaml:"dlq_topic"`
	MaxRetries    int      `yaml:"max_retries"`
}
type Topics struct {
	Swaps     string `yaml:"swaps"`
	Transfers string `yaml:"transfers"`
	LP        string `yaml:"lp"`
	Mints     string `yaml:"mints"`
}

type ClickHouseConfig struct {
	Addrs    []string `yaml:"addrs"`
	Database string   `yaml:"database"`
	Username string   `yaml:"username"`
	Password string   `yaml:"password"`
}
type TimescaleConfig struct {
	DSN string `yaml:"dsn"`
}
type RedisConfig struct {
	Addr string `yaml:"addr"`
}
type ProvidersConfig struct {
	CoinGeckoAPIKey string        `yaml:"coingecko_api_key"`
	Timeout         time.Duration `yaml:"timeout"`
}
type CacheConfig struct {
	PriceTTL   time.Duration `yaml:"price_ttl"`
	MetricsTTL time.Duration `yaml:"metrics_ttl"`
}
type WhaleConfig struct {
	ThresholdUSD float64 `yaml:"threshold_usd"`
	MinConviction int    `yaml:"min_conviction"`
}
type OpsConfig struct {
	Addr string `yaml:"addr"`
}
type LogConfig struct {
	Level string `yaml:"level"`
}

func Load(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}
	var c Config
	if err := yaml.Unmarshal([]byte(os.Expand(string(raw), os.Getenv)), &c); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}
	c.defaults()
	return &c, c.validate()
}

func (c *Config) defaults() {
	if c.Cache.PriceTTL == 0 {
		c.Cache.PriceTTL = 10 * time.Second
	}
	if c.Cache.MetricsTTL == 0 {
		c.Cache.MetricsTTL = 15 * time.Second
	}
	if c.Whale.ThresholdUSD == 0 {
		c.Whale.ThresholdUSD = 10000
	}
	if c.Whale.MinConviction == 0 {
		c.Whale.MinConviction = 50
	}
	if c.Ops.Addr == "" {
		c.Ops.Addr = ":9102"
	}
	if c.Kafka.MaxRetries == 0 {
		c.Kafka.MaxRetries = 3
	}
	if c.Kafka.GroupID == "" {
		c.Kafka.GroupID = "coindex-enricher"
	}
	if c.Providers.Timeout == 0 {
		c.Providers.Timeout = 3 * time.Second
	}
}

func (c *Config) validate() error {
	if len(c.Kafka.Brokers) == 0 {
		return fmt.Errorf("kafka.brokers empty")
	}
	if len(c.ClickHouse.Addrs) == 0 {
		return fmt.Errorf("clickhouse.addrs empty")
	}
	if c.Timescale.DSN == "" {
		return fmt.Errorf("timescale.dsn empty")
	}
	if c.Redis.Addr == "" {
		return fmt.Errorf("redis.addr empty")
	}
	return nil
}
