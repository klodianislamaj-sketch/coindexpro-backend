# coindex-enricher — Phase 4

Consumes the indexer's raw Kafka events and turns them into normalized
intelligence written into the existing Phase 2 tables. This is the source-of-truth
enrichment layer: it prices tokens by **multi-source consensus**, computes wallet
PnL by **FIFO from real fills**, and derives smart-money / sector / trust signals
— all from real rows, with USD only when a real price exists.

## Data flow

```
raw.*.swap ──┐
raw.*.transfer ─┤ Kafka ──> consumers (at-least-once, retry, DLQ, checkpoint)
raw.*.lp ────┤              │
raw.*.new_pair ─┘            ├─ swap processor ─> consensus price ─> swaps.amount_usd
                            │                                     ─> wallet_trades
                            │                                     ─> whale_history (large+priced)
                            │
                            └─ rollup worker (every 60s over recent wallet_trades):
                                 ├─ wallets.Apply  (FIFO) ─> wallet_positions
                                 ├─ whales.Conviction     ─> smart_money_events
                                 ├─ sector.Aggregate      ─> sector_history
                                 └─ trust.Compute         ─> trust_history
```

## Consensus engine (the core)

`internal/consensus` pulls prices from DexScreener, GeckoTerminal and CoinGecko
concurrently, then:
1. drops any unusable quote (error/timeout/NaN — providers never fabricate);
2. rejects any quote >10% from the median;
3. averages the survivors. Confidence: **high** (2+ agreeing), **low** (1 source),
   **none** (0 → `available:false`).

Returns `{price, source_count, confidence, rejected}`.

## Folder tree

```
cmd/enricher/main.go                wiring, ops server, graceful drain
config/{config.go, config.yaml}
internal/
  consumers/consumer.go             Kafka: at-least-once, retry, DLQ, checkpoint
  processors/{swap,lp,transfer,rollup,errors,util}.go
  providers/{providers,pricer}.go   3 price sources + concurrent consensus + cache
  consensus/consensus.go            median + 10% outlier rejection
  wallets/wallets.go                FIFO cost basis + realized PnL + hold time
  whales/whales.go                  transparent conviction score
  liquidity/liquidity.go            net liquidity, volatility, concentration
  trust/trust.go                    explainable trust inputs (missing = unavailable)
  sector/sector.go                  per-sector flow (real tags only)
  db/db.go                          writers for CH + Timescale (idempotent)
  cache/cache.go                    Redis price/metrics cache
  metrics/metrics.go                Prometheus instruments
Dockerfile · docker-compose.yml · README.md
```

## Run

```bash
export KAFKA_BROKERS=... CLICKHOUSE_ADDR=... CLICKHOUSE_USER=... CLICKHOUSE_PASSWORD=...
export TIMESCALE_DSN=... REDIS_ADDR=... COINGECKO_API_KEY=...   # CG key optional
docker compose up --build
# ops: http://localhost:9102/healthz  /readyz  /metrics
```

## Reliability

At-least-once consumption + **idempotent** writes (ClickHouse ReplacingMergeTree
keyed on `tx_hash/log_index`; Timescale `ON CONFLICT DO NOTHING`) → re-delivery is
safe (replay-safe). Bounded retry with backoff; permanent (decode) failures and
retry-exhausted messages go to the **DLQ**, never silently dropped. Offsets are
committed only after successful processing (checkpointing). Graceful drain flushes
the DLQ producer and commits on shutdown.

## Honest status & boundaries

- **Real, production-shaped code, NOT compiled or run here** (no Go toolchain, no
  network, no Kafka/DBs in the authoring environment). Static-reviewed for
  import/symbol/signature consistency. Before production: `go build` + `vet` +
  lint, decoder/consensus unit tests, and an integration run against live topics +
  the Phase 2 stores.
- **Price providers need real network + (optionally) a CoinGecko key.** They make
  real HTTP calls; an unreachable provider simply does not vote — there is no
  fabricated fallback price. CoinGecko has no PulseChain platform id, so it
  abstains on PulseChain (consensus then relies on DexScreener + GeckoTerminal).
- **USD requires token decimals to be exact.** The swap processor parses raw base
  units; precise human-unit scaling needs a token-decimals join (token metadata).
  Until that join exists, `amount_usd` is computed from the consensus price and
  raw magnitude and should be treated as provisional — it is never *invented*, but
  it is not decimals-corrected yet. This is called out rather than hidden.
- **Unrealized PnL** is only computed when a real price is supplied (see
  `wallets.Position.UnrealizedUSD`, which returns `ok=false` otherwise). No
  estimated balances, no synthetic PnL.
- **`internal/liquidity`** is a complete engine wired into the LP metrics roll-up
  (a documented follow-on); the streaming LP processor currently records events
  and defers precise `liq_usd` to that roll-up rather than writing a fabricated
  liquidity figure.
- **Sector flows use real token tags only** (`graph.token_nodes.sector`); untagged
  tokens are skipped, never guessed.
