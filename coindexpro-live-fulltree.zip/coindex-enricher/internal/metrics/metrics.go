// Package metrics holds the enricher's Prometheus instruments.
package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	EnrichLag = promauto.NewGaugeVec(prometheus.GaugeOpts{
		Name: "coindex_enrich_lag_seconds", Help: "block_time → processed delay.",
	}, []string{"topic"})

	Processed = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_enrich_processed_total", Help: "Events processed by topic.",
	}, []string{"topic"})

	ProviderFailures = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_enrich_provider_failures_total", Help: "Price provider failures.",
	}, []string{"provider"})

	ConsensusDisagreements = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_enrich_consensus_disagreements_total", Help: "Consensus runs that rejected an outlier.",
	})

	PricingMisses = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_enrich_pricing_misses_total", Help: "Tokens with no usable price.",
	})

	WriteFailures = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_enrich_write_failures_total", Help: "DB write failures by store/table.",
	}, []string{"store", "table"})

	QueueLag = promauto.NewGaugeVec(prometheus.GaugeOpts{
		Name: "coindex_enrich_queue_lag", Help: "Consumer group lag by topic.",
	}, []string{"topic"})

	DLQ = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_enrich_dlq_total", Help: "Messages routed to DLQ.",
	}, []string{"topic", "reason"})
)
