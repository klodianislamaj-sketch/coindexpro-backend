// Package sector aggregates real trade flow into per-sector inflow/outflow. It
// uses REAL token tags only: a trade whose token has no known sector tag is not
// counted (no guessed sector), so sector_history reflects tagged tokens only.
package sector

import "time"

type Trade struct {
	Sector string // resolved from token registry tag; "" = untagged → skipped
	Side   string // buy = inflow, sell = outflow
	USD    float64
	Wallet string
	Time   time.Time
}

type Flow struct {
	Sector     string
	InflowUSD  float64
	OutflowUSD float64
	VolumeUSD  float64
	Wallets    int
}

// Aggregate folds trades into per-sector flows over the batch. Untagged tokens
// are skipped entirely (real tags only).
func Aggregate(trades []Trade) []Flow {
	type agg struct {
		in, out, vol float64
		wallets      map[string]struct{}
	}
	m := map[string]*agg{}
	for _, t := range trades {
		if t.Sector == "" {
			continue // no real tag → not counted
		}
		a := m[t.Sector]
		if a == nil {
			a = &agg{wallets: map[string]struct{}{}}
			m[t.Sector] = a
		}
		a.vol += t.USD
		a.wallets[t.Wallet] = struct{}{}
		if t.Side == "buy" {
			a.in += t.USD
		} else {
			a.out += t.USD
		}
	}
	out := make([]Flow, 0, len(m))
	for s, a := range m {
		out = append(out, Flow{Sector: s, InflowUSD: a.in, OutflowUSD: a.out, VolumeUSD: a.vol, Wallets: len(a.wallets)})
	}
	return out
}
