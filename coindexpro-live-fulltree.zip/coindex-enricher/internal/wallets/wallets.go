// Package wallets computes wallet position state from real fills using FIFO
// cost basis. Every number here derives from actual buy/sell trades — there are
// no estimated balances and no synthetic PnL. Unrealized PnL is only computed
// when a real consensus price is supplied; otherwise it is left absent.
package wallets

import (
	"container/list"
	"time"
)

// Fill is a single real trade (from wallet_trades / enriched swap).
type Fill struct {
	Token    string
	Side     string // "buy" | "sell"
	Qty      float64
	PriceUSD float64
	USD      float64
	Time     time.Time
}

// lot is an open FIFO purchase lot.
type lot struct {
	qty      float64
	priceUSD float64
	at       time.Time
}

// Position is the computed state for one wallet+token.
type Position struct {
	Token         string
	QtyOpen       float64
	CostBasisUSD  float64 // USD cost of the open quantity
	RealizedUSD   float64 // realized PnL to date (FIFO)
	AvgEntryUSD   float64
	FirstBuy      time.Time
	LastAction    time.Time
	avgHoldNanos  float64 // running avg hold time of closed qty (weighted)
	closedQty     float64
}

// Apply processes fills in chronological order and returns the final positions
// per token. Caller MUST pass fills sorted by time ascending.
func Apply(fills []Fill) map[string]*Position {
	positions := map[string]*Position{}
	lots := map[string]*list.List{} // token -> FIFO queue of *lot

	for _, f := range fills {
		pos := positions[f.Token]
		if pos == nil {
			pos = &Position{Token: f.Token, FirstBuy: f.Time}
			positions[f.Token] = pos
			lots[f.Token] = list.New()
		}
		pos.LastAction = f.Time

		switch f.Side {
		case "buy":
			lots[f.Token].PushBack(&lot{qty: f.Qty, priceUSD: f.PriceUSD, at: f.Time})
			pos.QtyOpen += f.Qty
			pos.CostBasisUSD += f.Qty * f.PriceUSD
			if pos.FirstBuy.IsZero() || f.Time.Before(pos.FirstBuy) {
				pos.FirstBuy = f.Time
			}
		case "sell":
			remaining := f.Qty
			q := lots[f.Token]
			for remaining > 0 && q.Len() > 0 {
				front := q.Front()
				l := front.Value.(*lot)
				take := min(l.qty, remaining)
				// realized PnL on this slice = (sell price - lot price) * qty
				pos.RealizedUSD += take * (f.PriceUSD - l.priceUSD)
				pos.CostBasisUSD -= take * l.priceUSD
				pos.QtyOpen -= take
				// weighted hold time for the closed slice
				hold := f.Time.Sub(l.at).Seconds()
				pos.avgHoldNanos += hold * take
				pos.closedQty += take

				l.qty -= take
				remaining -= take
				if l.qty <= 1e-18 {
					q.Remove(front)
				}
			}
			// remaining > 0 here means a sell without a recorded prior buy
			// (token received via transfer, airdrop, etc.). We do NOT invent a
			// cost basis for it — it contributes no realized PnL and is skipped.
		}
	}

	for _, pos := range positions {
		if pos.QtyOpen > 1e-18 {
			pos.AvgEntryUSD = pos.CostBasisUSD / pos.QtyOpen
		}
	}
	return positions
}

// AvgHoldSeconds returns the quantity-weighted average hold time of closed
// positions, or 0 if nothing has been closed (not an estimate — a real average).
func (p *Position) AvgHoldSeconds() float64 {
	if p.closedQty <= 0 {
		return 0
	}
	return p.avgHoldNanos / p.closedQty
}

// UnrealizedUSD computes unrealized PnL at a given price. Returns ok=false if
// no price is supplied (so callers render unavailable rather than a fake zero).
func (p *Position) UnrealizedUSD(price float64, hasPrice bool) (float64, bool) {
	if !hasPrice || p.QtyOpen <= 0 {
		return 0, false
	}
	return p.QtyOpen*price - p.CostBasisUSD, true
}

func min(a, b float64) float64 {
	if a < b {
		return a
	}
	return b
}
