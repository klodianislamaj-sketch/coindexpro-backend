// Package trust computes the INPUTS to the trust score from real signals and
// writes an explainable trust_history row. It does not invent a score: each
// factor is present only when its underlying data exists; missing factors are
// recorded as unavailable, not defaulted.
package trust

import "time"

// Inputs are the real signals available for a token at a point in time.
type Inputs struct {
	LiquidityStability float64 // 1 - normalized liquidity volatility (0..1), if liq data exists
	SourceAgreement    string  // consensus confidence: high|low|none
	WhaleQuality       float64 // avg conviction of whales active in token (0..1), if any
	AgeFactor          float64 // normalized token age (0..1), if creation known
	Volatility         float64 // price volatility (0..1), if price history exists
	Has                map[string]bool // which factors are actually available
}

// Result is the explainable trust output.
type Result struct {
	Trust      int            `json:"trust"`
	Confidence string         `json:"confidence"`
	Factors    map[string]any `json:"factors"`
	TS         time.Time      `json:"ts"`
}

// Compute produces a trust score ONLY from available factors. The score is the
// weighted mean of present factors, renormalized by available weight, so a
// missing factor neither helps nor hurts (it is simply not counted). Confidence
// reflects how many factors were available.
func Compute(in Inputs) Result {
	weights := map[string]float64{
		"liquidity_stability": 0.30,
		"source_agreement":    0.20,
		"whale_quality":       0.20,
		"age_factor":          0.15,
		"volatility":          0.15,
	}
	values := map[string]float64{
		"liquidity_stability": in.LiquidityStability,
		"source_agreement":    agreementScore(in.SourceAgreement),
		"whale_quality":       in.WhaleQuality,
		"age_factor":          in.AgeFactor,
		"volatility":          1 - clamp01(in.Volatility), // lower volatility = more trust
	}
	factors := map[string]any{}
	var num, den float64
	for k, w := range weights {
		if in.Has[k] {
			num += values[k] * w
			den += w
			factors[k] = values[k]
		} else {
			factors[k] = map[string]any{"available": false}
		}
	}
	conf := "none"
	switch {
	case den >= 0.7:
		conf = "high"
	case den > 0:
		conf = "low"
	}
	score := 0
	if den > 0 {
		score = int((num/den)*100 + 0.5)
	}
	return Result{Trust: score, Confidence: conf, Factors: factors, TS: time.Now().UTC()}
}

func agreementScore(c string) float64 {
	switch c {
	case "high":
		return 1
	case "low":
		return 0.5
	default:
		return 0
	}
}
func clamp01(x float64) float64 {
	if x < 0 {
		return 0
	}
	if x > 1 {
		return 1
	}
	return x
}
