// Package liquidity computes liquidity state from real LP add/remove events.
// Net liquidity, volatility and concentration are all derived from actual
// on-chain events — nothing is estimated.
package liquidity

import (
	"math"
	"time"
)

// Event is a real LP add/remove.
type Event struct {
	Pool     string
	Provider string
	Kind     string // "add" | "remove"
	AmountUSD float64
	Time     time.Time
}

// State is the computed liquidity state for a pool over a window.
type State struct {
	Pool          string
	Adds          int
	Removes       int
	NetUSD        float64   // sum(add) - sum(remove)
	Volatility    float64   // stdev of per-event signed USD
	TopProviderShare float64 // largest single provider's share of adds (concentration)
}

// Compute folds events into a State. Pass events for a single pool.
func Compute(pool string, events []Event) State {
	s := State{Pool: pool}
	var signed []float64
	byProvider := map[string]float64{}
	var totalAddUSD float64
	for _, e := range events {
		switch e.Kind {
		case "add":
			s.Adds++
			s.NetUSD += e.AmountUSD
			signed = append(signed, e.AmountUSD)
			byProvider[e.Provider] += e.AmountUSD
			totalAddUSD += e.AmountUSD
		case "remove":
			s.Removes++
			s.NetUSD -= e.AmountUSD
			signed = append(signed, -e.AmountUSD)
		}
	}
	s.Volatility = stdev(signed)
	if totalAddUSD > 0 {
		var top float64
		for _, v := range byProvider {
			if v > top {
				top = v
			}
		}
		s.TopProviderShare = top / totalAddUSD
	}
	return s
}

func stdev(v []float64) float64 {
	if len(v) < 2 {
		return 0
	}
	var mean float64
	for _, x := range v {
		mean += x
	}
	mean /= float64(len(v))
	var ss float64
	for _, x := range v {
		ss += (x - mean) * (x - mean)
	}
	return math.Sqrt(ss / float64(len(v)-1))
}
