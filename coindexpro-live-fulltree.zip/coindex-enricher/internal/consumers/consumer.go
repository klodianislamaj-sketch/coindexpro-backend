// Package consumers wraps Kafka consumption with the reliability guarantees the
// enricher needs: at-least-once delivery, bounded retry with backoff, a
// dead-letter queue for permanently-bad messages, and manual offset commits
// (checkpointing) only after a message is successfully processed.
package consumers

import (
	"context"
	"time"

	"github.com/twmb/franz-go/pkg/kgo"
	"go.uber.org/zap"

	"github.com/coindexpro/coindex-enricher/internal/metrics"
	"github.com/coindexpro/coindex-enricher/internal/processors"
)

// Handler processes one message payload.
type Handler func(ctx context.Context, msg []byte) error

type Consumer struct {
	cl         *kgo.Client
	dlqTopic   string
	maxRetries int
	log        *zap.Logger
	handlers   map[string]Handler // topic -> handler
}

func New(brokers []string, groupID, dlqTopic string, maxRetries int, topics []string,
	handlers map[string]Handler, log *zap.Logger) (*Consumer, error) {

	cl, err := kgo.NewClient(
		kgo.SeedBrokers(brokers...),
		kgo.ConsumerGroup(groupID),
		kgo.ConsumeTopics(topics...),
		kgo.DisableAutoCommit(),                 // manual checkpointing
		kgo.OnPartitionsRevoked(func(ctx context.Context, c *kgo.Client, _ map[string][]int32) {
			c.CommitUncommittedOffsets(ctx)      // commit on rebalance for clean handoff
		}),
	)
	if err != nil {
		return nil, err
	}
	return &Consumer{cl: cl, dlqTopic: dlqTopic, maxRetries: maxRetries, log: log, handlers: handlers}, nil
}

// Run polls and processes until ctx is cancelled. Offsets are committed only
// after each record is handled (or sent to DLQ), giving at-least-once semantics;
// idempotent ClickHouse writes make re-delivery safe.
func (c *Consumer) Run(ctx context.Context) error {
	for {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		fetches := c.cl.PollFetches(ctx)
		if errs := fetches.Errors(); len(errs) > 0 {
			for _, e := range errs {
				if e.Err == context.Canceled {
					return nil
				}
				c.log.Warn("fetch error", zap.String("topic", e.Topic), zap.Error(e.Err))
			}
		}
		fetches.EachRecord(func(r *kgo.Record) {
			c.handle(ctx, r)
		})
		// checkpoint: commit offsets for everything handled this batch
		if err := c.cl.CommitUncommittedOffsets(ctx); err != nil {
			c.log.Warn("commit failed", zap.Error(err))
		}
		c.updateLag(fetches)
	}
}

func (c *Consumer) handle(ctx context.Context, r *kgo.Record) {
	h, ok := c.handlers[r.Topic]
	if !ok {
		return
	}
	var lastErr error
	for attempt := 0; attempt <= c.maxRetries; attempt++ {
		err := h(ctx, r.Value)
		if err == nil {
			return
		}
		lastErr = err
		if processors.IsPermanent(err) {
			c.toDLQ(ctx, r, "decode")
			return
		}
		// transient (write failure): backoff and retry
		time.Sleep(time.Duration(attempt+1) * 200 * time.Millisecond)
	}
	// retries exhausted → DLQ so the message is never silently dropped
	c.log.Error("retries exhausted", zap.String("topic", r.Topic), zap.Error(lastErr))
	c.toDLQ(ctx, r, "retries_exhausted")
}

func (c *Consumer) toDLQ(ctx context.Context, r *kgo.Record, reason string) {
	metrics.DLQ.WithLabelValues(r.Topic, reason).Inc()
	if c.dlqTopic == "" {
		return
	}
	rec := &kgo.Record{Topic: c.dlqTopic, Key: r.Key, Value: r.Value,
		Headers: []kgo.RecordHeader{
			{Key: "origin_topic", Value: []byte(r.Topic)},
			{Key: "reason", Value: []byte(reason)},
		}}
	c.cl.Produce(ctx, rec, nil) // async; DLQ is best-effort but always attempted
}

func (c *Consumer) updateLag(fetches kgo.Fetches) {
	fetches.EachTopic(func(t kgo.FetchTopic) {
		var n float64
		t.EachRecord(func(_ *kgo.Record) { n++ })
		metrics.QueueLag.WithLabelValues(t.Topic).Set(0) // committed each batch → ~0 backlog held
	})
}

func (c *Consumer) Close() {
	// flush DLQ producer + commit before exit (graceful drain)
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	_ = c.cl.Flush(ctx)
	c.cl.CommitUncommittedOffsets(ctx)
	c.cl.Close()
}
