// Package providers holds the external price sources. Each implements Provider
// and returns a consensus.Quote. On any error/timeout the quote is OK=false —
// providers NEVER fabricate a price; an unreachable source simply does not vote.
package providers

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.com/coindexpro/coindex-enricher/internal/consensus"
	"github.com/coindexpro/coindex-enricher/internal/metrics"
)

// Provider fetches a USD price for (chain, tokenAddress).
type Provider interface {
	Name() string
	Price(ctx context.Context, chain, token string) consensus.Quote
}

// chainSlug maps our canonical chain id to each provider's path slug.
var dexscreenerChain = map[string]string{
	"ethereum": "ethereum", "bsc": "bsc", "base": "base",
	"arbitrum": "arbitrum", "polygon": "polygon", "pulsechain": "pulsechain",
}
var geckoNetwork = map[string]string{
	"ethereum": "eth", "bsc": "bsc", "base": "base",
	"arbitrum": "arbitrum", "polygon": "polygon_pos", "pulsechain": "pulsechain",
}
var coingeckoPlatform = map[string]string{
	"ethereum": "ethereum", "bsc": "binance-smart-chain", "base": "base",
	"arbitrum": "arbitrum-one", "polygon": "polygon-pos",
	// pulsechain intentionally absent: CoinGecko has no platform id → no vote
}

func httpGet(ctx context.Context, url string, hdr map[string]string) ([]byte, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return nil, err
	}
	for k, v := range hdr {
		req.Header.Set(k, v)
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("status %d", resp.StatusCode)
	}
	buf := make([]byte, 0, 8192)
	tmp := make([]byte, 4096)
	for {
		n, e := resp.Body.Read(tmp)
		buf = append(buf, tmp[:n]...)
		if e != nil {
			break
		}
		if len(buf) > 1<<20 { // 1MB cap
			break
		}
	}
	return buf, nil
}

func fail(name string) consensus.Quote {
	metrics.ProviderFailures.WithLabelValues(name).Inc()
	return consensus.Quote{Source: name, OK: false}
}

// ---- DexScreener ----

type DexScreener struct{ Timeout time.Duration }

func (d DexScreener) Name() string { return "dexscreener" }
func (d DexScreener) Price(ctx context.Context, chain, token string) consensus.Quote {
	ctx, cancel := context.WithTimeout(ctx, d.timeout())
	defer cancel()
	url := fmt.Sprintf("https://api.dexscreener.com/latest/dex/tokens/%s", token)
	body, err := httpGet(ctx, url, nil)
	if err != nil {
		return fail(d.Name())
	}
	var r struct {
		Pairs []struct {
			ChainID  string `json:"chainId"`
			PriceUsd string `json:"priceUsd"`
			Liquidity struct {
				Usd float64 `json:"usd"`
			} `json:"liquidity"`
		} `json:"pairs"`
	}
	if json.Unmarshal(body, &r) != nil || len(r.Pairs) == 0 {
		return fail(d.Name())
	}
	// pick the most-liquid pair on the requested chain
	want := dexscreenerChain[chain]
	var best float64
	var bestLiq float64
	for _, p := range r.Pairs {
		if p.ChainID != want {
			continue
		}
		var px float64
		fmt.Sscanf(p.PriceUsd, "%g", &px)
		if px > 0 && p.Liquidity.Usd >= bestLiq {
			best, bestLiq = px, p.Liquidity.Usd
		}
	}
	if best <= 0 {
		return fail(d.Name())
	}
	return consensus.Quote{Source: d.Name(), Price: best, OK: true}
}
func (d DexScreener) timeout() time.Duration { return orDur(d.Timeout, 3*time.Second) }

// ---- GeckoTerminal ----

type GeckoTerminal struct{ Timeout time.Duration }

func (g GeckoTerminal) Name() string { return "geckoterminal" }
func (g GeckoTerminal) Price(ctx context.Context, chain, token string) consensus.Quote {
	net, ok := geckoNetwork[chain]
	if !ok {
		return consensus.Quote{Source: g.Name(), OK: false}
	}
	ctx, cancel := context.WithTimeout(ctx, g.timeout())
	defer cancel()
	url := fmt.Sprintf("https://api.geckoterminal.com/api/v2/networks/%s/tokens/%s", net, token)
	body, err := httpGet(ctx, url, map[string]string{"Accept": "application/json"})
	if err != nil {
		return fail(g.Name())
	}
	var r struct {
		Data struct {
			Attributes struct {
				PriceUsd string `json:"price_usd"`
			} `json:"attributes"`
		} `json:"data"`
	}
	if json.Unmarshal(body, &r) != nil {
		return fail(g.Name())
	}
	var px float64
	fmt.Sscanf(r.Data.Attributes.PriceUsd, "%g", &px)
	if px <= 0 {
		return fail(g.Name())
	}
	return consensus.Quote{Source: g.Name(), Price: px, OK: true}
}
func (g GeckoTerminal) timeout() time.Duration { return orDur(g.Timeout, 3*time.Second) }

// ---- CoinGecko ----

type CoinGecko struct {
	Timeout time.Duration
	APIKey  string // optional; demo/pro key passed as header if present
}

func (c CoinGecko) Name() string { return "coingecko" }
func (c CoinGecko) Price(ctx context.Context, chain, token string) consensus.Quote {
	platform, ok := coingeckoPlatform[chain]
	if !ok {
		return consensus.Quote{Source: c.Name(), OK: false} // unsupported chain → no vote
	}
	ctx, cancel := context.WithTimeout(ctx, c.timeout())
	defer cancel()
	url := fmt.Sprintf(
		"https://api.coingecko.com/api/v3/simple/token_price/%s?contract_addresses=%s&vs_currencies=usd",
		platform, token)
	hdr := map[string]string{"Accept": "application/json"}
	if c.APIKey != "" {
		hdr["x-cg-demo-api-key"] = c.APIKey
	}
	body, err := httpGet(ctx, url, hdr)
	if err != nil {
		return fail(c.Name())
	}
	var r map[string]struct {
		Usd float64 `json:"usd"`
	}
	if json.Unmarshal(body, &r) != nil {
		return fail(c.Name())
	}
	for _, v := range r {
		if v.Usd > 0 {
			return consensus.Quote{Source: c.Name(), Price: v.Usd, OK: true}
		}
	}
	return fail(c.Name())
}
func (c CoinGecko) timeout() time.Duration { return orDur(c.Timeout, 4*time.Second) }

func orDur(d, def time.Duration) time.Duration {
	if d <= 0 {
		return def
	}
	return d
}
