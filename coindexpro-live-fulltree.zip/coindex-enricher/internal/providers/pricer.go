// Package providers — pricer orchestration. The Pricer fans out to every
// provider concurrently, feeds the quotes to the consensus engine, caches the
// result for the configured TTL, and records disagreement/miss metrics.
package providers

import (
	"context"
	"fmt"
	"sync"
	"time"

	"github.com/coindexpro/coindex-enricher/internal/cache"
	"github.com/coindexpro/coindex-enricher/internal/consensus"
	"github.com/coindexpro/coindex-enricher/internal/metrics"
)

type Pricer struct {
	providers []Provider
	cache     *cache.Cache
	ttl       time.Duration
}

func NewPricer(cache *cache.Cache, ttl time.Duration, provs ...Provider) *Pricer {
	return &Pricer{providers: provs, cache: cache, ttl: ttl}
}

// Price returns the consensus price for a token, using a short Redis cache.
func (p *Pricer) Price(ctx context.Context, chain, token string) consensus.Result {
	key := fmt.Sprintf("price:%s:%s", chain, token)
	if p.cache != nil {
		var cached consensus.Result
		if p.cache.GetJSON(ctx, key, &cached) {
			return cached
		}
	}

	quotes := make([]consensus.Quote, len(p.providers))
	var wg sync.WaitGroup
	wg.Add(len(p.providers))
	for i, prov := range p.providers {
		go func(i int, prov Provider) {
			defer wg.Done()
			quotes[i] = prov.Price(ctx, chain, token)
		}(i, prov)
	}
	wg.Wait()

	res := consensus.Compute(quotes)
	if len(res.Rejected) > 0 {
		metrics.ConsensusDisagreements.Inc()
	}
	if !res.Available {
		metrics.PricingMisses.Inc()
	}
	if p.cache != nil && res.Available {
		p.cache.SetJSON(ctx, key, res, p.ttl)
	}
	return res
}
