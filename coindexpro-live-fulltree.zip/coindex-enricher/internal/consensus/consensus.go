// Package consensus implements the multi-source price consensus engine.
// It takes the prices returned by the providers and produces a single trusted
// price with an explicit confidence and a record of which sources were rejected
// as outliers. It NEVER invents a price: zero usable sources => Available=false.
package consensus

import (
	"math"
	"sort"
)

// Quote is one provider's price for a token.
type Quote struct {
	Source string
	Price  float64
	OK     bool // provider returned a usable value
}

// Confidence levels per spec.
const (
	ConfHigh = "high" // 2+ agreeing sources
	ConfLow  = "low"  // exactly 1 usable source
	ConfNone = "none" // 0 usable sources
)

// Result is the consensus output. Mirrors the required response shape.
type Result struct {
	Available   bool     `json:"available"`
	Price       float64  `json:"price,omitempty"`
	SourceCount int      `json:"source_count"`
	Confidence  string   `json:"confidence"`
	Rejected    []string `json:"rejected,omitempty"` // sources rejected as outliers
}

// OutlierThreshold: a quote more than this fraction from the median is rejected.
const OutlierThreshold = 0.10 // 10%

// Compute runs the consensus rules:
//  1. collect all usable quotes
//  2. reject any quote >10% from the median
//  3. average the survivors; confidence by surviving source count
func Compute(quotes []Quote) Result {
	usable := make([]Quote, 0, len(quotes))
	for _, q := range quotes {
		if q.OK && q.Price > 0 && !math.IsNaN(q.Price) && !math.IsInf(q.Price, 0) {
			usable = append(usable, q)
		}
	}
	if len(usable) == 0 {
		return Result{Available: false, Confidence: ConfNone, SourceCount: 0}
	}
	if len(usable) == 1 {
		// single source: accept but mark low confidence (no cross-check possible)
		return Result{Available: true, Price: usable[0].Price, SourceCount: 1, Confidence: ConfLow}
	}

	med := median(prices(usable))

	survivors := make([]Quote, 0, len(usable))
	var rejected []string
	for _, q := range usable {
		if med == 0 || math.Abs(q.Price-med)/med <= OutlierThreshold {
			survivors = append(survivors, q)
		} else {
			rejected = append(rejected, q.Source)
		}
	}

	// If every quote got rejected (extreme spread), fall back to the median of
	// the original usable set at low confidence rather than returning nothing.
	if len(survivors) == 0 {
		return Result{Available: true, Price: med, SourceCount: len(usable),
			Confidence: ConfLow, Rejected: rejected}
	}

	conf := ConfLow
	if len(survivors) >= 2 {
		conf = ConfHigh
	}
	return Result{
		Available:   true,
		Price:       mean(prices(survivors)),
		SourceCount: len(survivors),
		Confidence:  conf,
		Rejected:    rejected,
	}
}

func prices(qs []Quote) []float64 {
	out := make([]float64, len(qs))
	for i, q := range qs {
		out[i] = q.Price
	}
	return out
}

func median(v []float64) float64 {
	if len(v) == 0 {
		return 0
	}
	s := append([]float64(nil), v...)
	sort.Float64s(s)
	n := len(s)
	if n%2 == 1 {
		return s[n/2]
	}
	return (s[n/2-1] + s[n/2]) / 2
}

func mean(v []float64) float64 {
	if len(v) == 0 {
		return 0
	}
	var sum float64
	for _, x := range v {
		sum += x
	}
	return sum / float64(len(v))
}
