package processors

import (
	"context"
	"encoding/json"

	"github.com/coindexpro/coindex-enricher/internal/metrics"
)

// RawTransfer mirrors the indexer's transfer JSON. Transfers feed holder
// tracking + funding-graph edges (downstream jobs). The enricher counts them
// and forwards; it does not invent holder balances here.
type RawTransfer struct {
	Chain  string `json:"chain"`
	Token  string `json:"token"`
	From   string `json:"from"`
	To     string `json:"to"`
	Amount string `json:"amount"`
}

type TransferProcessor struct{}

func NewTransferProcessor() *TransferProcessor { return &TransferProcessor{} }

func (tp *TransferProcessor) Process(ctx context.Context, msg []byte) error {
	var t RawTransfer
	if err := json.Unmarshal(msg, &t); err != nil {
		return errDecode
	}
	metrics.Processed.WithLabelValues("transfers").Inc()
	return nil
}
