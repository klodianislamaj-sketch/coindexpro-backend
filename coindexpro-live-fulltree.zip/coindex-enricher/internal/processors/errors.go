package processors

import "errors"

// errDecode signals a permanently un-parseable message → DLQ (no retry).
var errDecode = errors.New("decode failed")

// IsPermanent reports whether an error should go straight to the DLQ instead of
// being retried (decode errors are permanent; write errors are transient).
func IsPermanent(err error) bool { return errors.Is(err, errDecode) }
