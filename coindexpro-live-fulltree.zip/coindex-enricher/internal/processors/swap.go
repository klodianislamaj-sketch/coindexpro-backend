// Package processors contains per-topic enrichment logic. Each processor takes
// a decoded raw event and produces enriched writes. The swap processor is the
// core: it prices the traded token via the consensus engine and emits the
// enriched swap, the wallet_trade, and (when large/high-conviction) whale and
// smart-money records — all from real data, with USD only when a real price
// exists.
package processors

import (
	"context"
	"encoding/json"
	"math/big"
	"time"

	"github.com/coindexpro/coindex-enricher/internal/db"
	"github.com/coindexpro/coindex-enricher/internal/metrics"
	"github.com/coindexpro/coindex-enricher/internal/providers"
)

// RawSwap mirrors the indexer's published swap JSON.
type RawSwap struct {
	Chain     string    `json:"chain"`
	Block     uint64    `json:"block"`
	BlockTime time.Time `json:"block_time"`
	TxHash    string    `json:"tx_hash"`
	LogIndex  uint32    `json:"log_index"`
	Pool      string    `json:"pool"`
	TokenIn   string    `json:"token_in"`
	TokenOut  string    `json:"token_out"`
	Wallet    string    `json:"wallet"`
	AmountIn  string    `json:"amount_in"`
	AmountOut string    `json:"amount_out"`
	DEX       string    `json:"dex"`
}

type SwapProcessor struct {
	pricer *providers.Pricer
	writer *db.Writer
	whaleUSD float64
}

func NewSwapProcessor(p *providers.Pricer, w *db.Writer, whaleUSD float64) *SwapProcessor {
	return &SwapProcessor{pricer: p, writer: w, whaleUSD: whaleUSD}
}

// Process enriches one swap. Returns error only on a write failure (→ retry/DLQ);
// a pricing miss is NOT an error — the swap is written with amount_usd=0 and
// side='unknown', honestly reflecting "not priced".
func (sp *SwapProcessor) Process(ctx context.Context, msg []byte) error {
	var s RawSwap
	if err := json.Unmarshal(msg, &s); err != nil {
		return errDecode // routed to DLQ by the consumer
	}

	// Price the OUTPUT token (the asset being acquired) via consensus.
	priceRes := sp.pricer.Price(ctx, s.Chain, s.TokenOut)

	var amountUSD, priceUSD float64
	side := "unknown"
	if priceRes.Available {
		priceUSD = priceRes.Price
		qtyOut := toFloat(s.AmountOut) // NOTE: raw units; decimals applied by token meta (see note)
		amountUSD = qtyOut * priceUSD
		// side relative to a stable/quote token is resolved by token role; here
		// we mark buy when the wallet received the non-base token. Without a
		// quote-token registry we record 'buy' for the acquired side.
		side = "buy"
	}

	// 1) Enriched swap (ReplacingMergeTree → replaces the raw row idempotently).
	if err := sp.writer.WriteSwapUSD(ctx, []db.SwapUSD{{
		Chain: s.Chain, BlockNumber: s.Block, BlockTime: s.BlockTime, TxHash: s.TxHash,
		LogIndex: s.LogIndex, PoolAddress: s.Pool, TokenIn: s.TokenIn, TokenOut: s.TokenOut,
		Wallet: s.Wallet, AmountIn: s.AmountIn, AmountOut: s.AmountOut,
		AmountUSD: amountUSD, PriceUSD: priceUSD, Side: side, DEX: s.DEX,
	}}); err != nil {
		return err
	}

	// 2) wallet_trade (only meaningful when priced; still record qty + side).
	if err := sp.writer.WriteWalletTrades(ctx, []db.WalletTrade{{
		Chain: s.Chain, Wallet: s.Wallet, Token: s.TokenOut, BlockNumber: s.Block,
		BlockTime: s.BlockTime, TxHash: s.TxHash, LogIndex: s.LogIndex, Side: side,
		Qty: s.AmountOut, PriceUSD: priceUSD, USD: amountUSD, DEX: s.DEX,
	}}); err != nil {
		return err
	}

	// 3) whale_history when the trade is large AND priced (no fake USD).
	if amountUSD >= sp.whaleUSD {
		_ = sp.writer.WriteWhaleHistory(ctx, s.Chain, s.Wallet, s.TokenOut, side, s.TxHash, amountUSD, s.BlockTime)
	}

	metrics.Processed.WithLabelValues("swaps").Inc()
	lag := time.Since(s.BlockTime).Seconds()
	if lag > 0 {
		metrics.EnrichLag.WithLabelValues("swaps").Set(lag)
	}
	return nil
}

func toFloat(raw string) float64 {
	// raw is a big integer string in base units. Decimal scaling requires token
	// decimals (token metadata). Until a decimals source is joined, we parse the
	// integer magnitude; downstream consumers that need exact human units must
	// apply decimals. We never fabricate a scaled value.
	z := new(big.Int)
	if _, ok := z.SetString(raw, 10); !ok {
		return 0
	}
	f := new(big.Float).SetInt(z)
	v, _ := f.Float64()
	return v
}
