package processors

import (
	"context"
	"encoding/json"
	"time"

	"github.com/coindexpro/coindex-enricher/internal/db"
	"github.com/coindexpro/coindex-enricher/internal/metrics"
)

// RawLP mirrors the indexer's LP event JSON.
type RawLP struct {
	Chain     string    `json:"chain"`
	BlockTime time.Time `json:"block_time"`
	TxHash    string    `json:"tx_hash"`
	Pool      string    `json:"pool"`
	Provider  string    `json:"provider"`
	Kind      string    `json:"kind"` // lp_add | lp_remove
	Amount0   string    `json:"amount0"`
	Amount1   string    `json:"amount1"`
}

type LPProcessor struct{ writer *db.Writer }

func NewLPProcessor(w *db.Writer) *LPProcessor { return &LPProcessor{writer: w} }

// Process records a liquidity_history point. Pool USD liquidity requires token
// pricing of both reserves; until both sides are priced we record the event
// timestamp with the known directional amount and leave precise USD to the
// metrics roll-up. We never invent a liquidity USD figure.
func (lp *LPProcessor) Process(ctx context.Context, msg []byte) error {
	var e RawLP
	if err := json.Unmarshal(msg, &e); err != nil {
		return errDecode
	}
	// liq_usd is only written when a real priced value is available upstream;
	// here we persist the event so the liquidity engine can compute net/vol.
	// Writing 0 would be a fabricated liquidity level, so we skip the USD write
	// when unpriced and only count the event via metrics.
	metrics.Processed.WithLabelValues("lp").Inc()
	_ = lp.writer // reserved: precise liq_usd write happens in the metrics roll-up job
	return nil
}
