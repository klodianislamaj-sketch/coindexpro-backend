// Package db writes enriched results into the existing Phase 2 tables. It does
// not create or alter schema. All writes are idempotent: ClickHouse targets use
// ReplacingMergeTree keys, so re-processing a Kafka message (at-least-once)
// collapses to one row.
package db

import (
	"context"
	"time"

	"github.com/ClickHouse/clickhouse-go/v2"
	"github.com/ClickHouse/clickhouse-go/v2/lib/driver"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/coindexpro/coindex-enricher/internal/metrics"
)

type Writer struct {
	ch driver.Conn
	ts *pgxpool.Pool
}

func Open(ctx context.Context, chAddrs []string, chDB, chUser, chPass, tsDSN string) (*Writer, error) {
	ch, err := clickhouse.Open(&clickhouse.Options{
		Addr: chAddrs,
		Auth: clickhouse.Auth{Database: chDB, Username: chUser, Password: chPass},
		Settings: clickhouse.Settings{"async_insert": 1, "wait_for_async_insert": 0},
	})
	if err != nil {
		return nil, err
	}
	if err := ch.Ping(ctx); err != nil {
		return nil, err
	}
	ts, err := pgxpool.New(ctx, tsDSN)
	if err != nil {
		return nil, err
	}
	return &Writer{ch: ch, ts: ts}, nil
}

// CH exposes the ClickHouse connection for read-side roll-up queries.
func (w *Writer) CH() driver.Conn { return w.ch }

func (w *Writer) Close() {
	_ = w.ch.Close()
	w.ts.Close()
}

// --- ClickHouse writes ---

// WalletTrade row (enriched swap attributed to a wallet, USD-priced).
type WalletTrade struct {
	Chain, Wallet, Token, TxHash, Side, Qty, DEX string
	LogIndex                                     uint32
	BlockNumber                                  uint64
	PriceUSD, USD                                float64
	BlockTime                                    time.Time
}

func (w *Writer) WriteWalletTrades(ctx context.Context, rows []WalletTrade) error {
	b, err := w.ch.PrepareBatch(ctx, `INSERT INTO coindex.wallet_trades
		(chain, wallet, token, block_number, block_time, tx_hash, log_index, side, qty, price_usd, usd, dex)`)
	if err != nil {
		metrics.WriteFailures.WithLabelValues("clickhouse", "wallet_trades").Inc()
		return err
	}
	for _, r := range rows {
		if err := b.Append(r.Chain, r.Wallet, r.Token, r.BlockNumber, r.BlockTime,
			r.TxHash, r.LogIndex, r.Side, r.Qty, r.PriceUSD, r.USD, r.DEX); err != nil {
			return err
		}
	}
	if err := b.Send(); err != nil {
		metrics.WriteFailures.WithLabelValues("clickhouse", "wallet_trades").Inc()
		return err
	}
	return nil
}

// Position row for wallet_positions (FIFO snapshot).
type Position struct {
	Chain, Wallet, Token, QtyOpen string
	CostBasisUSD, RealizedUSD, AvgEntryUSD float64
	FirstBuy, LastAction, UpdatedAt        time.Time
}

func (w *Writer) WritePositions(ctx context.Context, rows []Position) error {
	b, err := w.ch.PrepareBatch(ctx, `INSERT INTO coindex.wallet_positions
		(chain, wallet, token, qty_open, cost_basis_usd, realized_usd, avg_entry_usd, first_buy, last_action, updated_at)`)
	if err != nil {
		metrics.WriteFailures.WithLabelValues("clickhouse", "wallet_positions").Inc()
		return err
	}
	for _, r := range rows {
		if err := b.Append(r.Chain, r.Wallet, r.Token, r.QtyOpen, r.CostBasisUSD,
			r.RealizedUSD, r.AvgEntryUSD, r.FirstBuy, r.LastAction, r.UpdatedAt); err != nil {
			return err
		}
	}
	if err := b.Send(); err != nil {
		metrics.WriteFailures.WithLabelValues("clickhouse", "wallet_positions").Inc()
		return err
	}
	return nil
}

// TokenMetric row.
type TokenMetric struct {
	Chain, Token                                     string
	TS                                               time.Time
	Holders                                          uint64
	Top10Conc, DevConc, LiqUSD, Vol24hUSD, Volatility float64
	HolderGrowth24h                                  int64
}

func (w *Writer) WriteTokenMetrics(ctx context.Context, rows []TokenMetric) error {
	b, err := w.ch.PrepareBatch(ctx, `INSERT INTO coindex.token_metrics
		(chain, token, ts, holders, top10_concentration, dev_concentration, liq_usd, vol24h_usd, volatility, holder_growth_24h)`)
	if err != nil {
		metrics.WriteFailures.WithLabelValues("clickhouse", "token_metrics").Inc()
		return err
	}
	for _, r := range rows {
		if err := b.Append(r.Chain, r.Token, r.TS, r.Holders, r.Top10Conc, r.DevConc,
			r.LiqUSD, r.Vol24hUSD, r.Volatility, r.HolderGrowth24h); err != nil {
			return err
		}
	}
	if err := b.Send(); err != nil {
		metrics.WriteFailures.WithLabelValues("clickhouse", "token_metrics").Inc()
		return err
	}
	return nil
}

// SmartMoneyEvent row.
type SmartMoneyEvent struct {
	Chain, Wallet, Token, TxHash, Side, Reason string
	BlockNumber                                uint64
	USD                                        float64
	Conviction                                 uint8
	BlockTime                                  time.Time
}

func (w *Writer) WriteSmartMoney(ctx context.Context, rows []SmartMoneyEvent) error {
	b, err := w.ch.PrepareBatch(ctx, `INSERT INTO coindex.smart_money_events
		(chain, wallet, token, block_number, block_time, tx_hash, side, usd, conviction, reason)`)
	if err != nil {
		metrics.WriteFailures.WithLabelValues("clickhouse", "smart_money_events").Inc()
		return err
	}
	for _, r := range rows {
		if err := b.Append(r.Chain, r.Wallet, r.Token, r.BlockNumber, r.BlockTime,
			r.TxHash, r.Side, r.USD, r.Conviction, r.Reason); err != nil {
			return err
		}
	}
	if err := b.Send(); err != nil {
		metrics.WriteFailures.WithLabelValues("clickhouse", "smart_money_events").Inc()
		return err
	}
	return nil
}

// UpdateSwapUSD backfills amount_usd/price_usd/side on a swap row. Because swaps
// is a ReplacingMergeTree keyed on (chain,token_in,block_time,tx_hash,log_index),
// re-inserting the full row with USD filled replaces the prior version on merge.
type SwapUSD struct {
	Chain, TokenIn, TxHash, Side string
	LogIndex                     uint32
	BlockNumber                  uint64
	BlockTime                    time.Time
	AmountUSD, PriceUSD          float64
	// remaining original columns required to re-insert the replacing row
	PoolAddress, TokenOut, Wallet, AmountIn, AmountOut, DEX string
}

func (w *Writer) WriteSwapUSD(ctx context.Context, rows []SwapUSD) error {
	b, err := w.ch.PrepareBatch(ctx, `INSERT INTO coindex.swaps
		(chain, block_number, block_time, tx_hash, log_index, pool_address, token_in, token_out,
		 wallet, amount_in, amount_out, amount_usd, price_usd, side, dex)`)
	if err != nil {
		metrics.WriteFailures.WithLabelValues("clickhouse", "swaps").Inc()
		return err
	}
	for _, r := range rows {
		if err := b.Append(r.Chain, r.BlockNumber, r.BlockTime, r.TxHash, r.LogIndex,
			r.PoolAddress, r.TokenIn, r.TokenOut, r.Wallet, r.AmountIn, r.AmountOut,
			r.AmountUSD, r.PriceUSD, r.Side, r.DEX); err != nil {
			return err
		}
	}
	if err := b.Send(); err != nil {
		metrics.WriteFailures.WithLabelValues("clickhouse", "swaps").Inc()
		return err
	}
	return nil
}

// --- Timescale writes ---

func (w *Writer) WriteTrustHistory(ctx context.Context, chain, token string, trust int, conf string, factors []byte, ts time.Time) error {
	_, err := w.ts.Exec(ctx,
		`INSERT INTO trust_history (chain, token, ts, trust, confidence, factors)
		 VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT (chain, token, ts) DO NOTHING`,
		chain, token, ts, trust, conf, factors)
	if err != nil {
		metrics.WriteFailures.WithLabelValues("timescale", "trust_history").Inc()
	}
	return err
}

func (w *Writer) WriteWhaleHistory(ctx context.Context, chain, wallet, token, side, tx string, usd float64, ts time.Time) error {
	_, err := w.ts.Exec(ctx,
		`INSERT INTO whale_history (chain, wallet, ts, token, side, usd, tx_hash)
		 VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT (chain, wallet, ts, tx_hash) DO NOTHING`,
		chain, wallet, ts, token, side, usd, tx)
	if err != nil {
		metrics.WriteFailures.WithLabelValues("timescale", "whale_history").Inc()
	}
	return err
}

func (w *Writer) WriteLiquidityHistory(ctx context.Context, chain, pool string, liqUSD float64, ts time.Time) error {
	_, err := w.ts.Exec(ctx,
		`INSERT INTO liquidity_history (chain, pool_address, ts, liq_usd)
		 VALUES ($1,$2,$3,$4) ON CONFLICT (chain, pool_address, ts) DO NOTHING`,
		chain, pool, ts, liqUSD)
	if err != nil {
		metrics.WriteFailures.WithLabelValues("timescale", "liquidity_history").Inc()
	}
	return err
}

func (w *Writer) WriteSectorHistory(ctx context.Context, sector string, in, out, vol float64, ts time.Time) error {
	_, err := w.ts.Exec(ctx,
		`INSERT INTO sector_history (sector, ts, inflow_usd, outflow_usd, volume_usd)
		 VALUES ($1,$2,$3,$4,$5) ON CONFLICT (sector, ts) DO NOTHING`,
		sector, ts, in, out, vol)
	if err != nil {
		metrics.WriteFailures.WithLabelValues("timescale", "sector_history").Inc()
	}
	return err
}

// SectorTag resolves a token's sector from the Postgres registry (real tags
// only). Returns "" when untagged so the sector engine skips it.
func (w *Writer) SectorTag(ctx context.Context, chain, token string) string {
	var sector *string
	err := w.ts.QueryRow(ctx,
		`SELECT sector FROM graph.token_nodes WHERE chain=$1 AND address=$2`, chain, token).Scan(&sector)
	if err != nil || sector == nil {
		return ""
	}
	return *sector
}
