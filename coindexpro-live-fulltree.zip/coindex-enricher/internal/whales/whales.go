// Package whales computes smart-money signals from REAL trade history only.
// Conviction is a transparent, explainable function of observable behaviour —
// not a prediction and not derived from any fabricated performance metric.
package whales

import (
	"fmt"
	"time"
)

// Trade is a real enriched trade used for scoring.
type Trade struct {
	Wallet string
	Token  string
	Chain  string
	Sector string
	Side   string
	USD    float64
	Time   time.Time
}

// Score is the transparent conviction breakdown for one wallet.
type Score struct {
	Wallet         string
	Conviction     int      // 0..100
	Trades         int
	RepeatTokens   int      // tokens bought 2+ times
	Chains         int
	Sectors        int
	AvgUSD         float64
	Reasons        []string // explainable components
}

// WhaleThresholdUSD: a single trade at/above this is a "whale" print.
const WhaleThresholdUSD = 10000

// Conviction scores wallets from their trades. The formula is fixed and
// documented so the score is fully explainable:
//   +up to 40  repeat-buying (distinct tokens bought 2+ times)
//   +up to 25  activity volume (number of trades, log-damped)
//   +up to 15  multi-chain presence
//   +up to 20  multi-sector specialization breadth
// All inputs are observable; none assume profit or outcome.
func Conviction(trades []Trade) map[string]*Score {
	type agg struct {
		count       int
		usd         float64
		tokenBuys   map[string]int
		chains      map[string]struct{}
		sectors     map[string]struct{}
	}
	byWallet := map[string]*agg{}
	for _, t := range trades {
		a := byWallet[t.Wallet]
		if a == nil {
			a = &agg{tokenBuys: map[string]int{}, chains: map[string]struct{}{}, sectors: map[string]struct{}{}}
			byWallet[t.Wallet] = a
		}
		a.count++
		a.usd += t.USD
		if t.Side == "buy" {
			a.tokenBuys[t.Token]++
		}
		a.chains[t.Chain] = struct{}{}
		if t.Sector != "" {
			a.sectors[t.Sector] = struct{}{}
		}
	}

	out := map[string]*Score{}
	for w, a := range byWallet {
		repeat := 0
		for _, n := range a.tokenBuys {
			if n >= 2 {
				repeat++
			}
		}
		var reasons []string
		score := 0.0

		// repeat buying (max 40): 8 points per repeat token, capped
		rp := float64(repeat) * 8
		if rp > 40 {
			rp = 40
		}
		if repeat > 0 {
			reasons = append(reasons, fmt.Sprintf("repeat_buyer:%d", repeat))
		}
		score += rp

		// activity (max 25): log-damped trade count
		act := log2(float64(a.count)) * 6
		if act > 25 {
			act = 25
		}
		score += act

		// multi-chain (max 15): 7.5 per extra chain
		mc := float64(len(a.chains)-1) * 7.5
		if mc < 0 {
			mc = 0
		}
		if mc > 15 {
			mc = 15
		}
		if len(a.chains) > 1 {
			reasons = append(reasons, fmt.Sprintf("multi_chain:%d", len(a.chains)))
		}
		score += mc

		// sector breadth (max 20): 5 per sector
		sb := float64(len(a.sectors)) * 5
		if sb > 20 {
			sb = 20
		}
		score += sb

		conv := int(score + 0.5)
		if conv > 100 {
			conv = 100
		}
		avg := 0.0
		if a.count > 0 {
			avg = a.usd / float64(a.count)
		}
		out[w] = &Score{
			Wallet: w, Conviction: conv, Trades: a.count, RepeatTokens: repeat,
			Chains: len(a.chains), Sectors: len(a.sectors), AvgUSD: avg, Reasons: reasons,
		}
	}
	return out
}

func log2(x float64) float64 {
	if x <= 1 {
		return 0
	}
	// simple log2 without importing math twice; fine for damping
	r := 0.0
	for x > 1 {
		x /= 2
		r++
	}
	return r
}
