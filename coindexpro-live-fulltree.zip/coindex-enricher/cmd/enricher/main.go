// Command enricher is the coindex-enricher entrypoint. It consumes raw event
// topics, enriches them (consensus pricing, wallet/whale/liquidity/trust/sector
// derivation), and writes into the existing Phase 2 tables. Reliability:
// at-least-once + idempotent writes + DLQ + checkpoint commits + graceful drain.
package main

import (
	"context"
	"errors"
	"flag"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/redis/go-redis/v9"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"go.uber.org/zap"

	"github.com/coindexpro/coindex-enricher/config"
	"github.com/coindexpro/coindex-enricher/internal/cache"
	"github.com/coindexpro/coindex-enricher/internal/consumers"
	"github.com/coindexpro/coindex-enricher/internal/db"
	"github.com/coindexpro/coindex-enricher/internal/processors"
	"github.com/coindexpro/coindex-enricher/internal/providers"
)

func main() {
	cfgPath := flag.String("config", "config/config.yaml", "config path")
	flag.Parse()

	cfg, err := config.Load(*cfgPath)
	if err != nil {
		panic(err)
	}
	log, _ := zap.NewProduction()
	defer func() { _ = log.Sync() }()
	log.Info("starting enricher")

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// DB writer (ClickHouse + Timescale).
	writer, err := db.Open(ctx, cfg.ClickHouse.Addrs, cfg.ClickHouse.Database,
		cfg.ClickHouse.Username, cfg.ClickHouse.Password, cfg.Timescale.DSN)
	if err != nil {
		log.Fatal("db open failed", zap.Error(err))
	}
	defer writer.Close()

	// Redis + price cache.
	rdb := redis.NewClient(&redis.Options{Addr: cfg.Redis.Addr})
	if err := rdb.Ping(ctx).Err(); err != nil {
		log.Fatal("redis ping failed", zap.Error(err))
	}
	defer func() { _ = rdb.Close() }()
	c := cache.New(rdb)

	// Pricer: three providers + consensus + cache.
	pricer := providers.NewPricer(c, cfg.Cache.PriceTTL,
		providers.DexScreener{Timeout: cfg.Providers.Timeout},
		providers.GeckoTerminal{Timeout: cfg.Providers.Timeout},
		providers.CoinGecko{Timeout: cfg.Providers.Timeout, APIKey: cfg.Providers.CoinGeckoAPIKey},
	)

	// Processors per topic.
	swapProc := processors.NewSwapProcessor(pricer, writer, cfg.Whale.ThresholdUSD)
	lpProc := processors.NewLPProcessor(writer)
	transferProc := processors.NewTransferProcessor()

	handlers := map[string]consumers.Handler{
		cfg.Kafka.Topics.Swaps:     swapProc.Process,
		cfg.Kafka.Topics.LP:        lpProc.Process,
		cfg.Kafka.Topics.Transfers: transferProc.Process,
	}
	topics := []string{cfg.Kafka.Topics.Swaps, cfg.Kafka.Topics.LP, cfg.Kafka.Topics.Transfers}
	if cfg.Kafka.Topics.Mints != "" {
		topics = append(topics, cfg.Kafka.Topics.Mints)
		handlers[cfg.Kafka.Topics.Mints] = transferProc.Process // mints feed supply tracking
	}

	consumer, err := consumers.New(cfg.Kafka.Brokers, cfg.Kafka.GroupID, cfg.Kafka.DLQTopic,
		cfg.Kafka.MaxRetries, topics, handlers, log)
	if err != nil {
		log.Fatal("kafka consumer init failed", zap.Error(err))
	}
	defer consumer.Close()

	// Ops server (health + readiness + metrics).
	go serveOps(cfg.Ops.Addr, writer, rdb, log)

	// Run consumer until signal.
	go func() {
		if err := consumer.Run(ctx); err != nil && !errors.Is(err, context.Canceled) {
			log.Error("consumer stopped", zap.Error(err))
		}
	}()

	// Periodic roll-up: FIFO positions, smart-money scores, sector flows from
	// the freshly-enriched wallet_trades. This invokes the wallet/whale/sector
	// engines over real rows on a schedule.
	rollup := processors.NewRollup(writer.CH(), writer, 60*time.Second, 24*time.Hour, cfg.Whale.MinConviction, log)
	go rollup.Run(ctx)

	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
	<-sig
	log.Info("shutdown signal received, draining")
	cancel()
	time.Sleep(2 * time.Second) // allow in-flight commit + DLQ flush
}

func serveOps(addr string, writer *db.Writer, rdb *redis.Client, log *zap.Logger) {
	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ok"))
	})
	mux.HandleFunc("/readyz", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), 3*time.Second)
		defer cancel()
		if err := rdb.Ping(ctx).Err(); err != nil {
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte("redis down"))
			return
		}
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ready"))
	})
	mux.Handle("/metrics", promhttp.Handler())
	srv := &http.Server{Addr: addr, Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Error("ops server failed", zap.Error(err))
	}
}
