-- coindex-indexer-evm ClickHouse schema (Phase 2 storage for the indexer).
-- ReplacingMergeTree + (chain, ..., tx_hash, log_index) sort keys make
-- at-least-once writes idempotent: duplicates collapse on background merge.
-- Monthly partitions keep reorg-range deletes and retention cheap.

CREATE DATABASE IF NOT EXISTS coindex;

CREATE TABLE IF NOT EXISTS coindex.swaps (
    chain         LowCardinality(String),
    block_number  UInt64,
    block_time    DateTime64(3, 'UTC'),
    tx_hash       FixedString(66),
    log_index     UInt32,
    pool_address  String,
    token_in      String,
    token_out     String,
    wallet        String,
    amount_in     String,          -- raw uint256 as decimal string (no precision loss)
    amount_out    String,
    side          Enum8('buy' = 1, 'sell' = 2),
    dex           LowCardinality(String)
)
ENGINE = ReplacingMergeTree
PARTITION BY toYYYYMM(block_time)
ORDER BY (chain, token_in, block_time, tx_hash, log_index);

CREATE TABLE IF NOT EXISTS coindex.transfers (
    chain       LowCardinality(String),
    block_time  DateTime64(3, 'UTC'),
    tx_hash     FixedString(66),
    log_index   UInt32,
    token       String,
    from_addr   String,
    to_addr     String,
    amount      String
)
ENGINE = ReplacingMergeTree
PARTITION BY toYYYYMM(block_time)
ORDER BY (chain, token, block_time, tx_hash, log_index);

CREATE TABLE IF NOT EXISTS coindex.lp_events (
    chain        LowCardinality(String),
    block_time   DateTime64(3, 'UTC'),
    tx_hash      FixedString(66),
    pool_address String,
    provider     String,
    kind         Enum8('add' = 1, 'remove' = 2),
    amount0      String,
    amount1      String
)
ENGINE = ReplacingMergeTree
PARTITION BY toYYYYMM(block_time)
ORDER BY (chain, pool_address, block_time, tx_hash);

CREATE TABLE IF NOT EXISTS coindex.contract_deploys (
    chain      LowCardinality(String),
    block_time DateTime64(3, 'UTC'),
    tx_hash    FixedString(66),
    contract   String,
    deployer   String
)
ENGINE = ReplacingMergeTree
PARTITION BY toYYYYMM(block_time)
ORDER BY (chain, contract, block_time);

CREATE TABLE IF NOT EXISTS coindex.new_pairs (
    chain        LowCardinality(String),
    block_time   DateTime64(3, 'UTC'),
    tx_hash      FixedString(66),
    pool_address String,
    token0       String,
    token1       String,
    factory      String,
    dex          LowCardinality(String)
)
ENGINE = ReplacingMergeTree
PARTITION BY toYYYYMM(block_time)
ORDER BY (chain, pool_address, block_time);

-- Wallet ledger is BUILT from swaps by a downstream job (wallet-engine, Phase 4),
-- not by the indexer. Defined here so the schema is complete and the FIFO
-- materialized view has a target. Indexer never writes derived PnL.
CREATE TABLE IF NOT EXISTS coindex.wallet_positions (
    chain          LowCardinality(String),
    wallet         String,
    token          String,
    qty_open       String,
    cost_basis_usd Decimal64(2),
    realized_usd   Decimal64(2),
    first_buy      DateTime64(3, 'UTC'),
    last_action    DateTime64(3, 'UTC'),
    updated_at     DateTime64(3, 'UTC')
)
ENGINE = ReplacingMergeTree(updated_at)
ORDER BY (chain, wallet, token);
