// Command indexer is the coindex-indexer-evm entrypoint. One process indexes
// one chain (selected by the CHAIN env var). It wires the RPC pool, decoder,
// ClickHouse sink, Kafka publisher, checkpoint store and health server, then
// runs the pipeline until SIGINT/SIGTERM.
package main

import (
	"context"
	"flag"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"github.com/coindexpro/coindex-indexer-evm/internal/checkpoint"
	"github.com/coindexpro/coindex-indexer-evm/internal/config"
	"github.com/coindexpro/coindex-indexer-evm/internal/decode"
	"github.com/coindexpro/coindex-indexer-evm/internal/health"
	applog "github.com/coindexpro/coindex-indexer-evm/internal/log"
	"github.com/coindexpro/coindex-indexer-evm/internal/pipeline"
	"github.com/coindexpro/coindex-indexer-evm/internal/publish"
	"github.com/coindexpro/coindex-indexer-evm/internal/rpc"
	"github.com/coindexpro/coindex-indexer-evm/internal/sink"
)

func main() {
	cfgPath := flag.String("config", "config.yaml", "path to config file")
	flag.Parse()

	cfg, err := config.Load(*cfgPath)
	if err != nil {
		panic(err)
	}
	lg := applog.New(cfg.Log)
	ac := cfg.Active()
	lg.Info("starting indexer", "chain", ac.Name, "chain_id", ac.ChainID)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// RPC pool (multi-provider failover).
	pool, err := rpc.NewPool(ctx, ac.Name, ac.RPCEndpoints)
	if err != nil {
		lg.Error("rpc pool init failed", "err", err)
		os.Exit(1)
	}

	// Decoder with the chain's configured DEX factories (new-pair detection).
	factories := map[string]string{}
	for _, f := range ac.DEXFactories {
		factories[strings.ToLower(f)] = "dex"
	}
	dec := decode.New(ac.Name, ac.ChainID, factories)

	// ClickHouse sink.
	ch, err := sink.Open(ctx, cfg.ClickHouse, ac.Name)
	if err != nil {
		lg.Error("clickhouse init failed", "err", err)
		os.Exit(1)
	}
	defer ch.Close()

	// Kafka publisher + DLQ.
	pub, err := publish.New(cfg.Kafka, ac.Name)
	if err != nil {
		lg.Error("kafka init failed", "err", err)
		os.Exit(1)
	}
	defer pub.Close()

	// Checkpoint store.
	cp, err := checkpoint.Open(ctx, cfg.Checkpoint.PostgresDSN, cfg.Checkpoint.RedisAddr, ac.Name)
	if err != nil {
		lg.Error("checkpoint init failed", "err", err)
		os.Exit(1)
	}
	defer cp.Close()

	// Health + metrics server.
	hs := health.New(cfg.Health.LagThresholdBlocks)
	go func() {
		srv := &http.Server{Addr: cfg.Health.Addr, Handler: hs.Handler(), ReadHeaderTimeout: 5 * time.Second}
		lg.Info("health/metrics listening", "addr", cfg.Health.Addr)
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			lg.Error("health server failed", "err", err)
		}
	}()

	// Pipeline.
	pl := pipeline.New(cfg, pool, dec, ch, pub, cp, hs, lg)

	// Graceful shutdown on signal.
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		<-sig
		lg.Info("shutdown signal received, draining")
		cancel()
	}()

	if err := pl.Run(ctx); err != nil && err != context.Canceled {
		lg.Error("pipeline exited with error", "err", err)
		hs.SetLive(false)
		os.Exit(1)
	}
	lg.Info("indexer stopped cleanly")
}
