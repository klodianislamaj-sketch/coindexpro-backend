module github.com/coindexpro/coindex-indexer-evm

go 1.22

require (
	github.com/ClickHouse/clickhouse-go/v2 v2.23.0
	github.com/ethereum/go-ethereum v1.14.5
	github.com/twmb/franz-go v1.16.1
	github.com/twmb/franz-go/pkg/kadm v1.11.0
	github.com/prometheus/client_golang v1.19.1
	github.com/jackc/pgx/v5 v5.6.0
	github.com/redis/go-redis/v9 v9.5.3
	gopkg.in/yaml.v3 v3.0.1
)
