# coindex-indexer-evm

Production EVM indexer for CoinDex Pro — **Phase 1** of the backend build. Ingests
raw blockchain events from six EVM chains, normalizes them, writes to ClickHouse,
and publishes to Kafka for downstream services (enricher, wallet-engine, trust,
alerts). This is the foundation that turns CoinDex Pro from a frontend aggregator
into a platform with its own indexed history.

## What it does

Per block, for each configured chain, the indexer:

1. Tracks the chain head and processes only **finalized** blocks (`head − confirm_depth`) to stay reorg-safe.
2. Fetches all logs + the block body.
3. Decodes: **swaps** (Uniswap V2/V3 forks), **LP add/remove** (Mint/Burn), **ERC20 transfers**, **contract deployments**, and **new pairs** (factory `PairCreated`/`PoolCreated`).
4. Detects **reorgs** by parent-hash comparison; on a fork it rolls back the affected block range in ClickHouse and re-ingests.
5. Writes normalized rows to **ClickHouse** (idempotent via `ReplacingMergeTree` keyed on `chain/tx_hash/log_index`).
6. Publishes each event to **Kafka** (`raw.{chain}.{kind}`), routing un-publishable records to a **dead-letter queue**.
7. Commits a **checkpoint** (Postgres durable + Redis fast) only *after* sink + publish succeed → at-least-once delivery with idempotent storage.

Multi-provider **RPC failover** with exponential backoff, **Prometheus metrics**,
**/healthz** + **/readyz** (readiness gated on index lag), and structured JSON
logs are built in.

## Chains

Ethereum · BSC · Base · Arbitrum · Polygon · PulseChain. One process indexes one
chain (`CHAIN` env var); scale horizontally by running one deployment per chain.

## Run locally

```bash
cp .env.example .env          # fill in real RPC endpoints
export CHAIN=base
docker compose up --build
# health:   http://localhost:8080/healthz   /readyz
# metrics:  http://localhost:9100/metrics
# prom:     http://localhost:9090
```

ClickHouse schema auto-applies from `migrations/clickhouse/`. To index a
different chain, set `CHAIN` (ethereum|bsc|base|arbitrum|polygon|pulsechain).

## Layout

```
cmd/indexer            entrypoint, wiring, graceful shutdown
internal/config        YAML+env config, per-chain RPC pools, validation
internal/chain         canonical normalized event types
internal/decode        log → event decoders (signatures, amounts)
internal/rpc           multi-provider pool, failover, retry/backoff
internal/reorg         parent-hash reorg detector + rollback
internal/checkpoint    durable (Postgres) + fast (Redis) progress
internal/sink          batched ClickHouse writes + reorg-range delete
internal/publish       Kafka producer + dead-letter queue
internal/health        /healthz, /readyz, /metrics
internal/metrics       Prometheus instruments
internal/pipeline      the control loop tying it all together
migrations/clickhouse  event-table DDL
deploy/                prometheus.yml, alerts.yml
```

## Honest status & caveats

- **This is real, production-shaped code, but it has not been compiled or run in the environment it was authored in** (no Go toolchain / no live RPC there). Before production it needs: `go build` + `go vet` + `golangci-lint`, unit tests for the decoders against captured real logs, and an integration run against a testnet/mainnet archive endpoint. Treat it as a strong starting implementation, not a battle-tested binary.
- **`amount_in/out` are raw on-chain integers.** USD pricing, token decimals, and definitive buy/sell side are intentionally **downstream** (the enricher), because they require token metadata + a price source the indexer deliberately does not own. The indexer never fabricates USD.
- **Decoder coverage is the dominant DEX families**, not every exotic pool type. New DEXes are added by extending the signature set + factory list. Unknown logs are skipped, never guessed.
- **Solana is intentionally out of scope here** — its account model needs a separate (Geyser-based) indexer, as noted in the architecture doc.
- **Wallet PnL / ledger is not built here.** `wallet_positions` is defined as the target table; the FIFO cost-basis job is Phase 4 (`coindex-wallet-engine`), derived from these swaps.

## Next phases (built in order)

Phase 2 finishes the storage layer (Timescale candles/rollups, Postgres
registry/users). Phase 3 is the API. Phase 4 the wallet engine. See the
architecture spec for the full sequence.
