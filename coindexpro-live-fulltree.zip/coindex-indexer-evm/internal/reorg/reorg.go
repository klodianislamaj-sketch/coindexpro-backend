// Package reorg detects chain reorganizations by tracking a sliding window of
// recent (block, hash) pairs and comparing each new block's parent hash against
// the stored hash of its parent (requirement 8). On a mismatch it reports the
// fork point so the pipeline can roll back ClickHouse and re-ingest.
package reorg

import "sync"

// Detector keeps the last N block hashes in memory. N should exceed the chain's
// realistic reorg depth (configured as confirm_depth).
type Detector struct {
	mu     sync.Mutex
	hashes map[uint64]string
	order  []uint64
	window int
}

func New(window int) *Detector {
	if window < 8 {
		window = 8
	}
	return &Detector{hashes: make(map[uint64]string), window: window}
}

// Seed primes the detector from the checkpoint so the first post-restart block
// can be validated against the last known hash.
func (d *Detector) Seed(block uint64, hash string) {
	d.mu.Lock()
	defer d.mu.Unlock()
	d.record(block, hash)
}

// Check validates a new block against the stored parent. It returns:
//   - reorg=false when the block extends the known chain (or is the first seen)
//   - reorg=true + forkBlock when parentHash != stored hash of (block-1):
//     the caller must roll back from forkBlock forward and re-ingest.
func (d *Detector) Check(block uint64, hash, parentHash string) (reorg bool, forkBlock uint64) {
	d.mu.Lock()
	defer d.mu.Unlock()

	if prev, ok := d.hashes[block-1]; ok {
		if prev != parentHash {
			// Parent changed → reorg. Walk back to find the deepest divergence
			// we still have in the window; that is the safe rollback point.
			fork := block - 1
			for b := block - 1; b > 0; b-- {
				h, have := d.hashes[b]
				if !have {
					break
				}
				fork = b
				// We can't know the new parent of older blocks without refetch;
				// the pipeline will refetch from `fork` forward and the hashes
				// will be corrected as it re-ingests.
				if h == parentHash {
					fork = b + 1
					break
				}
				parentHash = "" // force walk to window edge if unknown
			}
			d.record(block, hash)
			return true, fork
		}
	}
	d.record(block, hash)
	return false, 0
}

// record stores a hash and evicts the oldest beyond the window.
func (d *Detector) record(block uint64, hash string) {
	if _, exists := d.hashes[block]; !exists {
		d.order = append(d.order, block)
	}
	d.hashes[block] = hash
	for len(d.order) > d.window {
		old := d.order[0]
		d.order = d.order[1:]
		delete(d.hashes, old)
	}
}

// Rollback drops in-memory hashes at/after forkBlock so they get re-recorded
// from fresh data during re-ingestion.
func (d *Detector) Rollback(forkBlock uint64) {
	d.mu.Lock()
	defer d.mu.Unlock()
	kept := d.order[:0]
	for _, b := range d.order {
		if b < forkBlock {
			kept = append(kept, b)
		} else {
			delete(d.hashes, b)
		}
	}
	d.order = kept
}
