// Package log is a thin wrapper over the standard library slog, configured from
// LogConfig (json|console, level). Centralizing it keeps log shape consistent
// for the centralized logging pipeline (Loki/ELK) described in the arch doc.
package log

import (
	"log/slog"
	"os"
	"strings"

	"github.com/coindexpro/coindex-indexer-evm/internal/config"
)

func New(cfg config.LogConfig) *slog.Logger {
	var lvl slog.Level
	switch strings.ToLower(cfg.Level) {
	case "debug":
		lvl = slog.LevelDebug
	case "warn":
		lvl = slog.LevelWarn
	case "error":
		lvl = slog.LevelError
	default:
		lvl = slog.LevelInfo
	}
	opts := &slog.HandlerOptions{Level: lvl}
	var h slog.Handler
	if strings.ToLower(cfg.Format) == "console" {
		h = slog.NewTextHandler(os.Stdout, opts)
	} else {
		h = slog.NewJSONHandler(os.Stdout, opts)
	}
	return slog.New(h)
}
