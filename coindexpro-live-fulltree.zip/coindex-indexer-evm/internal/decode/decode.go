// Package decode translates raw EVM logs into canonical chain events by
// matching topic0 against known event signatures. It covers the dominant DEX
// families on the supported chains (Uniswap V2 + V3 forks: PancakeSwap,
// PulseX, Aerodrome, SushiSwap, QuickSwap, Camelot) plus ERC20 Transfer.
//
// Decoding is intentionally conservative: an unrecognized log is skipped, never
// guessed. Amounts stay as raw big.Int — USD/decimals are a downstream concern.
package decode

import (
	"math/big"
	"strings"
	"time"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/crypto"

	"github.com/coindexpro/coindex-indexer-evm/internal/chain"
)

// Pre-computed keccak256 topic hashes for the events we decode.
var (
	// UniswapV2 Swap(address,uint256,uint256,uint256,uint256,address)
	sigSwapV2 = sig("Swap(address,uint256,uint256,uint256,uint256,address)")
	// UniswapV3 Swap(address,address,int256,int256,uint160,uint128,int24)
	sigSwapV3 = sig("Swap(address,address,int256,int256,uint160,uint128,int24)")
	// V2 Mint(address,uint256,uint256) / Burn(address,uint256,uint256,address)
	sigMintV2 = sig("Mint(address,uint256,uint256)")
	sigBurnV2 = sig("Burn(address,uint256,uint256,address)")
	// ERC20 Transfer(address,address,uint256)
	sigTransfer = sig("Transfer(address,address,uint256)")
	// Factory PairCreated(address,address,address,uint256) / PoolCreated(...)
	sigPairCreated = sig("PairCreated(address,address,address,uint256)")
	sigPoolCreated = sig("PoolCreated(address,address,uint24,int24,address)")
)

func sig(s string) common.Hash { return crypto.Keccak256Hash([]byte(s)) }

// Decoder holds chain-scoped context (factory→DEX name map) for labelling.
type Decoder struct {
	chainName string
	chainID   uint64
	factories map[string]string // lower-case factory addr -> dex name
}

func New(chainName string, chainID uint64, factories map[string]string) *Decoder {
	return &Decoder{chainName: chainName, chainID: chainID, factories: factories}
}

// DecodeBlock turns a block's logs (plus block meta) into a normalized Batch.
// txOrigin maps txHash -> origin address so swaps can attribute a wallet even
// when the immediate `sender` is a router contract.
func (d *Decoder) DecodeBlock(
	blockNum uint64, blockHash, parentHash string, blockTime int64,
	logs []types.Log, deploys []chain.Deploy, txOrigin map[string]string,
) *chain.Batch {

	b := &chain.Batch{
		Chain: d.chainName, Block: blockNum, BlockHash: blockHash,
		ParentHash: parentHash, BlockTime: unix(blockTime),
		Deploys: deploys,
	}

	for _, lg := range logs {
		if lg.Removed { // log removed by a reorg in the provider's view — skip
			continue
		}
		if len(lg.Topics) == 0 {
			continue
		}
		base := chain.Base{
			Chain: d.chainName, ChainID: d.chainID,
			Block: blockNum, BlockHash: blockHash, BlockTime: unix(blockTime),
			TxHash: lg.TxHash.Hex(), LogIndex: uint32(lg.Index),
		}
		switch lg.Topics[0] {
		case sigSwapV2:
			if s := d.swapV2(base, lg, txOrigin); s != nil {
				b.Swaps = append(b.Swaps, *s)
			}
		case sigSwapV3:
			if s := d.swapV3(base, lg, txOrigin); s != nil {
				b.Swaps = append(b.Swaps, *s)
			}
		case sigMintV2:
			if e := d.lpV2(base, lg, chain.KindLPAdd); e != nil {
				b.LPEvents = append(b.LPEvents, *e)
			}
		case sigBurnV2:
			if e := d.lpV2(base, lg, chain.KindLPRemove); e != nil {
				b.LPEvents = append(b.LPEvents, *e)
			}
		case sigTransfer:
			if t := d.transfer(base, lg); t != nil {
				b.Transfers = append(b.Transfers, *t)
			}
		case sigPairCreated, sigPoolCreated:
			if np := d.newPair(base, lg); np != nil {
				b.NewPairs = append(b.NewPairs, *np)
			}
		}
	}
	return b
}

// --- individual decoders ---

func (d *Decoder) swapV2(base chain.Base, lg types.Log, origin map[string]string) *chain.Swap {
	if len(lg.Topics) < 3 || len(lg.Data) < 4*32 {
		return nil
	}
	base.Kind = chain.KindSwap
	a0In := word(lg.Data, 0)
	a1In := word(lg.Data, 1)
	a0Out := word(lg.Data, 2)
	a1Out := word(lg.Data, 3)
	// V2 emits both token amounts; direction is whichever side is non-zero in.
	s := &chain.Swap{Base: base, Pool: lg.Address.Hex(),
		Wallet: wallet(lg, origin), DEX: d.dexFor(lg.Address)}
	if a0In.Sign() > 0 {
		s.AmountIn, s.AmountOut = a0In, a1Out
	} else {
		s.AmountIn, s.AmountOut = a1In, a0Out
	}
	return s
}

func (d *Decoder) swapV3(base chain.Base, lg types.Log, origin map[string]string) *chain.Swap {
	if len(lg.Topics) < 3 || len(lg.Data) < 2*32 {
		return nil
	}
	base.Kind = chain.KindSwap
	// V3 amounts are signed int256: positive = into pool, negative = out.
	amt0 := signedWord(lg.Data, 0)
	amt1 := signedWord(lg.Data, 1)
	s := &chain.Swap{Base: base, Pool: lg.Address.Hex(),
		Wallet: topicAddr(lg, 2), DEX: d.dexFor(lg.Address)}
	if amt0.Sign() > 0 {
		s.AmountIn, s.AmountOut = abs(amt0), abs(amt1)
	} else {
		s.AmountIn, s.AmountOut = abs(amt1), abs(amt0)
	}
	_ = origin
	return s
}

func (d *Decoder) lpV2(base chain.Base, lg types.Log, kind chain.EventKind) *chain.LPEvent {
	if len(lg.Data) < 2*32 {
		return nil
	}
	base.Kind = kind
	return &chain.LPEvent{Base: base, Pool: lg.Address.Hex(),
		Provider: topicAddr(lg, 1), Amount0: word(lg.Data, 0), Amount1: word(lg.Data, 1)}
}

func (d *Decoder) transfer(base chain.Base, lg types.Log) *chain.Transfer {
	// Standard ERC20 Transfer has 3 topics (sig, from, to) + 32-byte data value.
	// NFT Transfer(address,address,uint256) collides on topic0 but carries the
	// tokenId as the 3rd *topic*; we filter those out by requiring data length.
	if len(lg.Topics) != 3 || len(lg.Data) < 32 {
		return nil
	}
	base.Kind = chain.KindTransfer
	return &chain.Transfer{Base: base, Token: lg.Address.Hex(),
		From: topicAddr(lg, 1), To: topicAddr(lg, 2), Amount: word(lg.Data, 0)}
}

func (d *Decoder) newPair(base chain.Base, lg types.Log) *chain.NewPair {
	dex, known := d.factories[strings.ToLower(lg.Address.Hex())]
	if !known { // only trust factories we explicitly configured
		return nil
	}
	base.Kind = chain.KindNewPair
	np := &chain.NewPair{Base: base, Factory: lg.Address.Hex(), DEX: dex}
	if len(lg.Topics) >= 3 {
		np.Token0 = topicAddr(lg, 1)
		np.Token1 = topicAddr(lg, 2)
	}
	// V2 PairCreated carries pool in data[0]; V3 PoolCreated in data (last word).
	if len(lg.Data) >= 32 {
		np.Pool = common.BytesToAddress(lg.Data[len(lg.Data)-20:]).Hex()
	}
	return np
}

// --- helpers ---

func (d *Decoder) dexFor(pool common.Address) string {
	// Pool→DEX is resolved downstream from factory; here we tag "evm-dex"
	// unless the pool address itself is a configured factory (rare).
	if name, ok := d.factories[strings.ToLower(pool.Hex())]; ok {
		return name
	}
	return "dex"
}

func word(data []byte, i int) *big.Int {
	off := i * 32
	if off+32 > len(data) {
		return big.NewInt(0)
	}
	return new(big.Int).SetBytes(data[off : off+32])
}

func signedWord(data []byte, i int) *big.Int {
	v := word(data, i)
	// interpret as two's-complement int256
	if v.Bit(255) == 1 {
		mod := new(big.Int).Lsh(big.NewInt(1), 256)
		v.Sub(v, mod)
	}
	return v
}

func abs(x *big.Int) *big.Int { return new(big.Int).Abs(x) }

func topicAddr(lg types.Log, i int) string {
	if i >= len(lg.Topics) {
		return ""
	}
	return common.BytesToAddress(lg.Topics[i].Bytes()).Hex()
}

func wallet(lg types.Log, origin map[string]string) string {
	if o, ok := origin[lg.TxHash.Hex()]; ok && o != "" {
		return o
	}
	return topicAddr(lg, 1) // fallback: the `sender` topic
}

func unix(sec int64) time.Time { return time.Unix(sec, 0).UTC() }
