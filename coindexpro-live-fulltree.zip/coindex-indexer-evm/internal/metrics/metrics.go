// Package metrics defines the Prometheus instruments exposed at /metrics
// (requirement: metrics + Prometheus support). Every counter/gauge here maps to
// an operational signal the monitoring strategy alerts on.
package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	// IndexHead and IndexLag drive the primary "are we keeping up" alert.
	IndexHead = promauto.NewGaugeVec(prometheus.GaugeOpts{
		Name: "coindex_index_head_block", Help: "Last block processed by the indexer.",
	}, []string{"chain"})

	ChainHead = promauto.NewGaugeVec(prometheus.GaugeOpts{
		Name: "coindex_chain_head_block", Help: "Current chain head as reported by RPC.",
	}, []string{"chain"})

	IndexLag = promauto.NewGaugeVec(prometheus.GaugeOpts{
		Name: "coindex_index_lag_blocks", Help: "chain_head - index_head.",
	}, []string{"chain"})

	BlocksProcessed = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_blocks_processed_total", Help: "Blocks fully processed.",
	}, []string{"chain"})

	EventsProcessed = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_events_processed_total", Help: "Normalized events produced.",
	}, []string{"chain", "kind"})

	Reorgs = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_reorgs_total", Help: "Reorgs detected and handled.",
	}, []string{"chain"})

	ReorgDepth = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name: "coindex_reorg_depth_blocks", Help: "Depth of handled reorgs.",
		Buckets: []float64{1, 2, 3, 5, 8, 13, 21, 34},
	}, []string{"chain"})

	RPCErrors = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_rpc_errors_total", Help: "RPC errors by endpoint and op.",
	}, []string{"chain", "endpoint", "op"})

	RPCLatency = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name: "coindex_rpc_latency_seconds", Help: "RPC call latency.",
		Buckets: prometheus.DefBuckets,
	}, []string{"chain", "endpoint", "op"})

	SinkFlush = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name: "coindex_sink_flush_seconds", Help: "ClickHouse batch flush latency.",
		Buckets: prometheus.DefBuckets,
	}, []string{"chain", "table"})

	SinkRows = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_sink_rows_total", Help: "Rows written to ClickHouse.",
	}, []string{"chain", "table"})

	PublishErrors = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_publish_errors_total", Help: "Kafka publish failures.",
	}, []string{"chain", "topic"})

	DLQMessages = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_dlq_messages_total", Help: "Messages routed to the dead-letter queue.",
	}, []string{"chain", "reason"})
)
