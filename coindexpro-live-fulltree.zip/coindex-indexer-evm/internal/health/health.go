// Package health exposes liveness (/healthz) and readiness (/readyz) endpoints.
// Readiness fails when index lag exceeds the configured threshold, so an
// orchestrator (Kubernetes) stops routing/treats the pod as not-ready while it
// is backfilling or stalled — without killing it (liveness stays up).
package health

import (
	"net/http"
	"sync/atomic"

	"github.com/prometheus/client_golang/prometheus/promhttp"
)

type Server struct {
	lag       atomic.Uint64
	threshold uint64
	live      atomic.Bool
}

func New(threshold uint64) *Server {
	s := &Server{threshold: threshold}
	s.live.Store(true)
	return s
}

// SetLag is called by the pipeline each cycle.
func (s *Server) SetLag(n uint64) { s.lag.Store(n) }

// SetLive lets the pipeline mark itself unhealthy on fatal, unrecoverable error.
func (s *Server) SetLive(v bool) { s.live.Store(v) }

func (s *Server) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, _ *http.Request) {
		if s.live.Load() {
			w.WriteHeader(http.StatusOK)
			_, _ = w.Write([]byte("ok"))
			return
		}
		w.WriteHeader(http.StatusServiceUnavailable)
	})
	mux.HandleFunc("/readyz", func(w http.ResponseWriter, _ *http.Request) {
		if s.threshold > 0 && s.lag.Load() > s.threshold {
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte("lagging"))
			return
		}
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ready"))
	})
	mux.Handle("/metrics", promhttp.Handler())
	return mux
}
