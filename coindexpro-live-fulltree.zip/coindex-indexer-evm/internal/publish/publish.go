// Package publish emits normalized events to Kafka topics (requirement 13) and
// routes failures to a dead-letter queue (requirement 14). Topics are
// per-chain, per-kind: {prefix}.{chain}.{kind}. Keying by pool/token preserves
// ordering for downstream candle building and FIFO PnL.
package publish

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/twmb/franz-go/pkg/kgo"

	"github.com/coindexpro/coindex-indexer-evm/internal/chain"
	"github.com/coindexpro/coindex-indexer-evm/internal/config"
	"github.com/coindexpro/coindex-indexer-evm/internal/metrics"
)

type Publisher struct {
	cl     *kgo.Client
	prefix string
	dlq    string
	chain  string
}

func New(cfg config.KafkaConfig, chainName string) (*Publisher, error) {
	opts := []kgo.Opt{
		kgo.SeedBrokers(cfg.Brokers...),
		kgo.RequiredAcks(kgo.AllISRAcks()),
		kgo.ProducerBatchCompression(kgo.ZstdCompression()),
		kgo.MaxBufferedRecords(cfg.MaxInflight),
		kgo.RecordRetries(5),
	}
	cl, err := kgo.NewClient(opts...)
	if err != nil {
		return nil, fmt.Errorf("kafka client: %w", err)
	}
	if err := cl.Ping(context.Background()); err != nil {
		return nil, fmt.Errorf("kafka ping: %w", err)
	}
	return &Publisher{cl: cl, prefix: cfg.TopicPrefix, dlq: cfg.DLQTopic, chain: chainName}, nil
}

func (p *Publisher) topic(kind chain.EventKind) string {
	return fmt.Sprintf("%s.%s.%s", p.prefix, p.chain, kind)
}

// PublishBatch fan-outs every event to its topic. A record that cannot be
// produced after retries is routed to the DLQ with the original payload + error
// metadata so it is never silently lost (and can be replayed after a fix).
func (p *Publisher) PublishBatch(ctx context.Context, b *chain.Batch) error {
	var recs []*kgo.Record
	add := func(kind chain.EventKind, key string, v any) {
		payload, err := json.Marshal(v)
		if err != nil {
			p.toDLQ(ctx, string(kind), key, nil, err)
			return
		}
		recs = append(recs, &kgo.Record{Topic: p.topic(kind), Key: []byte(key), Value: payload})
	}
	for i := range b.Swaps {
		add(chain.KindSwap, b.Swaps[i].Pool, &b.Swaps[i])
	}
	for i := range b.LPEvents {
		add(b.LPEvents[i].Kind, b.LPEvents[i].Pool, &b.LPEvents[i])
	}
	for i := range b.Transfers {
		add(chain.KindTransfer, b.Transfers[i].Token, &b.Transfers[i])
	}
	for i := range b.Deploys {
		add(chain.KindDeploy, b.Deploys[i].Contract, &b.Deploys[i])
	}
	for i := range b.NewPairs {
		add(chain.KindNewPair, b.NewPairs[i].Pool, &b.NewPairs[i])
	}

	// Synchronous produce so the caller only checkpoints after durable publish.
	results := p.cl.ProduceSync(ctx, recs...)
	for _, r := range results {
		if r.Err != nil {
			metrics.PublishErrors.WithLabelValues(p.chain, r.Record.Topic).Inc()
			p.toDLQ(ctx, r.Record.Topic, string(r.Record.Key), r.Record.Value, r.Err)
		}
	}
	return results.FirstErr()
}

// toDLQ writes a failed record to the dead-letter topic with error context.
func (p *Publisher) toDLQ(ctx context.Context, origin, key string, payload []byte, cause error) {
	env := map[string]any{
		"chain": p.chain, "origin_topic": origin, "key": key,
		"error": cause.Error(), "ts": time.Now().UTC(),
		"payload": json.RawMessage(payload),
	}
	body, _ := json.Marshal(env)
	rec := &kgo.Record{Topic: p.dlq, Key: []byte(key), Value: body}
	// best-effort; if the DLQ itself is down we at least count it.
	if err := p.cl.ProduceSync(ctx, rec).FirstErr(); err != nil {
		metrics.DLQMessages.WithLabelValues(p.chain, "dlq_write_failed").Inc()
		return
	}
	metrics.DLQMessages.WithLabelValues(p.chain, "produce_failed").Inc()
}

func (p *Publisher) Close() { p.cl.Close() }
