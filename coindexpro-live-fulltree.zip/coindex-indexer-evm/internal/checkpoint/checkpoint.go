// Package checkpoint persists the last fully-processed block per chain so the
// indexer resumes exactly where it left off after a restart or crash
// (requirement 9). Durable truth lives in Postgres; Redis is a fast read cache.
package checkpoint

import (
	"context"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/redis/go-redis/v9"
)

type Store struct {
	pg    *pgxpool.Pool
	rdb   *redis.Client
	chain string
}

// Schema applied at startup (idempotent).
const ddl = `
CREATE TABLE IF NOT EXISTS indexer_checkpoints (
    chain        text PRIMARY KEY,
    block_number bigint NOT NULL,
    block_hash   text   NOT NULL,
    updated_at   timestamptz NOT NULL DEFAULT now()
);`

func Open(ctx context.Context, pgDSN, redisAddr, chain string) (*Store, error) {
	pg, err := pgxpool.New(ctx, pgDSN)
	if err != nil {
		return nil, fmt.Errorf("checkpoint pg: %w", err)
	}
	if _, err := pg.Exec(ctx, ddl); err != nil {
		return nil, fmt.Errorf("checkpoint ddl: %w", err)
	}
	var rdb *redis.Client
	if redisAddr != "" {
		rdb = redis.NewClient(&redis.Options{Addr: redisAddr})
	}
	return &Store{pg: pg, rdb: rdb, chain: chain}, nil
}

// Last returns the last committed (block, hash). ok=false means a fresh start.
func (s *Store) Last(ctx context.Context) (block uint64, hash string, ok bool, err error) {
	// fast path: Redis
	if s.rdb != nil {
		if v, e := s.rdb.HGetAll(ctx, s.key()).Result(); e == nil && len(v) == 2 {
			fmt.Sscanf(v["block"], "%d", &block)
			return block, v["hash"], true, nil
		}
	}
	row := s.pg.QueryRow(ctx,
		`SELECT block_number, block_hash FROM indexer_checkpoints WHERE chain=$1`, s.chain)
	var b int64
	if err = row.Scan(&b, &hash); err != nil {
		return 0, "", false, nil // no row → fresh start (not an error)
	}
	return uint64(b), hash, true, nil
}

// Commit persists progress. Postgres is the source of truth; Redis is updated
// best-effort for the fast read path.
func (s *Store) Commit(ctx context.Context, block uint64, hash string) error {
	_, err := s.pg.Exec(ctx,
		`INSERT INTO indexer_checkpoints (chain, block_number, block_hash, updated_at)
		 VALUES ($1,$2,$3,now())
		 ON CONFLICT (chain) DO UPDATE SET block_number=$2, block_hash=$3, updated_at=now()`,
		s.chain, int64(block), hash)
	if err != nil {
		return err
	}
	if s.rdb != nil {
		s.rdb.HSet(ctx, s.key(), map[string]any{"block": block, "hash": hash})
		s.rdb.Expire(ctx, s.key(), 24*time.Hour)
	}
	return nil
}

func (s *Store) key() string { return "checkpoint:" + s.chain }

func (s *Store) Close() {
	if s.pg != nil {
		s.pg.Close()
	}
	if s.rdb != nil {
		_ = s.rdb.Close()
	}
}
