// Package chain defines the canonical, normalized event types the indexer
// produces. Decoders translate raw EVM logs into these; sinks and publishers
// consume them. Keeping this the single shape is what lets downstream services
// (enricher, wallet-intel, trust) treat all chains uniformly.
package chain

import (
	"math/big"
	"time"
)

// EventKind enumerates the on-chain events the indexer extracts.
type EventKind string

const (
	KindSwap     EventKind = "swap"
	KindLPAdd    EventKind = "lp_add"
	KindLPRemove EventKind = "lp_remove"
	KindTransfer EventKind = "transfer"
	KindDeploy   EventKind = "deploy"
	KindNewPair  EventKind = "new_pair"
)

// Base carries the provenance every event needs for dedupe and reorg handling.
// (chain, block, tx_hash, log_index) is globally unique and is the idempotency
// key used by both Kafka producers and ClickHouse ReplacingMergeTree.
type Base struct {
	Chain     string    `json:"chain"`
	ChainID   uint64    `json:"chain_id"`
	Block     uint64    `json:"block"`
	BlockHash string    `json:"block_hash"`
	BlockTime time.Time `json:"block_time"`
	TxHash    string    `json:"tx_hash"`
	LogIndex  uint32    `json:"log_index"`
	Kind      EventKind `json:"kind"`
}

// Swap is a normalized DEX swap. Amounts are raw on-chain integers (no decimal
// scaling here — the enricher applies token decimals + USD pricing). Indexer
// never fabricates USD; that is a downstream, source-backed step.
type Swap struct {
	Base
	Pool      string   `json:"pool"`
	TokenIn   string   `json:"token_in"`
	TokenOut  string   `json:"token_out"`
	Wallet    string   `json:"wallet"`      // tx origin / sender (recipient for V3)
	AmountIn  *big.Int `json:"amount_in"`
	AmountOut *big.Int `json:"amount_out"`
	DEX       string   `json:"dex"`
}

// LPEvent is a liquidity add or remove (Mint/Burn on V2-style pairs).
type LPEvent struct {
	Base
	Pool     string   `json:"pool"`
	Provider string   `json:"provider"`
	Amount0  *big.Int `json:"amount0"`
	Amount1  *big.Int `json:"amount1"`
}

// Transfer is an ERC20 Transfer log (drives holder tracking + funding graph).
type Transfer struct {
	Base
	Token  string   `json:"token"`
	From   string   `json:"from"`
	To     string   `json:"to"`
	Amount *big.Int `json:"amount"`
}

// Deploy records a contract creation (to addr nil in the tx). Used for token
// registry seeding and new-token detection.
type Deploy struct {
	Base
	Contract string `json:"contract"`
	Deployer string `json:"deployer"`
}

// NewPair is emitted when a known DEX factory logs PairCreated/PoolCreated.
type NewPair struct {
	Base
	Pool    string `json:"pool"`
	Token0  string `json:"token0"`
	Token1  string `json:"token1"`
	Factory string `json:"factory"`
	DEX     string `json:"dex"`
}

// Batch is the unit produced per block: all events decoded from one block,
// kept together so reorg rollback and checkpointing operate at block grain.
type Batch struct {
	Chain     string
	Block     uint64
	BlockHash string
	ParentHash string
	BlockTime time.Time
	Swaps     []Swap
	LPEvents  []LPEvent
	Transfers []Transfer
	Deploys   []Deploy
	NewPairs  []NewPair
}

// Count returns the total number of events in the batch (for metrics).
func (b *Batch) Count() int {
	return len(b.Swaps) + len(b.LPEvents) + len(b.Transfers) + len(b.Deploys) + len(b.NewPairs)
}
