// Package sink writes normalized events to ClickHouse in batches and supports
// block-range deletion for reorg rollback. ClickHouse async inserts + a
// ReplacingMergeTree (keyed on chain/tx/log) make duplicate writes idempotent,
// which pairs with the at-least-once Kafka path.
package sink

import (
	"context"
	"fmt"
	"time"

	"github.com/ClickHouse/clickhouse-go/v2"
	"github.com/ClickHouse/clickhouse-go/v2/lib/driver"

	"github.com/coindexpro/coindex-indexer-evm/internal/chain"
	"github.com/coindexpro/coindex-indexer-evm/internal/config"
	"github.com/coindexpro/coindex-indexer-evm/internal/metrics"
)

type ClickHouse struct {
	conn  driver.Conn
	chain string
	cfg   config.ClickHouseConfig
}

func Open(ctx context.Context, cfg config.ClickHouseConfig, chainName string) (*ClickHouse, error) {
	conn, err := clickhouse.Open(&clickhouse.Options{
		Addr: cfg.Addrs,
		Auth: clickhouse.Auth{Database: cfg.Database, Username: cfg.Username, Password: cfg.Password},
		Settings: clickhouse.Settings{
			"async_insert":          1,
			"wait_for_async_insert": 0,
		},
		Compression: &clickhouse.Compression{Method: clickhouse.CompressionLZ4},
	})
	if err != nil {
		return nil, fmt.Errorf("clickhouse open: %w", err)
	}
	if err := conn.Ping(ctx); err != nil {
		return nil, fmt.Errorf("clickhouse ping: %w", err)
	}
	return &ClickHouse{conn: conn, chain: chainName, cfg: cfg}, nil
}

// WriteBatch persists every event in a decoded block. Each table is flushed in
// its own batch; a failure on one table returns an error so the caller can
// route the block to the DLQ and NOT advance the checkpoint.
func (c *ClickHouse) WriteBatch(ctx context.Context, b *chain.Batch) error {
	if len(b.Swaps) > 0 {
		if err := c.writeSwaps(ctx, b.Swaps); err != nil {
			return fmt.Errorf("swaps: %w", err)
		}
	}
	if len(b.Transfers) > 0 {
		if err := c.writeTransfers(ctx, b.Transfers); err != nil {
			return fmt.Errorf("transfers: %w", err)
		}
	}
	if len(b.LPEvents) > 0 {
		if err := c.writeLP(ctx, b.LPEvents); err != nil {
			return fmt.Errorf("lp: %w", err)
		}
	}
	if len(b.Deploys) > 0 {
		if err := c.writeDeploys(ctx, b.Deploys); err != nil {
			return fmt.Errorf("deploys: %w", err)
		}
	}
	if len(b.NewPairs) > 0 {
		if err := c.writeNewPairs(ctx, b.NewPairs); err != nil {
			return fmt.Errorf("newpairs: %w", err)
		}
	}
	return nil
}

func (c *ClickHouse) writeSwaps(ctx context.Context, rows []chain.Swap) error {
	t := time.Now()
	batch, err := c.conn.PrepareBatch(ctx, `INSERT INTO swaps
		(chain, block_number, block_time, tx_hash, log_index, pool_address,
		 token_in, token_out, wallet, amount_in, amount_out, side, dex)`)
	if err != nil {
		return err
	}
	for _, s := range rows {
		side := "buy"
		// direction relative to token_out being the "bought" asset is resolved
		// downstream; the indexer records raw in/out and a provisional side.
		if err := batch.Append(
			s.Chain, s.Block, s.BlockTime, s.TxHash, s.LogIndex, s.Pool,
			s.TokenIn, s.TokenOut, s.Wallet, s.AmountIn.String(), s.AmountOut.String(), side, s.DEX,
		); err != nil {
			return err
		}
	}
	if err := batch.Send(); err != nil {
		return err
	}
	metrics.SinkRows.WithLabelValues(c.chain, "swaps").Add(float64(len(rows)))
	metrics.SinkFlush.WithLabelValues(c.chain, "swaps").Observe(time.Since(t).Seconds())
	return nil
}

func (c *ClickHouse) writeTransfers(ctx context.Context, rows []chain.Transfer) error {
	batch, err := c.conn.PrepareBatch(ctx, `INSERT INTO transfers
		(chain, block_time, tx_hash, log_index, token, from_addr, to_addr, amount)`)
	if err != nil {
		return err
	}
	for _, r := range rows {
		if err := batch.Append(r.Chain, r.BlockTime, r.TxHash, r.LogIndex,
			r.Token, r.From, r.To, r.Amount.String()); err != nil {
			return err
		}
	}
	if err := batch.Send(); err != nil {
		return err
	}
	metrics.SinkRows.WithLabelValues(c.chain, "transfers").Add(float64(len(rows)))
	return nil
}

func (c *ClickHouse) writeLP(ctx context.Context, rows []chain.LPEvent) error {
	batch, err := c.conn.PrepareBatch(ctx, `INSERT INTO lp_events
		(chain, block_time, tx_hash, pool_address, provider, kind, amount0, amount1)`)
	if err != nil {
		return err
	}
	for _, r := range rows {
		kind := "add"
		if r.Kind == chain.KindLPRemove {
			kind = "remove"
		}
		if err := batch.Append(r.Chain, r.BlockTime, r.TxHash, r.Pool,
			r.Provider, kind, r.Amount0.String(), r.Amount1.String()); err != nil {
			return err
		}
	}
	if err := batch.Send(); err != nil {
		return err
	}
	metrics.SinkRows.WithLabelValues(c.chain, "lp_events").Add(float64(len(rows)))
	return nil
}

func (c *ClickHouse) writeDeploys(ctx context.Context, rows []chain.Deploy) error {
	batch, err := c.conn.PrepareBatch(ctx, `INSERT INTO contract_deploys
		(chain, block_time, tx_hash, contract, deployer)`)
	if err != nil {
		return err
	}
	for _, r := range rows {
		if err := batch.Append(r.Chain, r.BlockTime, r.TxHash, r.Contract, r.Deployer); err != nil {
			return err
		}
	}
	if err := batch.Send(); err != nil {
		return err
	}
	metrics.SinkRows.WithLabelValues(c.chain, "contract_deploys").Add(float64(len(rows)))
	return nil
}

func (c *ClickHouse) writeNewPairs(ctx context.Context, rows []chain.NewPair) error {
	batch, err := c.conn.PrepareBatch(ctx, `INSERT INTO new_pairs
		(chain, block_time, tx_hash, pool_address, token0, token1, factory, dex)`)
	if err != nil {
		return err
	}
	for _, r := range rows {
		if err := batch.Append(r.Chain, r.BlockTime, r.TxHash, r.Pool,
			r.Token0, r.Token1, r.Factory, r.DEX); err != nil {
			return err
		}
	}
	if err := batch.Send(); err != nil {
		return err
	}
	metrics.SinkRows.WithLabelValues(c.chain, "new_pairs").Add(float64(len(rows)))
	return nil
}

// RollbackFrom deletes all rows at/after forkBlock for a reorg. Only `swaps`
// carries block_number; the other event tables are corrected on replay via
// ReplacingMergeTree dedupe (same tx_hash/log_index overwrites), so deleting
// them by block isn't required for correctness.
func (c *ClickHouse) RollbackFrom(ctx context.Context, forkBlock uint64) error {
	const q = `ALTER TABLE swaps DELETE WHERE chain = ? AND block_number >= ?`
	if err := c.conn.Exec(ctx, q, c.chain, forkBlock); err != nil {
		return fmt.Errorf("rollback swaps: %w", err)
	}
	return nil
}

func (c *ClickHouse) Close() error { return c.conn.Close() }
