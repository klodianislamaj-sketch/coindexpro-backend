// Package rpc provides a multi-provider EVM client pool with health-aware
// failover, exponential backoff, and per-endpoint metrics. Requirement 10-12
// (retry/backoff, RPC failover, multi-provider redundancy) live here.
package rpc

import (
	"context"
	"errors"
	"math/big"
	"sync"
	"time"

	"github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/ethclient"

	"github.com/coindexpro/coindex-indexer-evm/internal/config"
	"github.com/coindexpro/coindex-indexer-evm/internal/metrics"
)

var ErrAllEndpointsDown = errors.New("rpc: all endpoints unhealthy")

// endpoint wraps a dialled client with health state.
type endpoint struct {
	cfg     config.RPCEndpoint
	client  *ethclient.Client
	healthy bool
	cooldownUntil time.Time
	fails   int
}

// Pool round-robins across healthy endpoints, preferring higher weight, and
// cools down endpoints that error. Every call retries across the pool before
// giving up, so a single provider outage never stalls ingestion.
type Pool struct {
	mu        sync.Mutex
	eps       []*endpoint
	chainName string
	maxRetry  int
}

// NewPool dials every configured endpoint. A dial failure marks the endpoint
// unhealthy but does not abort — the pool is usable as long as one works.
func NewPool(ctx context.Context, chainName string, cfgs []config.RPCEndpoint) (*Pool, error) {
	p := &Pool{chainName: chainName, maxRetry: 4}
	for _, c := range cfgs {
		ep := &endpoint{cfg: c}
		cl, err := ethclient.DialContext(ctx, c.URL)
		if err == nil {
			ep.client, ep.healthy = cl, true
		} else {
			metrics.RPCErrors.WithLabelValues(chainName, c.Label, "dial").Inc()
		}
		p.eps = append(p.eps, ep)
	}
	if !p.anyHealthy() {
		return nil, ErrAllEndpointsDown
	}
	return p, nil
}

func (p *Pool) anyHealthy() bool {
	for _, e := range p.eps {
		if e.healthy {
			return true
		}
	}
	return false
}

// pick returns the best currently-usable endpoint, reviving cooled-down ones
// whose cooldown has elapsed.
func (p *Pool) pick() *endpoint {
	p.mu.Lock()
	defer p.mu.Unlock()
	now := time.Now()
	var best *endpoint
	for _, e := range p.eps {
		if !e.healthy && now.After(e.cooldownUntil) {
			e.healthy = true // give it another chance
			e.fails = 0
		}
		if e.healthy && e.client != nil {
			if best == nil || e.cfg.Weight > best.cfg.Weight {
				best = e
			}
		}
	}
	return best
}

// fail records an error against an endpoint and applies exponential cooldown.
func (p *Pool) fail(e *endpoint, op string, err error) {
	p.mu.Lock()
	defer p.mu.Unlock()
	e.fails++
	backoff := time.Duration(1<<min(e.fails, 6)) * time.Second // 2s..64s
	e.cooldownUntil = time.Now().Add(backoff)
	e.healthy = false
	metrics.RPCErrors.WithLabelValues(p.chainName, e.cfg.Label, op).Inc()
}

// withRetry runs fn against successive healthy endpoints until one succeeds or
// the retry budget is exhausted.
func (p *Pool) withRetry(op string, fn func(c *ethclient.Client) error) error {
	var lastErr error
	for attempt := 0; attempt < p.maxRetry; attempt++ {
		e := p.pick()
		if e == nil {
			lastErr = ErrAllEndpointsDown
			time.Sleep(time.Duration(attempt+1) * 500 * time.Millisecond)
			continue
		}
		start := time.Now()
		err := fn(e.client)
		metrics.RPCLatency.WithLabelValues(p.chainName, e.cfg.Label, op).Observe(time.Since(start).Seconds())
		if err == nil {
			return nil
		}
		lastErr = err
		p.fail(e, op, err)
	}
	return lastErr
}

// HeadNumber returns the current chain head.
func (p *Pool) HeadNumber(ctx context.Context) (uint64, error) {
	var n uint64
	err := p.withRetry("head", func(c *ethclient.Client) error {
		h, err := c.BlockNumber(ctx)
		if err != nil {
			return err
		}
		n = h
		return nil
	})
	return n, err
}

// HeaderByNumber returns a block header (used for hash/parent/timestamp + reorg).
func (p *Pool) HeaderByNumber(ctx context.Context, n uint64) (*types.Header, error) {
	var hdr *types.Header
	err := p.withRetry("header", func(c *ethclient.Client) error {
		h, err := c.HeaderByNumber(ctx, new(big.Int).SetUint64(n))
		if err != nil {
			return err
		}
		hdr = h
		return nil
	})
	return hdr, err
}

// FilterLogs fetches all logs in [from,to] across all addresses/topics. The
// indexer pulls every log and filters by signature locally — simpler and more
// reorg-robust than per-contract subscriptions.
func (p *Pool) FilterLogs(ctx context.Context, from, to uint64) ([]types.Log, error) {
	var out []types.Log
	q := ethereum.FilterQuery{
		FromBlock: new(big.Int).SetUint64(from),
		ToBlock:   new(big.Int).SetUint64(to),
	}
	err := p.withRetry("filterLogs", func(c *ethclient.Client) error {
		lgs, err := c.FilterLogs(ctx, q)
		if err != nil {
			return err
		}
		out = lgs
		return nil
	})
	return out, err
}

// BlockByNumber returns a full block (for tx origins + contract deploys).
func (p *Pool) BlockByNumber(ctx context.Context, n uint64) (*types.Block, error) {
	var blk *types.Block
	err := p.withRetry("block", func(c *ethclient.Client) error {
		b, err := c.BlockByNumber(ctx, new(big.Int).SetUint64(n))
		if err != nil {
			return err
		}
		blk = b
		return nil
	})
	return blk, err
}

// CodeAt reports whether an address has bytecode (deploy confirmation).
func (p *Pool) CodeAt(ctx context.Context, addr common.Address, block uint64) ([]byte, error) {
	var code []byte
	err := p.withRetry("codeAt", func(c *ethclient.Client) error {
		b, err := c.CodeAt(ctx, addr, new(big.Int).SetUint64(block))
		if err != nil {
			return err
		}
		code = b
		return nil
	})
	return code, err
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
