package pipeline

import (
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/crypto"
)

// createAddress returns the address a contract deployed by `sender` at `nonce`
// will receive (keccak256(rlp([sender, nonce]))[12:]). This is the standard
// CREATE derivation used by go-ethereum.
func createAddress(sender common.Address, nonce uint64) common.Address {
	return crypto.CreateAddress(sender, nonce)
}
