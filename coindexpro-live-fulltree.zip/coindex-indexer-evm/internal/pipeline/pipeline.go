// Package pipeline is the indexer's control loop. It advances from the last
// checkpoint toward the (confirmed) chain head, and for each block: fetches
// logs, decodes events, checks for reorg, writes to ClickHouse, publishes to
// Kafka, then commits the checkpoint. Ordering matters: we only advance the
// checkpoint AFTER both the sink and the publish succeed, giving at-least-once
// delivery with idempotent storage.
package pipeline

import (
	"context"
	"log/slog"
	"time"

	"github.com/ethereum/go-ethereum/core/types"

	"github.com/coindexpro/coindex-indexer-evm/internal/chain"
	"github.com/coindexpro/coindex-indexer-evm/internal/checkpoint"
	"github.com/coindexpro/coindex-indexer-evm/internal/config"
	"github.com/coindexpro/coindex-indexer-evm/internal/decode"
	"github.com/coindexpro/coindex-indexer-evm/internal/health"
	"github.com/coindexpro/coindex-indexer-evm/internal/metrics"
	"github.com/coindexpro/coindex-indexer-evm/internal/publish"
	"github.com/coindexpro/coindex-indexer-evm/internal/reorg"
	"github.com/coindexpro/coindex-indexer-evm/internal/rpc"
	"github.com/coindexpro/coindex-indexer-evm/internal/sink"
)

type Pipeline struct {
	cfg     config.ChainConfig
	gcfg    *config.Config
	pool    *rpc.Pool
	dec     *decode.Decoder
	ch      *sink.ClickHouse
	pub     *publish.Publisher
	cp      *checkpoint.Store
	reorg   *reorg.Detector
	health  *health.Server
	log     *slog.Logger
	next    uint64 // next block to process
}

func New(
	gcfg *config.Config, pool *rpc.Pool, dec *decode.Decoder, ch *sink.ClickHouse,
	pub *publish.Publisher, cp *checkpoint.Store, h *health.Server, lg *slog.Logger,
) *Pipeline {
	ac := gcfg.Active()
	return &Pipeline{
		cfg: ac, gcfg: gcfg, pool: pool, dec: dec, ch: ch, pub: pub, cp: cp,
		reorg: reorg.New(int(ac.ConfirmDepth) * 2), health: h, log: lg,
	}
}

// Run resumes from the checkpoint and processes forever until ctx is cancelled.
func (p *Pipeline) Run(ctx context.Context) error {
	if err := p.resume(ctx); err != nil {
		return err
	}
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
		}
		head, err := p.pool.HeadNumber(ctx)
		if err != nil {
			p.log.Warn("head fetch failed", "err", err)
			time.Sleep(p.cfg.PollInterval)
			continue
		}
		confirmed := head
		if confirmed >= p.cfg.ConfirmDepth {
			confirmed -= p.cfg.ConfirmDepth // only process finalized blocks
		} else {
			confirmed = 0
		}
		metrics.ChainHead.WithLabelValues(p.cfg.Name).Set(float64(head))
		p.updateLag(head)

		if p.next > confirmed {
			time.Sleep(p.cfg.PollInterval) // caught up; wait for new blocks
			continue
		}
		// process a bounded window per iteration
		end := p.next + p.cfg.BatchSize - 1
		if end > confirmed {
			end = confirmed
		}
		if err := p.processRange(ctx, p.next, end); err != nil {
			p.log.Error("process range failed", "from", p.next, "to", end, "err", err)
			time.Sleep(2 * time.Second) // back off, do NOT advance checkpoint
			continue
		}
	}
}

func (p *Pipeline) resume(ctx context.Context) error {
	block, hash, ok, err := p.cp.Last(ctx)
	if err != nil {
		return err
	}
	if ok {
		p.reorg.Seed(block, hash)
		p.next = block + 1
		p.log.Info("resumed from checkpoint", "chain", p.cfg.Name, "block", block)
	} else {
		p.next = p.cfg.StartBlock
		p.log.Info("fresh start", "chain", p.cfg.Name, "start_block", p.next)
	}
	return nil
}

// processRange handles [from,to] block by block so reorg detection and
// checkpointing stay at block granularity.
func (p *Pipeline) processRange(ctx context.Context, from, to uint64) error {
	for n := from; n <= to; n++ {
		hdr, err := p.pool.HeaderByNumber(ctx, n)
		if err != nil {
			return err
		}
		blockHash := hdr.Hash().Hex()
		parentHash := hdr.ParentHash.Hex()

		// reorg check against the block we previously stored as (n-1)
		if isReorg, fork := p.reorg.Check(n, blockHash, parentHash); isReorg {
			depth := n - fork
			p.log.Warn("reorg detected", "chain", p.cfg.Name, "fork", fork, "depth", depth)
			metrics.Reorgs.WithLabelValues(p.cfg.Name).Inc()
			metrics.ReorgDepth.WithLabelValues(p.cfg.Name).Observe(float64(depth))
			if err := p.ch.RollbackFrom(ctx, fork); err != nil {
				return err
			}
			p.reorg.Rollback(fork)
			p.next = fork // re-ingest from the fork point
			return nil
		}

		batch, err := p.buildBatch(ctx, n, hdr)
		if err != nil {
			return err
		}

		// write storage FIRST, then publish, then checkpoint — at-least-once.
		if err := p.ch.WriteBatch(ctx, batch); err != nil {
			return err
		}
		if err := p.pub.PublishBatch(ctx, batch); err != nil {
			return err
		}
		p.countEvents(batch)
		metrics.BlocksProcessed.WithLabelValues(p.cfg.Name).Inc()
		metrics.IndexHead.WithLabelValues(p.cfg.Name).Set(float64(n))
		p.next = n + 1

		if n%p.gcfg.Checkpoint.CommitEvery == 0 || n == to {
			if err := p.cp.Commit(ctx, n, blockHash); err != nil {
				return err
			}
		}
	}
	return nil
}

// buildBatch fetches logs + block body for one block and decodes them.
func (p *Pipeline) buildBatch(ctx context.Context, n uint64, hdr *types.Header) (*chain.Batch, error) {
	logs, err := p.pool.FilterLogs(ctx, n, n)
	if err != nil {
		return nil, err
	}
	blk, err := p.pool.BlockByNumber(ctx, n)
	if err != nil {
		return nil, err
	}
	// tx origins + contract deploys from the block body
	origins := map[string]string{}
	var deploys []chain.Deploy
	signer := types.LatestSignerForChainID(blk.Number()) // chain-id aware
	for _, tx := range blk.Transactions() {
		from, ferr := types.Sender(signer, tx)
		if ferr == nil {
			origins[tx.Hash().Hex()] = from.Hex()
		}
		if tx.To() == nil { // contract creation
			contract := createAddress(from, tx.Nonce())
			deploys = append(deploys, chain.Deploy{
				Base: chain.Base{
					Chain: p.cfg.Name, ChainID: p.cfg.ChainID, Block: n,
					BlockHash: hdr.Hash().Hex(), BlockTime: time.Unix(int64(hdr.Time), 0).UTC(),
					TxHash: tx.Hash().Hex(), Kind: chain.KindDeploy,
				},
				Contract: contract.Hex(), Deployer: from.Hex(),
			})
		}
	}
	return p.dec.DecodeBlock(n, hdr.Hash().Hex(), hdr.ParentHash.Hex(),
		int64(hdr.Time), logs, deploys, origins), nil
}

func (p *Pipeline) countEvents(b *chain.Batch) {
	c := metrics.EventsProcessed
	c.WithLabelValues(p.cfg.Name, "swap").Add(float64(len(b.Swaps)))
	c.WithLabelValues(p.cfg.Name, "lp").Add(float64(len(b.LPEvents)))
	c.WithLabelValues(p.cfg.Name, "transfer").Add(float64(len(b.Transfers)))
	c.WithLabelValues(p.cfg.Name, "deploy").Add(float64(len(b.Deploys)))
	c.WithLabelValues(p.cfg.Name, "new_pair").Add(float64(len(b.NewPairs)))
}

func (p *Pipeline) updateLag(head uint64) {
	var lag uint64
	if head > p.next {
		lag = head - p.next
	}
	metrics.IndexLag.WithLabelValues(p.cfg.Name).Set(float64(lag))
	p.health.SetLag(lag)
}
