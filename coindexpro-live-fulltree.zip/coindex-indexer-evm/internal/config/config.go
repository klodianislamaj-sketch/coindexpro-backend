// Package config loads and validates indexer configuration from a YAML file
// with environment-variable overrides for secrets (RPC URLs, broker creds).
package config

import (
	"fmt"
	"os"
	"strings"
	"time"

	"gopkg.in/yaml.v3"
)

// Config is the root configuration for one indexer deployment. A deployment
// indexes exactly one chain (horizontal scaling = one process per chain), but
// the file can hold all chains and the active one is selected by CHAIN env.
type Config struct {
	ActiveChain string                 `yaml:"-"` // set from CHAIN env at load
	Chains      map[string]ChainConfig `yaml:"chains"`
	ClickHouse  ClickHouseConfig       `yaml:"clickhouse"`
	Kafka       KafkaConfig            `yaml:"kafka"`
	Checkpoint  CheckpointConfig       `yaml:"checkpoint"`
	Metrics     MetricsConfig          `yaml:"metrics"`
	Health      HealthConfig           `yaml:"health"`
	Log         LogConfig              `yaml:"log"`
}

// ChainConfig describes one EVM chain: its identity, RPC endpoints (a pool for
// redundancy), and ingestion tuning.
type ChainConfig struct {
	Name           string        `yaml:"name"`             // ethereum, bsc, base, arbitrum, polygon, pulsechain
	ChainID        uint64        `yaml:"chain_id"`         // 1, 56, 8453, 42161, 137, 369
	RPCEndpoints   []RPCEndpoint `yaml:"rpc_endpoints"`    // ordered by preference; failover walks the list
	StartBlock     uint64        `yaml:"start_block"`      // backfill floor; 0 = from chain head
	ConfirmDepth   uint64        `yaml:"confirm_depth"`    // blocks behind head treated as final (reorg safety)
	BatchSize      uint64        `yaml:"batch_size"`       // logs/blocks per getLogs call
	PollInterval   time.Duration `yaml:"poll_interval"`    // head poll cadence when WSS unavailable
	UseWebsocket   bool          `yaml:"use_websocket"`    // subscribe to new heads if a WSS endpoint exists
	DEXFactories   []string      `yaml:"dex_factories"`    // factory addresses for new-pair detection
}

// RPCEndpoint is a single provider URL with a weight for the pool scheduler.
type RPCEndpoint struct {
	URL     string `yaml:"url"`      // may contain ${ENV_VAR} placeholders
	Weight  int    `yaml:"weight"`   // higher = preferred
	WSS     string `yaml:"wss"`      // optional websocket URL for head subscription
	Label   string `yaml:"label"`    // e.g. "alchemy", "quicknode" — for metrics labels
}

type ClickHouseConfig struct {
	Addrs    []string `yaml:"addrs"`
	Database string   `yaml:"database"`
	Username string   `yaml:"username"`
	Password string   `yaml:"password"`
	// BatchSize controls how many rows accumulate before a flush to ClickHouse.
	BatchSize    int           `yaml:"batch_size"`
	FlushTimeout time.Duration `yaml:"flush_timeout"`
}

type KafkaConfig struct {
	Brokers      []string          `yaml:"brokers"`
	TopicPrefix  string            `yaml:"topic_prefix"`  // e.g. "raw" -> raw.ethereum.swaps
	DLQTopic     string            `yaml:"dlq_topic"`     // dead-letter for un-processable events
	Acks         string            `yaml:"acks"`          // "all" for durability
	Compression  string            `yaml:"compression"`   // "zstd"
	MaxInflight  int               `yaml:"max_inflight"`
}

type CheckpointConfig struct {
	// Postgres connection for durable checkpoints; Redis for fast read path.
	PostgresDSN string `yaml:"postgres_dsn"`
	RedisAddr   string `yaml:"redis_addr"`
	// CommitEvery: how often (in blocks) to persist the checkpoint.
	CommitEvery uint64 `yaml:"commit_every"`
}

type MetricsConfig struct {
	Addr string `yaml:"addr"` // ":9100" — Prometheus scrape endpoint
}

type HealthConfig struct {
	Addr string `yaml:"addr"` // ":8080" — /healthz and /readyz
	// LagThresholdBlocks: readiness fails if index lag exceeds this.
	LagThresholdBlocks uint64 `yaml:"lag_threshold_blocks"`
}

type LogConfig struct {
	Level  string `yaml:"level"`  // debug|info|warn|error
	Format string `yaml:"format"` // json|console
}

// Load reads the YAML file, expands ${ENV} placeholders in string fields,
// selects the active chain from the CHAIN env var, and validates.
func Load(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}
	expanded := os.Expand(string(raw), func(k string) string { return os.Getenv(k) })

	var c Config
	if err := yaml.Unmarshal([]byte(expanded), &c); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}

	c.ActiveChain = strings.ToLower(os.Getenv("CHAIN"))
	if c.ActiveChain == "" {
		return nil, fmt.Errorf("CHAIN env var is required (one of: %s)", strings.Join(c.chainNames(), ", "))
	}
	if err := c.validate(); err != nil {
		return nil, err
	}
	return &c, nil
}

// Active returns the config for the selected chain.
func (c *Config) Active() ChainConfig { return c.Chains[c.ActiveChain] }

func (c *Config) chainNames() []string {
	out := make([]string, 0, len(c.Chains))
	for k := range c.Chains {
		out = append(out, k)
	}
	return out
}

func (c *Config) validate() error {
	ch, ok := c.Chains[c.ActiveChain]
	if !ok {
		return fmt.Errorf("active chain %q not present in config", c.ActiveChain)
	}
	if len(ch.RPCEndpoints) == 0 {
		return fmt.Errorf("chain %q has no rpc_endpoints", c.ActiveChain)
	}
	if ch.ConfirmDepth == 0 {
		return fmt.Errorf("chain %q confirm_depth must be > 0 (reorg safety)", c.ActiveChain)
	}
	if len(c.ClickHouse.Addrs) == 0 {
		return fmt.Errorf("clickhouse.addrs is empty")
	}
	if len(c.Kafka.Brokers) == 0 {
		return fmt.Errorf("kafka.brokers is empty")
	}
	if c.Checkpoint.PostgresDSN == "" {
		return fmt.Errorf("checkpoint.postgres_dsn is empty")
	}
	if c.Checkpoint.CommitEvery == 0 {
		c.Checkpoint.CommitEvery = 50
	}
	if c.ClickHouse.BatchSize == 0 {
		c.ClickHouse.BatchSize = 5000
	}
	if c.ClickHouse.FlushTimeout == 0 {
		c.ClickHouse.FlushTimeout = 2 * time.Second
	}
	return nil
}
