# CoinDex — Platform Secret Inventory (Phase 25)

Real inventory of every platform secret, grouped by consuming service and
classified. Mapping is derived from the actual `secretKeyRef` entries in the
Phase 20 deployments and the `${ENV}` bindings in each service config — not
assumed. **No secret values appear here; only names.**

## Classification legend
`auth` · `billing` · `database` · `rpc-provider` · `signing`

## Inventory (30 secrets)

| Secret (env name) | Class | Consuming service(s) | Rotation |
|---|---|---|---|
| `JWT_SECRET` | auth | api | restart-required (read at boot into Authenticator) |
| `ADMIN_API_KEY` | auth | api | restart-required |
| `IMPORT_API_KEY` | auth | label-engine | restart-required |
| `STRIPE_SECRET_KEY` | billing | premium-engine | restart-required (fail-fast at boot) |
| `STRIPE_WEBHOOK_SECRET` | billing | premium-engine | restart-required (fail-fast at boot) |
| `STRIPE_PRICE_PREMIUM` | billing (non-secret id) | premium-engine | hot (config id, not a credential) |
| `STRIPE_PRICE_ENTERPRISE` | billing (non-secret id) | premium-engine | hot |
| `POSTGRES_DSN` | database | api + 12 engines | restart-required (pool built at boot) |
| `TIMESCALE_DSN` | database | api, enricher | restart-required |
| `CHECKPOINT_PG_DSN` | database | indexer-evm | restart-required |
| `PROVIDER_TRUST_PG_DSN` | database | provider-trust | restart-required |
| `LABEL_ENGINE_PG_DSN` | database | label-engine | restart-required |
| `CLICKHOUSE_PASSWORD` | database | api + 9 engines | restart-required |
| `COINGECKO_API_KEY` | rpc-provider | enricher | restart-required |
| `ETH_RPC_PRIMARY` | rpc-provider | indexer-evm | restart-required |
| `ETH_RPC_SECONDARY` | rpc-provider | indexer-evm | restart-required |
| `ETH_WSS_PRIMARY` | rpc-provider | indexer-evm | restart-required |
| `BSC_RPC_PRIMARY` | rpc-provider | indexer-evm | restart-required |
| `BSC_RPC_SECONDARY` | rpc-provider | indexer-evm | restart-required |
| `BASE_RPC_PRIMARY` | rpc-provider | indexer-evm | restart-required |
| `ARB_RPC_PRIMARY` | rpc-provider | indexer-evm | restart-required |
| `POLYGON_RPC_PRIMARY` | rpc-provider | indexer-evm | restart-required |
| `PLS_RPC_PRIMARY` | rpc-provider | indexer-evm | restart-required |
| `TELEGRAM_BOT_TOKEN` | rpc-provider | social-engine, alert-engine | restart-required |
| `DISCORD_BOT_TOKEN` | rpc-provider | social-engine | restart-required |
| `TWITTER_BEARER` | rpc-provider | social-engine | restart-required |
| `REDDIT_OAUTH_TOKEN` | rpc-provider | social-engine | restart-required |
| `FARCASTER_API_KEY` | rpc-provider | social-engine | restart-required |
| `SMTP_USER` | rpc-provider | alert-engine | restart-required |
| `SMTP_PASS` | rpc-provider | alert-engine | restart-required |
| `PARTNER_ARKHAM_PUBKEY` | signing | label-engine | hot-capable (verify key; rotate upstream) |
| `PARTNER_CHAINALYSIS_PUBKEY` | signing | label-engine | hot-capable |

> `STRIPE_PRICE_*` are non-secret Stripe price identifiers and live in the
> ConfigMap, not the Secret — listed here only for completeness.

## Grouping by service
- **api**: JWT_SECRET, ADMIN_API_KEY, POSTGRES_DSN, TIMESCALE_DSN, CLICKHOUSE_PASSWORD
- **premium-engine**: STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, POSTGRES_DSN
- **execution-engine**: POSTGRES_DSN, CLICKHOUSE_PASSWORD
- **indexer-evm**: CHECKPOINT_PG_DSN, CLICKHOUSE_PASSWORD, all `*_RPC_*` / `*_WSS_*`
- **status-engine**: POSTGRES_DSN
- **label-engine**: LABEL_ENGINE_PG_DSN, IMPORT_API_KEY, PARTNER_*_PUBKEY
- **enricher**: TIMESCALE_DSN, CLICKHOUSE_PASSWORD, COINGECKO_API_KEY
- **social/alert-engine**: bot tokens, SMTP creds
- **CI/CD**: `KUBECONFIG_B64`, `REGISTRY_USERNAME`, `REGISTRY_PASSWORD`, `GITLEAKS_LICENSE` (GitHub Actions secrets — never in repo)
- **Kubernetes**: the synchronized `coindex-secrets` Secret (now sourced from the canonical store, see below)

## Canonical source
All cluster secrets are sourced from **one** upstream store via the **External
Secrets Operator (ESO)**. ESO reconciles the upstream values into the native
`coindex-secrets` Kubernetes Secret, so every existing `secretKeyRef` in the
deployments keeps working unchanged. See `k8s/secrets/`.

## Rotation model
- Upstream rotation (in AWS/GCP/Vault) is picked up by ESO on its
  `refreshInterval` and rewritten into the k8s Secret with **no code change**.
- Most services read secrets once at boot (pools/clients), so a rotated value
  takes effect on the next rollout: `kubectl rollout restart`. This is the
  documented "restart-required" path — not a code dependency.
- No secret is hardcoded in any source file; none has a code default.
