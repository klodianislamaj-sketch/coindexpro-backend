# CoinDex — Canonical Secret Sourcing (Phase 25)

Production secrets come from **one** upstream store via the **External Secrets
Operator (ESO)**. Nothing in the application services changed: ESO writes the
`coindex-secrets` Kubernetes Secret that the Phase 20 deployments already consume
via `secretKeyRef`.

## Files
- `SECRET-INVENTORY.md` — every platform secret, grouped by service + classified.
- `secret-store.yaml` — `ClusterSecretStore` (canonical backend: AWS Secrets
  Manager; swap the `provider` block for GCP Secret Manager or Vault — ESO supports all).
- `external-secret.yaml` — reconciles all 30 secrets from the store into the
  `coindex-secrets` Secret. `refreshInterval: 1h` drives rotation pickup.
- `service-account.yaml` — workload-identity SA (IRSA/GKE WI); no static cloud
  credential is stored in the cluster.

## Apply order
1. Install ESO (Helm): `external-secrets/external-secrets`.
2. `kubectl apply -f service-account.yaml`
3. `kubectl apply -f secret-store.yaml`
4. `kubectl apply -f external-secret.yaml`
ESO then creates/updates `coindex-secrets`; existing Deployments need no change.

## Rotation
Rotate the value in the upstream store. ESO rewrites the k8s Secret within
`refreshInterval` — **no code or manifest change**. Because services read most
secrets once at boot, apply with `kubectl rollout restart deploy -n coindex` to
pick up the new value (documented per-secret in SECRET-INVENTORY.md).

## What is NOT here
`k8s/secrets.example/coindex-secrets.example.yaml` is a deprecated schema/dev
fallback only — not a production source. No real secret value lives in this repo.
