# CoinDex — Kubernetes Deployment Layer (Phase 20)

Production manifests for all 17 services + 5 stateful dependencies, generated from
the **real** service contracts on disk (EXPOSE ports, /healthz+/readyz+/metrics
endpoints, and the exact ${ENV} dependencies each service's config references).

## Layout
- `namespace.yaml` — the `coindex` namespace
- `configmaps/` — non-secret connection coordinates (in-cluster Service DNS)
- `secrets.example/` — **template only**, no real secrets; copy + fill out-of-band
- `deployments/` — 17 app Deployments + 5 stateful StatefulSets (postgres,
  timescale, clickhouse, redis, kafka)
- `services/` — ClusterIP Services for apps + headless Services for stateful infra
- `ingress/` — public `api` (8090) + `status-engine` (8104) via nginx
- `hpa/` — CPU(70%)+memory(80%) autoscalers (all apps except the single-writer
  `indexer-evm` and the singleton `status-engine`)
- `pdb/` — PodDisruptionBudgets for every app
- `jobs/` — migration Jobs + ConfigMaps built from the **real** SQL files, applied
  in real order (postgres core first → engines → graph; then timescale; clickhouse)

## Probe ports (real, verified)
- `indexer-evm`: probes on **8080** (health package), metrics on **9100**
- all other services: probes + metrics on their **ops port (91xx)**, API on **80xx**

## Honest runtime limitations
- **Not applied to a real cluster.** These manifests are statically authored and
  validated (all 86 parse; ports/probes/deps/secrets/graph audited A–F). They have
  **not** been `kubectl apply`-ed, dry-run, or validated by a live API server / admission
  controllers; no `kubeval`/`kubeconform` schema pass was run here.
- **App images are assumed to exist** at `ghcr.io/coindexpro/coindex-<svc>:${IMAGE_TAG}`,
  built+pushed by the Phase 19 release pipeline. `${IMAGE_TAG}` must be substituted at
  deploy time (kustomize/Helm/envsubst) — it is intentionally templated, not a fake digest.
- **Stateful infra is the self-hosted option.** Single-replica StatefulSets are
  provided so the graph is complete and correct; production may instead point the
  DSNs at managed Postgres/ClickHouse. The DSN hosts in the example Secret are the
  in-cluster Service names and must be repointed if using managed stores.
- **Secrets are placeholders** (`CHANGEME`) and must be supplied via a real secret
  manager; nothing here contains a real credential.
