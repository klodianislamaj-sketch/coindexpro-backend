#!/usr/bin/env python3
"""Generate the CoinDex Kubernetes layer from VERIFIED real service data.

Every value below was extracted from the real Dockerfiles/configs on disk
(EXPOSE ports, /healthz+/readyz+/metrics endpoints, ${ENV} dependency vars). The
generator emits manifests so ports/probes/env stay exactly consistent across all
17 services. Nothing is guessed.
"""
import os, textwrap

NS = "coindex"
REGISTRY = "ghcr.io/coindexpro"
TAG = "${IMAGE_TAG}"  # set by release pipeline; templated, not a fake digest

# --- real service model (verified from disk) --------------------------------
# api_port / ops_port from EXPOSE; probe_port = where /healthz,/readyz live:
#   indexer-evm serves probes on 8080 (health pkg) + metrics on 9100
#   all others serve probes+metrics on the ops port (91xx), API on the 80xx port
# envs = the real ${ENV} vars each service's config references.
SERVICES = {
  "indexer-evm": dict(api=8080, ops=9100, probe=8080, metrics=9100, hpa=False, replicas=1,
    envs=["CHECKPOINT_PG_DSN","REDIS_ADDR","CLICKHOUSE_ADDR","CLICKHOUSE_USER","CLICKHOUSE_PASSWORD",
          "KAFKA_BROKERS","ETH_RPC_PRIMARY","ETH_RPC_SECONDARY","ETH_WSS_PRIMARY","BSC_RPC_PRIMARY",
          "BSC_RPC_SECONDARY","BASE_RPC_PRIMARY","ARB_RPC_PRIMARY","POLYGON_RPC_PRIMARY","PLS_RPC_PRIMARY"]),
  "enricher": dict(api=None, ops=9102, probe=9102, metrics=9102, hpa=True, replicas=2,
    envs=["CLICKHOUSE_ADDR","CLICKHOUSE_USER","CLICKHOUSE_PASSWORD","COINGECKO_API_KEY","KAFKA_BROKERS","REDIS_ADDR","TIMESCALE_DSN"]),
  "api": dict(api=8090, ops=9101, probe=9101, metrics=9101, hpa=True, replicas=3, public=True,
    envs=["ADMIN_API_KEY","CLICKHOUSE_ADDR","CLICKHOUSE_USER","CLICKHOUSE_PASSWORD","CORS_ORIGINS","JWT_SECRET","POSTGRES_DSN","REDIS_ADDR","TIMESCALE_DSN"]),
  "provider-trust": dict(api=8091, ops=9103, probe=9103, metrics=9103, hpa=True, replicas=2,
    envs=["KAFKA_BROKERS","PROVIDER_TRUST_PG_DSN","REDIS_ADDR"]),
  "wallet-profiler": dict(api=8092, ops=9104, probe=9104, metrics=9104, hpa=True, replicas=2,
    envs=["CLICKHOUSE_ADDR","CLICKHOUSE_USER","CLICKHOUSE_PASSWORD","POSTGRES_DSN","REDIS_ADDR"]),
  "label-engine": dict(api=8093, ops=9105, probe=9105, metrics=9105, hpa=True, replicas=2,
    envs=["IMPORT_API_KEY","LABEL_ENGINE_PG_DSN","PARTNER_ARKHAM_PUBKEY","PARTNER_CHAINALYSIS_PUBKEY","REDIS_ADDR"]),
  "contract-analyzer": dict(api=8094, ops=9106, probe=9106, metrics=9106, hpa=True, replicas=2,
    envs=["POSTGRES_DSN","REDIS_ADDR"]),
  "graph-engine": dict(api=8095, ops=9107, probe=9107, metrics=9107, hpa=True, replicas=2,
    envs=["CLICKHOUSE_ADDR","CLICKHOUSE_USER","CLICKHOUSE_PASSWORD","KAFKA_BROKERS","POSTGRES_DSN","REDIS_ADDR"]),
  "alert-engine": dict(api=8096, ops=9108, probe=9108, metrics=9108, hpa=True, replicas=2,
    envs=["KAFKA_BROKERS","POSTGRES_DSN","REDIS_ADDR","SMTP_FROM","SMTP_HOST","SMTP_PASS","SMTP_USER","TELEGRAM_BOT_TOKEN"]),
  "flow-engine": dict(api=8097, ops=9109, probe=9109, metrics=9109, hpa=True, replicas=2,
    envs=["CLICKHOUSE_ADDR","CLICKHOUSE_USER","CLICKHOUSE_PASSWORD","KAFKA_BROKERS","POSTGRES_DSN","REDIS_ADDR"]),
  "social-engine": dict(api=8098, ops=9110, probe=9110, metrics=9110, hpa=True, replicas=2,
    envs=["DISCORD_BOT_TOKEN","FARCASTER_API_KEY","FARCASTER_BASE_URL","POSTGRES_DSN","REDDIT_OAUTH_TOKEN","REDIS_ADDR","TELEGRAM_BOT_TOKEN","TWITTER_BEARER"]),
  "strategy-engine": dict(api=8099, ops=9111, probe=9111, metrics=9111, hpa=True, replicas=2,
    envs=["CLICKHOUSE_ADDR","CLICKHOUSE_USER","CLICKHOUSE_PASSWORD","KAFKA_BROKERS","POSTGRES_DSN","REDIS_ADDR"]),
  "execution-engine": dict(api=8100, ops=9112, probe=9112, metrics=9112, hpa=True, replicas=2,
    envs=["CLICKHOUSE_ADDR","CLICKHOUSE_USER","CLICKHOUSE_PASSWORD","KAFKA_BROKERS","POSTGRES_DSN","REDIS_ADDR"]),
  "portfolio-engine": dict(api=8101, ops=9113, probe=9113, metrics=9113, hpa=True, replicas=2,
    envs=["CLICKHOUSE_ADDR","CLICKHOUSE_USER","CLICKHOUSE_PASSWORD","KAFKA_BROKERS","POSTGRES_DSN","REDIS_ADDR"]),
  "premium-engine": dict(api=8102, ops=9114, probe=9114, metrics=9114, hpa=True, replicas=2,
    envs=["POSTGRES_DSN","REDIS_ADDR","STRIPE_PRICE_ENTERPRISE","STRIPE_PRICE_PREMIUM","STRIPE_SECRET_KEY","STRIPE_WEBHOOK_SECRET"]),
  "replay-engine": dict(api=8103, ops=9115, probe=9115, metrics=9115, hpa=True, replicas=2,
    envs=["CLICKHOUSE_ADDR","CLICKHOUSE_USER","CLICKHOUSE_PASSWORD","POSTGRES_DSN","REDIS_ADDR"]),
  "status-engine": dict(api=8104, ops=9116, probe=9116, metrics=9116, hpa=False, replicas=1, public=True,
    envs=["POSTGRES_DSN","REDIS_ADDR"]),
}

# env classification: connection coordinates -> ConfigMap; credentials/keys -> Secret.
SECRET_ENVS = {
  "POSTGRES_DSN","TIMESCALE_DSN","CHECKPOINT_PG_DSN","PROVIDER_TRUST_PG_DSN","LABEL_ENGINE_PG_DSN",
  "CLICKHOUSE_PASSWORD","JWT_SECRET","ADMIN_API_KEY","IMPORT_API_KEY","COINGECKO_API_KEY",
  "STRIPE_SECRET_KEY","STRIPE_WEBHOOK_SECRET","TELEGRAM_BOT_TOKEN","DISCORD_BOT_TOKEN",
  "TWITTER_BEARER","REDDIT_OAUTH_TOKEN","FARCASTER_API_KEY","SMTP_PASS","SMTP_USER",
  "PARTNER_ARKHAM_PUBKEY","PARTNER_CHAINALYSIS_PUBKEY",
  "ETH_RPC_PRIMARY","ETH_RPC_SECONDARY","ETH_WSS_PRIMARY","BSC_RPC_PRIMARY","BSC_RPC_SECONDARY",
  "BASE_RPC_PRIMARY","ARB_RPC_PRIMARY","POLYGON_RPC_PRIMARY","PLS_RPC_PRIMARY",
}
# everything else is a non-secret coordinate
CONFIG_ENVS = {
  "REDIS_ADDR","CLICKHOUSE_ADDR","CLICKHOUSE_USER","KAFKA_BROKERS","CORS_ORIGINS",
  "FARCASTER_BASE_URL","SMTP_HOST","SMTP_FROM","STRIPE_PRICE_PREMIUM","STRIPE_PRICE_ENTERPRISE",
}

ROOT = "k8s"
def w(path, content):
    full = os.path.join(ROOT, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    open(full, "w").write(content.rstrip()+"\n")

def env_block(envs, indent="        "):
    lines=[]
    for e in sorted(envs):
        src = "coindex-secrets" if e in SECRET_ENVS else "coindex-config"
        kind = "secretKeyRef" if e in SECRET_ENVS else "configMapKeyRef"
        lines.append(f"{indent}- name: {e}")
        lines.append(f"{indent}  valueFrom:")
        lines.append(f"{indent}    {kind}:")
        lines.append(f"{indent}      name: {src}")
        lines.append(f"{indent}      key: {e}")
    return "\n".join(lines)

def deployment(name, s):
    probe = s["probe"]; metrics = s["metrics"]
    ports = []
    if s["api"]:
        ports.append((s["api"], "api"))
    if metrics != s.get("api"):
        ports.append((metrics, "metrics"))
    if probe not in [p for p,_ in ports]:
        ports.append((probe, "health"))
    port_yaml = "\n".join(
        f"        - containerPort: {p}\n          name: {nm}" for p,nm in ports)
    return f"""apiVersion: apps/v1
kind: Deployment
metadata:
  name: {name}
  namespace: {NS}
  labels: {{ app: {name}, part-of: coindex }}
spec:
  replicas: {s['replicas']}
  selector:
    matchLabels: {{ app: {name} }}
  strategy:
    type: RollingUpdate
    rollingUpdate: {{ maxUnavailable: 0, maxSurge: 1 }}
  template:
    metadata:
      labels: {{ app: {name}, part-of: coindex }}
      annotations:
        prometheus.io/scrape: "true"
        prometheus.io/port: "{metrics}"
        prometheus.io/path: "/metrics"
    spec:
      securityContext:
        runAsNonRoot: true
        runAsUser: 65532
        fsGroup: 65532
        seccompProfile: {{ type: RuntimeDefault }}
      containers:
      - name: {name}
        image: {REGISTRY}/coindex-{name}:{TAG}
        imagePullPolicy: IfNotPresent
        ports:
{port_yaml}
        env:
{env_block(s['envs'])}
        livenessProbe:
          httpGet: {{ path: /healthz, port: {probe} }}
          initialDelaySeconds: 10
          periodSeconds: 15
          timeoutSeconds: 3
          failureThreshold: 3
        readinessProbe:
          httpGet: {{ path: /readyz, port: {probe} }}
          initialDelaySeconds: 5
          periodSeconds: 10
          timeoutSeconds: 3
          failureThreshold: 3
        resources:
          requests: {{ cpu: "100m", memory: "128Mi" }}
          limits:   {{ cpu: "1000m", memory: "512Mi" }}
        securityContext:
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          capabilities: {{ drop: ["ALL"] }}
"""

def service(name, s):
    ports=[]
    if s["api"]:
        ports.append(f"  - name: api\n    port: {s['api']}\n    targetPort: {s['api']}")
    ports.append(f"  - name: metrics\n    port: {s['metrics']}\n    targetPort: {s['metrics']}")
    if s['probe'] not in (s.get('api'), s['metrics']):
        ports.append(f"  - name: health\n    port: {s['probe']}\n    targetPort: {s['probe']}")
    return f"""apiVersion: v1
kind: Service
metadata:
  name: {name}
  namespace: {NS}
  labels: {{ app: {name}, part-of: coindex }}
spec:
  type: ClusterIP
  selector: {{ app: {name} }}
  ports:
{chr(10).join(ports)}
"""

def hpa(name, s):
    return f"""apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: {name}
  namespace: {NS}
spec:
  scaleTargetRef: {{ apiVersion: apps/v1, kind: Deployment, name: {name} }}
  minReplicas: {s['replicas']}
  maxReplicas: {max(s['replicas']*3, 6)}
  metrics:
  - type: Resource
    resource: {{ name: cpu, target: {{ type: Utilization, averageUtilization: 70 }} }}
  - type: Resource
    resource: {{ name: memory, target: {{ type: Utilization, averageUtilization: 80 }} }}
  behavior:
    scaleDown: {{ stabilizationWindowSeconds: 300 }}
"""

def pdb(name, s):
    return f"""apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: {name}
  namespace: {NS}
spec:
  {"minAvailable: 1" if s['replicas']>1 else "maxUnavailable: 1"}
  selector:
    matchLabels: {{ app: {name} }}
"""

# --- emit -------------------------------------------------------------------
for name, s in SERVICES.items():
    w(f"deployments/{name}.yaml", deployment(name, s))
    w(f"services/{name}.yaml", service(name, s))
    if s["hpa"]:
        w(f"hpa/{name}.yaml", hpa(name, s))
    w(f"pdb/{name}.yaml", pdb(name, s))

# collect env -> which keys go to config vs secret (only ones actually used)
used = set()
for s in SERVICES.values():
    used |= set(s["envs"])
cfg_keys = sorted(used & CONFIG_ENVS)
sec_keys = sorted(used & SECRET_ENVS)
print("CONFIG keys:", cfg_keys)
print("SECRET keys:", sec_keys)
print(f"Generated manifests for {len(SERVICES)} services.")
