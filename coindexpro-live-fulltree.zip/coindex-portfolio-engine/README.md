## coindex-portfolio-engine — Phase 15

Portfolio engine. It derives **per-wallet holdings, cost basis, realized PnL, and
(only when a real price exists) current value + unrealized PnL** from real indexed
trades. It ingests nothing new — it reads existing tables only.

### The hard honesty gate (rules 3 + 9)

There is **no oracle / price-feed table** in this system. The only real price is
the **last observed on-chain trade price**. Therefore:

- **Current value** and **unrealized PnL** are computed **only** when a real,
  recent trade price exists (within `price_window`, default 24h).
- When no real price exists, those fields are **NULL** and the position is marked
  `price_available:false, reason:"not indexed"` — **never estimated**.
- A wallet whose positions are all unpriced gets a snapshot with
  `current_value_usd: null` and `priced_coverage: 0` — a partial valuation is
  never presented as complete.

### Source-of-truth mapping (verified on disk)

| Output | Real source |
|---|---|
| tracked wallets | Phase 2 `portfolios` (`sync_state='synced'`) |
| holdings (net qty) | Phase 2 `wallet_trades` — `sum(buy.qty) − sum(sell.qty)`, raw base units scaled by `token_registry.decimals` |
| cost basis + realized PnL | Phase 6 `wallet_trade_stats` (`buy_usd`, `sell_usd`, `realized_pnl_usd`) |
| current price | Phase 2 `wallet_trades.price_usd` — **last real trade within the price window** |
| per-holding risk | Phase 8 `contract_analysis.score` |
| symbol / decimals | Phase 2 `token_registry` |

Tracked wallets are real synced `portfolios` rows — never an invented list. A
position only exists when the wallet actually holds the token (net qty > 0);
sold-out / dust positions are excluded.

### Realized vs unrealized (kept honest)

- **Realized PnL** is read directly from Phase 6 (real FIFO close PnL) and is
  always summable, regardless of current price.
- **Cost basis remaining** is derived from the real `buy_usd`/`sell_usd` and the
  realized figure (`remaining = buy_usd − (sell_usd − realized)`); if it can't be
  determined it is left `null`, never assumed.
- **Unrealized PnL** requires **both** a real current value **and** a known real
  cost basis; missing either leaves it `null`.

### priced_coverage (the snapshot honesty field)

`priced_coverage = priced_positions / open_positions`. Value and unrealized totals
sum only the priced positions; with `coverage < 1` the totals are explicitly
partial, and with `coverage = 0` they are `null`.

### Outputs (tables)

`portfolio_positions` (per holding, price-dependent fields null without a real
price) and `portfolio_snapshots` (per-wallet totals + `priced_coverage`).

### API

| Route | Returns |
|---|---|
| `GET /portfolio/:chain/:wallet/positions` | per-token holdings (or not indexed) |
| `GET /portfolio/:chain/:wallet/snapshot` | portfolio totals + priced_coverage (or not indexed) |
| `GET /portfolio/:chain/:wallet` | combined snapshot + positions |

Static/longer routes are registered before the shorter param route. Ops:
`/healthz`, `/readyz`, `/metrics`.

### Idempotency & replay

`portfolio_positions` is rewritten per wallet in a transaction (delete+insert) so
the table always reflects the current real holdings (no stale sold-out rows);
`portfolio_snapshots` upserts on `(user_id, chain, wallet)`. Builds are
deterministic over the same indexed trades.

### Honest boundaries / runtime limitations

- **Real, production-shaped code, NOT compiled or run here** (no Go toolchain, no
  Postgres/ClickHouse/Redis/Kafka, no network). Statically reviewed: imports/
  symbols/interfaces resolve, no import cycle (`db` and `portfolio` depend only on
  `models`), routes ordered, metrics symbols match engine references, no dead code,
  **no orphaned upstream reads** (a redundant `HasTrades` flag was removed). The
  holdings math, priced-coverage aggregation, and unavailable paths were verified
  by simulation. Before production: `go build` + `vet` + lint and an integration
  run.
- **Unrealized PnL is only as fresh as the last trade.** The "current price" is the
  most recent on-chain trade price within the window — not a live quote. Illiquid
  tokens with no recent trade are reported unavailable rather than valued on stale
  data. This is a deliberate honesty choice given no oracle feed exists.
- **No estimates, ever.** No holding, price, value, cost basis, or PnL is synthesized;
  absent inputs are surfaced as `null` / `not indexed`, and a wallet with no
  indexed holdings produces no positions.
- **Position qty assumes complete trade indexing for the wallet.** Net qty is
  `buys − sells` over indexed `wallet_trades`; if a wallet received tokens via
  transfers not captured as trades, qty reflects only what the trade index has
  seen (a documented indexer-coverage limitation, not an estimate).
