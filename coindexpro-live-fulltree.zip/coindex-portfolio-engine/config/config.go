// Package config loads portfolio-engine configuration from YAML with ${ENV} expansion.
package config

import (
	"fmt"
	"os"
	"time"

	"gopkg.in/yaml.v3"
)

type Config struct {
	Server     ServerConfig     `yaml:"server"`
	Postgres   PostgresConfig   `yaml:"postgres"`
	ClickHouse ClickHouseConfig `yaml:"clickhouse"`
	Redis      RedisConfig      `yaml:"redis"`
	Kafka      KafkaConfig      `yaml:"kafka"`
	Build      BuildConfig      `yaml:"build"`
	Log        LogConfig        `yaml:"log"`
}

type ServerConfig struct {
	APIAddr     string `yaml:"api_addr"`
	MetricsAddr string `yaml:"metrics_addr"`
}
type PostgresConfig struct {
	DSN string `yaml:"dsn"`
}
type ClickHouseConfig struct {
	Addrs    []string `yaml:"addrs"`
	Database string   `yaml:"database"`
	Username string   `yaml:"username"`
	Password string   `yaml:"password"`
}
type RedisConfig struct {
	Addr string `yaml:"addr"`
}
type KafkaConfig struct {
	Enabled  bool          `yaml:"enabled"`
	Brokers  []string      `yaml:"brokers"`
	GroupID  string        `yaml:"group_id"`
	Topics   []string      `yaml:"topics"`
	Debounce time.Duration `yaml:"debounce"`
}
type BuildConfig struct {
	Enabled       bool          `yaml:"enabled"`
	Interval      time.Duration `yaml:"interval"`
	MaxPortfolios int           `yaml:"max_portfolios"`
	// PriceWindow: a trade older than this is NOT a usable current price; positions
	// then report value/unrealized PnL as unavailable rather than valuing on stale data.
	PriceWindow time.Duration `yaml:"price_window"`
	CacheTTL    time.Duration `yaml:"cache_ttl"`
}
type LogConfig struct {
	Level string `yaml:"level"`
}

func Load(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}
	var c Config
	if err := yaml.Unmarshal([]byte(os.Expand(string(raw), os.Getenv)), &c); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}
	c.defaults()
	return &c, c.validate()
}

func (c *Config) defaults() {
	if c.Server.APIAddr == "" {
		c.Server.APIAddr = ":8101"
	}
	if c.Server.MetricsAddr == "" {
		c.Server.MetricsAddr = ":9113"
	}
	if c.Build.Interval == 0 {
		c.Build.Interval = 5 * time.Minute
	}
	if c.Build.MaxPortfolios == 0 {
		c.Build.MaxPortfolios = 5000
	}
	if c.Build.PriceWindow == 0 {
		c.Build.PriceWindow = 24 * time.Hour
	}
	if c.Build.CacheTTL == 0 {
		c.Build.CacheTTL = 30 * time.Second
	}
	if c.Kafka.GroupID == "" {
		c.Kafka.GroupID = "coindex-portfolio-engine"
	}
}

func (c *Config) validate() error {
	if c.Postgres.DSN == "" {
		return fmt.Errorf("postgres.dsn empty")
	}
	if len(c.ClickHouse.Addrs) == 0 {
		return fmt.Errorf("clickhouse.addrs empty")
	}
	if c.Redis.Addr == "" {
		return fmt.Errorf("redis.addr empty")
	}
	if c.Kafka.Enabled && len(c.Kafka.Brokers) == 0 {
		return fmt.Errorf("kafka.enabled but brokers empty")
	}
	return nil
}
