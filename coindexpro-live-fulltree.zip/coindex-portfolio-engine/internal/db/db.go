// Package db is the portfolio-engine persistence layer. It reads REAL indexed
// data — ClickHouse wallet_trades (Phase 2) for holdings + last price, Postgres
// wallet_trade_stats (Phase 6) for cost/realized PnL, contract_analysis (Phase 8)
// for risk, token_registry + portfolios (Phase 2) — and persists positions +
// snapshots. Price-dependent values come only from a real last trade; absence
// becomes nil, never an estimate. Imports only the models package (no cycle).
package db

import (
	"context"
	"errors"
	"math/big"
	"strings"
	"time"

	"github.com/ClickHouse/clickhouse-go/v2"
	"github.com/ClickHouse/clickhouse-go/v2/lib/driver"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/coindexpro/coindex-portfolio-engine/internal/models"
)

type Store struct {
	pg *pgxpool.Pool
	ch driver.Conn

	priceWindow time.Duration // a trade older than this is not a usable current price
}

func Open(ctx context.Context, pgDSN string, chAddrs []string, chDB, chUser, chPass string, priceWindow time.Duration) (*Store, error) {
	pg, err := pgxpool.New(ctx, pgDSN)
	if err != nil {
		return nil, err
	}
	if err := pg.Ping(ctx); err != nil {
		return nil, err
	}
	ch, err := clickhouse.Open(&clickhouse.Options{
		Addr: chAddrs,
		Auth: clickhouse.Auth{Database: chDB, Username: chUser, Password: chPass},
	})
	if err != nil {
		return nil, err
	}
	if err := ch.Ping(ctx); err != nil {
		return nil, err
	}
	if priceWindow <= 0 {
		priceWindow = 24 * time.Hour
	}
	return &Store{pg: pg, ch: ch, priceWindow: priceWindow}, nil
}

func (s *Store) Close() {
	s.pg.Close()
	_ = s.ch.Close()
}
func (s *Store) Ping(ctx context.Context) error {
	if err := s.pg.Ping(ctx); err != nil {
		return err
	}
	return s.ch.Ping(ctx)
}

// ---------- sources ----------

// TrackedPortfolios reads real user portfolios (Phase 2). We track wallets that
// have been synced (positions are only meaningful over real indexed history).
func (s *Store) TrackedPortfolios(ctx context.Context, limit int) ([]models.PortfolioRef, error) {
	const q = `
		SELECT user_id::text, chain, wallet, sync_state
		FROM portfolios
		WHERE sync_state = 'synced'
		ORDER BY synced_at DESC NULLS LAST
		LIMIT $1`
	rows, err := s.pg.Query(ctx, q, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.PortfolioRef
	for rows.Next() {
		var r models.PortfolioRef
		if err := rows.Scan(&r.UserID, &r.Chain, &r.Wallet, &r.SyncState); err != nil {
			return nil, err
		}
		r.Wallet = strings.ToLower(r.Wallet)
		out = append(out, r)
	}
	return out, rows.Err()
}

// HeldTokens reconstructs net holdings from REAL wallet_trades. qty is stored as a
// raw decimal string of token base units; we sum buys minus sells per token and
// scale by the token's decimals (from token_registry) to get human units. Tokens
// with non-positive net qty are excluded (sold out / dust).
func (s *Store) HeldTokens(ctx context.Context, chain, wallet string) ([]models.TradeAgg, error) {
	wallet = strings.ToLower(wallet)
	// Sum signed raw qty per token. qty is a decimal string; ClickHouse can't sum a
	// String, so we pull per-token buy/sell raw sums via toDecimal256 on the string.
	const q = `
		SELECT token,
		       sumIf(toDecimal256(qty, 0), side = 'buy')  AS bought,
		       sumIf(toDecimal256(qty, 0), side = 'sell') AS sold
		FROM coindex.wallet_trades
		WHERE chain = ? AND wallet = ?
		GROUP BY token`
	rows, err := s.ch.Query(ctx, q, chain, wallet)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	type raw struct {
		token         string
		bought, sold  *big.Int
	}
	var raws []raw
	tokens := make([]string, 0)
	for rows.Next() {
		var token string
		var bought, sold big.Int
		if err := rows.Scan(&token, &bought, &sold); err != nil {
			return nil, err
		}
		raws = append(raws, raw{token: token, bought: &bought, sold: &sold})
		tokens = append(tokens, strings.ToLower(token))
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}

	decimals := s.tokenDecimals(ctx, chain, tokens)
	var out []models.TradeAgg
	for _, r := range raws {
		net := new(big.Int).Sub(r.bought, r.sold)
		if net.Sign() <= 0 {
			continue // not a current holding
		}
		dec := 18
		if d, ok := decimals[strings.ToLower(r.token)]; ok {
			dec = d
		}
		out = append(out, models.TradeAgg{
			Chain: chain, Wallet: wallet, Token: strings.ToLower(r.token),
			QtyHeld: scaleByDecimals(net, dec),
		})
	}
	return out, nil
}

// PositionInputs gathers the real per-holding inputs: cost/realized (Phase 6),
// last real price (Phase 2 trades), risk (Phase 8), symbol (Phase 2 registry).
func (s *Store) PositionInputs(ctx context.Context, userID, chain, wallet, token string, qty float64) (models.PositionInputs, error) {
	token = strings.ToLower(token)
	in := models.PositionInputs{Chain: chain, Wallet: strings.ToLower(wallet), Token: token, QtyHeld: qty}

	// symbol (Phase 2 token_registry)
	{
		const q = `SELECT symbol FROM token_registry WHERE chain=$1 AND address=$2`
		var sym *string
		err := s.pg.QueryRow(ctx, q, chain, token).Scan(&sym)
		if err == nil && sym != nil {
			in.Symbol = *sym
		} else if err != nil && !errors.Is(err, pgx.ErrNoRows) {
			return in, err
		}
	}

	// Phase 6 wallet_trade_stats: remaining cost basis proxy + realized PnL.
	// cost basis remaining ~= buy_usd - sell_usd is NOT used (that is net flow);
	// we read the real realized_pnl_usd directly, and use buy_usd as the cost basis
	// of acquired units only when sells have not closed the position. To stay
	// strictly real we expose realized PnL always, and cost basis as buy_usd minus
	// the portion already realized; if that is unknown we leave it nil.
	{
		const q = `SELECT buy_usd, sell_usd, realized_pnl_usd FROM wallet_trade_stats
			WHERE chain=$1 AND address=$2 AND token=$3`
		var buyUSD, sellUSD float64
		var realized *float64
		err := s.pg.QueryRow(ctx, q, chain, in.Wallet, token).Scan(&buyUSD, &sellUSD, &realized)
		if err == nil {
			in.RealizedPnlUSD = realized
			// remaining cost basis = total bought cost minus cost already sold.
			// sell proceeds (sell_usd) minus realized PnL = cost of sold units.
			if realized != nil {
				costOfSold := sellUSD - *realized
				remaining := buyUSD - costOfSold
				if remaining > 0 {
					rb := round2(remaining)
					in.CostBasisUSD = &rb
				}
			} else if sellUSD == 0 && buyUSD > 0 {
				// nothing sold yet: full buy cost is the basis
				rb := round2(buyUSD)
				in.CostBasisUSD = &rb
			}
		} else if !errors.Is(err, pgx.ErrNoRows) {
			return in, err
		}
	}

	// last REAL trade price within the price window (Phase 2 wallet_trades)
	if pr, ok := s.lastTradePrice(ctx, chain, token); ok {
		in.Price = &pr
	}

	// Phase 8 contract risk
	{
		const q = `SELECT score FROM contract_analysis WHERE chain=$1 AND address=$2`
		var sc int
		err := s.pg.QueryRow(ctx, q, chain, token).Scan(&sc)
		if err == nil {
			in.RiskScore = &sc
		} else if !errors.Is(err, pgx.ErrNoRows) {
			return in, err
		}
	}
	return in, nil
}

// lastTradePrice returns the most recent REAL priced trade for a token, but only
// if it is within priceWindow — a stale price is not a current price, so we report
// it unavailable rather than value a position on old data.
func (s *Store) lastTradePrice(ctx context.Context, chain, token string) (models.Price, bool) {
	since := time.Now().Add(-s.priceWindow)
	const q = `
		SELECT price_usd, block_time
		FROM coindex.wallet_trades
		WHERE chain = ? AND token = ? AND price_usd > 0 AND block_time >= ?
		ORDER BY block_time DESC LIMIT 1`
	var price float64
	var ts time.Time
	if err := s.ch.QueryRow(ctx, q, chain, token, since).Scan(&price, &ts); err != nil {
		return models.Price{}, false
	}
	if price <= 0 {
		return models.Price{}, false
	}
	return models.Price{PriceUSD: price, AsOf: ts}, true
}

// tokenDecimals batch-reads decimals for a set of tokens (default 18 when absent).
func (s *Store) tokenDecimals(ctx context.Context, chain string, tokens []string) map[string]int {
	out := map[string]int{}
	if len(tokens) == 0 {
		return out
	}
	const q = `SELECT address, decimals FROM token_registry WHERE chain=$1 AND address = ANY($2)`
	rows, err := s.pg.Query(ctx, q, chain, tokens)
	if err != nil {
		return out
	}
	defer rows.Close()
	for rows.Next() {
		var addr string
		var dec *int
		if err := rows.Scan(&addr, &dec); err != nil {
			continue
		}
		if dec != nil {
			out[strings.ToLower(addr)] = *dec
		}
	}
	return out
}

// ---------- sink ----------

// ReplacePositions rewrites a wallet's positions in one tx so the table always
// reflects exactly the current real holdings (no stale rows from sold-out tokens).
func (s *Store) ReplacePositions(ctx context.Context, userID, chain, wallet string, ps []models.Position) error {
	wallet = strings.ToLower(wallet)
	tx, err := s.pg.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	if _, err := tx.Exec(ctx,
		`DELETE FROM portfolio_positions WHERE user_id=$1 AND chain=$2 AND wallet=$3`,
		userID, chain, wallet); err != nil {
		return err
	}
	for _, p := range ps {
		const q = `
			INSERT INTO portfolio_positions
				(user_id, chain, wallet, token, symbol, qty_held, cost_basis_usd, realized_pnl_usd,
				 current_price_usd, price_as_of, current_value_usd, unrealized_pnl_usd, risk_score)
			VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`
		if _, err := tx.Exec(ctx, q, userID, chain, wallet, p.Token, nullStr(p.Symbol), p.QtyHeld,
			p.CostBasisUSD, p.RealizedPnlUSD, p.CurrentPriceUSD, p.PriceAsOf,
			p.CurrentValueUSD, p.UnrealizedPnlUSD, p.RiskScore); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

func (s *Store) UpsertSnapshot(ctx context.Context, snap models.Snapshot) error {
	const q = `
		INSERT INTO portfolio_snapshots
			(user_id, chain, wallet, positions, priced_positions, current_value_usd,
			 cost_basis_usd, realized_pnl_usd, unrealized_pnl_usd, priced_coverage)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
		ON CONFLICT (user_id, chain, wallet) DO UPDATE SET
			positions=$4, priced_positions=$5, current_value_usd=$6, cost_basis_usd=$7,
			realized_pnl_usd=$8, unrealized_pnl_usd=$9, priced_coverage=$10, updated_at=now()`
	_, err := s.pg.Exec(ctx, q, snap.UserID, snap.Chain, snap.Wallet, snap.Positions, snap.PricedPositions,
		snap.CurrentValueUSD, snap.CostBasisUSD, snap.RealizedPnlUSD, snap.UnrealizedPnlUSD, snap.PricedCoverage)
	return err
}

// ---------- API reads ----------

func (s *Store) Positions(ctx context.Context, chain, wallet string) ([]models.Position, error) {
	const q = `
		SELECT user_id::text, chain, wallet, token, coalesce(symbol,''), qty_held, cost_basis_usd, realized_pnl_usd,
		       current_price_usd, price_as_of, current_value_usd, unrealized_pnl_usd, risk_score
		FROM portfolio_positions WHERE chain=$1 AND wallet=$2 ORDER BY current_value_usd DESC NULLS LAST`
	rows, err := s.pg.Query(ctx, q, chain, strings.ToLower(wallet))
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.Position
	for rows.Next() {
		var p models.Position
		if err := rows.Scan(&p.UserID, &p.Chain, &p.Wallet, &p.Token, &p.Symbol, &p.QtyHeld,
			&p.CostBasisUSD, &p.RealizedPnlUSD, &p.CurrentPriceUSD, &p.PriceAsOf,
			&p.CurrentValueUSD, &p.UnrealizedPnlUSD, &p.RiskScore); err != nil {
			return nil, err
		}
		p.PriceAvailable = p.CurrentPriceUSD != nil
		if !p.PriceAvailable {
			p.PriceReason = "not indexed"
		}
		out = append(out, p)
	}
	return out, rows.Err()
}

func (s *Store) SnapshotFor(ctx context.Context, chain, wallet string) (models.Snapshot, bool, error) {
	const q = `
		SELECT user_id::text, chain, wallet, positions, priced_positions, current_value_usd,
		       cost_basis_usd, realized_pnl_usd, unrealized_pnl_usd, priced_coverage, updated_at
		FROM portfolio_snapshots WHERE chain=$1 AND wallet=$2`
	var s2 models.Snapshot
	err := s.pg.QueryRow(ctx, q, chain, strings.ToLower(wallet)).Scan(
		&s2.UserID, &s2.Chain, &s2.Wallet, &s2.Positions, &s2.PricedPositions, &s2.CurrentValueUSD,
		&s2.CostBasisUSD, &s2.RealizedPnlUSD, &s2.UnrealizedPnlUSD, &s2.PricedCoverage, &s2.UpdatedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return models.Snapshot{}, false, nil
	}
	if err != nil {
		return models.Snapshot{}, false, err
	}
	return s2, true, nil
}

// ---------- helpers ----------

func nullStr(s string) any {
	if s == "" {
		return nil
	}
	return s
}

// scaleByDecimals converts a raw base-unit big.Int to human units (float64).
func scaleByDecimals(raw *big.Int, decimals int) float64 {
	if raw.Sign() == 0 {
		return 0
	}
	f := new(big.Float).SetInt(raw)
	div := new(big.Float).SetInt(new(big.Int).Exp(big.NewInt(10), big.NewInt(int64(decimals)), nil))
	res := new(big.Float).Quo(f, div)
	v, _ := res.Float64()
	return v
}

func round2(x float64) float64 {
	return float64(int64(x*100+0.5)) / 100
}
