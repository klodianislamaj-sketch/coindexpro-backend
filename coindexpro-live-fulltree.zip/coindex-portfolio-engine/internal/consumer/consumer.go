// Package consumer drives portfolio rebuilds. Holdings/PnL are a synthesis over
// already-indexed trades, so a rebuild is a periodic recomputation and optionally
// a debounced reaction to upstream Kafka activity. The Kafka message is only a
// "something changed" signal; the rebuild always reads the real tables.
package consumer

import (
	"context"
	"time"

	"github.com/twmb/franz-go/pkg/kgo"
	"go.uber.org/zap"
)

// Builder is satisfied by portfolio.Engine.
type Builder interface {
	BuildOnce(ctx context.Context) error
}

type Scheduler struct {
	builder  Builder
	interval time.Duration
	log      *zap.Logger
}

func NewScheduler(builder Builder, interval time.Duration, log *zap.Logger) *Scheduler {
	if interval <= 0 {
		interval = 5 * time.Minute
	}
	return &Scheduler{builder: builder, interval: interval, log: log}
}

func (s *Scheduler) Run(ctx context.Context) error {
	t := time.NewTicker(s.interval)
	defer t.Stop()
	s.once(ctx)
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-t.C:
			s.once(ctx)
		}
	}
}

func (s *Scheduler) once(ctx context.Context) {
	if err := s.builder.BuildOnce(ctx); err != nil {
		s.log.Warn("scheduled portfolio build failed", zap.Error(err))
	}
}

// KafkaTrigger optionally debounces upstream activity (new trades) into rebuilds.
type KafkaTrigger struct {
	cl       *kgo.Client
	builder  Builder
	debounce time.Duration
	log      *zap.Logger
}

func NewKafkaTrigger(brokers []string, group string, topics []string, builder Builder, debounce time.Duration, log *zap.Logger) (*KafkaTrigger, error) {
	cl, err := kgo.NewClient(
		kgo.SeedBrokers(brokers...),
		kgo.ConsumerGroup(group),
		kgo.ConsumeTopics(topics...),
	)
	if err != nil {
		return nil, err
	}
	if debounce <= 0 {
		debounce = time.Minute
	}
	return &KafkaTrigger{cl: cl, builder: builder, debounce: debounce, log: log}, nil
}

func (k *KafkaTrigger) Run(ctx context.Context) error {
	dirty := false
	timer := time.NewTimer(k.debounce)
	timer.Stop()
	for {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		pollCtx, cancel := context.WithTimeout(ctx, time.Second)
		fetches := k.cl.PollFetches(pollCtx)
		cancel()
		n := 0
		fetches.EachRecord(func(_ *kgo.Record) { n++ })
		if n > 0 && !dirty {
			dirty = true
			timer.Reset(k.debounce)
		}
		select {
		case <-timer.C:
			if dirty {
				dirty = false
				if err := k.builder.BuildOnce(ctx); err != nil {
					k.log.Warn("triggered portfolio build failed", zap.Error(err))
				}
			}
		default:
		}
	}
}

func (k *KafkaTrigger) Close() { k.cl.Close() }
