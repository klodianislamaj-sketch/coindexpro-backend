// Package api serves the portfolio reads. Any "no real data" path returns the
// mandated {available:false, reason:"not indexed"} envelope. Price-dependent
// fields are surfaced exactly as the engine computed them — present only when a
// real trade price existed — and every snapshot carries priced_coverage so a
// partial valuation is never shown as complete.
package api

import (
	"regexp"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"

	"github.com/coindexpro/coindex-portfolio-engine/internal/db"
	"github.com/coindexpro/coindex-portfolio-engine/internal/metrics"
)

type API struct{ store *db.Store }

func New(store *db.Store) *API { return &API{store: store} }

// Register orders static routes before parameterized ones.
func (a *API) Register(app *fiber.App) {
	app.Use(a.observe)
	app.Get("/portfolio/:chain/:wallet/positions", a.positions)
	app.Get("/portfolio/:chain/:wallet/snapshot", a.snapshot)
	app.Get("/portfolio/:chain/:wallet", a.overview)
}

func (a *API) observe(c *fiber.Ctx) error {
	start := time.Now()
	err := c.Next()
	metrics.APILatency.WithLabelValues(c.Route().Path, statusClass(c.Response().StatusCode())).
		Observe(time.Since(start).Seconds())
	return err
}

var evmAddr = regexp.MustCompile(`^0x[0-9a-fA-F]{40}$`)

func walletParams(c *fiber.Ctx) (chain, wallet string, ok bool) {
	chain = strings.ToLower(c.Params("chain"))
	wallet = strings.ToLower(c.Params("wallet"))
	if chain == "" || !evmAddr.MatchString(wallet) {
		return "", "", false
	}
	return chain, wallet, true
}

func notIndexed(c *fiber.Ctx, extra fiber.Map) error {
	m := fiber.Map{"available": false, "reason": "not indexed"}
	for k, v := range extra {
		m[k] = v
	}
	return c.JSON(m)
}

// GET /portfolio/:chain/:wallet/positions
func (a *API) positions(c *fiber.Ctx) error {
	chain, wallet, ok := walletParams(c)
	if !ok {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid chain or wallet"})
	}
	ps, err := a.store.Positions(c.UserContext(), chain, wallet)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(ps) == 0 {
		return notIndexed(c, fiber.Map{"chain": chain, "wallet": wallet})
	}
	return c.JSON(fiber.Map{"chain": chain, "wallet": wallet, "available": true, "positions": ps})
}

// GET /portfolio/:chain/:wallet/snapshot
func (a *API) snapshot(c *fiber.Ctx) error {
	chain, wallet, ok := walletParams(c)
	if !ok {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid chain or wallet"})
	}
	snap, found, err := a.store.SnapshotFor(c.UserContext(), chain, wallet)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !found {
		return notIndexed(c, fiber.Map{"chain": chain, "wallet": wallet})
	}
	return c.JSON(fiber.Map{"chain": chain, "wallet": wallet, "available": true, "snapshot": snap})
}

// GET /portfolio/:chain/:wallet — combined snapshot + positions
func (a *API) overview(c *fiber.Ctx) error {
	chain, wallet, ok := walletParams(c)
	if !ok {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid chain or wallet"})
	}
	snap, found, err := a.store.SnapshotFor(c.UserContext(), chain, wallet)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !found {
		return notIndexed(c, fiber.Map{"chain": chain, "wallet": wallet})
	}
	ps, err := a.store.Positions(c.UserContext(), chain, wallet)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	return c.JSON(fiber.Map{"chain": chain, "wallet": wallet, "available": true,
		"snapshot": snap, "positions": ps})
}

func statusClass(code int) string {
	switch {
	case code >= 500:
		return "5xx"
	case code >= 400:
		return "4xx"
	default:
		return "2xx"
	}
}
