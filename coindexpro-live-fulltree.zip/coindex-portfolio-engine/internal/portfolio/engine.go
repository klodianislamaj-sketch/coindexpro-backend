package portfolio

import (
	"context"
	"time"

	"go.uber.org/zap"

	"github.com/coindexpro/coindex-portfolio-engine/internal/metrics"
	"github.com/coindexpro/coindex-portfolio-engine/internal/models"
)

// Sources reads real upstream inputs (implemented by db.Store).
type Sources interface {
	TrackedPortfolios(ctx context.Context, limit int) ([]models.PortfolioRef, error)
	HeldTokens(ctx context.Context, chain, wallet string) ([]models.TradeAgg, error)
	PositionInputs(ctx context.Context, userID, chain, wallet, token string, qty float64) (models.PositionInputs, error)
}

// Sink persists portfolio outputs (implemented by db.Store).
type Sink interface {
	ReplacePositions(ctx context.Context, userID, chain, wallet string, ps []models.Position) error
	UpsertSnapshot(ctx context.Context, s models.Snapshot) error
}

type Engine struct {
	src  Sources
	sink Sink
	cfg  Config
	log  *zap.Logger
}

type Config struct {
	MaxPortfolios int
}

func NewEngine(src Sources, sink Sink, cfg Config, log *zap.Logger) *Engine {
	return &Engine{src: src, sink: sink, cfg: cfg, log: log}
}

// BuildOnce recomputes positions + snapshots for tracked portfolios.
func (e *Engine) BuildOnce(ctx context.Context) error {
	t0 := time.Now()
	refs, err := e.src.TrackedPortfolios(ctx, e.cfg.MaxPortfolios)
	if err != nil {
		return err
	}
	built := 0
	for _, ref := range refs {
		held, err := e.src.HeldTokens(ctx, ref.Chain, ref.Wallet)
		if err != nil {
			return err
		}
		var positions []models.Position
		for _, h := range held {
			if h.QtyHeld <= 0 {
				continue // not a current holding (sold out / dust)
			}
			in, err := e.src.PositionInputs(ctx, ref.UserID, ref.Chain, ref.Wallet, h.Token, h.QtyHeld)
			if err != nil {
				return err
			}
			pos, ok := BuildPosition(in)
			if !ok {
				continue
			}
			pos.UserID = ref.UserID
			positions = append(positions, pos)
			metrics.Positions.Inc()
			if !pos.PriceAvailable {
				metrics.UnpricedPositions.Inc()
			}
		}

		// persist positions (replace = always reflects current real holdings)
		if err := e.sink.ReplacePositions(ctx, ref.UserID, ref.Chain, ref.Wallet, positions); err != nil {
			return err
		}
		// snapshot aggregate (priced_coverage exposed)
		snap := Aggregate(ref.UserID, ref.Chain, ref.Wallet, positions)
		if err := e.sink.UpsertSnapshot(ctx, snap); err != nil {
			return err
		}
		built++
	}

	metrics.Builds.Inc()
	metrics.BuildDuration.Observe(time.Since(t0).Seconds())
	e.log.Info("portfolio build complete", zap.Int("portfolios", len(refs)), zap.Int("rebuilt", built))
	return nil
}
