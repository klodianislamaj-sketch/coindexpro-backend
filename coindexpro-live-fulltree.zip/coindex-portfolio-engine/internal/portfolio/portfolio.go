// Package portfolio holds the portfolio computation logic. Every figure is
// derived from a REAL indexed value. The central honesty gate: current value and
// unrealized PnL are computed ONLY when a real recent trade price exists. There is
// no oracle price source, so without a real price these fields stay nil and the
// position is marked price-unavailable — never estimated.
package portfolio

import (
	"math"
	"time"

	"github.com/coindexpro/coindex-portfolio-engine/internal/models"
)

// BuildPosition turns real per-holding inputs into a Position. It returns ok=false
// when the wallet does not actually hold the token (qty <= 0) — we do not emit
// dust/closed positions. Price-dependent fields are populated only when a real
// price is present.
func BuildPosition(in models.PositionInputs) (models.Position, bool) {
	if in.QtyHeld <= 0 {
		return models.Position{}, false // not a current holding
	}
	p := models.Position{
		Chain: in.Chain, Wallet: in.Wallet, Token: in.Token, Symbol: in.Symbol,
		QtyHeld:        round8(in.QtyHeld),
		CostBasisUSD:   in.CostBasisUSD,
		RealizedPnlUSD: in.RealizedPnlUSD,
		RiskScore:      in.RiskScore,
	}

	if in.Price == nil || in.Price.PriceUSD <= 0 {
		// No real price -> no value, no unrealized PnL. Explicitly unavailable.
		p.PriceAvailable = false
		p.PriceReason = "not indexed"
		return p, true
	}

	// real price present -> value is a real computation
	price := in.Price.PriceUSD
	asOf := in.Price.AsOf
	value := round2(in.QtyHeld * price)
	p.CurrentPriceUSD = &price
	p.PriceAsOf = &asOf
	p.CurrentValueUSD = &value
	p.PriceAvailable = true

	// unrealized PnL requires BOTH a real value AND a known real cost basis
	if in.CostBasisUSD != nil {
		u := round2(value - *in.CostBasisUSD)
		p.UnrealizedPnlUSD = &u
	}
	return p, true
}

// Aggregate rolls positions up into a portfolio snapshot. priced_coverage is the
// fraction of open positions that had a real price; value/unrealized totals sum
// only the priced positions and are nil when none could be priced (so a partial
// total is never presented as complete). Realized PnL and cost basis sum the real
// known values regardless of price availability.
func Aggregate(userID, chain, wallet string, positions []models.Position) models.Snapshot {
	s := models.Snapshot{UserID: userID, Chain: chain, Wallet: wallet, UpdatedAt: time.Now().UTC()}
	var value, unreal, cost, realized float64
	var haveValue, haveUnreal, haveCost, haveRealized bool

	for _, p := range positions {
		if p.QtyHeld <= 0 {
			continue
		}
		s.Positions++
		if p.PriceAvailable && p.CurrentValueUSD != nil {
			s.PricedPositions++
			value += *p.CurrentValueUSD
			haveValue = true
			if p.UnrealizedPnlUSD != nil {
				unreal += *p.UnrealizedPnlUSD
				haveUnreal = true
			}
		}
		if p.CostBasisUSD != nil {
			cost += *p.CostBasisUSD
			haveCost = true
		}
		if p.RealizedPnlUSD != nil {
			realized += *p.RealizedPnlUSD
			haveRealized = true
		}
	}

	if s.Positions > 0 {
		s.PricedCoverage = round4(float64(s.PricedPositions) / float64(s.Positions))
	}
	if haveValue {
		v := round2(value)
		s.CurrentValueUSD = &v
	}
	if haveUnreal {
		u := round2(unreal)
		s.UnrealizedPnlUSD = &u
	}
	if haveCost {
		c := round2(cost)
		s.CostBasisUSD = &c
	}
	if haveRealized {
		r := round2(realized)
		s.RealizedPnlUSD = &r
	}
	return s
}

func round2(x float64) float64 { return math.Round(x*100) / 100 }
func round4(x float64) float64 { return math.Round(x*10000) / 10000 }
func round8(x float64) float64 { return math.Round(x*1e8) / 1e8 }
