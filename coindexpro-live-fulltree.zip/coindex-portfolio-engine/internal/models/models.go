// Package models holds the portfolio-engine's shared domain types. The honesty
// contract is in the type model: a Position's price-dependent fields
// (CurrentPriceUSD, CurrentValueUSD, UnrealizedPnlUSD) are POINTERS that are nil
// whenever there is no real recent trade price. There is no oracle price source in
// this system, so these stay nil rather than being estimated, and the snapshot
// always carries PricedCoverage so partial totals are never shown as complete.
package models

import "time"

// PortfolioRef is a user wallet to track (from the real portfolios table).
type PortfolioRef struct {
	UserID    string
	Chain     string
	Wallet    string
	SyncState string
}

// TradeAgg is the real per-(wallet,token) trade aggregate read from indexed data.
// QtyHeld is net token units (buys - sells) reconstructed from real trades.
type TradeAgg struct {
	Chain    string
	Wallet   string
	Token    string
	QtyHeld  float64 // net units from real wallet_trades
}

// Price is the LAST REAL observed trade price for a token (nil-able by absence).
type Price struct {
	PriceUSD float64
	AsOf     time.Time
}

// Position is one explainable holding. Price-dependent fields are nil when no
// real price exists; they are never filled with an estimate.
type Position struct {
	UserID           string     `json:"user_id"`
	Chain            string     `json:"chain"`
	Wallet           string     `json:"wallet"`
	Token            string     `json:"token"`
	Symbol           string     `json:"symbol,omitempty"`
	QtyHeld          float64    `json:"qty_held"`
	CostBasisUSD     *float64   `json:"cost_basis_usd,omitempty"`     // Phase 6; nil if unknown
	RealizedPnlUSD   *float64   `json:"realized_pnl_usd,omitempty"`   // Phase 6; nil until a close
	CurrentPriceUSD  *float64   `json:"current_price_usd,omitempty"`  // last real trade; nil if not indexed
	PriceAsOf        *time.Time `json:"price_as_of,omitempty"`
	CurrentValueUSD  *float64   `json:"current_value_usd,omitempty"`  // qty*price; nil if no price
	UnrealizedPnlUSD *float64   `json:"unrealized_pnl_usd,omitempty"` // value-cost; nil if no price/cost
	RiskScore        *int       `json:"risk_score,omitempty"`         // Phase 8; nil if unanalyzed
	// PriceAvailable makes the unavailable reason explicit on each position.
	PriceAvailable bool   `json:"price_available"`
	PriceReason    string `json:"price_reason,omitempty"`
}

// Snapshot is a per-(user,chain,wallet) aggregate. PricedCoverage = priced / open
// positions; totals that depend on price are nil when nothing could be priced.
type Snapshot struct {
	UserID           string    `json:"user_id"`
	Chain            string    `json:"chain"`
	Wallet           string    `json:"wallet"`
	Positions        int       `json:"positions"`
	PricedPositions  int       `json:"priced_positions"`
	CurrentValueUSD  *float64  `json:"current_value_usd,omitempty"`
	CostBasisUSD     *float64  `json:"cost_basis_usd,omitempty"`
	RealizedPnlUSD   *float64  `json:"realized_pnl_usd,omitempty"`
	UnrealizedPnlUSD *float64  `json:"unrealized_pnl_usd,omitempty"`
	PricedCoverage   float64   `json:"priced_coverage"`
	UpdatedAt        time.Time `json:"updated_at,omitempty"`
}

// PositionInputs bundles the real upstream values for one (wallet, token) holding.
// Every pointer is nil when its source has no row.
type PositionInputs struct {
	Chain  string
	Wallet string
	Token  string
	Symbol string

	QtyHeld        float64  // net units from real trades (required to be a position)
	CostBasisUSD   *float64 // Phase 6 remaining cost basis
	RealizedPnlUSD *float64 // Phase 6 realized PnL
	Price          *Price   // last real trade price (nil = not indexed)
	RiskScore      *int     // Phase 8 contract risk
}
