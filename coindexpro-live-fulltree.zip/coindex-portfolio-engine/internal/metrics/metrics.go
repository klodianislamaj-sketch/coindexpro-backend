// Package metrics holds the portfolio-engine's Prometheus instruments. The symbol
// set matches exactly what internal/portfolio/engine.go references.
package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	Builds = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_portfolio_builds_total", Help: "Portfolio build cycles.",
	})
	BuildDuration = promauto.NewHistogram(prometheus.HistogramOpts{
		Name: "coindex_portfolio_build_seconds", Help: "Portfolio build duration.",
		Buckets: []float64{0.1, 0.5, 1, 5, 15, 30, 60, 120},
	})
	Positions = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_portfolio_positions_total", Help: "Positions computed.",
	})
	UnpricedPositions = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_portfolio_unpriced_positions_total", Help: "Positions with no real price (value unavailable).",
	})
	APILatency = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name: "coindex_portfolio_api_seconds", Help: "API latency by route + status.",
		Buckets: prometheus.DefBuckets,
	}, []string{"route", "status"})
	DBErrors = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_portfolio_db_errors_total", Help: "DB errors.",
	})
)
