module github.com/coindexpro/coindex-portfolio-engine

go 1.22

require (
	github.com/gofiber/fiber/v2 v2.52.4
	github.com/ClickHouse/clickhouse-go/v2 v2.23.0
	github.com/jackc/pgx/v5 v5.6.0
	github.com/redis/go-redis/v9 v9.5.3
	github.com/twmb/franz-go v1.16.1
	github.com/prometheus/client_golang v1.19.1
	go.uber.org/zap v1.27.0
	gopkg.in/yaml.v3 v3.0.1
)
