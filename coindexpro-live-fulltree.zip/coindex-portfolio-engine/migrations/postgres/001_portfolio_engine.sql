-- =============================================================================
-- CoinDex Portfolio Engine — PostgreSQL migration (Phase 15)
-- =============================================================================
-- Derives per-wallet holdings + PnL strictly from REAL indexed data:
--   * portfolios            (Phase 2) — which user wallets to track
--   * wallet_trades         (Phase 2, ClickHouse) — real buys/sells (qty, price)
--   * wallet_trade_stats    (Phase 6) — real per-(wallet,token) realized PnL/cost
--   * wallet_trades.price_usd / swaps.price_usd — last REAL observed trade price
--   * contract_analysis     (Phase 8) — per-holding risk
--   * token_registry        (Phase 2) — symbol/decimals
--
-- HARD HONESTY RULE: current value and UNREALIZED PnL require a real recent trade
-- price. There is no oracle/price-feed table in this system, so when no real price
-- exists the value/unrealized fields are NULL and the API reports them unavailable
-- ({available:false, reason:"not indexed"}). Nothing is ever estimated.
--
-- All NEW tables (collision-checked: no portfolio_positions/holdings exist);
-- idempotent.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- portfolio_positions — one row per (portfolio wallet, token) holding.
--   qty_held is reconstructed from REAL trades (buys - sells, FIFO-consistent).
--   cost_basis_usd / realized_pnl_usd come from Phase 6 (real, FIFO).
--   current_price_usd is the LAST REAL observed trade price (NULL if none recent).
--   current_value_usd / unrealized_pnl_usd are populated ONLY when a real price
--   exists; otherwise NULL (never estimated).
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS portfolio_positions (
    id                bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id           uuid        NOT NULL,
    chain             text        NOT NULL,
    wallet            text        NOT NULL CHECK (wallet = lower(wallet)),
    token             text        NOT NULL CHECK (token = lower(token)),
    symbol            text,                                  -- token_registry.symbol (may be NULL)
    qty_held          numeric     NOT NULL,                  -- net token units from real trades
    cost_basis_usd    numeric,                               -- remaining cost basis (Phase 6); NULL if unknown
    realized_pnl_usd  numeric,                               -- Phase 6 wallet_trade_stats (NULL until a close)
    -- price-dependent fields: present ONLY when a real recent price exists
    current_price_usd numeric,                               -- last real trade price; NULL if not indexed
    price_as_of       timestamptz,                           -- block_time of that real trade
    current_value_usd numeric,                               -- qty_held * current_price_usd; NULL if no price
    unrealized_pnl_usd numeric,                              -- value - cost_basis; NULL if no price/cost
    risk_score        integer CHECK (risk_score IS NULL OR (risk_score BETWEEN 0 AND 100)), -- Phase 8
    updated_at        timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_position UNIQUE (user_id, chain, wallet, token)
);
CREATE INDEX IF NOT EXISTS idx_pp_wallet ON portfolio_positions (chain, wallet);
CREATE INDEX IF NOT EXISTS idx_pp_user ON portfolio_positions (user_id);

-- -----------------------------------------------------------------------------
-- portfolio_snapshots — per (user, chain, wallet) aggregate. priced_coverage is
-- the honesty field: the fraction of held positions that had a real price (and so
-- contributed to current_value_usd). When coverage < 1 the totals are PARTIAL and
-- the API exposes that rather than presenting a complete-looking number.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS portfolio_snapshots (
    user_id            uuid       NOT NULL,
    chain              text       NOT NULL,
    wallet             text       NOT NULL CHECK (wallet = lower(wallet)),
    positions          integer    NOT NULL DEFAULT 0,        -- open positions (qty_held > 0)
    priced_positions   integer    NOT NULL DEFAULT 0,        -- positions with a real price
    current_value_usd  numeric,                              -- sum of priced positions; NULL if none priced
    cost_basis_usd     numeric,                              -- sum of known cost bases
    realized_pnl_usd   numeric,                              -- sum of real realized PnL
    unrealized_pnl_usd numeric,                              -- sum over priced positions; NULL if none priced
    priced_coverage    numeric    NOT NULL DEFAULT 0 CHECK (priced_coverage BETWEEN 0 AND 1),
    updated_at         timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, chain, wallet)
);
CREATE INDEX IF NOT EXISTS idx_ps_wallet ON portfolio_snapshots (chain, wallet);
