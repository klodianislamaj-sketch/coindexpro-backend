// Command portfolio-engine is the Phase 15 entrypoint. It derives per-wallet
// holdings + PnL strictly from real indexed trades, valuing positions only when a
// real recent trade price exists (otherwise reporting value/unrealized PnL
// unavailable), and serves them. No holding, price, value, or PnL is ever
// estimated.
package main

import (
	"context"
	"errors"
	"flag"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/compress"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"github.com/redis/go-redis/v9"
	"go.uber.org/zap"

	"github.com/coindexpro/coindex-portfolio-engine/config"
	"github.com/coindexpro/coindex-portfolio-engine/internal/api"
	"github.com/coindexpro/coindex-portfolio-engine/internal/cache"
	"github.com/coindexpro/coindex-portfolio-engine/internal/consumer"
	"github.com/coindexpro/coindex-portfolio-engine/internal/db"
	"github.com/coindexpro/coindex-portfolio-engine/internal/portfolio"
)

func main() {
	cfgPath := flag.String("config", "config/config.yaml", "config path")
	flag.Parse()

	cfg, err := config.Load(*cfgPath)
	if err != nil {
		panic(err)
	}
	log, _ := zap.NewProduction()
	defer func() { _ = log.Sync() }()
	log.Info("starting portfolio-engine")

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	store, err := db.Open(ctx, cfg.Postgres.DSN, cfg.ClickHouse.Addrs,
		cfg.ClickHouse.Database, cfg.ClickHouse.Username, cfg.ClickHouse.Password, cfg.Build.PriceWindow)
	if err != nil {
		log.Fatal("db open failed", zap.Error(err))
	}
	defer store.Close()

	c := cache.New(cfg.Redis.Addr, cfg.Build.CacheTTL)
	if err := c.Ping(ctx); err != nil {
		log.Fatal("redis ping failed", zap.Error(err))
	}
	defer func() { _ = c.Close() }()
	rdb := redis.NewClient(&redis.Options{Addr: cfg.Redis.Addr})
	defer func() { _ = rdb.Close() }()

	engine := portfolio.NewEngine(store, store, portfolio.Config{
		MaxPortfolios: cfg.Build.MaxPortfolios,
	}, log)

	if cfg.Build.Enabled {
		sched := consumer.NewScheduler(engine, cfg.Build.Interval, log)
		go func() {
			if err := sched.Run(ctx); err != nil && !errors.Is(err, context.Canceled) {
				log.Error("scheduler stopped", zap.Error(err))
			}
		}()
	}

	if cfg.Kafka.Enabled {
		trig, err := consumer.NewKafkaTrigger(cfg.Kafka.Brokers, cfg.Kafka.GroupID, cfg.Kafka.Topics, engine, cfg.Kafka.Debounce, log)
		if err != nil {
			log.Fatal("kafka trigger init failed", zap.Error(err))
		}
		go func() {
			if err := trig.Run(ctx); err != nil && !errors.Is(err, context.Canceled) {
				log.Error("kafka trigger stopped", zap.Error(err))
			}
		}()
		defer trig.Close()
	}

	app := fiber.New(fiber.Config{AppName: "coindex-portfolio-engine"})
	app.Use(compress.New())
	api.New(store).Register(app)
	go func() {
		log.Info("api listening", zap.String("addr", cfg.Server.APIAddr))
		if err := app.Listen(cfg.Server.APIAddr); err != nil {
			log.Error("api stopped", zap.Error(err))
		}
	}()

	go serveOps(cfg.Server.MetricsAddr, store, rdb, log)

	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
	<-sig
	log.Info("shutting down")
	cancel()
	sc, scCancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer scCancel()
	_ = app.ShutdownWithContext(sc)
}

func serveOps(addr string, store *db.Store, rdb *redis.Client, log *zap.Logger) {
	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ok"))
	})
	mux.HandleFunc("/readyz", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), 3*time.Second)
		defer cancel()
		if err := store.Ping(ctx); err != nil {
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte("db down"))
			return
		}
		if err := rdb.Ping(ctx).Err(); err != nil {
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte("redis down"))
			return
		}
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ready"))
	})
	mux.Handle("/metrics", promhttp.Handler())
	srv := &http.Server{Addr: addr, Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Error("ops server failed", zap.Error(err))
	}
}
