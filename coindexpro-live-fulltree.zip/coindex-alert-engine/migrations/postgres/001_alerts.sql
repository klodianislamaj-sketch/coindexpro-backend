-- =============================================================================
-- CoinDex Alert Engine — PostgreSQL migration (Phase 10)
-- =============================================================================
-- REUSES the Phase 2 tables (source of truth, not rebuilt):
--   * alerts       — user rules: kind, target (jsonb), channels (jsonb), enabled
--   * alert_fires  — one row per real fire, with dedupe_key + UNIQUE(alert_id,dedupe_key)
-- ADDS:
--   * alert_deliveries — one row per channel delivery attempt (retry/DLQ tracking)
--   * alert_dead_letters (VIEW) — deliveries that exhausted retries
-- An alert only ever fires from a REAL consumed upstream event; this schema has
-- no mechanism to manufacture a fire. All statements are idempotent.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- alert_deliveries — tracks each notifier attempt for an alert_fire
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS alert_deliveries (
    id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fire_id     bigint NOT NULL REFERENCES alert_fires(id) ON DELETE CASCADE,
    channel     text   NOT NULL CHECK (channel IN ('webhook','telegram','discord','email')),
    dest        text   NOT NULL,                       -- url / chat id / email (never logged in metrics)
    status      text   NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','sent','failed','dead','unavailable')),
    attempts    int    NOT NULL DEFAULT 0,
    max_attempts int   NOT NULL DEFAULT 5,
    last_error  text,
    next_retry_at timestamptz,                          -- backoff schedule
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now(),
    -- one delivery row per (fire, channel, dest): idempotent enqueue
    CONSTRAINT uq_delivery UNIQUE (fire_id, channel, dest)
);
CREATE INDEX IF NOT EXISTS idx_ad_due
    ON alert_deliveries (next_retry_at)
    WHERE status IN ('pending','failed');
CREATE INDEX IF NOT EXISTS idx_ad_fire ON alert_deliveries (fire_id);

-- -----------------------------------------------------------------------------
-- alert_dead_letters — deliveries that exhausted their retries (DLQ surface)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW alert_dead_letters AS
    SELECT d.id, d.fire_id, d.channel, d.dest, d.attempts, d.last_error, d.updated_at,
           f.alert_id, f.payload
    FROM alert_deliveries d
    JOIN alert_fires f ON f.id = d.fire_id
    WHERE d.status = 'dead';

-- Helpful index for the dispatcher scanning unsent deliveries by status.
CREATE INDEX IF NOT EXISTS idx_ad_status ON alert_deliveries (status);
