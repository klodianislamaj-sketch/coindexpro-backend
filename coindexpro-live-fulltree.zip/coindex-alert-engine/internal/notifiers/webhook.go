package notifiers

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.com/coindexpro/coindex-alert-engine/internal/db"
)

// Webhook POSTs the fire payload as JSON to the destination URL. The dest URL is
// the rule's own configured endpoint, so "configured" means a non-empty dest.
type Webhook struct{ http *http.Client }

func NewWebhook(timeout time.Duration) *Webhook {
	if timeout == 0 {
		timeout = 10 * time.Second
	}
	return &Webhook{http: &http.Client{Timeout: timeout}}
}

func (w *Webhook) Channel() string { return db.ChannelWebhook }

func (w *Webhook) Send(ctx context.Context, m Message) error {
	if m.Dest == "" {
		return ErrNotConfigured
	}
	body, _ := json.Marshal(map[string]any{
		"title": m.Title, "body": m.Body, "fire": m.Fire,
	})
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, m.Dest, bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")
	resp, err := w.http.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 300 {
		return fmt.Errorf("webhook status %d", resp.StatusCode)
	}
	return nil
}
