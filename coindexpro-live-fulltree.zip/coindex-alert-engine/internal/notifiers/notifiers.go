// Package notifiers delivers alert fires to external channels. Every notifier
// returns ErrNotConfigured when its channel lacks the required credentials/URL,
// so the dispatcher marks the delivery 'unavailable' rather than pretending it
// was sent. No notifier ever fabricates a successful send.
package notifiers

import (
	"context"
	"errors"

	"github.com/coindexpro/coindex-alert-engine/internal/db"
)

// ErrNotConfigured signals the channel is not set up (e.g. no telegram token).
var ErrNotConfigured = errors.New("channel not configured")

// Message is the rendered alert to deliver.
type Message struct {
	Title string
	Body  string
	Dest  string         // url | chat id | email
	Fire  db.Fire        // for structured channels (webhook posts JSON)
}

// Notifier delivers a Message over one channel.
type Notifier interface {
	Channel() string
	Send(ctx context.Context, m Message) error
}

// Registry resolves a channel name to its notifier.
type Registry struct{ byChannel map[string]Notifier }

func NewRegistry(ns ...Notifier) *Registry {
	m := map[string]Notifier{}
	for _, n := range ns {
		m[n.Channel()] = n
	}
	return &Registry{byChannel: m}
}

func (r *Registry) For(channel string) (Notifier, bool) {
	n, ok := r.byChannel[channel]
	return n, ok
}
