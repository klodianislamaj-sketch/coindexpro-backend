package notifiers

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.com/coindexpro/coindex-alert-engine/internal/db"
)

// Discord posts to a Discord webhook URL (the rule's dest). Not configured =
// empty dest.
type Discord struct{ http *http.Client }

func NewDiscord(timeout time.Duration) *Discord {
	if timeout == 0 {
		timeout = 10 * time.Second
	}
	return &Discord{http: &http.Client{Timeout: timeout}}
}

func (d *Discord) Channel() string { return db.ChannelDiscord }

func (d *Discord) Send(ctx context.Context, m Message) error {
	if m.Dest == "" {
		return ErrNotConfigured
	}
	content := m.Title
	if m.Body != "" {
		content += "\n" + m.Body
	}
	body, _ := json.Marshal(map[string]any{"content": content})
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, m.Dest, bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")
	resp, err := d.http.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 300 {
		return fmt.Errorf("discord status %d", resp.StatusCode)
	}
	return nil
}
