package notifiers

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.com/coindexpro/coindex-alert-engine/internal/db"
)

// Telegram sends via the Bot API. It needs a bot token (engine-wide config) AND a
// chat id (the rule's dest). Missing EITHER -> ErrNotConfigured. We never invent a
// token or pretend a send happened.
type Telegram struct {
	http  *http.Client
	token string
}

func NewTelegram(token string, timeout time.Duration) *Telegram {
	if timeout == 0 {
		timeout = 10 * time.Second
	}
	return &Telegram{http: &http.Client{Timeout: timeout}, token: token}
}

func (t *Telegram) Channel() string { return db.ChannelTelegram }

func (t *Telegram) Send(ctx context.Context, m Message) error {
	if t.token == "" || m.Dest == "" {
		return ErrNotConfigured
	}
	text := m.Title
	if m.Body != "" {
		text += "\n" + m.Body
	}
	body, _ := json.Marshal(map[string]any{"chat_id": m.Dest, "text": text})
	url := fmt.Sprintf("https://api.telegram.org/bot%s/sendMessage", t.token)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, url, bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")
	resp, err := t.http.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 300 {
		return fmt.Errorf("telegram status %d", resp.StatusCode)
	}
	return nil
}
