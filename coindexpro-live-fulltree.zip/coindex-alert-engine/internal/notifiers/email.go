package notifiers

import (
	"context"
	"fmt"
	"net/smtp"

	"github.com/coindexpro/coindex-alert-engine/internal/db"
)

// SMTPConfig holds the engine-wide mail settings.
type SMTPConfig struct {
	Host     string
	Port     int
	Username string
	Password string
	From     string
}

func (c SMTPConfig) configured() bool { return c.Host != "" && c.From != "" }

// Email sends via SMTP. Missing SMTP host/from (engine config) or dest (rule) ->
// ErrNotConfigured. Delivery is real or it is reported unavailable; never faked.
type Email struct {
	cfg  SMTPConfig
	send func(addr string, a smtp.Auth, from string, to []string, msg []byte) error
}

func NewEmail(cfg SMTPConfig) *Email {
	return &Email{cfg: cfg, send: smtp.SendMail}
}

func (e *Email) Channel() string { return db.ChannelEmail }

func (e *Email) Send(ctx context.Context, m Message) error {
	if !e.cfg.configured() || m.Dest == "" {
		return ErrNotConfigured
	}
	var auth smtp.Auth
	if e.cfg.Username != "" {
		auth = smtp.PlainAuth("", e.cfg.Username, e.cfg.Password, e.cfg.Host)
	}
	msg := []byte(fmt.Sprintf("From: %s\r\nTo: %s\r\nSubject: %s\r\n\r\n%s\r\n",
		e.cfg.From, m.Dest, m.Title, m.Body))
	addr := fmt.Sprintf("%s:%d", e.cfg.Host, e.cfg.Port)
	return e.send(addr, auth, e.cfg.From, []string{m.Dest}, msg)
}
