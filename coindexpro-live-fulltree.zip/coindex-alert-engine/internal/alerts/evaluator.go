package alerts

import (
	"fmt"

	"github.com/coindexpro/coindex-alert-engine/internal/db"
)

// Match is the result of evaluating one rule against one real event.
type Match struct {
	Matched bool
	Reason  string         // human explanation of why it fired
	Detail  map[string]any // the real values that triggered it
}

// Evaluate decides whether a real event satisfies a rule. Every branch compares
// fields that came off the consumed event; if the event lacks the data a rule
// needs, the rule does NOT fire (no assumption, no fabrication).
func Evaluate(a db.Alert, e db.Event) Match {
	if !kindMatchesEvent(a.Kind, e.Kind) || !targetMatches(a, e) {
		return Match{}
	}
	th, hasTh := threshold(a)

	switch a.Kind {
	case db.KindWhaleBuy:
		if e.Kind != db.KindWhaleBuy {
			return Match{}
		}
		if e.AmountUSD <= 0 {
			return Match{} // no real amount -> cannot assert a whale buy
		}
		if hasTh && e.AmountUSD < th {
			return Match{}
		}
		return fire("whale buy", map[string]any{"amount_usd": e.AmountUSD, "threshold": th, "wallet": e.Wallet, "token": e.Token})

	case db.KindWhaleSell:
		if e.AmountUSD <= 0 {
			return Match{}
		}
		if hasTh && e.AmountUSD < th {
			return Match{}
		}
		return fire("whale sell", map[string]any{"amount_usd": e.AmountUSD, "threshold": th, "wallet": e.Wallet, "token": e.Token})

	case db.KindDevSell:
		if e.AmountUSD <= 0 {
			return Match{}
		}
		return fire("dev sell", map[string]any{"amount_usd": e.AmountUSD, "wallet": e.Wallet, "token": e.Token})

	case db.KindLiquidity:
		if e.AmountUSD == 0 {
			return Match{}
		}
		if hasTh && abs(e.AmountUSD) < th {
			return Match{}
		}
		dir := "liquidity_add"
		if e.Kind == "liquidity_remove" {
			dir = "liquidity_remove"
		}
		return fire(dir, map[string]any{"amount_usd": e.AmountUSD, "threshold": th, "token": e.Token})

	case db.KindTrustDrop:
		// requires both current and previous trust scores (real, from provider trust)
		if e.TrustScore == nil || e.TrustPrev == nil {
			return Match{}
		}
		drop := *e.TrustPrev - *e.TrustScore
		// threshold is the minimum drop (default any drop crossing below prev)
		minDrop := 0.05
		if hasTh {
			minDrop = th
		}
		if drop < minDrop {
			return Match{}
		}
		return fire("provider trust drop", map[string]any{
			"provider": e.Provider, "from": *e.TrustPrev, "to": *e.TrustScore, "drop": round4(drop)})

	case db.KindRiskChange:
		if e.RiskScore == nil || e.RiskPrev == nil {
			return Match{}
		}
		if *e.RiskScore == *e.RiskPrev {
			return Match{}
		}
		// optional threshold = minimum absolute change in score
		delta := *e.RiskScore - *e.RiskPrev
		if hasTh && absInt(delta) < int(th) {
			return Match{}
		}
		return fire("contract risk change", map[string]any{
			"token": e.Token, "from": *e.RiskPrev, "to": *e.RiskScore, "delta": delta})

	case db.KindPrice:
		// price breakout: needs current + previous price (real candle data)
		if e.Price <= 0 || e.PricePrev <= 0 {
			return Match{}
		}
		pct := (e.Price - e.PricePrev) / e.PricePrev * 100
		minPct := 10.0
		if hasTh {
			minPct = th
		}
		if abs(pct) < minPct {
			return Match{}
		}
		return fire("price breakout", map[string]any{
			"token": e.Token, "price": e.Price, "prev": e.PricePrev, "pct_change": round4(pct), "threshold_pct": minPct})

	case db.KindVolume:
		// volume spike: needs volume + a real baseline to compare against
		if e.Volume <= 0 || e.Baseline <= 0 {
			return Match{}
		}
		mult := e.Volume / e.Baseline
		minMult := 3.0
		if hasTh {
			minMult = th
		}
		if mult < minMult {
			return Match{}
		}
		return fire("volume spike", map[string]any{
			"token": e.Token, "volume": e.Volume, "baseline": e.Baseline, "multiple": round4(mult), "threshold_mult": minMult})

	case db.KindSmartMoney:
		// smart-money cluster entry: needs a real cluster id from the graph engine
		if e.ClusterID == nil {
			return Match{}
		}
		return fire("smart money cluster entry", map[string]any{
			"token": e.Token, "cluster_id": *e.ClusterID, "wallet": e.Wallet})

	case db.KindHolderChange:
		if e.Baseline <= 0 || e.Volume <= 0 { // reuse Volume as current count, Baseline as prev
			return Match{}
		}
		return fire("holder change", map[string]any{"token": e.Token, "from": e.Baseline, "to": e.Volume})

	case db.KindUnlock:
		// unlock events must carry a real schedule reference in Raw; otherwise skip
		if e.Raw == nil {
			return Match{}
		}
		if _, ok := e.Raw["unlock_at"]; !ok {
			return Match{}
		}
		return fire("token unlock", map[string]any{"token": e.Token, "unlock": e.Raw["unlock_at"]})
	}
	return Match{}
}

func fire(reason string, detail map[string]any) Match {
	return Match{Matched: true, Reason: reason, Detail: detail}
}

func abs(x float64) float64 {
	if x < 0 {
		return -x
	}
	return x
}
func absInt(x int) int {
	if x < 0 {
		return -x
	}
	return x
}
func round4(x float64) float64 { return float64(int(x*10000+0.5)) / 10000 }

// summary renders a short human line for notifier bodies.
func summary(a db.Alert, m Match, e db.Event) string {
	return fmt.Sprintf("[%s] %s on %s", a.Kind, m.Reason, entityOf(e))
}

func entityOf(e db.Event) string {
	if e.Token != "" {
		return e.Chain + ":" + e.Token
	}
	if e.Wallet != "" {
		return e.Chain + ":" + e.Wallet
	}
	if e.Provider != "" {
		return e.Provider
	}
	return e.Chain
}
