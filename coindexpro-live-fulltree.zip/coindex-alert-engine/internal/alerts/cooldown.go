package alerts

import (
	"context"
	"time"

	"github.com/redis/go-redis/v9"
)

// Cooldown enforces a minimum gap between fires of the same alert rule. This is
// distinct from dedupe: dedupe stops the SAME event firing twice; cooldown stops
// DIFFERENT events from a rule firing too frequently (anti-spam).
type Cooldown struct {
	rdb     *redis.Client
	defGap  time.Duration
}

func NewCooldown(rdb *redis.Client, defaultGap time.Duration) *Cooldown {
	if defaultGap <= 0 {
		defaultGap = 5 * time.Minute
	}
	return &Cooldown{rdb: rdb, defGap: defaultGap}
}

// Allow reports whether the rule may fire now given its cooldown. gap of 0 uses
// the engine default. Fail-open on Redis error (the DB dedupe still bounds dupes).
func (c *Cooldown) Allow(ctx context.Context, alertID int64, gap time.Duration) bool {
	if gap <= 0 {
		gap = c.defGap
	}
	key := "alert:cooldown:" + itoa(alertID)
	ok, err := c.rdb.SetNX(ctx, key, 1, gap).Result()
	if err != nil {
		return true
	}
	return ok
}

func itoa(n int64) string {
	if n == 0 {
		return "0"
	}
	neg := n < 0
	if neg {
		n = -n
	}
	var b [20]byte
	i := len(b)
	for n > 0 {
		i--
		b[i] = byte('0' + n%10)
		n /= 10
	}
	if neg {
		i--
		b[i] = '-'
	}
	return string(b[i:])
}
