package alerts

import (
	"context"
	"time"

	"go.uber.org/zap"

	"github.com/coindexpro/coindex-alert-engine/internal/db"
	"github.com/coindexpro/coindex-alert-engine/internal/metrics"
)

// Store is the persistence surface the engine needs.
type Store interface {
	EnabledAlertsByKind(ctx context.Context, kind string) ([]db.Alert, error)
	RecordFire(ctx context.Context, alertID int64, payload map[string]any, dedupeKey string) (db.Fire, bool, error)
	EnqueueDelivery(ctx context.Context, fireID int64, ch db.Channel) error
}

// Engine evaluates real consumed events against user rules and enqueues
// deliveries. It is the only path to a fire, and that path requires a real Event.
type Engine struct {
	store    Store
	dedupe   *Deduper
	cooldown *Cooldown
	defGap   time.Duration
	log      *zap.Logger
}

func NewEngine(store Store, dedupe *Deduper, cooldown *Cooldown, defaultCooldown time.Duration, log *zap.Logger) *Engine {
	return &Engine{store: store, dedupe: dedupe, cooldown: cooldown, defGap: defaultCooldown, log: log}
}

// Process handles one real event end to end. Returns the number of fires created.
func (e *Engine) Process(ctx context.Context, ev db.Event) (int, error) {
	metrics.EventsProcessed.WithLabelValues(ev.Kind).Inc()

	// candidate rules: those whose kind is interested in this event kind
	kinds := alertKindsForEvent(ev.Kind)
	fired := 0
	for _, k := range kinds {
		alerts, err := e.store.EnabledAlertsByKind(ctx, k)
		if err != nil {
			return fired, err
		}
		for _, a := range alerts {
			m := Evaluate(a, ev)
			if !m.Matched {
				continue
			}
			// cooldown (anti-spam, per rule)
			if !e.cooldown.Allow(ctx, a.ID, ruleCooldown(a, e.defGap)) {
				metrics.Suppressed.WithLabelValues("cooldown").Inc()
				continue
			}
			key := dedupeKey(a, ev)
			// dedupe (same event cannot fire same rule twice)
			if !e.dedupe.FirstSeen(ctx, key) {
				metrics.Suppressed.WithLabelValues("dedupe").Inc()
				continue
			}
			payload := map[string]any{
				"reason":  m.Reason,
				"detail":  m.Detail,
				"event":   ev,
				"summary": summary(a, m, ev),
			}
			fire, created, err := e.store.RecordFire(ctx, a.ID, payload, key)
			if err != nil {
				return fired, err
			}
			if !created {
				// DB UNIQUE backstop caught a duplicate the cache missed
				metrics.Suppressed.WithLabelValues("dedupe_db").Inc()
				continue
			}
			metrics.Fires.WithLabelValues(a.Kind).Inc()
			fired++
			// enqueue one delivery per configured channel
			for _, ch := range a.Channels {
				if err := e.store.EnqueueDelivery(ctx, fire.ID, ch); err != nil {
					e.log.Warn("enqueue delivery failed", zap.Int64("fire", fire.ID), zap.Error(err))
				}
			}
		}
	}
	return fired, nil
}

// alertKindsForEvent maps an event kind to the alert-rule kinds that could match.
func alertKindsForEvent(eventKind string) []string {
	switch eventKind {
	case db.KindWhaleBuy:
		return []string{db.KindWhaleBuy}
	case db.KindWhaleSell:
		return []string{db.KindWhaleSell}
	case db.KindDevSell:
		return []string{db.KindDevSell}
	case "liquidity_add", "liquidity_remove", db.KindLiquidity:
		return []string{db.KindLiquidity}
	case db.KindTrustDrop:
		return []string{db.KindTrustDrop}
	case db.KindRiskChange:
		return []string{db.KindRiskChange}
	case "price_breakout", db.KindPrice:
		return []string{db.KindPrice}
	case "volume_spike", db.KindVolume:
		return []string{db.KindVolume}
	case "smart_money_cluster_entry", db.KindSmartMoney:
		return []string{db.KindSmartMoney}
	case db.KindHolderChange:
		return []string{db.KindHolderChange}
	case db.KindUnlock:
		return []string{db.KindUnlock}
	}
	return nil
}

// ruleCooldown reads an optional per-rule cooldown_seconds from the rule target.
func ruleCooldown(a db.Alert, def time.Duration) time.Duration {
	if v, ok := a.Target["cooldown_seconds"]; ok {
		switch n := v.(type) {
		case float64:
			return time.Duration(n) * time.Second
		case int:
			return time.Duration(n) * time.Second
		}
	}
	return def
}
