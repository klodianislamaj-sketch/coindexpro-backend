// Package alerts contains the evaluation engine. rules.go defines how a consumed
// real Event is matched to user alert rules and how the dedupe key is derived.
// No rule can synthesize data — each rule reads fields off the real Event and
// compares them to the user's configured threshold.
package alerts

import (
	"fmt"
	"strings"

	"github.com/coindexpro/coindex-alert-engine/internal/db"
)

// kindMatchesEvent reports whether an alert rule of a given kind is interested in
// this event. Both sides use the same vocabulary; some alert kinds map from more
// than one event signal (e.g. a "smart_money" rule reacts to cluster-entry).
func kindMatchesEvent(alertKind, eventKind string) bool {
	if alertKind == eventKind {
		return true
	}
	switch alertKind {
	case db.KindSmartMoney:
		return eventKind == "smart_money_cluster_entry" || eventKind == db.KindSmartMoney
	case db.KindLiquidity:
		return eventKind == "liquidity_add" || eventKind == "liquidity_remove" || eventKind == db.KindLiquidity
	case db.KindPrice:
		return eventKind == "price_breakout" || eventKind == db.KindPrice
	case db.KindVolume:
		return eventKind == "volume_spike" || eventKind == db.KindVolume
	}
	return false
}

// targetMatches checks the rule's target scoping (chain/token/wallet/provider)
// against the event. A rule with no scoping on a field matches any value of it.
func targetMatches(a db.Alert, e db.Event) bool {
	if c, ok := stringField(a.Target, "chain"); ok && !strings.EqualFold(c, e.Chain) {
		return false
	}
	if t, ok := stringField(a.Target, "token"); ok && !strings.EqualFold(t, e.Token) {
		return false
	}
	if w, ok := stringField(a.Target, "wallet"); ok && !strings.EqualFold(w, e.Wallet) {
		return false
	}
	if p, ok := stringField(a.Target, "provider"); ok && !strings.EqualFold(p, e.Provider) {
		return false
	}
	return true
}

// threshold returns the numeric threshold configured on the rule, if present.
func threshold(a db.Alert) (float64, bool) { return floatField(a.Target, "threshold") }

func stringField(m map[string]any, k string) (string, bool) {
	if m == nil {
		return "", false
	}
	v, ok := m[k]
	if !ok {
		return "", false
	}
	s, ok := v.(string)
	if !ok || s == "" {
		return "", false
	}
	return s, true
}

func floatField(m map[string]any, k string) (float64, bool) {
	if m == nil {
		return 0, false
	}
	switch v := m[k].(type) {
	case float64:
		return v, true
	case int:
		return float64(v), true
	case int64:
		return float64(v), true
	}
	return 0, false
}

// dedupeKey builds a stable key so the same real event cannot fire the same rule
// twice. It bins by the rule's natural identity for the event: kind + the entity
// + a coarse time/condition bucket. Two genuinely distinct events produce
// distinct keys; a duplicate upstream delivery produces the same key.
func dedupeKey(a db.Alert, e db.Event) string {
	entity := e.Token
	if entity == "" {
		entity = e.Wallet
	}
	if entity == "" {
		entity = e.Provider
	}
	bucket := e.BlockTime.UTC().Format("2006010215") // hour bucket
	return fmt.Sprintf("%d|%s|%s|%s|%s", a.ID, a.Kind, e.Chain, entity, bucket)
}
