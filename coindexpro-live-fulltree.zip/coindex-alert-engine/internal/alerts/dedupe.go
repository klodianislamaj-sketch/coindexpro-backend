package alerts

import (
	"context"
	"time"

	"github.com/redis/go-redis/v9"
)

// Deduper suppresses repeat fires of the same rule for the same real event.
// It uses Redis SETNX with a TTL window as the fast path; the alert_fires table's
// UNIQUE(alert_id, dedupe_key) is the durable backstop (so even if Redis is cold,
// a duplicate fire cannot be persisted twice).
type Deduper struct {
	rdb    *redis.Client
	window time.Duration
}

func NewDeduper(rdb *redis.Client, window time.Duration) *Deduper {
	if window <= 0 {
		window = time.Hour
	}
	return &Deduper{rdb: rdb, window: window}
}

// FirstSeen returns true if this dedupe key has not been seen within the window.
// On Redis error it returns true (fail-open) because the DB UNIQUE constraint
// still prevents a real duplicate row — we never silently drop a genuine alert
// just because the cache is unavailable.
func (d *Deduper) FirstSeen(ctx context.Context, key string) bool {
	ok, err := d.rdb.SetNX(ctx, "alert:dedupe:"+key, 1, d.window).Result()
	if err != nil {
		return true
	}
	return ok
}
