// Package cache is a thin Redis client constructor shared by the dedupe and
// cooldown components.
package cache

import "github.com/redis/go-redis/v9"

// New builds a redis client from an address.
func New(addr string) *redis.Client {
	return redis.NewClient(&redis.Options{Addr: addr})
}
