// Package db holds the alert-engine persistence layer and the shared domain
// types. The central honesty invariant lives in the types: an Event always
// originates from a consumed upstream message (real data), and a Fire can only
// be created from an Event that satisfied a real rule — there is no constructor
// for a synthetic fire.
package db

import "time"

// Alert kinds (must match the Phase 2 alerts.kind CHECK).
const (
	KindPrice         = "price"
	KindLiquidity     = "liquidity"
	KindVolume        = "volume"
	KindWhaleBuy      = "whale_buy"
	KindWhaleSell     = "whale_sell"
	KindDevSell       = "dev_sell"
	KindTrustDrop     = "trust_drop"
	KindRiskChange    = "risk_change"
	KindUnlock        = "unlock"
	KindSmartMoney    = "smart_money"
	KindHolderChange  = "holder_change"
)

// Delivery channels + statuses.
const (
	ChannelWebhook  = "webhook"
	ChannelTelegram = "telegram"
	ChannelDiscord  = "discord"
	ChannelEmail    = "email"

	StatusPending     = "pending"
	StatusSent        = "sent"
	StatusFailed      = "failed"
	StatusDead        = "dead"
	StatusUnavailable = "unavailable"
)

// Channel is a single delivery destination attached to an alert rule.
type Channel struct {
	Type string `json:"type"` // webhook|telegram|discord|email
	Dest string `json:"dest"` // url | chat id | email
}

// Alert is a user-defined rule (read from the Phase 2 alerts table).
type Alert struct {
	ID       int64          `json:"id"`
	UserID   string         `json:"user_id"`
	Kind     string         `json:"kind"`
	Target   map[string]any `json:"target"`   // {chain, token?, threshold?, ...}
	Channels []Channel      `json:"channels"`
	Enabled  bool           `json:"enabled"`
}

// Event is a REAL upstream event consumed from Kafka. The engine never creates
// one itself; it is decoded from a producer (enricher, graph, contract analyzer,
// provider trust). Fields are a normalized superset; absent fields are zero.
type Event struct {
	Source     string         `json:"source"`     // topic / producer
	Kind       string         `json:"kind"`       // maps to alert kind space
	Chain      string         `json:"chain"`
	Token      string         `json:"token,omitempty"`
	Wallet     string         `json:"wallet,omitempty"`
	Provider   string         `json:"provider,omitempty"`
	AmountUSD  float64        `json:"amount_usd,omitempty"`
	Price      float64        `json:"price,omitempty"`
	PricePrev  float64        `json:"price_prev,omitempty"`
	Volume     float64        `json:"volume,omitempty"`
	Baseline   float64        `json:"baseline,omitempty"`
	RiskScore  *int           `json:"risk_score,omitempty"`
	RiskPrev   *int           `json:"risk_prev,omitempty"`
	TrustScore *float64       `json:"trust_score,omitempty"`
	TrustPrev  *float64       `json:"trust_prev,omitempty"`
	ClusterID  *int64         `json:"cluster_id,omitempty"`
	BlockTime  time.Time      `json:"block_time,omitempty"`
	Raw        map[string]any `json:"raw,omitempty"` // original decoded payload (real)
}

// Fire is a recorded alert fire (alert_fires row). DedupeKey enforces idempotency.
type Fire struct {
	ID        int64          `json:"id"`
	AlertID   int64          `json:"alert_id"`
	FiredAt   time.Time      `json:"fired_at"`
	Payload   map[string]any `json:"payload"` // the real event + matched condition
	DedupeKey string         `json:"dedupe_key"`
}

// Delivery is one channel delivery attempt (alert_deliveries row).
type Delivery struct {
	ID          int64     `json:"id"`
	FireID      int64     `json:"fire_id"`
	Channel     string    `json:"channel"`
	Dest        string    `json:"dest"`
	Status      string    `json:"status"`
	Attempts    int       `json:"attempts"`
	MaxAttempts int       `json:"max_attempts"`
	LastError   string    `json:"last_error,omitempty"`
	NextRetryAt time.Time `json:"next_retry_at,omitempty"`
}
