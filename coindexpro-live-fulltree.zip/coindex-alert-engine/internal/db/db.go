package db

import (
	"context"
	"encoding/json"
	"errors"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

type Store struct{ pool *pgxpool.Pool }

func Open(ctx context.Context, dsn string) (*Store, error) {
	pool, err := pgxpool.New(ctx, dsn)
	if err != nil {
		return nil, err
	}
	if err := pool.Ping(ctx); err != nil {
		return nil, err
	}
	return &Store{pool: pool}, nil
}

func (s *Store) Close()                         { s.pool.Close() }
func (s *Store) Ping(ctx context.Context) error { return s.pool.Ping(ctx) }

// EnabledAlertsByKind loads active user rules of a given kind (Phase 2 alerts).
func (s *Store) EnabledAlertsByKind(ctx context.Context, kind string) ([]Alert, error) {
	const q = `SELECT id, user_id, kind, target, channels, enabled
		FROM alerts WHERE kind=$1 AND enabled`
	rows, err := s.pool.Query(ctx, q, kind)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []Alert
	for rows.Next() {
		var a Alert
		var target, channels []byte
		if err := rows.Scan(&a.ID, &a.UserID, &a.Kind, &target, &channels, &a.Enabled); err != nil {
			return nil, err
		}
		_ = json.Unmarshal(target, &a.Target)
		_ = json.Unmarshal(channels, &a.Channels)
		out = append(out, a)
	}
	return out, rows.Err()
}

// RecordFire inserts a fire idempotently. The UNIQUE(alert_id, dedupe_key) makes
// a duplicate a no-op: created=false signals the fire already existed (the DB is
// the durable dedupe backstop). Returns the fire either way.
func (s *Store) RecordFire(ctx context.Context, alertID int64, payload map[string]any, dedupeKey string) (Fire, bool, error) {
	pl, _ := json.Marshal(payload)
	const q = `
		INSERT INTO alert_fires (alert_id, payload, dedupe_key)
		VALUES ($1,$2,$3)
		ON CONFLICT (alert_id, dedupe_key) DO NOTHING
		RETURNING id, alert_id, fired_at, dedupe_key`
	var f Fire
	err := s.pool.QueryRow(ctx, q, alertID, pl, dedupeKey).Scan(&f.ID, &f.AlertID, &f.FiredAt, &f.DedupeKey)
	if errors.Is(err, pgx.ErrNoRows) {
		// conflict: load the existing fire id so caller can still attach deliveries if needed
		const sel = `SELECT id, alert_id, fired_at, dedupe_key FROM alert_fires WHERE alert_id=$1 AND dedupe_key=$2`
		if err2 := s.pool.QueryRow(ctx, sel, alertID, dedupeKey).Scan(&f.ID, &f.AlertID, &f.FiredAt, &f.DedupeKey); err2 != nil {
			return Fire{}, false, err2
		}
		f.Payload = payload
		return f, false, nil
	}
	if err != nil {
		return Fire{}, false, err
	}
	f.Payload = payload
	return f, true, nil
}

// EnqueueDelivery creates a pending delivery row (idempotent per fire+channel+dest).
func (s *Store) EnqueueDelivery(ctx context.Context, fireID int64, ch Channel) error {
	const q = `
		INSERT INTO alert_deliveries (fire_id, channel, dest, status, next_retry_at)
		VALUES ($1,$2,$3,'pending', now())
		ON CONFLICT (fire_id, channel, dest) DO NOTHING`
	_, err := s.pool.Exec(ctx, q, fireID, ch.Type, ch.Dest)
	return err
}

// ClaimDueDeliveries atomically claims a batch of deliveries that are due for an
// attempt (pending/failed and past next_retry_at), marking them in-flight via a
// status bump is unnecessary because the dispatcher processes the batch inline;
// SKIP LOCKED prevents two dispatchers grabbing the same rows.
func (s *Store) ClaimDueDeliveries(ctx context.Context, limit int) ([]Delivery, error) {
	const q = `
		SELECT d.id, d.fire_id, d.channel, d.dest, d.status, d.attempts, d.max_attempts
		FROM alert_deliveries d
		WHERE d.status IN ('pending','failed') AND (d.next_retry_at IS NULL OR d.next_retry_at <= now())
		ORDER BY d.next_retry_at NULLS FIRST
		LIMIT $1
		FOR UPDATE SKIP LOCKED`
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback(ctx)
	rows, err := tx.Query(ctx, q, limit)
	if err != nil {
		return nil, err
	}
	var out []Delivery
	for rows.Next() {
		var d Delivery
		if err := rows.Scan(&d.ID, &d.FireID, &d.Channel, &d.Dest, &d.Status, &d.Attempts, &d.MaxAttempts); err != nil {
			rows.Close()
			return nil, err
		}
		out = append(out, d)
	}
	rows.Close()
	if err := rows.Err(); err != nil {
		return nil, err
	}
	// mark claimed rows as 'pending' with a far next_retry to avoid double-claim
	// within the same tick; real status is set by MarkSent/MarkFailed afterwards.
	for _, d := range out {
		if _, err := tx.Exec(ctx,
			`UPDATE alert_deliveries SET next_retry_at = now() + interval '1 minute', updated_at = now() WHERE id=$1`,
			d.ID); err != nil {
			return nil, err
		}
	}
	if err := tx.Commit(ctx); err != nil {
		return nil, err
	}
	return out, nil
}

// FirePayload loads a fire's payload for rendering a delivery.
func (s *Store) FirePayload(ctx context.Context, fireID int64) (Fire, error) {
	const q = `SELECT id, alert_id, fired_at, payload, dedupe_key FROM alert_fires WHERE id=$1`
	var f Fire
	var pl []byte
	if err := s.pool.QueryRow(ctx, q, fireID).Scan(&f.ID, &f.AlertID, &f.FiredAt, &pl, &f.DedupeKey); err != nil {
		return Fire{}, err
	}
	_ = json.Unmarshal(pl, &f.Payload)
	return f, nil
}

// MarkSent finalizes a delivery as sent.
func (s *Store) MarkSent(ctx context.Context, id int64) error {
	_, err := s.pool.Exec(ctx,
		`UPDATE alert_deliveries SET status='sent', attempts=attempts+1, next_retry_at=NULL, updated_at=now() WHERE id=$1`, id)
	return err
}

// MarkUnavailable marks a delivery whose channel is not configured. It is not a
// retryable failure — the channel simply isn't set up — so it is terminal and
// honest, never reported as sent.
func (s *Store) MarkUnavailable(ctx context.Context, id int64, reason string) error {
	_, err := s.pool.Exec(ctx,
		`UPDATE alert_deliveries SET status='unavailable', attempts=attempts+1, last_error=$2, next_retry_at=NULL, updated_at=now() WHERE id=$1`,
		id, reason)
	return err
}

// MarkFailed records a failed attempt with exponential backoff, or moves the
// delivery to 'dead' (DLQ) once max_attempts is reached.
func (s *Store) MarkFailed(ctx context.Context, id int64, attempts, maxAttempts int, reason string) error {
	if attempts+1 >= maxAttempts {
		_, err := s.pool.Exec(ctx,
			`UPDATE alert_deliveries SET status='dead', attempts=attempts+1, last_error=$2, next_retry_at=NULL, updated_at=now() WHERE id=$1`,
			id, reason)
		return err
	}
	backoff := time.Duration(1<<uint(attempts)) * 30 * time.Second // 30s,60s,120s,...
	_, err := s.pool.Exec(ctx,
		`UPDATE alert_deliveries SET status='failed', attempts=attempts+1, last_error=$2,
		 next_retry_at = now() + $3::interval, updated_at=now() WHERE id=$1`,
		id, reason, backoff.String())
	return err
}

// ---- API reads ----

func (s *Store) RecentFires(ctx context.Context, alertID int64, limit int) ([]Fire, error) {
	const q = `SELECT id, alert_id, fired_at, payload, dedupe_key FROM alert_fires
		WHERE alert_id=$1 ORDER BY fired_at DESC LIMIT $2`
	rows, err := s.pool.Query(ctx, q, alertID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []Fire
	for rows.Next() {
		var f Fire
		var pl []byte
		if err := rows.Scan(&f.ID, &f.AlertID, &f.FiredAt, &pl, &f.DedupeKey); err != nil {
			return nil, err
		}
		_ = json.Unmarshal(pl, &f.Payload)
		out = append(out, f)
	}
	return out, rows.Err()
}

func (s *Store) DeliveriesForFire(ctx context.Context, fireID int64) ([]Delivery, error) {
	const q = `SELECT id, fire_id, channel, dest, status, attempts, max_attempts, COALESCE(last_error,'')
		FROM alert_deliveries WHERE fire_id=$1 ORDER BY id`
	rows, err := s.pool.Query(ctx, q, fireID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []Delivery
	for rows.Next() {
		var d Delivery
		if err := rows.Scan(&d.ID, &d.FireID, &d.Channel, &d.Dest, &d.Status, &d.Attempts, &d.MaxAttempts, &d.LastError); err != nil {
			return nil, err
		}
		out = append(out, d)
	}
	return out, rows.Err()
}

func (s *Store) DeadLetters(ctx context.Context, limit int) ([]Delivery, error) {
	const q = `SELECT id, fire_id, channel, dest, attempts, COALESCE(last_error,'')
		FROM alert_dead_letters ORDER BY updated_at DESC LIMIT $1`
	rows, err := s.pool.Query(ctx, q, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []Delivery
	for rows.Next() {
		var d Delivery
		d.Status = StatusDead
		if err := rows.Scan(&d.ID, &d.FireID, &d.Channel, &d.Dest, &d.Attempts, &d.LastError); err != nil {
			return nil, err
		}
		out = append(out, d)
	}
	return out, rows.Err()
}
