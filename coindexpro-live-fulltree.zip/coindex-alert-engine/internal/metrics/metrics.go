// Package metrics holds the alert-engine's Prometheus instruments.
package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	EventsProcessed = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_alert_events_total", Help: "Upstream events processed by kind.",
	}, []string{"kind"})

	Fires = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_alert_fires_total", Help: "Alert fires by kind.",
	}, []string{"kind"})

	Suppressed = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_alert_suppressed_total", Help: "Suppressed fires by reason.",
	}, []string{"reason"}) // cooldown | dedupe | dedupe_db

	Deliveries = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_alert_deliveries_total", Help: "Delivery outcomes by channel + status.",
	}, []string{"channel", "status"}) // sent | failed | dead | unavailable

	DecodeErrors = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_alert_decode_errors_total", Help: "Malformed upstream messages skipped.",
	})
	ProcessErrors = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_alert_process_errors_total", Help: "Engine processing errors.",
	})

	APILatency = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name: "coindex_alert_api_seconds", Help: "API latency by route + status.",
		Buckets: prometheus.DefBuckets,
	}, []string{"route", "status"})

	DBErrors = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_alert_db_errors_total", Help: "DB errors.",
	})
)
