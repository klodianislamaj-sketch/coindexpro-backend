// Package api serves read-only visibility into the alert engine: recent fires
// for a rule, deliveries for a fire, and the dead-letter queue. It deliberately
// has NO endpoint that manufactures a fire or a delivery — fires only originate
// from real consumed events.
package api

import (
	"strconv"
	"time"

	"github.com/gofiber/fiber/v2"

	"github.com/coindexpro/coindex-alert-engine/internal/db"
	"github.com/coindexpro/coindex-alert-engine/internal/metrics"
)

type API struct{ store *db.Store }

func New(store *db.Store) *API { return &API{store: store} }

func (a *API) Register(app *fiber.App) {
	app.Use(a.observe)
	app.Get("/alerts/:id/fires", a.fires)
	app.Get("/fires/:id/deliveries", a.deliveries)
	app.Get("/deliveries/dead", a.dead)
}

func (a *API) observe(c *fiber.Ctx) error {
	start := time.Now()
	err := c.Next()
	metrics.APILatency.WithLabelValues(c.Route().Path, statusClass(c.Response().StatusCode())).
		Observe(time.Since(start).Seconds())
	return err
}

// GET /alerts/:id/fires
func (a *API) fires(c *fiber.Ctx) error {
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid alert id"})
	}
	limit := clamp(c.QueryInt("limit", 50), 1, 200)
	fires, err := a.store.RecentFires(c.UserContext(), id, limit)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(fires) == 0 {
		return c.JSON(fiber.Map{"alert_id": id, "available": false, "reason": "no fires"})
	}
	return c.JSON(fiber.Map{"alert_id": id, "available": true, "fires": fires})
}

// GET /fires/:id/deliveries
func (a *API) deliveries(c *fiber.Ctx) error {
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid fire id"})
	}
	ds, err := a.store.DeliveriesForFire(c.UserContext(), id)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(ds) == 0 {
		return c.JSON(fiber.Map{"fire_id": id, "available": false, "reason": "no deliveries"})
	}
	return c.JSON(fiber.Map{"fire_id": id, "available": true, "deliveries": ds})
}

// GET /deliveries/dead — the DLQ surface
func (a *API) dead(c *fiber.Ctx) error {
	limit := clamp(c.QueryInt("limit", 100), 1, 500)
	ds, err := a.store.DeadLetters(c.UserContext(), limit)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(ds) == 0 {
		return c.JSON(fiber.Map{"available": false, "reason": "no dead letters"})
	}
	return c.JSON(fiber.Map{"available": true, "dead_letters": ds})
}

func clamp(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}

func statusClass(code int) string {
	switch {
	case code >= 500:
		return "5xx"
	case code >= 400:
		return "4xx"
	default:
		return "2xx"
	}
}
