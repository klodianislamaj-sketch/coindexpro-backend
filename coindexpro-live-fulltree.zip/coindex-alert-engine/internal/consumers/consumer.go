// Package consumers wires the alert engine to its inputs and outputs. The event
// consumer decodes REAL upstream messages (from the enricher, graph engine,
// contract analyzer, provider trust) and feeds them to the engine. The dispatcher
// drains queued deliveries through the notifiers with retries/backoff/DLQ. Neither
// invents events nor fabricates successful sends.
package consumers

import (
	"context"
	"encoding/json"
	"time"

	"github.com/twmb/franz-go/pkg/kgo"
	"go.uber.org/zap"

	"github.com/coindexpro/coindex-alert-engine/internal/db"
	"github.com/coindexpro/coindex-alert-engine/internal/metrics"
	"github.com/coindexpro/coindex-alert-engine/internal/notifiers"
)

// Processor is satisfied by alerts.Engine.
type Processor interface {
	Process(ctx context.Context, ev db.Event) (int, error)
}

// EventConsumer reads upstream topics and feeds decoded events to the engine.
type EventConsumer struct {
	cl   *kgo.Client
	eng  Processor
	log  *zap.Logger
}

func NewEventConsumer(brokers, topics []string, group string, eng Processor, log *zap.Logger) (*EventConsumer, error) {
	cl, err := kgo.NewClient(
		kgo.SeedBrokers(brokers...),
		kgo.ConsumerGroup(group),
		kgo.ConsumeTopics(topics...),
		kgo.DisableAutoCommit(),
	)
	if err != nil {
		return nil, err
	}
	return &EventConsumer{cl: cl, eng: eng, log: log}, nil
}

// Run consumes until ctx is cancelled. Offsets are committed only after an event
// is processed (at-least-once); a malformed message is logged and skipped (we do
// not fabricate a substitute event).
func (c *EventConsumer) Run(ctx context.Context) error {
	for {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		fetches := c.cl.PollFetches(ctx)
		if errs := fetches.Errors(); len(errs) > 0 {
			for _, e := range errs {
				if e.Err != nil && ctx.Err() == nil {
					c.log.Warn("fetch error", zap.String("topic", e.Topic), zap.Error(e.Err))
				}
			}
		}
		fetches.EachRecord(func(r *kgo.Record) {
			var ev db.Event
			if err := json.Unmarshal(r.Value, &ev); err != nil {
				metrics.DecodeErrors.Inc()
				c.log.Warn("skip malformed event", zap.String("topic", r.Topic), zap.Error(err))
				return
			}
			if ev.Source == "" {
				ev.Source = r.Topic
			}
			if _, err := c.eng.Process(ctx, ev); err != nil {
				metrics.ProcessErrors.Inc()
				c.log.Warn("process error", zap.Error(err))
			}
		})
		c.cl.CommitUncommittedOffsets(ctx)
	}
}

func (c *EventConsumer) Close() { c.cl.Close() }

// --- Dispatcher ---

// DeliveryStore is the persistence the dispatcher needs.
type DeliveryStore interface {
	ClaimDueDeliveries(ctx context.Context, limit int) ([]db.Delivery, error)
	FirePayload(ctx context.Context, fireID int64) (db.Fire, error)
	MarkSent(ctx context.Context, id int64) error
	MarkFailed(ctx context.Context, id int64, attempts, maxAttempts int, reason string) error
	MarkUnavailable(ctx context.Context, id int64, reason string) error
}

// Dispatcher drains queued deliveries through the notifier registry.
type Dispatcher struct {
	store   DeliveryStore
	reg     *notifiers.Registry
	batch   int
	tick    time.Duration
	timeout time.Duration
	log     *zap.Logger
}

func NewDispatcher(store DeliveryStore, reg *notifiers.Registry, batch int, tick, timeout time.Duration, log *zap.Logger) *Dispatcher {
	if batch <= 0 {
		batch = 100
	}
	if tick <= 0 {
		tick = 2 * time.Second
	}
	if timeout <= 0 {
		timeout = 10 * time.Second
	}
	return &Dispatcher{store: store, reg: reg, batch: batch, tick: tick, timeout: timeout, log: log}
}

func (d *Dispatcher) Run(ctx context.Context) error {
	t := time.NewTicker(d.tick)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-t.C:
			d.drain(ctx)
		}
	}
}

func (d *Dispatcher) drain(ctx context.Context) {
	deliveries, err := d.store.ClaimDueDeliveries(ctx, d.batch)
	if err != nil {
		d.log.Warn("claim deliveries failed", zap.Error(err))
		return
	}
	for _, dl := range deliveries {
		d.deliver(ctx, dl)
	}
}

func (d *Dispatcher) deliver(ctx context.Context, dl db.Delivery) {
	n, ok := d.reg.For(dl.Channel)
	if !ok {
		_ = d.store.MarkUnavailable(ctx, dl.ID, "no notifier for channel")
		metrics.Deliveries.WithLabelValues(dl.Channel, "unavailable").Inc()
		return
	}
	fire, err := d.store.FirePayload(ctx, dl.FireID)
	if err != nil {
		_ = d.store.MarkFailed(ctx, dl.ID, dl.Attempts, dl.MaxAttempts, "load fire: "+err.Error())
		return
	}
	title, body := render(fire)
	cctx, cancel := context.WithTimeout(ctx, d.timeout)
	defer cancel()
	err = n.Send(cctx, notifiers.Message{Title: title, Body: body, Dest: dl.Dest, Fire: fire})
	switch {
	case err == nil:
		_ = d.store.MarkSent(ctx, dl.ID)
		metrics.Deliveries.WithLabelValues(dl.Channel, "sent").Inc()
	case err == notifiers.ErrNotConfigured:
		_ = d.store.MarkUnavailable(ctx, dl.ID, "channel not configured")
		metrics.Deliveries.WithLabelValues(dl.Channel, "unavailable").Inc()
	default:
		_ = d.store.MarkFailed(ctx, dl.ID, dl.Attempts, dl.MaxAttempts, err.Error())
		st := "failed"
		if dl.Attempts+1 >= dl.MaxAttempts {
			st = "dead"
		}
		metrics.Deliveries.WithLabelValues(dl.Channel, st).Inc()
	}
}

// render builds a title/body from the real fire payload (no embellishment).
func render(f db.Fire) (string, string) {
	title := "CoinDex Alert"
	if s, ok := f.Payload["summary"].(string); ok && s != "" {
		title = s
	}
	body := ""
	if r, ok := f.Payload["reason"].(string); ok {
		body = r
	}
	if detail, ok := f.Payload["detail"]; ok {
		if b, err := json.Marshal(detail); err == nil {
			body += "\n" + string(b)
		}
	}
	return title, body
}
