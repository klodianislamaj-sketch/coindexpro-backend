## coindex-alert-engine — Phase 10

Evaluates **real consumed upstream events** against user-defined alert rules and
delivers fires through configured channels. The core invariant: **an alert can
only fire from a real event that satisfied a real rule.** There is no code path
that manufactures an event, a fire, or a successful delivery.

### Architecture

```
real upstream (Kafka)            alert engine                       delivery
─────────────────────            ────────────                       ────────
enriched.wallet_trades  ─┐       consumer ─► engine.Process         dispatcher ─► notifiers
enriched.lp_events      ─┤   decode real    ├─ Evaluate (per rule)    claim due  ├─ webhook
provider.trust_updates  ─┼─► events ──────► ├─ cooldown (anti-spam)   deliveries ├─ telegram
graph.cluster_updates   ─┤                  ├─ dedupe (Redis + DB)    + retries  ├─ discord
contract.risk_updates   ─┤                  └─ RecordFire ─► enqueue  + DLQ       └─ email
market.candle_updates   ─┘                     deliveries
```

The engine reuses the **Phase 2 `alerts` + `alert_fires`** tables (source of
truth, not rebuilt) and adds **`alert_deliveries`** (+ an `alert_dead_letters`
view) for delivery tracking.

### Rule kinds & what each requires from a real event

| Kind | Fires when (all from real event fields) |
|---|---|
| `whale_buy` / `whale_sell` | `amount_usd > 0` and ≥ rule threshold |
| `dev_sell` | a real sell with `amount_usd > 0` |
| `liquidity` | `liquidity_add`/`remove` with `|amount_usd|` ≥ threshold |
| `trust_drop` | both `trust_score` and `trust_prev` present; drop ≥ threshold |
| `risk_change` | both `risk_score` and `risk_prev` present; change ≥ threshold |
| `price` | both `price` and `price_prev` present; `|%Δ|` ≥ threshold |
| `volume` | `volume` and real `baseline` present; multiple ≥ threshold |
| `smart_money` | a real `cluster_id` from the graph engine |
| `holder_change` / `unlock` | real holder counts / a real unlock reference |

If the event lacks the data a rule needs, the rule **does not fire** — no
assumption, no fabrication.

### Dedupe & cooldown

- **Dedupe** stops the *same* event firing the *same* rule twice. Fast path is
  Redis `SETNX` over a window; the durable backstop is
  `alert_fires UNIQUE(alert_id, dedupe_key)` — so even with a cold cache a
  duplicate fire cannot be persisted. The key bins by rule + entity + hour.
- **Cooldown** stops *different* events from a rule firing too often (anti-spam),
  with an optional per-rule `cooldown_seconds` in the rule target.

Both fail **open** on Redis error (the DB UNIQUE still bounds true duplicates), so
a genuine alert is never silently dropped because the cache is down.

### Delivery, retries & DLQ

The dispatcher claims due deliveries (`FOR UPDATE SKIP LOCKED`, so multiple
replicas don't double-send), renders the **real fire payload**, and calls the
channel notifier. Outcomes:

- **sent** — notifier returned success.
- **failed** → retried with exponential backoff (30s, 60s, 120s, …).
- **dead** — retries exhausted → moves to the `alert_dead_letters` DLQ view.
- **unavailable** — the channel is **not configured** (e.g. no telegram token, no
  SMTP host). This is terminal and honest: the delivery is recorded `unavailable`,
  **never reported as sent**.

### Notifiers

`webhook` (POST JSON to the rule's URL), `discord` (webhook), `telegram` (Bot API;
needs engine token + rule chat id), `email` (SMTP; needs engine host/from + rule
address). Each returns `ErrNotConfigured` when its prerequisites are missing.

### API (read-only)

| Route | Returns |
|---|---|
| `GET /alerts/:id/fires` | recent fires for a rule (or `available:false`) |
| `GET /fires/:id/deliveries` | delivery rows for a fire (or `available:false`) |
| `GET /deliveries/dead` | the dead-letter queue (or `available:false`) |

There is deliberately **no endpoint to create a fire** — fires come only from real
events. Ops: `/healthz`, `/readyz`, `/metrics`.

### Idempotency & replay

Re-delivered upstream messages are safe: dedupe + the `alert_fires` UNIQUE make a
repeat a no-op, and `alert_deliveries UNIQUE(fire_id, channel, dest)` makes
delivery enqueue idempotent. Event-consumer offsets commit only after processing
(at-least-once), and the dedupe layer makes that exactly-once at the fire level.

### Honest boundaries

- **Real, production-shaped code, NOT compiled or run here** (no Go toolchain, no
  Postgres/Redis/Kafka/SMTP, no network in the authoring environment). Statically
  reviewed (imports/symbols/interfaces resolve; routes distinct; channel CHECK
  matches constants). Evaluator thresholds and dedupe verified by simulation.
  Before production: `go build` + `vet` + lint and an integration run.
- **No synthetic triggers.** The engine never generates an event; it only reacts
  to consumed real messages. A malformed message is skipped (and counted), not
  replaced by a fabricated one.
- **No fake deliveries.** A send is real or it is recorded `unavailable`/`failed`/
  `dead` — there is no "pretend sent" path.
- **Only as real as upstream.** If a producer isn't running, the matching alert
  kinds simply never fire; the engine does not invent activity to fill the gap.
