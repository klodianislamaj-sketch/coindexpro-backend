// Command alert-engine is the Phase 10 entrypoint. It consumes real upstream
// events, evaluates them against user alert rules, and delivers fires through
// configured channels with dedupe, cooldown, retries, and a dead-letter queue.
package main

import (
	"context"
	"errors"
	"flag"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/compress"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"github.com/redis/go-redis/v9"
	"go.uber.org/zap"

	"github.com/coindexpro/coindex-alert-engine/config"
	"github.com/coindexpro/coindex-alert-engine/internal/alerts"
	"github.com/coindexpro/coindex-alert-engine/internal/api"
	"github.com/coindexpro/coindex-alert-engine/internal/cache"
	"github.com/coindexpro/coindex-alert-engine/internal/consumers"
	"github.com/coindexpro/coindex-alert-engine/internal/db"
	"github.com/coindexpro/coindex-alert-engine/internal/notifiers"
)

func main() {
	cfgPath := flag.String("config", "config/config.yaml", "config path")
	flag.Parse()

	cfg, err := config.Load(*cfgPath)
	if err != nil {
		panic(err)
	}
	log, _ := zap.NewProduction()
	defer func() { _ = log.Sync() }()
	log.Info("starting alert-engine")

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	store, err := db.Open(ctx, cfg.Postgres.DSN)
	if err != nil {
		log.Fatal("postgres open failed", zap.Error(err))
	}
	defer store.Close()

	rdb := cache.New(cfg.Redis.Addr)
	if err := rdb.Ping(ctx).Err(); err != nil {
		log.Fatal("redis ping failed", zap.Error(err))
	}
	defer func() { _ = rdb.Close() }()

	dedupe := alerts.NewDeduper(rdb, cfg.Engine.DedupeWindow)
	cooldown := alerts.NewCooldown(rdb, cfg.Engine.DefaultCooldown)
	engine := alerts.NewEngine(store, dedupe, cooldown, cfg.Engine.DefaultCooldown, log)

	// notifier registry — channels missing credentials report not-configured at send
	reg := notifiers.NewRegistry(
		notifiers.NewWebhook(cfg.Notifiers.HTTPTimeout),
		notifiers.NewDiscord(cfg.Notifiers.HTTPTimeout),
		notifiers.NewTelegram(cfg.Notifiers.TelegramToken, cfg.Notifiers.HTTPTimeout),
		notifiers.NewEmail(notifiers.SMTPConfig{
			Host: cfg.Notifiers.SMTP.Host, Port: cfg.Notifiers.SMTP.Port,
			Username: cfg.Notifiers.SMTP.Username, Password: cfg.Notifiers.SMTP.Password,
			From: cfg.Notifiers.SMTP.From,
		}),
	)

	// event consumer (real upstream → engine)
	ec, err := consumers.NewEventConsumer(cfg.Kafka.Brokers, cfg.Kafka.Topics, cfg.Kafka.GroupID, engine, log)
	if err != nil {
		log.Fatal("event consumer init failed", zap.Error(err))
	}
	defer ec.Close()
	go func() {
		if err := ec.Run(ctx); err != nil && !errors.Is(err, context.Canceled) {
			log.Error("event consumer stopped", zap.Error(err))
		}
	}()

	// dispatcher (deliveries → notifiers, with retries/DLQ)
	disp := consumers.NewDispatcher(store, reg, cfg.Dispatcher.Batch, cfg.Dispatcher.Tick, cfg.Dispatcher.Timeout, log)
	go func() {
		if err := disp.Run(ctx); err != nil && !errors.Is(err, context.Canceled) {
			log.Error("dispatcher stopped", zap.Error(err))
		}
	}()

	app := fiber.New(fiber.Config{AppName: "coindex-alert-engine"})
	app.Use(compress.New())
	api.New(store).Register(app)
	go func() {
		log.Info("api listening", zap.String("addr", cfg.Server.APIAddr))
		if err := app.Listen(cfg.Server.APIAddr); err != nil {
			log.Error("api stopped", zap.Error(err))
		}
	}()

	go serveOps(cfg.Server.MetricsAddr, store, rdb, log)

	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
	<-sig
	log.Info("shutting down")
	cancel()
	sc, scCancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer scCancel()
	_ = app.ShutdownWithContext(sc)
}

func serveOps(addr string, store *db.Store, rdb *redis.Client, log *zap.Logger) {
	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ok"))
	})
	mux.HandleFunc("/readyz", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), 3*time.Second)
		defer cancel()
		if err := store.Ping(ctx); err != nil {
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte("postgres down"))
			return
		}
		if err := rdb.Ping(ctx).Err(); err != nil {
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte("redis down"))
			return
		}
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ready"))
	})
	mux.Handle("/metrics", promhttp.Handler())
	srv := &http.Server{Addr: addr, Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Error("ops server failed", zap.Error(err))
	}
}
