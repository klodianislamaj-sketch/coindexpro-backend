// Package config loads alert-engine configuration from YAML with ${ENV} expansion.
package config

import (
	"fmt"
	"os"
	"time"

	"gopkg.in/yaml.v3"
)

type Config struct {
	Server     ServerConfig    `yaml:"server"`
	Postgres   PostgresConfig  `yaml:"postgres"`
	Redis      RedisConfig     `yaml:"redis"`
	Kafka      KafkaConfig     `yaml:"kafka"`
	Engine     EngineConfig    `yaml:"engine"`
	Dispatcher DispatcherConfig `yaml:"dispatcher"`
	Notifiers  NotifiersConfig `yaml:"notifiers"`
	Log        LogConfig       `yaml:"log"`
}

type ServerConfig struct {
	APIAddr     string `yaml:"api_addr"`
	MetricsAddr string `yaml:"metrics_addr"`
}
type PostgresConfig struct {
	DSN string `yaml:"dsn"`
}
type RedisConfig struct {
	Addr string `yaml:"addr"`
}
type KafkaConfig struct {
	Brokers []string `yaml:"brokers"`
	GroupID string   `yaml:"group_id"`
	Topics  []string `yaml:"topics"`
}
type EngineConfig struct {
	DedupeWindow    time.Duration `yaml:"dedupe_window"`
	DefaultCooldown time.Duration `yaml:"default_cooldown"`
}
type DispatcherConfig struct {
	Batch   int           `yaml:"batch"`
	Tick    time.Duration `yaml:"tick"`
	Timeout time.Duration `yaml:"timeout"`
}
type NotifiersConfig struct {
	TelegramToken string     `yaml:"telegram_token"`
	SMTP          SMTPConfig `yaml:"smtp"`
	HTTPTimeout   time.Duration `yaml:"http_timeout"`
}
type SMTPConfig struct {
	Host     string `yaml:"host"`
	Port     int    `yaml:"port"`
	Username string `yaml:"username"`
	Password string `yaml:"password"`
	From     string `yaml:"from"`
}
type LogConfig struct {
	Level string `yaml:"level"`
}

func Load(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}
	var c Config
	if err := yaml.Unmarshal([]byte(os.Expand(string(raw), os.Getenv)), &c); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}
	c.defaults()
	return &c, c.validate()
}

func (c *Config) defaults() {
	if c.Server.APIAddr == "" {
		c.Server.APIAddr = ":8096"
	}
	if c.Server.MetricsAddr == "" {
		c.Server.MetricsAddr = ":9108"
	}
	if c.Engine.DedupeWindow == 0 {
		c.Engine.DedupeWindow = time.Hour
	}
	if c.Engine.DefaultCooldown == 0 {
		c.Engine.DefaultCooldown = 5 * time.Minute
	}
	if c.Dispatcher.Batch == 0 {
		c.Dispatcher.Batch = 100
	}
	if c.Dispatcher.Tick == 0 {
		c.Dispatcher.Tick = 2 * time.Second
	}
	if c.Dispatcher.Timeout == 0 {
		c.Dispatcher.Timeout = 10 * time.Second
	}
	if c.Notifiers.HTTPTimeout == 0 {
		c.Notifiers.HTTPTimeout = 10 * time.Second
	}
	if c.Kafka.GroupID == "" {
		c.Kafka.GroupID = "coindex-alert-engine"
	}
}

func (c *Config) validate() error {
	if c.Postgres.DSN == "" {
		return fmt.Errorf("postgres.dsn empty")
	}
	if c.Redis.Addr == "" {
		return fmt.Errorf("redis.addr empty")
	}
	if len(c.Kafka.Brokers) == 0 {
		return fmt.Errorf("kafka.brokers empty")
	}
	if len(c.Kafka.Topics) == 0 {
		return fmt.Errorf("kafka.topics empty")
	}
	return nil
}
