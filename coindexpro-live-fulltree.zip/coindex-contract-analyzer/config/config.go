// Package config loads contract-analyzer configuration from YAML with ${ENV} expansion.
package config

import (
	"fmt"
	"os"
	"time"

	"gopkg.in/yaml.v3"
)

type Config struct {
	Server   ServerConfig            `yaml:"server"`
	Chains   map[string]ChainConfig  `yaml:"chains"` // chain -> rpc endpoints
	Postgres PostgresConfig          `yaml:"postgres"`
	Redis    RedisConfig             `yaml:"redis"`
	Analyze  AnalyzeConfig           `yaml:"analyze"`
	Log      LogConfig               `yaml:"log"`
}

type ServerConfig struct {
	APIAddr     string `yaml:"api_addr"`
	MetricsAddr string `yaml:"metrics_addr"`
}
type ChainConfig struct {
	RPCEndpoints []string `yaml:"rpc_endpoints"`
}
type PostgresConfig struct {
	DSN string `yaml:"dsn"`
}
type RedisConfig struct {
	Addr string `yaml:"addr"`
}
type AnalyzeConfig struct {
	RPCTimeout time.Duration `yaml:"rpc_timeout"`
	CacheTTL   time.Duration `yaml:"cache_ttl"`
	Freshness  time.Duration `yaml:"freshness"`
}
type LogConfig struct {
	Level string `yaml:"level"`
}

func Load(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}
	var c Config
	if err := yaml.Unmarshal([]byte(os.Expand(string(raw), os.Getenv)), &c); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}
	c.defaults()
	return &c, c.validate()
}

func (c *Config) defaults() {
	if c.Server.APIAddr == "" {
		c.Server.APIAddr = ":8094"
	}
	if c.Server.MetricsAddr == "" {
		c.Server.MetricsAddr = ":9106"
	}
	if c.Analyze.RPCTimeout == 0 {
		c.Analyze.RPCTimeout = 5 * time.Second
	}
	if c.Analyze.CacheTTL == 0 {
		c.Analyze.CacheTTL = 10 * time.Minute
	}
	if c.Analyze.Freshness == 0 {
		c.Analyze.Freshness = 30 * time.Minute
	}
}

func (c *Config) validate() error {
	if len(c.Chains) == 0 {
		return fmt.Errorf("no chains configured")
	}
	for name, ch := range c.Chains {
		if len(ch.RPCEndpoints) == 0 {
			return fmt.Errorf("chain %q has no rpc_endpoints", name)
		}
	}
	if c.Postgres.DSN == "" {
		return fmt.Errorf("postgres.dsn empty")
	}
	if c.Redis.Addr == "" {
		return fmt.Errorf("redis.addr empty")
	}
	return nil
}
