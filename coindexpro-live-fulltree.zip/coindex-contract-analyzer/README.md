## coindex-contract-analyzer — Phase 8

Produces **explainable** contract risk from **real on-chain reads only** (RPC
`eth_getCode`, `eth_call`, `eth_getStorageAt`). There is no safe/unsafe verdict:
the output is a 0–100 score that is the transparent sum of individually-explained
factors, each with a confidence level and the evidence behind it.

### Confidence model (the honesty core)

| Confidence | Meaning | Examples |
|---|---|---|
| `definitive` | read from chain state | EIP-1967 proxy slot is non-zero; `owner()` returned an address; `ORIGIN`/`SELFDESTRUCT` opcode present |
| `probable` | function selector present in the bytecode dispatcher (implemented), but its effect/caller/cap needs source to confirm | mint, blacklist, tax-setter, pause selectors |

Function selectors are **computed at runtime via Keccak256** from canonical
signatures — never hardcoded hex — so the registry cannot silently drift. (Verified:
`owner()`→`0x8da5cb5b`, `mint(address,uint256)`→`0x40c10f19`, etc.)

A "probable" signal contributes **less** to the score than a "definitive" one — a
heuristic is never scored as certainty.

### What it detects

- **Ownership** — `owner()`/`getOwner()`/`pendingOwner()` via eth_call; detects
  renounced ownership (`owner == 0x0`) and removes owner-privilege risk when so.
- **Mint** — `totalSupply()` read; mint selectors (probable).
- **Blacklist** — address-restriction selectors (probable).
- **Tax / limits** — fee/tax setters and max-tx/max-wallet setters (probable);
  exact rates are **not** asserted (would need a getter/ABI — never invented).
- **Proxy / upgradeability** — EIP-1967 implementation/admin/beacon **storage
  slots** (definitive); UUPS selector (probable); DELEGATECALL signal.
- **Hidden admin** — `tx.origin` (ORIGIN opcode), SELFDESTRUCT, pause/trading-gate.

### Risk scoring (transparent, reproducible)

Max weights are published in every response: owner_privileges 20, mintable 20,
proxy_upgradeable 18, blacklist_capable 15, tax_mutable 12, pausable 8,
uses_tx_origin 4, selfdestruct 3. `points = weight × confidence_fraction`. Output:
`{ score, factors:[{factor, severity, weight, points, confidence, reason, evidence}], explainable:true, disclaimer }`.

The disclaimer ships in every result: **detected capabilities describe what a
contract CAN do, not intent** — many legitimate tokens have owners, pausability,
or upgradeability.

### Folder tree

```
cmd/contract-analyzer/main.go        per-chain RPC clients, API, ops, shutdown
config/{config.go, config.yaml}
internal/
  analyzer/  bytecode.go ownership.go mint.go blacklist.go tax.go proxy.go hidden_admin.go risk.go
  rpc/       client.go (failover) multicall.go (JSON-RPC batch)
  db/        db.go models.go
  api/       api.go        (/analyze /risk /history)
  cache/     cache.go
  metrics/   metrics.go
migrations/postgres/001_contract_analysis.sql   contract_analysis, contract_risks, contract_history
Dockerfile · docker-compose.yml · go.mod · README.md
```

### API

`GET /contract/:chain/:address/analyze` · `GET /contract/:chain/:address/risk` ·
`GET /contract/:chain/:address/history` · ops `/healthz` `/readyz` `/metrics`

### Run

```bash
export ETH_RPC_1=https://... BSC_RPC_1=https://... POSTGRES_DSN=... REDIS_ADDR=...
# apply migrations/postgres/001_contract_analysis.sql
docker compose up --build
# GET http://localhost:8094/contract/ethereum/0x.../analyze
```

### Honest status & limits

- **Real, production-shaped code, NOT compiled or run here** (no Go toolchain, no
  RPC, no DBs in the authoring environment). Static-reviewed (imports/symbols
  resolve; dead helper removed). Keccak selectors and the opcode scanner were
  verified by simulation. Before production: `go build` + `vet` + lint, and an
  integration run against a real archive/full node.
- **Only as real as the RPC.** No code at the address → `{available:false,
  reason:"no contract code at address"}`. RPC unreachable → `{available:false,
  reason:"rpc unavailable"}` (and that transient result is **not** cached).
- **Selector presence ≠ behaviour proof.** The analyzer is explicit that a
  bytecode selector shows a function is implemented, not that it is exploitable or
  malicious — hence `probable` confidence and reduced score weight. Exact tax
  rates, mint caps, and access-control details require verified source, which this
  service does not assume; it reports the capability, not a fabricated value.
- **Not a verdict.** No binary safe/unsafe label is ever emitted.
