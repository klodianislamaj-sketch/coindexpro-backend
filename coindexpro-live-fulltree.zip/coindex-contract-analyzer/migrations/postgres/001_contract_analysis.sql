-- =============================================================================
-- CoinDex Contract Analyzer — PostgreSQL schema (Phase 8)
-- =============================================================================
-- Stores explainable, RPC-derived contract analysis. Nothing here is a verdict:
-- a score is the transparent sum of weighted, individually-explained factors.
-- A contract with no code is recorded with has_code=false and no factors, never
-- a fabricated risk profile.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- contract_analysis — one headline row per (chain, address)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contract_analysis (
    chain        text        NOT NULL,
    address      text        NOT NULL CHECK (address = lower(address)),
    has_code     boolean     NOT NULL,
    score        integer     NOT NULL CHECK (score BETWEEN 0 AND 100),
    owner        text,                              -- from owner()/getOwner(); NULL if not readable
    renounced    boolean     NOT NULL DEFAULT false,
    proxy_kind   text,                              -- eip1967|beacon|uups|NULL
    total_supply numeric,                           -- from totalSupply(); NULL if not readable
    analyzed_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (chain, address)
);
CREATE INDEX IF NOT EXISTS idx_ca_score ON contract_analysis (chain, score DESC);

-- -----------------------------------------------------------------------------
-- contract_risks — the explainable factors behind each score (1 row per factor)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contract_risks (
    id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    chain      text    NOT NULL,
    address    text    NOT NULL CHECK (address = lower(address)),
    factor     text    NOT NULL,
    severity   text    NOT NULL CHECK (severity IN ('none','info','low','medium','high')),
    weight     numeric NOT NULL,                    -- max contribution of this factor
    points     numeric NOT NULL,                    -- actual contribution given confidence
    confidence text    NOT NULL CHECK (confidence IN ('definitive','probable')),
    reason     text    NOT NULL,                    -- human explanation
    evidence   jsonb   NOT NULL DEFAULT '{}'::jsonb,
    FOREIGN KEY (chain, address) REFERENCES contract_analysis (chain, address) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_cr_lookup ON contract_risks (chain, address);

-- -----------------------------------------------------------------------------
-- contract_history — append-only score snapshots (audit how risk changes over time)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contract_history (
    id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    chain      text        NOT NULL,
    address    text        NOT NULL CHECK (address = lower(address)),
    score      integer     NOT NULL CHECK (score BETWEEN 0 AND 100),
    snapshot   jsonb       NOT NULL,                -- score + factors at this time
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_ch_lookup ON contract_history (chain, address, created_at DESC);
