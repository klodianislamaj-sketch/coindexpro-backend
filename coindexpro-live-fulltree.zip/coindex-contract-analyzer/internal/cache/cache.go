// Package cache stores rendered analysis JSON in Redis. Contract analysis is
// RPC-heavy, so caching avoids re-probing the same contract within the TTL. The
// cache holds only real, computed results.
package cache

import (
	"context"
	"time"

	"github.com/redis/go-redis/v9"
)

type Cache struct {
	rdb *redis.Client
	ttl time.Duration
}

func New(rdb *redis.Client, ttl time.Duration) *Cache {
	if ttl == 0 {
		ttl = 10 * time.Minute
	}
	return &Cache{rdb: rdb, ttl: ttl}
}

func key(chain, addr string) string { return "contract:" + chain + ":" + addr }

func (c *Cache) Get(ctx context.Context, chain, addr string) ([]byte, bool) {
	b, err := c.rdb.Get(ctx, key(chain, addr)).Bytes()
	if err != nil {
		return nil, false
	}
	return b, true
}

func (c *Cache) Set(ctx context.Context, chain, addr string, body []byte) {
	_ = c.rdb.Set(ctx, key(chain, addr), body, c.ttl).Err()
}

func (c *Cache) Invalidate(ctx context.Context, chain, addr string) {
	_ = c.rdb.Del(ctx, key(chain, addr)).Err()
}

func (c *Cache) Ping(ctx context.Context) error { return c.rdb.Ping(ctx).Err() }
func (c *Cache) Close() error                   { return c.rdb.Close() }
