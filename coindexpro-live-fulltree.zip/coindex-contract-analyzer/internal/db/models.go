// Package db persists contract analyses to Postgres. It stores exactly what the
// analyzer produced from real chain reads — including the explainable factors —
// and never synthesizes a value.
package db

import (
	"time"

	"github.com/coindexpro/coindex-contract-analyzer/internal/analyzer"
)

// AnalysisRow is the headline analysis persisted to contract_analysis.
type AnalysisRow struct {
	Chain       string
	Address     string
	HasCode     bool
	Score       int
	Owner       string
	Renounced   bool
	ProxyKind   string
	TotalSupply string
	AnalyzedAt  time.Time
}

// FactorRow is one explainable risk factor persisted to contract_risks.
type FactorRow struct {
	Chain      string
	Address    string
	Factor     string
	Severity   string
	Weight     float64
	Points     float64
	Confidence string
	Reason     string
	Evidence   map[string]any
}

// FromAnalysis splits an analyzer.Analysis into the row shapes for persistence.
func FromAnalysis(a analyzer.Analysis) (AnalysisRow, []FactorRow) {
	proxyKind := ""
	if a.Proxy != nil {
		proxyKind = a.Proxy.Kind
	}
	row := AnalysisRow{
		Chain: a.Chain, Address: a.Address, HasCode: a.HasCode, Score: a.Score,
		Owner: a.Owner, Renounced: a.Renounced, ProxyKind: proxyKind,
		TotalSupply: a.TotalSupply, AnalyzedAt: time.Now().UTC(),
	}
	factors := make([]FactorRow, 0, len(a.Factors))
	for _, f := range a.Factors {
		factors = append(factors, FactorRow{
			Chain: a.Chain, Address: a.Address, Factor: f.Factor, Severity: f.Severity,
			Weight: f.Weight, Points: f.Points, Confidence: f.Confidence,
			Reason: f.Reason, Evidence: f.Evidence,
		})
	}
	return row, factors
}
