package db

import (
	"context"
	"encoding/json"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

type Store struct{ pool *pgxpool.Pool }

func Open(ctx context.Context, dsn string) (*Store, error) {
	pool, err := pgxpool.New(ctx, dsn)
	if err != nil {
		return nil, err
	}
	if err := pool.Ping(ctx); err != nil {
		return nil, err
	}
	return &Store{pool: pool}, nil
}

func (s *Store) Close()                          { s.pool.Close() }
func (s *Store) Ping(ctx context.Context) error  { return s.pool.Ping(ctx) }

// Save upserts the analysis, replaces its factors, and appends a history
// snapshot — all in one transaction so a reader never sees a half-updated state.
func (s *Store) Save(ctx context.Context, row AnalysisRow, factors []FactorRow) error {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)

	const up = `
		INSERT INTO contract_analysis
			(chain, address, has_code, score, owner, renounced, proxy_kind, total_supply, analyzed_at)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8, now())
		ON CONFLICT (chain, address) DO UPDATE SET
			has_code=$3, score=$4, owner=$5, renounced=$6, proxy_kind=$7,
			total_supply=$8, analyzed_at=now()`
	if _, err := tx.Exec(ctx, up, row.Chain, row.Address, row.HasCode, row.Score,
		nullStr(row.Owner), row.Renounced, nullStr(row.ProxyKind), nullStr(row.TotalSupply)); err != nil {
		return err
	}

	if _, err := tx.Exec(ctx, `DELETE FROM contract_risks WHERE chain=$1 AND address=$2`,
		row.Chain, row.Address); err != nil {
		return err
	}
	for _, f := range factors {
		ev, _ := json.Marshal(f.Evidence)
		const ins = `
			INSERT INTO contract_risks
				(chain, address, factor, severity, weight, points, confidence, reason, evidence)
			VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`
		if _, err := tx.Exec(ctx, ins, f.Chain, f.Address, f.Factor, f.Severity,
			f.Weight, f.Points, f.Confidence, f.Reason, ev); err != nil {
			return err
		}
	}

	// history snapshot: append the score + factor summary so score changes over
	// time are auditable (immutable append).
	summary, _ := json.Marshal(map[string]any{"score": row.Score, "factors": factors})
	const hist = `
		INSERT INTO contract_history (chain, address, score, snapshot)
		VALUES ($1,$2,$3,$4)`
	if _, err := tx.Exec(ctx, hist, row.Chain, row.Address, row.Score, summary); err != nil {
		return err
	}
	return tx.Commit(ctx)
}

// LoadAnalysis returns the stored headline analysis (ok=false if none).
func (s *Store) LoadAnalysis(ctx context.Context, chain, address string) (AnalysisRow, time.Time, bool, error) {
	const q = `
		SELECT has_code, score, COALESCE(owner,''), renounced, COALESCE(proxy_kind,''),
		       COALESCE(total_supply,''), analyzed_at
		FROM contract_analysis WHERE chain=$1 AND address=$2`
	var r AnalysisRow
	var at time.Time
	r.Chain, r.Address = chain, address
	err := s.pool.QueryRow(ctx, q, chain, address).Scan(
		&r.HasCode, &r.Score, &r.Owner, &r.Renounced, &r.ProxyKind, &r.TotalSupply, &at)
	if err == pgx.ErrNoRows {
		return AnalysisRow{}, time.Time{}, false, nil
	}
	if err != nil {
		return AnalysisRow{}, time.Time{}, false, err
	}
	return r, at, true, nil
}

// LoadFactors returns the stored explainable factors for an address.
func (s *Store) LoadFactors(ctx context.Context, chain, address string) ([]FactorRow, error) {
	const q = `
		SELECT factor, severity, weight, points, confidence, reason, evidence
		FROM contract_risks WHERE chain=$1 AND address=$2
		ORDER BY points DESC`
	rows, err := s.pool.Query(ctx, q, chain, address)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []FactorRow
	for rows.Next() {
		var f FactorRow
		var ev []byte
		if err := rows.Scan(&f.Factor, &f.Severity, &f.Weight, &f.Points, &f.Confidence, &f.Reason, &ev); err != nil {
			return nil, err
		}
		_ = json.Unmarshal(ev, &f.Evidence)
		f.Chain, f.Address = chain, address
		out = append(out, f)
	}
	return out, rows.Err()
}

// History returns score snapshots over time (newest first).
func (s *Store) History(ctx context.Context, chain, address string, limit int) ([]map[string]any, error) {
	const q = `
		SELECT score, snapshot, created_at FROM contract_history
		WHERE chain=$1 AND address=$2 ORDER BY created_at DESC LIMIT $3`
	rows, err := s.pool.Query(ctx, q, chain, address, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []map[string]any
	for rows.Next() {
		var score int
		var snap []byte
		var ts time.Time
		if err := rows.Scan(&score, &snap, &ts); err != nil {
			return nil, err
		}
		var s any
		_ = json.Unmarshal(snap, &s)
		out = append(out, map[string]any{"score": score, "snapshot": s, "at": ts})
	}
	return out, rows.Err()
}

func nullStr(s string) any {
	if s == "" {
		return nil
	}
	return s
}
