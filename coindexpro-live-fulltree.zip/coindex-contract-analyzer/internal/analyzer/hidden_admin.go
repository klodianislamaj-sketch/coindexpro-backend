package analyzer

import "context"

// HiddenAdminResult reports signals of non-obvious privileged control.
type HiddenAdminResult struct {
	Findings  []Finding
	Available bool
}

// AnalyzeHiddenAdmin scans bytecode opcodes for signals that admin control may
// be exercised in non-obvious ways:
//   - ORIGIN (tx.origin): often used for hidden auth or phishing-style gating
//   - SELFDESTRUCT: contract can be destroyed
//   - pause/trading-enable selectors: trading can be gated on/off by a role
// Each is reported with honest confidence. tx.origin USAGE is definitive (the
// opcode is in the code); its PURPOSE needs source, which we state plainly.
func AnalyzeHiddenAdmin(ctx context.Context, code Bytecode) HiddenAdminResult {
	out := HiddenAdminResult{Available: true}

	if code.HasOpcode(opORIGIN) {
		out.Findings = append(out.Findings, Finding{
			Factor: "uses_tx_origin", Present: true, Confidence: ConfDefinitive,
			Reason: "bytecode uses the ORIGIN opcode (tx.origin); can indicate non-standard auth — purpose requires source to confirm",
		})
	}
	if code.HasOpcode(opSELFDESTRUCT) {
		out.Findings = append(out.Findings, Finding{
			Factor: "selfdestruct", Present: true, Confidence: ConfDefinitive,
			Reason: "bytecode contains SELFDESTRUCT; contract may be destroyable",
		})
	}
	if sigs := code.MatchedGroups()["pause"]; len(sigs) > 0 {
		out.Findings = append(out.Findings, Finding{
			Factor: "pausable", Present: true, Confidence: ConfProbable,
			Reason: "pause / trading-enable selector(s) present; transfers or trading may be haltable by a role",
			Evidence: map[string]any{"signatures": sigs},
		})
	}
	return out
}
