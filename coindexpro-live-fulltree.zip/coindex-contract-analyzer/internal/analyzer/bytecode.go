// Package analyzer inspects real on-chain bytecode and contract state. The
// bytecode scanner is opcode-aware: it walks the code respecting PUSH immediates
// so data bytes are never misread as opcodes, and it extracts the 4-byte
// function selectors from the dispatcher (PUSH4 immediates). Selectors are
// COMPUTED at runtime from canonical signatures via Keccak256 — never hardcoded
// hex that could silently be wrong.
package analyzer

import (
	"golang.org/x/crypto/sha3"
)

// EVM opcodes we care about.
const (
	opSTOP         = 0x00
	opORIGIN       = 0x32 // tx.origin
	opPUSH1        = 0x60
	opPUSH4        = 0x63
	opPUSH32       = 0x7f
	opDELEGATECALL = 0xf4
	opCREATE       = 0xf0
	opCREATE2      = 0xf5
	opSELFDESTRUCT = 0xff
	opSSTORE       = 0x55
)

// Selector is a 4-byte function selector.
type Selector [4]byte

// computeSelector returns the first 4 bytes of keccak256(signature). This is the
// canonical Ethereum selector derivation; doing it in code guarantees the
// registry can never drift from a wrong hardcoded constant.
func computeSelector(sig string) Selector {
	h := sha3.NewLegacyKeccak256()
	h.Write([]byte(sig))
	sum := h.Sum(nil)
	var s Selector
	copy(s[:], sum[:4])
	return s
}

// SignatureRegistry maps a human signature to its capability group. Detection is
// honest about meaning: presence of a selector indicates the function is
// implemented in the dispatcher, matched against these canonical signatures.
var signatureGroups = map[string][]string{
	"ownership": {
		"owner()", "pendingOwner()", "transferOwnership(address)",
		"renounceOwnership()", "getOwner()",
	},
	"mint": {
		"mint(address,uint256)", "mint(uint256)", "_mint(address,uint256)",
	},
	"blacklist": {
		"blacklist(address)", "isBlacklisted(address)", "addBlackList(address)",
		"setBlacklist(address,bool)", "_blacklist(address,bool)", "isBot(address)",
	},
	"pause": {
		"pause()", "unpause()", "paused()", "setTradingEnabled(bool)",
		"enableTrading()", "setTrading(bool)",
	},
	"tax": {
		"setFee(uint256)", "setFees(uint256,uint256)", "setTaxes(uint256,uint256)",
		"setBuyTax(uint256)", "setSellTax(uint256)", "setTaxFee(uint256)",
		"updateFees(uint256,uint256)",
	},
	"limits": {
		"setMaxTxAmount(uint256)", "setMaxWallet(uint256)", "setMaxWalletAmount(uint256)",
		"removeLimits()", "setMaxTransactionAmount(uint256)",
	},
	"supply": {"totalSupply()"},
}

// precomputed selector → (group, signature)
type selectorMeta struct {
	Group     string
	Signature string
}

var knownSelectors = func() map[Selector]selectorMeta {
	m := map[Selector]selectorMeta{}
	for group, sigs := range signatureGroups {
		for _, sig := range sigs {
			m[computeSelector(sig)] = selectorMeta{Group: group, Signature: sig}
		}
	}
	return m
}()

// Bytecode is runtime contract code fetched from the chain.
type Bytecode []byte

// ExtractSelectors walks the bytecode and returns every PUSH4 immediate, which
// in Solidity/Vyper dispatchers are the function selectors. The walk skips PUSH
// data so it never misreads an immediate as an opcode.
func (b Bytecode) ExtractSelectors() map[Selector]bool {
	out := map[Selector]bool{}
	for i := 0; i < len(b); {
		op := b[i]
		if op == opPUSH4 && i+5 <= len(b) {
			var s Selector
			copy(s[:], b[i+1:i+5])
			out[s] = true
			i += 5
			continue
		}
		if op >= opPUSH1 && op <= opPUSH32 {
			i += int(op-opPUSH1) + 2 // opcode + N immediate bytes
			continue
		}
		i++
	}
	return out
}

// HasOpcode reports whether an opcode appears in executable position (PUSH data
// skipped). Used for ORIGIN (tx.origin), DELEGATECALL, SELFDESTRUCT detection.
func (b Bytecode) HasOpcode(target byte) bool {
	for i := 0; i < len(b); {
		op := b[i]
		if op == target {
			return true
		}
		if op >= opPUSH1 && op <= opPUSH32 {
			i += int(op-opPUSH1) + 2
			continue
		}
		i++
	}
	return false
}

// MatchedGroups returns which capability groups have at least one selector
// present in the bytecode, with the specific signatures matched (the evidence).
func (b Bytecode) MatchedGroups() map[string][]string {
	selectors := b.ExtractSelectors()
	groups := map[string][]string{}
	for sel := range selectors {
		if meta, ok := knownSelectors[sel]; ok {
			groups[meta.Group] = append(groups[meta.Group], meta.Signature)
		}
	}
	return groups
}

// SelectorHex renders a selector as 0x-prefixed hex (for evidence/JSON).
func SelectorHex(s Selector) string {
	const hexdigits = "0123456789abcdef"
	out := []byte("0x00000000")
	for i, bb := range s {
		out[2+i*2] = hexdigits[bb>>4]
		out[3+i*2] = hexdigits[bb&0x0f]
	}
	return string(out)
}

// CallData builds calldata for a zero-argument function (selector only).
func CallData(sig string) string {
	s := computeSelector(sig)
	return SelectorHex(s)
}

// selectorOf is exported-internal helper for other analyzer files.
func selectorOf(sig string) Selector { return computeSelector(sig) }
