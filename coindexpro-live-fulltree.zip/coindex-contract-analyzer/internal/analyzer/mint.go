package analyzer

import (
	"context"
	"math/big"

	"github.com/coindexpro/coindex-contract-analyzer/internal/rpc"
)

// MintResult reports mint capability + supply readability.
type MintResult struct {
	Findings    []Finding
	TotalSupply string // decimal string when totalSupply() is readable, else ""
	Available   bool
	Reason      string
}

// AnalyzeMint reads totalSupply() (definitive when it returns) and checks the
// bytecode for mint selectors. Mint capability is reported as PROBABLE because
// the selector's presence proves the function exists but not who may call it or
// whether it is capped — that requires source. We never assert "mintable" as a
// certainty.
func AnalyzeMint(ctx context.Context, c *rpc.Client, addr string, code Bytecode) MintResult {
	out := MintResult{Available: true}

	// totalSupply() — definitive if it returns a word
	if data, err := c.Call(ctx, addr, CallData("totalSupply()")); err == nil && len(data) >= 32 {
		out.TotalSupply = new(big.Int).SetBytes(data[:32]).String()
	}

	if sigs := code.MatchedGroups()["mint"]; len(sigs) > 0 {
		out.Findings = append(out.Findings, Finding{
			Factor: "mintable", Present: true, Confidence: ConfProbable,
			Reason: "mint selector(s) present in bytecode; supply may be inflatable depending on access control (needs source to confirm caller/cap)",
			Evidence: map[string]any{"signatures": sigs},
		})
	}
	return out
}
