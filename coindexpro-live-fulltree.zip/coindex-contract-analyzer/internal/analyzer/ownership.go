package analyzer

import (
	"context"
	"strings"

	"github.com/coindexpro/coindex-contract-analyzer/internal/rpc"
)

// Finding is one detected capability with explainable provenance. confidence is
// honest about how the signal was obtained:
//   definitive — read from chain state (eth_call returned, or storage slot set)
//   probable   — selector present in bytecode dispatcher (function implemented,
//                effect needs source to confirm)
type Finding struct {
	Factor     string         `json:"factor"`
	Present    bool           `json:"present"`
	Confidence string         `json:"confidence"`
	Reason     string         `json:"reason"`
	Evidence   map[string]any `json:"evidence,omitempty"`
}

const (
	ConfDefinitive = "definitive"
	ConfProbable   = "probable"
)

// OwnershipResult summarizes owner state.
type OwnershipResult struct {
	HasOwner   bool
	Owner      string
	Renounced  bool
	Findings   []Finding
	Available  bool
	Reason     string
}

// AnalyzeOwnership probes owner()/getOwner()/pendingOwner() via eth_call. A
// returned address is definitive evidence the function exists; owner == zero
// address means ownership is renounced (a real, lower-risk state).
func AnalyzeOwnership(ctx context.Context, c *rpc.Client, addr string, code Bytecode) OwnershipResult {
	probes := []rpc.Probe{
		{Key: "owner", To: addr, Data: CallData("owner()")},
		{Key: "getOwner", To: addr, Data: CallData("getOwner()")},
		{Key: "pendingOwner", To: addr, Data: CallData("pendingOwner()")},
	}
	res, err := c.BatchCall(ctx, probes)
	if err != nil {
		return OwnershipResult{Available: false, Reason: "rpc unavailable"}
	}

	out := OwnershipResult{Available: true}
	ownerRes, ok := firstOk(res, "owner", "getOwner")
	if ok {
		owner := addressFromWord(ownerRes.Data)
		out.HasOwner = true
		out.Owner = owner
		if isZeroAddress(owner) {
			out.Renounced = true
			out.Findings = append(out.Findings, Finding{
				Factor: "ownership_renounced", Present: true, Confidence: ConfDefinitive,
				Reason: "owner() returned the zero address; admin control appears renounced",
				Evidence: map[string]any{"owner": owner},
			})
		} else {
			out.Findings = append(out.Findings, Finding{
				Factor: "owner_privileges", Present: true, Confidence: ConfDefinitive,
				Reason: "contract has an active owner that may hold privileged functions",
				Evidence: map[string]any{"owner": owner},
			})
		}
	} else {
		// no owner() getter callable; check bytecode for ownership selectors so we
		// can still report transferOwnership/renounce presence honestly.
		if sigs := code.MatchedGroups()["ownership"]; len(sigs) > 0 {
			out.Findings = append(out.Findings, Finding{
				Factor: "owner_privileges", Present: true, Confidence: ConfProbable,
				Reason: "ownership-related selectors present in bytecode though owner() did not return",
				Evidence: map[string]any{"signatures": sigs},
			})
		}
	}

	if p, has := res["pendingOwner"]; has && p.Ok {
		out.Findings = append(out.Findings, Finding{
			Factor: "two_step_ownership", Present: true, Confidence: ConfDefinitive,
			Reason: "pendingOwner() present (two-step ownership transfer)",
		})
	}
	return out
}

func firstOk(res map[string]rpc.ProbeResult, keys ...string) (rpc.ProbeResult, bool) {
	for _, k := range keys {
		if r, ok := res[k]; ok && r.Ok {
			return r, true
		}
	}
	return rpc.ProbeResult{}, false
}

// addressFromWord extracts the low 20 bytes of a 32-byte ABI word as a 0x address.
func addressFromWord(word []byte) string {
	if len(word) < 32 {
		return ""
	}
	return "0x" + toHex(word[12:32])
}

func isZeroAddress(a string) bool {
	a = strings.ToLower(strings.TrimPrefix(a, "0x"))
	if a == "" {
		return false
	}
	for _, c := range a {
		if c != '0' {
			return false
		}
	}
	return true
}

func toHex(b []byte) string {
	const h = "0123456789abcdef"
	out := make([]byte, len(b)*2)
	for i, bb := range b {
		out[i*2] = h[bb>>4]
		out[i*2+1] = h[bb&0x0f]
	}
	return string(out)
}
