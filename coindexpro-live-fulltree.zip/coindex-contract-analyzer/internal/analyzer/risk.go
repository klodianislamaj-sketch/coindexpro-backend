package analyzer

import (
	"context"
	"sort"

	"github.com/coindexpro/coindex-contract-analyzer/internal/rpc"
)

// RiskFactor is one scored contributor — fully explainable.
type RiskFactor struct {
	Factor     string         `json:"factor"`
	Severity   string         `json:"severity"`   // none|low|medium|high
	Weight     float64        `json:"weight"`     // its max contribution to the score
	Points     float64        `json:"points"`     // actual contribution given severity
	Confidence string         `json:"confidence"` // definitive|probable
	Reason     string         `json:"reason"`
	Evidence   map[string]any `json:"evidence,omitempty"`
}

// Analysis is the full, explainable result for a contract.
type Analysis struct {
	Chain       string       `json:"chain"`
	Address     string       `json:"address"`
	HasCode     bool         `json:"has_code"`
	Score       int          `json:"score"` // 0..100, higher = more owner/upgrade/restriction power
	Factors     []RiskFactor `json:"factors"`
	Explainable bool         `json:"explainable"`
	Owner       string       `json:"owner,omitempty"`
	Renounced   bool         `json:"renounced"`
	Proxy       *ProxyResult `json:"proxy,omitempty"`
	TotalSupply string       `json:"total_supply,omitempty"`
	Available   bool         `json:"available"`
	Reason      string       `json:"reason,omitempty"`
	Disclaimer  string       `json:"disclaimer"`
}

// factorWeights are the transparent max contributions per capability (sum=100).
// These are published in the output so the score is fully reproducible.
var factorWeights = map[string]float64{
	"owner_privileges":  20,
	"mintable":          20,
	"blacklist_capable": 15,
	"tax_mutable":       12,
	"proxy_upgradeable": 18,
	"pausable":          8,
	"uses_tx_origin":    4,
	"selfdestruct":      3,
}

// severityForConfidence maps a finding's confidence to severity + the fraction
// of its weight applied. A "probable" (bytecode-only) signal contributes less
// than a "definitive" (state-read) one — we never score a heuristic as certainty.
func severityAndFraction(factor, confidence string) (string, float64) {
	switch confidence {
	case ConfDefinitive:
		switch factor {
		case "proxy_upgradeable", "owner_privileges", "mintable":
			return "high", 1.0
		case "selfdestruct":
			return "high", 1.0
		default:
			return "medium", 0.8
		}
	case ConfProbable:
		switch factor {
		case "mintable", "proxy_upgradeable", "blacklist_capable":
			return "medium", 0.6
		default:
			return "low", 0.45
		}
	}
	return "low", 0.3
}

// Analyze orchestrates every sub-analyzer over REAL chain data and produces the
// explainable risk. If the address has no bytecode, it returns available:false.
func Analyze(ctx context.Context, c *rpc.Client, chain, addr string) Analysis {
	a := Analysis{
		Chain: chain, Address: addr, Explainable: true,
		Disclaimer: "Detected capabilities describe what the contract CAN do, not intent. Many legitimate tokens have owners, pausability, or upgradeability. This is not a safe/unsafe verdict.",
	}

	code, err := c.GetCode(ctx, addr)
	if err != nil {
		a.Available = false
		a.Reason = "rpc unavailable"
		return a
	}
	if len(code) == 0 {
		a.Available = false
		a.Reason = "no contract code at address (EOA or self-destructed)"
		return a
	}
	a.Available = true
	a.HasCode = true
	bc := Bytecode(code)

	var findings []Finding

	own := AnalyzeOwnership(ctx, c, addr, bc)
	findings = append(findings, own.Findings...)
	a.Owner, a.Renounced = own.Owner, own.Renounced

	mint := AnalyzeMint(ctx, c, addr, bc)
	findings = append(findings, mint.Findings...)
	a.TotalSupply = mint.TotalSupply

	findings = append(findings, AnalyzeBlacklist(ctx, bc).Findings...)
	findings = append(findings, AnalyzeTax(ctx, bc).Findings...)

	proxy := AnalyzeProxy(ctx, c, addr, bc)
	if proxy.Available {
		a.Proxy = &proxy
		findings = append(findings, proxy.Findings...)
	}

	findings = append(findings, AnalyzeHiddenAdmin(ctx, bc).Findings...)

	a.Factors, a.Score = scoreFindings(findings)
	return a
}

// scoreFindings converts findings into weighted, explainable RiskFactors and a
// 0..100 score. Renouncing ownership is reflected: if ownership_renounced is
// present, owner_privileges is not double-counted.
func scoreFindings(findings []Finding) ([]RiskFactor, int) {
	seen := map[string]bool{}
	renounced := false
	for _, f := range findings {
		if f.Factor == "ownership_renounced" && f.Present {
			renounced = true
		}
	}

	var factors []RiskFactor
	var total float64
	for _, f := range findings {
		if !f.Present {
			continue
		}
		weight, scored := factorWeights[f.Factor]
		if !scored {
			// informational finding (e.g. two_step_ownership, uses_delegatecall):
			// surface it but with zero score weight, clearly.
			factors = append(factors, RiskFactor{
				Factor: f.Factor, Severity: "info", Weight: 0, Points: 0,
				Confidence: f.Confidence, Reason: f.Reason, Evidence: f.Evidence,
			})
			continue
		}
		if f.Factor == "owner_privileges" && renounced {
			continue // ownership renounced → don't score active owner privileges
		}
		if seen[f.Factor] {
			continue
		}
		seen[f.Factor] = true

		sev, frac := severityAndFraction(f.Factor, f.Confidence)
		pts := weight * frac
		total += pts
		factors = append(factors, RiskFactor{
			Factor: f.Factor, Severity: sev, Weight: weight, Points: round1(pts),
			Confidence: f.Confidence, Reason: f.Reason, Evidence: f.Evidence,
		})
	}

	if renounced {
		factors = append(factors, RiskFactor{
			Factor: "ownership_renounced", Severity: "info", Weight: 0, Points: 0,
			Confidence: ConfDefinitive, Reason: "owner is the zero address; reduces owner-privilege risk",
		})
	}

	// sort by points desc so the biggest contributors lead.
	sort.SliceStable(factors, func(i, j int) bool { return factors[i].Points > factors[j].Points })

	score := int(total + 0.5)
	if score > 100 {
		score = 100
	}
	return factors, score
}

func round1(x float64) float64 { return float64(int(x*10+0.5)) / 10 }
