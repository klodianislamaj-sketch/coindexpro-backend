package analyzer

import "context"

// TaxResult reports tax/fee mutability + limit setters.
type TaxResult struct {
	Findings  []Finding
	Available bool
}

// AnalyzeTax checks for fee/tax setter selectors and max-tx/max-wallet limit
// setters. Exact tax RATES are NOT asserted here: reading a rate requires a
// known getter + ABI, and inventing a percentage would be fabrication. We report
// only that mutable-tax / limit machinery is present (PROBABLE), with the matched
// signatures as evidence.
func AnalyzeTax(ctx context.Context, code Bytecode) TaxResult {
	out := TaxResult{Available: true}
	groups := code.MatchedGroups()
	if sigs := groups["tax"]; len(sigs) > 0 {
		out.Findings = append(out.Findings, Finding{
			Factor: "tax_mutable", Present: true, Confidence: ConfProbable,
			Reason: "fee/tax setter selector(s) present; tax can likely be changed by a privileged role (exact rate not asserted — needs source/getter)",
			Evidence: map[string]any{"signatures": sigs},
		})
	}
	if sigs := groups["limits"]; len(sigs) > 0 {
		out.Findings = append(out.Findings, Finding{
			Factor: "trade_limits", Present: true, Confidence: ConfProbable,
			Reason: "max-tx / max-wallet setter selector(s) present; transfer limits can likely be adjusted",
			Evidence: map[string]any{"signatures": sigs},
		})
	}
	return out
}
