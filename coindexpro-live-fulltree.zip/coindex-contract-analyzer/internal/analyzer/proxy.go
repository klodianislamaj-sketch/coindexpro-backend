package analyzer

import (
	"context"

	"github.com/coindexpro/coindex-contract-analyzer/internal/rpc"
)

// EIP-1967 standardized storage slots (keccak256(label) - 1). Reading a non-zero
// value at these slots is DEFINITIVE evidence of a proxy — no heuristic involved.
const (
	slotImplementation = "0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc"
	slotAdmin          = "0xb53127684a568b3173ae13b9f8a6016e243e63b6e8ee1178d6a717850b5d6103"
	slotBeacon         = "0xa3f0ad74e5423aebfd80d3ef4346578335a9a72aeaee59ff6cb3582b35133d50"
)

// ProxyResult reports proxy/upgradeability state.
type ProxyResult struct {
	IsProxy        bool
	Kind           string // "eip1967" | "beacon" | "uups" | ""
	Implementation string
	Admin          string
	Findings       []Finding
	Available      bool
	Reason         string
}

// AnalyzeProxy reads the EIP-1967 slots directly. This is the most reliable
// signal in the whole analyzer: storage is read from chain state, so an
// upgradeable proxy is detected with definitive confidence.
func AnalyzeProxy(ctx context.Context, c *rpc.Client, addr string, code Bytecode) ProxyResult {
	out := ProxyResult{Available: true}

	impl, err := c.StorageAt(ctx, addr, slotImplementation)
	if err != nil {
		return ProxyResult{Available: false, Reason: "rpc unavailable"}
	}
	if implAddr := addressFromWord(pad32(impl)); !isZeroAddress(implAddr) && implAddr != "" {
		out.IsProxy = true
		out.Kind = "eip1967"
		out.Implementation = implAddr
	}

	if beacon, err := c.StorageAt(ctx, addr, slotBeacon); err == nil {
		if b := addressFromWord(pad32(beacon)); !isZeroAddress(b) && b != "" {
			out.IsProxy = true
			out.Kind = "beacon"
		}
	}
	if admin, err := c.StorageAt(ctx, addr, slotAdmin); err == nil {
		if a := addressFromWord(pad32(admin)); !isZeroAddress(a) && a != "" {
			out.Admin = a
		}
	}

	// UUPS proxies expose upgradeTo(address)/upgradeToAndCall on the impl; detect
	// the selector in bytecode as a secondary (probable) signal.
	uupsPresent := code.ExtractSelectors()[selectorOf("upgradeTo(address)")] ||
		code.ExtractSelectors()[selectorOf("upgradeToAndCall(address,bytes)")]

	if out.IsProxy {
		conf := ConfDefinitive
		reason := "EIP-1967 proxy: implementation can be upgraded by the proxy admin (logic is mutable)"
		if out.Kind == "beacon" {
			reason = "Beacon proxy: implementation is controlled by a beacon contract (logic is mutable)"
		}
		out.Findings = append(out.Findings, Finding{
			Factor: "proxy_upgradeable", Present: true, Confidence: conf, Reason: reason,
			Evidence: map[string]any{"kind": out.Kind, "implementation": out.Implementation, "admin": out.Admin},
		})
	} else if uupsPresent {
		out.IsProxy = true
		out.Kind = "uups"
		out.Findings = append(out.Findings, Finding{
			Factor: "proxy_upgradeable", Present: true, Confidence: ConfProbable,
			Reason: "UUPS upgrade selector present in bytecode (upgradeable), though EIP-1967 impl slot was empty",
		})
	}

	// DELEGATECALL presence corroborates proxy/forwarder behaviour (informational).
	if code.HasOpcode(opDELEGATECALL) && !out.IsProxy {
		out.Findings = append(out.Findings, Finding{
			Factor: "uses_delegatecall", Present: true, Confidence: ConfProbable,
			Reason: "contract uses DELEGATECALL; behaviour may depend on external logic",
		})
	}
	return out
}

// pad32 left-pads storage bytes to a 32-byte word for uniform address extraction.
func pad32(b []byte) []byte {
	if len(b) >= 32 {
		return b
	}
	out := make([]byte, 32)
	copy(out[32-len(b):], b)
	return out
}
