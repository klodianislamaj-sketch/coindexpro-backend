package analyzer

import "context"

// BlacklistResult reports address-restriction capability.
type BlacklistResult struct {
	Findings  []Finding
	Available bool
}

// AnalyzeBlacklist checks the bytecode for blacklist/bot-restriction selectors.
// Reported as PROBABLE: presence of the selector shows the mechanism exists, but
// whether and how it is used needs source. We do not assert intent.
func AnalyzeBlacklist(ctx context.Context, code Bytecode) BlacklistResult {
	out := BlacklistResult{Available: true}
	if sigs := code.MatchedGroups()["blacklist"]; len(sigs) > 0 {
		out.Findings = append(out.Findings, Finding{
			Factor: "blacklist_capable", Present: true, Confidence: ConfProbable,
			Reason: "blacklist/bot-restriction selector(s) present; contract can likely restrict specific addresses",
			Evidence: map[string]any{"signatures": sigs},
		})
	}
	return out
}
