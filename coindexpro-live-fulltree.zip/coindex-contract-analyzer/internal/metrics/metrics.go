// Package metrics holds the contract-analyzer's Prometheus instruments.
package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	Analyses = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_ca_analyses_total", Help: "Analyses by result.",
	}, []string{"result"}) // ok | no_code | rpc_unavailable | cache_hit | error

	AnalyzeLatency = promauto.NewHistogram(prometheus.HistogramOpts{
		Name: "coindex_ca_analyze_seconds", Help: "End-to-end analyze latency.",
		Buckets: prometheus.DefBuckets,
	})

	RPCCalls = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_ca_rpc_calls_total", Help: "RPC calls by method + outcome.",
	}, []string{"method", "outcome"})

	APILatency = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name: "coindex_ca_api_seconds", Help: "API latency by route + status.",
		Buckets: prometheus.DefBuckets,
	}, []string{"route", "status"})

	DBErrors = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_ca_db_errors_total", Help: "DB errors.",
	})
)
