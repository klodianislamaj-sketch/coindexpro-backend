// Package rpc — multicall batches several eth_call probes into one HTTP request
// using native JSON-RPC batching (an array of requests). This cuts round-trips
// when probing many functions (owner, pendingOwner, totalSupply, ...) without
// depending on any on-chain aggregator contract. Each sub-call's outcome is
// reported independently: a reverted probe is Ok=false (function absent/not
// callable), never a fabricated value.
package rpc

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"sync/atomic"
)

// Probe is one eth_call to attempt.
type Probe struct {
	Key  string // caller's label, e.g. "owner"
	To   string
	Data string // calldata hex (selector [+ args])
}

// ProbeResult carries the outcome of one probe.
type ProbeResult struct {
	Key    string
	Ok     bool   // node returned a non-error result
	Data   []byte // decoded return bytes (when Ok)
	Reason string // error/revert message (when !Ok)
}

// BatchCall executes probes in a single JSON-RPC batch with endpoint failover.
func (c *Client) BatchCall(ctx context.Context, probes []Probe) (map[string]ProbeResult, error) {
	if len(probes) == 0 {
		return map[string]ProbeResult{}, nil
	}
	reqs := make([]rpcRequest, len(probes))
	idToKey := make(map[int]string, len(probes))
	for i, p := range probes {
		reqs[i] = rpcRequest{
			JSONRPC: "2.0", ID: i + 1, Method: "eth_call",
			Params: []any{map[string]string{"to": p.To, "data": p.Data}, "latest"},
		}
		idToKey[i+1] = p.Key
	}
	body, _ := json.Marshal(reqs)

	var lastErr error
	n := len(c.endpoints)
	start := int(atomic.AddUint64(&c.idx, 1))
	for attempt := 0; attempt < n; attempt++ {
		ep := c.endpoints[(start+attempt)%n]
		req, err := http.NewRequestWithContext(ctx, http.MethodPost, ep, bytes.NewReader(body))
		if err != nil {
			lastErr = err
			continue
		}
		req.Header.Set("Content-Type", "application/json")
		resp, err := c.http.Do(req)
		if err != nil {
			lastErr = err
			continue
		}
		raw, _ := io.ReadAll(io.LimitReader(resp.Body, 16<<20))
		resp.Body.Close()
		if resp.StatusCode != http.StatusOK {
			lastErr = fmt.Errorf("http %d from %s", resp.StatusCode, ep)
			continue
		}
		var batch []struct {
			ID     int             `json:"id"`
			Result json.RawMessage `json:"result"`
			Error  *rpcError       `json:"error"`
		}
		if err := json.Unmarshal(raw, &batch); err != nil {
			lastErr = err
			continue
		}
		out := make(map[string]ProbeResult, len(probes))
		for _, item := range batch {
			key := idToKey[item.ID]
			if item.Error != nil {
				out[key] = ProbeResult{Key: key, Ok: false, Reason: item.Error.Message}
				continue
			}
			var hexStr string
			if json.Unmarshal(item.Result, &hexStr) != nil {
				out[key] = ProbeResult{Key: key, Ok: false, Reason: "unparseable result"}
				continue
			}
			data, derr := decodeHex(hexStr)
			if derr != nil {
				out[key] = ProbeResult{Key: key, Ok: false, Reason: "invalid hex"}
				continue
			}
			// A function returning empty bytes is treated as not-present: a real
			// getter returns 32+ bytes. This avoids inferring a value from nothing.
			out[key] = ProbeResult{Key: key, Ok: len(data) > 0, Data: data}
			if len(data) == 0 {
				r := out[key]
				r.Reason = "empty return"
				out[key] = r
			}
		}
		return out, nil
	}
	return nil, lastErr
}
