// Package rpc is a minimal JSON-RPC client for read-only EVM calls. It performs
// REAL on-chain reads (eth_getCode, eth_call, eth_getStorageAt) over one or more
// endpoints with failover. Any failure returns an error so callers can report
// unavailable — the client never invents a result.
package rpc

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"sync/atomic"
	"time"
)

type Client struct {
	endpoints []string
	http      *http.Client
	idx       uint64 // round-robin cursor for failover
}

func New(endpoints []string, timeout time.Duration) *Client {
	if timeout == 0 {
		timeout = 5 * time.Second
	}
	return &Client{
		endpoints: endpoints,
		http:      &http.Client{Timeout: timeout},
	}
}

type rpcRequest struct {
	JSONRPC string `json:"jsonrpc"`
	ID      int    `json:"id"`
	Method  string `json:"method"`
	Params  []any  `json:"params"`
}

type rpcResponse struct {
	Result json.RawMessage `json:"result"`
	Error  *rpcError       `json:"error"`
}
type rpcError struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

func (e *rpcError) Error() string { return fmt.Sprintf("rpc error %d: %s", e.Code, e.Message) }

// call sends a single JSON-RPC request, trying endpoints in turn on transport
// failure (failover). A JSON-RPC error from a responding node is returned as-is
// (it is a real answer, e.g. "execution reverted").
func (c *Client) call(ctx context.Context, method string, params []any) (json.RawMessage, error) {
	body, _ := json.Marshal(rpcRequest{JSONRPC: "2.0", ID: 1, Method: method, Params: params})
	var lastErr error
	n := len(c.endpoints)
	start := int(atomic.AddUint64(&c.idx, 1))
	for i := 0; i < n; i++ {
		ep := c.endpoints[(start+i)%n]
		req, err := http.NewRequestWithContext(ctx, http.MethodPost, ep, bytes.NewReader(body))
		if err != nil {
			lastErr = err
			continue
		}
		req.Header.Set("Content-Type", "application/json")
		resp, err := c.http.Do(req)
		if err != nil {
			lastErr = err
			continue // transport failure → try next endpoint
		}
		raw, _ := io.ReadAll(io.LimitReader(resp.Body, 8<<20))
		resp.Body.Close()
		if resp.StatusCode != http.StatusOK {
			lastErr = fmt.Errorf("http %d from %s", resp.StatusCode, ep)
			continue
		}
		var r rpcResponse
		if err := json.Unmarshal(raw, &r); err != nil {
			lastErr = err
			continue
		}
		if r.Error != nil {
			return nil, r.Error // genuine node answer; do not failover/retry
		}
		return r.Result, nil
	}
	if lastErr == nil {
		lastErr = fmt.Errorf("no endpoints configured")
	}
	return nil, lastErr
}

// GetCode returns the runtime bytecode at an address (0x-stripped bytes). Empty
// result means no contract (EOA or self-destructed) → caller returns unavailable.
func (c *Client) GetCode(ctx context.Context, addr string) ([]byte, error) {
	res, err := c.call(ctx, "eth_getCode", []any{addr, "latest"})
	if err != nil {
		return nil, err
	}
	var hexStr string
	if err := json.Unmarshal(res, &hexStr); err != nil {
		return nil, err
	}
	return decodeHex(hexStr)
}

// Call performs eth_call with the given calldata; returns the raw return bytes.
// A revert surfaces as an rpcError from call(), which the caller treats as
// "function not present / not callable" → unavailable for that aspect.
func (c *Client) Call(ctx context.Context, to, data string) ([]byte, error) {
	res, err := c.call(ctx, "eth_call", []any{map[string]string{"to": to, "data": data}, "latest"})
	if err != nil {
		return nil, err
	}
	var hexStr string
	if err := json.Unmarshal(res, &hexStr); err != nil {
		return nil, err
	}
	return decodeHex(hexStr)
}

// StorageAt reads a 32-byte storage slot (used for EIP-1967 proxy slots).
func (c *Client) StorageAt(ctx context.Context, addr, slot string) ([]byte, error) {
	res, err := c.call(ctx, "eth_getStorageAt", []any{addr, slot, "latest"})
	if err != nil {
		return nil, err
	}
	var hexStr string
	if err := json.Unmarshal(res, &hexStr); err != nil {
		return nil, err
	}
	return decodeHex(hexStr)
}

func decodeHex(s string) ([]byte, error) {
	if len(s) >= 2 && (s[:2] == "0x" || s[:2] == "0X") {
		s = s[2:]
	}
	if len(s) == 0 {
		return []byte{}, nil
	}
	if len(s)%2 != 0 {
		s = "0" + s
	}
	out := make([]byte, len(s)/2)
	for i := 0; i < len(out); i++ {
		hi, ok1 := hexVal(s[i*2])
		lo, ok2 := hexVal(s[i*2+1])
		if !ok1 || !ok2 {
			return nil, fmt.Errorf("invalid hex")
		}
		out[i] = hi<<4 | lo
	}
	return out, nil
}

func hexVal(c byte) (byte, bool) {
	switch {
	case c >= '0' && c <= '9':
		return c - '0', true
	case c >= 'a' && c <= 'f':
		return c - 'a' + 10, true
	case c >= 'A' && c <= 'F':
		return c - 'A' + 10, true
	}
	return 0, false
}
