// Package api serves the contract analyzer endpoints. /analyze runs (or reuses)
// a full analysis from real RPC; /risk returns the explainable factors; /history
// returns score snapshots. When a contract has no code or RPC is unavailable, the
// response is {available:false} with a reason — never a fabricated analysis.
package api

import (
	"encoding/json"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"

	"github.com/coindexpro/coindex-contract-analyzer/internal/analyzer"
	"github.com/coindexpro/coindex-contract-analyzer/internal/cache"
	"github.com/coindexpro/coindex-contract-analyzer/internal/db"
	"github.com/coindexpro/coindex-contract-analyzer/internal/metrics"
	"github.com/coindexpro/coindex-contract-analyzer/internal/rpc"
)

type API struct {
	clients   map[string]*rpc.Client // chain -> rpc client
	store     *db.Store
	cache     *cache.Cache
	freshness time.Duration
}

func New(clients map[string]*rpc.Client, store *db.Store, c *cache.Cache, freshness time.Duration) *API {
	if freshness == 0 {
		freshness = 30 * time.Minute
	}
	return &API{clients: clients, store: store, cache: c, freshness: freshness}
}

func (a *API) Register(app *fiber.App) {
	app.Use(a.observe)
	app.Get("/contract/:chain/:address/analyze", a.analyze)
	app.Get("/contract/:chain/:address/risk", a.risk)
	app.Get("/contract/:chain/:address/history", a.history)
}

func (a *API) observe(c *fiber.Ctx) error {
	start := time.Now()
	err := c.Next()
	metrics.APILatency.WithLabelValues(c.Route().Path, statusClass(c.Response().StatusCode())).
		Observe(time.Since(start).Seconds())
	return err
}

var evmAddr = regexp.MustCompile(`^0x[0-9a-fA-F]{40}$`)

func (a *API) params(c *fiber.Ctx) (chain, addr string, client *rpc.Client, ok bool) {
	chain = strings.ToLower(c.Params("chain"))
	addr = strings.ToLower(c.Params("address"))
	if !evmAddr.MatchString(addr) {
		return "", "", nil, false
	}
	client, ok = a.clients[chain]
	return chain, addr, client, ok
}

// GET /contract/:chain/:address/analyze
func (a *API) analyze(c *fiber.Ctx) error {
	chain, addr, client, ok := a.params(c)
	if !ok {
		// distinguish bad address from unsupported chain
		if !evmAddr.MatchString(strings.ToLower(c.Params("address"))) {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid address"})
		}
		return c.JSON(fiber.Map{"available": false, "reason": "chain not configured"})
	}
	ctx := c.UserContext()

	if body, hit := a.cache.Get(ctx, chain, addr); hit {
		metrics.Analyses.WithLabelValues("cache_hit").Inc()
		c.Set("Content-Type", "application/json")
		return c.Send(body)
	}

	t := time.Now()
	an := analyzer.Analyze(ctx, client, chain, addr)
	metrics.AnalyzeLatency.Observe(time.Since(t).Seconds())

	if !an.Available {
		switch an.Reason {
		case "rpc unavailable":
			metrics.Analyses.WithLabelValues("rpc_unavailable").Inc()
		default:
			metrics.Analyses.WithLabelValues("no_code").Inc()
		}
		body, _ := json.Marshal(an)
		// do not cache transient rpc failures; cache the stable "no code" result
		if an.Reason != "rpc unavailable" {
			a.cache.Set(ctx, chain, addr, body)
		}
		c.Set("Content-Type", "application/json")
		return c.Send(body)
	}

	// persist + cache the real analysis
	row, factors := db.FromAnalysis(an)
	if err := a.store.Save(ctx, row, factors); err != nil {
		metrics.DBErrors.Inc() // still return the computed analysis
	}
	body, _ := json.Marshal(an)
	a.cache.Set(ctx, chain, addr, body)
	metrics.Analyses.WithLabelValues("ok").Inc()
	c.Set("Content-Type", "application/json")
	return c.Send(body)
}

// GET /contract/:chain/:address/risk — explainable factors (from store; computes
// if absent so a first call still returns real data).
func (a *API) risk(c *fiber.Ctx) error {
	chain, addr, client, ok := a.params(c)
	if !ok {
		return c.JSON(fiber.Map{"available": false, "reason": "chain not configured"})
	}
	ctx := c.UserContext()

	row, at, found, err := a.store.LoadAnalysis(ctx, chain, addr)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !found || time.Since(at) > a.freshness {
		an := analyzer.Analyze(ctx, client, chain, addr)
		if !an.Available {
			return c.JSON(fiber.Map{"chain": chain, "address": addr, "available": false, "reason": an.Reason})
		}
		r, f := db.FromAnalysis(an)
		_ = a.store.Save(ctx, r, f)
		return c.JSON(fiber.Map{
			"chain": chain, "address": addr, "available": true,
			"score": an.Score, "factors": an.Factors, "explainable": true,
			"disclaimer": an.Disclaimer,
		})
	}

	factors, err := a.store.LoadFactors(ctx, chain, addr)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	return c.JSON(fiber.Map{
		"chain": chain, "address": addr, "available": true,
		"score": row.Score, "factors": factors, "explainable": true,
	})
}

// GET /contract/:chain/:address/history
func (a *API) history(c *fiber.Ctx) error {
	chain, addr, _, _ := a.params(c)
	if !evmAddr.MatchString(addr) {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid address"})
	}
	limit := 50
	if v, err := strconv.Atoi(c.Query("limit")); err == nil && v > 0 && v <= 200 {
		limit = v
	}
	h, err := a.store.History(c.UserContext(), chain, addr, limit)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(h) == 0 {
		return c.JSON(fiber.Map{"chain": chain, "address": addr, "available": false, "reason": "no analysis history"})
	}
	return c.JSON(fiber.Map{"chain": chain, "address": addr, "available": true, "history": h})
}

func statusClass(code int) string {
	switch {
	case code >= 500:
		return "5xx"
	case code >= 400:
		return "4xx"
	default:
		return "2xx"
	}
}
