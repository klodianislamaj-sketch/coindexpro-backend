// Command social-engine is the Phase 12 entrypoint. It fetches REAL social
// mentions for tracked tokens from configured providers, computes activity +
// sentiment aggregates, and serves them. With no provider configured it runs
// idle and the API reports social/sentiment unavailable — it never mocks data.
package main

import (
	"context"
	"errors"
	"flag"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/compress"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"github.com/redis/go-redis/v9"
	"go.uber.org/zap"

	"github.com/coindexpro/coindex-social-engine/config"
	"github.com/coindexpro/coindex-social-engine/internal/api"
	"github.com/coindexpro/coindex-social-engine/internal/cache"
	"github.com/coindexpro/coindex-social-engine/internal/consumer"
	"github.com/coindexpro/coindex-social-engine/internal/db"
	"github.com/coindexpro/coindex-social-engine/internal/providers"
	"github.com/coindexpro/coindex-social-engine/internal/social"
)

func main() {
	cfgPath := flag.String("config", "config/config.yaml", "config path")
	flag.Parse()

	cfg, err := config.Load(*cfgPath)
	if err != nil {
		panic(err)
	}
	log, _ := zap.NewProduction()
	defer func() { _ = log.Sync() }()
	log.Info("starting social-engine")

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	store, err := db.Open(ctx, cfg.Postgres.DSN)
	if err != nil {
		log.Fatal("postgres open failed", zap.Error(err))
	}
	defer store.Close()

	c := cache.New(cfg.Redis.Addr, cfg.Build.CacheTTL)
	if err := c.Ping(ctx); err != nil {
		log.Fatal("redis ping failed", zap.Error(err))
	}
	defer func() { _ = c.Close() }()
	rdb := redis.NewClient(&redis.Options{Addr: cfg.Redis.Addr})
	defer func() { _ = rdb.Close() }()

	// registry contains ONLY providers with credentials
	to := cfg.Providers.HTTPTimeout
	reg := providers.NewRegistry(
		providers.NewTwitter(cfg.Providers.TwitterBearer, to),
		providers.NewReddit(cfg.Providers.RedditToken, to),
		providers.NewTelegram(cfg.Providers.TelegramBot, to),
		providers.NewDiscord(cfg.Providers.DiscordBot, to),
		providers.NewFarcaster(cfg.Providers.FarcasterKey, cfg.Providers.FarcasterBase, to),
	)
	log.Info("social providers configured", zap.Strings("platforms", reg.Configured()))

	engine := social.NewEngine(store, store, reg, social.Config{
		Window:          cfg.Build.Window,
		MaxTokens:       cfg.Build.MaxTokens,
		PerTokenLimit:   cfg.Build.PerTokenLimit,
		BaselineWindows: cfg.Build.BaselineWindows,
	}, log)

	if cfg.Build.Enabled {
		sched := consumer.NewScheduler(engine, cfg.Build.Interval, cfg.Build.Window, log)
		go func() {
			if err := sched.Run(ctx); err != nil && !errors.Is(err, context.Canceled) {
				log.Error("scheduler stopped", zap.Error(err))
			}
		}()
	}

	app := fiber.New(fiber.Config{AppName: "coindex-social-engine"})
	app.Use(compress.New())
	api.New(store, reg).Register(app)
	go func() {
		log.Info("api listening", zap.String("addr", cfg.Server.APIAddr))
		if err := app.Listen(cfg.Server.APIAddr); err != nil {
			log.Error("api stopped", zap.Error(err))
		}
	}()

	go serveOps(cfg.Server.MetricsAddr, store, rdb, log)

	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
	<-sig
	log.Info("shutting down")
	cancel()
	sc, scCancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer scCancel()
	_ = app.ShutdownWithContext(sc)
}

func serveOps(addr string, store *db.Store, rdb *redis.Client, log *zap.Logger) {
	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ok"))
	})
	mux.HandleFunc("/readyz", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), 3*time.Second)
		defer cancel()
		if err := store.Ping(ctx); err != nil {
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte("postgres down"))
			return
		}
		if err := rdb.Ping(ctx).Err(); err != nil {
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte("redis down"))
			return
		}
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ready"))
	})
	mux.Handle("/metrics", promhttp.Handler())
	srv := &http.Server{Addr: addr, Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Error("ops server failed", zap.Error(err))
	}
}
