// Package metrics holds the social-engine's Prometheus instruments.
package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	Builds = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_social_builds_total", Help: "Social build cycles.",
	})
	Skipped = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_social_skipped_total", Help: "Skipped builds by reason.",
	}, []string{"reason"})
	MentionsWritten = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_social_mentions_total", Help: "Mentions written.",
	})
	ProviderErrors = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_social_provider_errors_total", Help: "Provider fetch errors by platform.",
	}, []string{"platform"})
	APILatency = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name: "coindex_social_api_seconds", Help: "API latency by route + status.",
		Buckets: prometheus.DefBuckets,
	}, []string{"route", "status"})
	DBErrors = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_social_db_errors_total", Help: "DB errors.",
	})
)
