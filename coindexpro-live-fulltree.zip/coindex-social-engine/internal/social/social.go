// Package social aggregates real observed mentions into per-token activity
// scores. Every figure is a count or sum over mentions that a provider actually
// returned. Velocity is computed against a real prior-window baseline; with no
// baseline it is left nil rather than fabricated.
package social

import (
	"time"

	"github.com/coindexpro/coindex-social-engine/internal/db"
)

// Score aggregates a window's mentions for one token. baselineMentions is the
// mean mention count of prior windows (0/absent => velocity unavailable). It does
// not invent mentions for tokens with no posts — callers pass only observed data.
func Score(chain, token string, mentions []db.Mention, start, end time.Time, baselineMentions float64) db.SocialScore {
	s := db.SocialScore{
		Chain: chain, Token: token, WindowStart: start, WindowEnd: end,
		Platforms: map[string]int{},
	}
	authors := map[string]struct{}{}
	for _, m := range mentions {
		s.Mentions++
		s.Engagement += m.Engagement
		s.Platforms[m.Platform]++
		if m.Author != "" {
			authors[m.Platform+":"+m.Author] = struct{}{}
		}
		if m.AuthorFollowers != nil && *m.AuthorFollowers > 0 {
			s.InfluencerWeight += *m.AuthorFollowers
		}
	}
	s.DistinctAuthors = int64(len(authors))

	// velocity = current mentions / baseline mentions, only when a real baseline exists
	if baselineMentions > 0 {
		v := round4(float64(s.Mentions) / baselineMentions)
		s.Velocity = &v
	}
	return s
}

func round4(x float64) float64 { return float64(int(x*10000+0.5)) / 10000 }
