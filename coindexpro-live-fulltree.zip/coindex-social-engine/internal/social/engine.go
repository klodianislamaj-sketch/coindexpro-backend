package social

import (
	"context"
	"time"

	"go.uber.org/zap"

	"github.com/coindexpro/coindex-social-engine/internal/db"
	"github.com/coindexpro/coindex-social-engine/internal/metrics"
	"github.com/coindexpro/coindex-social-engine/internal/providers"
	"github.com/coindexpro/coindex-social-engine/internal/sentiment"
)

// Sources is the read surface (implemented by db.Store).
type Sources interface {
	TrackedTokens(ctx context.Context, limit int) ([]db.TrackedToken, error)
	BaselineMentions(ctx context.Context, chain, token string, before time.Time, n int) (float64, bool, error)
}

// Sink persists mentions + derived aggregates (implemented by db.Store).
type Sink interface {
	UpsertMentions(ctx context.Context, m []db.Mention) (int, error)
	UpsertSocialScore(ctx context.Context, s db.SocialScore) error
	UpsertSentiment(ctx context.Context, s db.Sentiment) error
}

// Engine runs the fetch→store→aggregate cycle.
type Engine struct {
	src  Sources
	sink Sink
	reg  *providers.Registry
	cfg  Config
	log  *zap.Logger
}

type Config struct {
	Window          time.Duration
	MaxTokens       int
	PerTokenLimit   int
	BaselineWindows int
}

func NewEngine(src Sources, sink Sink, reg *providers.Registry, cfg Config, log *zap.Logger) *Engine {
	return &Engine{src: src, sink: sink, reg: reg, cfg: cfg, log: log}
}

// Configured reports whether any provider is usable. When false, the engine does
// nothing (and the API reports social/sentiment unavailable) — it never fabricates.
func (e *Engine) Configured() bool { return e.reg.Any() }

// BuildWindow fetches real mentions for tracked tokens and computes aggregates.
func (e *Engine) BuildWindow(ctx context.Context, start, end time.Time) error {
	if !e.reg.Any() {
		e.log.Info("no social providers configured; nothing to fetch")
		metrics.Skipped.WithLabelValues("no_providers").Inc()
		return nil
	}
	tokens, err := e.src.TrackedTokens(ctx, e.cfg.MaxTokens)
	if err != nil {
		return err
	}
	for _, tok := range tokens {
		if tok.Symbol == "" {
			continue // no symbol to search for -> nothing real to fetch
		}
		q := providers.Query{
			Chain: tok.Chain, Token: tok.Token, Symbol: tok.Symbol, Socials: tok.Socials,
			Since: start, Until: end, Limit: e.cfg.PerTokenLimit,
		}
		mentions, perr := e.reg.FetchAll(ctx, q)
		for plat, ferr := range perr {
			metrics.ProviderErrors.WithLabelValues(plat).Inc()
			e.log.Warn("provider fetch error", zap.String("platform", plat), zap.Error(ferr))
		}
		if len(mentions) == 0 {
			continue // no real posts this window -> no row written
		}
		// scope mentions to the window by provider timestamp
		mentions = withinWindow(mentions, start, end)
		if len(mentions) == 0 {
			continue
		}
		if _, err := e.sink.UpsertMentions(ctx, mentions); err != nil {
			return err
		}
		metrics.MentionsWritten.Add(float64(len(mentions)))

		// social activity score (velocity vs real baseline)
		baseline, hasBase, err := e.src.BaselineMentions(ctx, tok.Chain, tok.Token, start, e.cfg.BaselineWindows)
		if err != nil {
			return err
		}
		base := 0.0
		if hasBase {
			base = baseline
		}
		score := Score(tok.Chain, tok.Token, mentions, start, end, base)
		score.WindowStart, score.WindowEnd = start, end
		if err := e.sink.UpsertSocialScore(ctx, score); err != nil {
			return err
		}

		// sentiment aggregate (lexicon over real text; coverage exposed)
		sent, ok := sentiment.Aggregate(tok.Chain, tok.Token, mentions, textOf)
		if ok {
			sent.WindowStart, sent.WindowEnd = start, end
			if err := e.sink.UpsertSentiment(ctx, sent); err != nil {
				return err
			}
			// persist back the per-post sentiment the aggregator attached
			if _, err := e.sink.UpsertMentions(ctx, mentions); err != nil {
				return err
			}
		}
	}
	metrics.Builds.Inc()
	return nil
}

func withinWindow(ms []db.Mention, start, end time.Time) []db.Mention {
	out := ms[:0]
	for _, m := range ms {
		if m.PostedAt.IsZero() || (!m.PostedAt.Before(start) && m.PostedAt.Before(end)) {
			out = append(out, m)
		}
	}
	return out
}

// textOf pulls the post text out of the real provider payload for scoring.
func textOf(m db.Mention) string {
	if m.Raw == nil {
		return ""
	}
	for _, k := range []string{"text", "title"} {
		if v, ok := m.Raw[k]; ok {
			if s, ok := v.(string); ok {
				return s
			}
		}
	}
	return ""
}
