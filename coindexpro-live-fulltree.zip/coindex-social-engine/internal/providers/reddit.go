package providers

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/coindexpro/coindex-social-engine/internal/db"
)

// Reddit queries Reddit's search endpoint with an OAuth app token. Configured only
// when a token is present; otherwise ErrNotConfigured.
type Reddit struct {
	token string
	http  *http.Client
	base  string
}

func NewReddit(token string, timeout time.Duration) *Reddit {
	if timeout == 0 {
		timeout = 10 * time.Second
	}
	return &Reddit{token: token, http: &http.Client{Timeout: timeout}, base: "https://oauth.reddit.com/search"}
}

func (r *Reddit) Platform() string { return db.PlatformReddit }
func (r *Reddit) Configured() bool { return strings.TrimSpace(r.token) != "" }

type redditResp struct {
	Data struct {
		Children []struct {
			Data struct {
				ID          string  `json:"id"`
				Title       string  `json:"title"`
				Author      string  `json:"author"`
				Permalink   string  `json:"permalink"`
				CreatedUTC  float64 `json:"created_utc"`
				Score       int64   `json:"score"`
				NumComments int64   `json:"num_comments"`
			} `json:"data"`
		} `json:"children"`
	} `json:"data"`
}

func (r *Reddit) Fetch(ctx context.Context, q Query) ([]db.Mention, error) {
	if !r.Configured() {
		return nil, ErrNotConfigured
	}
	term := searchTerm(q)
	if term == "" {
		return nil, nil
	}
	params := url.Values{}
	params.Set("q", term)
	params.Set("sort", "new")
	params.Set("limit", "100")
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, r.base+"?"+params.Encode(), nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", "Bearer "+r.token)
	req.Header.Set("User-Agent", "coindex-social-engine/1.0")
	resp, err := r.http.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode == http.StatusUnauthorized || resp.StatusCode == http.StatusForbidden {
		return nil, ErrNotConfigured
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("reddit status %d", resp.StatusCode)
	}
	var rr redditResp
	if err := json.NewDecoder(resp.Body).Decode(&rr); err != nil {
		return nil, err
	}
	out := make([]db.Mention, 0, len(rr.Data.Children))
	for _, c := range rr.Data.Children {
		d := c.Data
		out = append(out, db.Mention{
			Platform: db.PlatformReddit, ExternalID: d.ID,
			Chain: q.Chain, Token: q.Token, Symbol: q.Symbol, Author: d.Author,
			URL:      "https://reddit.com" + d.Permalink,
			PostedAt: time.Unix(int64(d.CreatedUTC), 0).UTC(),
			Engagement: d.Score + d.NumComments,
			Raw:      map[string]any{"title": d.Title},
		})
	}
	return out, nil
}
