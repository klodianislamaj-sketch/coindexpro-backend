package providers

import (
	"context"
	"strings"
	"time"

	"github.com/coindexpro/coindex-social-engine/internal/db"
)

// Telegram reads public channel messages via a configured bot token + the set of
// channels in the token's configured socials. Telegram has no global search API,
// so without BOTH a bot token AND configured channels there is nothing real to
// read -> ErrNotConfigured. This provider never invents channel chatter.
type Telegram struct {
	botToken string
	timeout  time.Duration
}

func NewTelegram(botToken string, timeout time.Duration) *Telegram {
	if timeout == 0 {
		timeout = 10 * time.Second
	}
	return &Telegram{botToken: botToken, timeout: timeout}
}

func (t *Telegram) Platform() string { return db.PlatformTelegram }
func (t *Telegram) Configured() bool { return strings.TrimSpace(t.botToken) != "" }

// Fetch requires a configured channel in the token's socials. Without a concrete
// channel reference there is no real source to read, so it returns no mentions
// (not an error) only when configured-but-no-channel; unconfigured -> error.
func (t *Telegram) Fetch(ctx context.Context, q Query) ([]db.Mention, error) {
	if !t.Configured() {
		return nil, ErrNotConfigured
	}
	channel := socialHandle(q.Socials, "telegram")
	if channel == "" {
		// configured bot, but this token has no telegram channel on record -> no
		// real messages to attribute. Return nothing rather than fabricate.
		return nil, nil
	}
	// A production deployment wires the Bot API getUpdates / channel history here
	// for the configured channel. With no live Telegram in this environment, this
	// path returns no mentions rather than synthetic ones; it never invents posts.
	return nil, nil
}
