// Package providers defines the social-source abstraction. The entire phase
// hinges on one rule: a provider either returns REAL posts from a configured
// upstream, or it reports ErrNotConfigured. There is no mock provider and no
// synthetic-post path. The registry only holds providers that have credentials,
// so an unconfigured platform is simply absent — and the API reports it
// unavailable rather than inventing mentions.
package providers

import (
	"context"
	"errors"
	"time"

	"github.com/coindexpro/coindex-social-engine/internal/db"
)

// ErrNotConfigured means the platform has no credentials/endpoint set up.
var ErrNotConfigured = errors.New("social provider not configured")

// Query describes what to fetch: a token's symbol/handles over a time window.
type Query struct {
	Chain   string
	Token   string
	Symbol  string
	Socials map[string]any
	Since   time.Time
	Until   time.Time
	Limit   int
}

// Provider fetches real mentions for a query from one platform.
type Provider interface {
	Platform() string
	// Configured reports whether this provider has the credentials to run. A
	// provider that is not configured MUST return false here and ErrNotConfigured
	// from Fetch — never an empty-but-successful result that looks like "no chatter".
	Configured() bool
	Fetch(ctx context.Context, q Query) ([]db.Mention, error)
}

// Registry holds only configured providers.
type Registry struct {
	byPlatform map[string]Provider
	order      []string
}

// NewRegistry includes a provider only if it reports Configured()==true. The set
// of available platforms is therefore exactly the set that can return real data.
func NewRegistry(provs ...Provider) *Registry {
	r := &Registry{byPlatform: map[string]Provider{}}
	for _, p := range provs {
		if p == nil || !p.Configured() {
			continue
		}
		r.byPlatform[p.Platform()] = p
		r.order = append(r.order, p.Platform())
	}
	return r
}

// Configured returns the platforms that are actually usable.
func (r *Registry) Configured() []string { return append([]string(nil), r.order...) }

// Any reports whether at least one provider is configured.
func (r *Registry) Any() bool { return len(r.order) > 0 }

// FetchAll runs every configured provider for the query and concatenates real
// results. Per-provider errors are returned alongside partial results so the
// caller can record which platforms failed (vs which simply had no posts).
func (r *Registry) FetchAll(ctx context.Context, q Query) ([]db.Mention, map[string]error) {
	var out []db.Mention
	errs := map[string]error{}
	for _, p := range r.order {
		prov := r.byPlatform[p]
		ms, err := prov.Fetch(ctx, q)
		if err != nil {
			errs[p] = err
			continue
		}
		out = append(out, ms...)
	}
	return out, errs
}
