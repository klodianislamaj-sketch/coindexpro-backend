package providers

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/coindexpro/coindex-social-engine/internal/db"
)

// Farcaster queries a hub/indexer (e.g. a Neynar-style API) for casts mentioning
// the token. Configured only with an API key.
type Farcaster struct {
	apiKey string
	http   *http.Client
	base   string
}

func NewFarcaster(apiKey, baseURL string, timeout time.Duration) *Farcaster {
	if timeout == 0 {
		timeout = 10 * time.Second
	}
	if baseURL == "" {
		baseURL = "https://api.neynar.com/v2/farcaster/cast/search"
	}
	return &Farcaster{apiKey: apiKey, http: &http.Client{Timeout: timeout}, base: baseURL}
}

func (f *Farcaster) Platform() string { return db.PlatformFarcaster }
func (f *Farcaster) Configured() bool { return strings.TrimSpace(f.apiKey) != "" }

type farcasterResp struct {
	Result struct {
		Casts []struct {
			Hash      string `json:"hash"`
			Text      string `json:"text"`
			Timestamp string `json:"timestamp"`
			Author    struct {
				Username      string `json:"username"`
				FollowerCount int64  `json:"follower_count"`
			} `json:"author"`
			Reactions struct {
				LikesCount   int64 `json:"likes_count"`
				RecastsCount int64 `json:"recasts_count"`
			} `json:"reactions"`
		} `json:"casts"`
	} `json:"result"`
}

func (f *Farcaster) Fetch(ctx context.Context, q Query) ([]db.Mention, error) {
	if !f.Configured() {
		return nil, ErrNotConfigured
	}
	term := searchTerm(q)
	if term == "" {
		return nil, nil
	}
	params := url.Values{}
	params.Set("q", term)
	params.Set("limit", "100")
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, f.base+"?"+params.Encode(), nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("api_key", f.apiKey)
	resp, err := f.http.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode == http.StatusUnauthorized || resp.StatusCode == http.StatusForbidden {
		return nil, ErrNotConfigured
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("farcaster status %d", resp.StatusCode)
	}
	var fr farcasterResp
	if err := json.NewDecoder(resp.Body).Decode(&fr); err != nil {
		return nil, err
	}
	out := make([]db.Mention, 0, len(fr.Result.Casts))
	for _, c := range fr.Result.Casts {
		posted, _ := time.Parse(time.RFC3339, c.Timestamp)
		followers := c.Author.FollowerCount
		out = append(out, db.Mention{
			Platform: db.PlatformFarcaster, ExternalID: c.Hash,
			Chain: q.Chain, Token: q.Token, Symbol: q.Symbol, Author: c.Author.Username,
			AuthorFollowers: &followers,
			PostedAt: posted, Engagement: c.Reactions.LikesCount + c.Reactions.RecastsCount,
			Raw: map[string]any{"text": c.Text},
		})
	}
	return out, nil
}

// socialHandle extracts a platform handle/channel from token_registry.socials.
func socialHandle(socials map[string]any, key string) string {
	if socials == nil {
		return ""
	}
	if v, ok := socials[key]; ok {
		if s, ok := v.(string); ok {
			return strings.TrimSpace(s)
		}
	}
	return ""
}
