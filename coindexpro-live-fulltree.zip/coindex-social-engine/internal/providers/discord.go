package providers

import (
	"context"
	"strings"
	"time"

	"github.com/coindexpro/coindex-social-engine/internal/db"
)

// Discord reads messages from configured guild channels via a bot token. Like
// Telegram, there is no global search; without a bot token it is not configured,
// and without a configured channel for the token there is nothing real to read.
type Discord struct {
	botToken string
	timeout  time.Duration
}

func NewDiscord(botToken string, timeout time.Duration) *Discord {
	if timeout == 0 {
		timeout = 10 * time.Second
	}
	return &Discord{botToken: botToken, timeout: timeout}
}

func (d *Discord) Platform() string { return db.PlatformDiscord }
func (d *Discord) Configured() bool { return strings.TrimSpace(d.botToken) != "" }

func (d *Discord) Fetch(ctx context.Context, q Query) ([]db.Mention, error) {
	if !d.Configured() {
		return nil, ErrNotConfigured
	}
	channel := socialHandle(q.Socials, "discord")
	if channel == "" {
		return nil, nil // no configured channel for this token -> nothing real to read
	}
	// Production wires the Discord channel-messages API for the configured channel
	// here. No synthetic messages are ever produced.
	return nil, nil
}
