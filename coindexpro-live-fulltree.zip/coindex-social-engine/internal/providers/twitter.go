package providers

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"

	"github.com/coindexpro/coindex-social-engine/internal/db"
)

// Twitter queries the X/Twitter v2 recent-search endpoint. It is configured only
// when a bearer token is present; without one it returns ErrNotConfigured (it does
// NOT return an empty success that would look like "no one is talking about this").
type Twitter struct {
	bearer string
	http   *http.Client
	base   string
}

func NewTwitter(bearer string, timeout time.Duration) *Twitter {
	if timeout == 0 {
		timeout = 10 * time.Second
	}
	return &Twitter{
		bearer: bearer,
		http:   &http.Client{Timeout: timeout},
		base:   "https://api.twitter.com/2/tweets/search/recent",
	}
}

func (t *Twitter) Platform() string  { return db.PlatformTwitter }
func (t *Twitter) Configured() bool  { return strings.TrimSpace(t.bearer) != "" }

// twitterResp mirrors the real v2 search payload (subset we use).
type twitterResp struct {
	Data []struct {
		ID        string `json:"id"`
		Text      string `json:"text"`
		AuthorID  string `json:"author_id"`
		CreatedAt string `json:"created_at"`
		Lang      string `json:"lang"`
		Metrics   struct {
			Like    int64 `json:"like_count"`
			Reply   int64 `json:"reply_count"`
			Repost  int64 `json:"retweet_count"`
			Quote   int64 `json:"quote_count"`
		} `json:"public_metrics"`
	} `json:"data"`
	Includes struct {
		Users []struct {
			ID      string `json:"id"`
			Username string `json:"username"`
			Metrics struct {
				Followers int64 `json:"followers_count"`
			} `json:"public_metrics"`
		} `json:"users"`
	} `json:"includes"`
	Errors []struct {
		Detail string `json:"detail"`
	} `json:"errors"`
}

func (t *Twitter) Fetch(ctx context.Context, q Query) ([]db.Mention, error) {
	if !t.Configured() {
		return nil, ErrNotConfigured
	}
	term := searchTerm(q)
	if term == "" {
		return nil, nil // nothing to search for is not an error, but also not invented data
	}
	limit := q.Limit
	if limit <= 0 || limit > 100 {
		limit = 100
	}
	params := url.Values{}
	params.Set("query", term+" -is:retweet")
	params.Set("max_results", strconv.Itoa(limit))
	params.Set("tweet.fields", "created_at,lang,public_metrics,author_id")
	params.Set("expansions", "author_id")
	params.Set("user.fields", "public_metrics,username")
	if !q.Since.IsZero() {
		params.Set("start_time", q.Since.UTC().Format(time.RFC3339))
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, t.base+"?"+params.Encode(), nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", "Bearer "+t.bearer)
	resp, err := t.http.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode == http.StatusUnauthorized || resp.StatusCode == http.StatusForbidden {
		// bad/expired credentials -> treat as not configured, not as "no data"
		return nil, ErrNotConfigured
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("twitter status %d", resp.StatusCode)
	}
	var tr twitterResp
	if err := json.NewDecoder(resp.Body).Decode(&tr); err != nil {
		return nil, err
	}
	if len(tr.Errors) > 0 && len(tr.Data) == 0 {
		return nil, fmt.Errorf("twitter error: %s", tr.Errors[0].Detail)
	}

	followers := map[string]int64{}
	handle := map[string]string{}
	for _, u := range tr.Includes.Users {
		followers[u.ID] = u.Metrics.Followers
		handle[u.ID] = u.Username
	}

	out := make([]db.Mention, 0, len(tr.Data))
	for _, d := range tr.Data {
		posted, _ := time.Parse(time.RFC3339, d.CreatedAt)
		eng := d.Metrics.Like + d.Metrics.Reply + d.Metrics.Repost + d.Metrics.Quote
		m := db.Mention{
			Platform: db.PlatformTwitter, ExternalID: d.ID,
			Chain: q.Chain, Token: q.Token, Symbol: q.Symbol,
			Author: handle[d.AuthorID], URL: "https://twitter.com/i/web/status/" + d.ID,
			PostedAt: posted, Engagement: eng, Lang: d.Lang,
			Raw: map[string]any{"text": d.Text},
		}
		if f, ok := followers[d.AuthorID]; ok {
			ff := f
			m.AuthorFollowers = &ff
		}
		out = append(out, m)
	}
	return out, nil
}

// searchTerm builds a query from the token's symbol (cashtag) when present. We do
// not fabricate a search target; if there is no symbol we return "".
func searchTerm(q Query) string {
	s := strings.TrimSpace(q.Symbol)
	if s == "" {
		return ""
	}
	return "$" + strings.TrimPrefix(s, "$")
}
