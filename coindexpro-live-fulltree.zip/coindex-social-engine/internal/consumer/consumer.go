// Package consumer triggers social refreshes on a schedule. Unlike trade-driven
// engines, social fetching is poll-based (providers are queried), so this is a
// simple ticker that asks the engine to rebuild the current window. It is only
// active when at least one provider is configured.
package consumer

import (
	"context"
	"time"

	"go.uber.org/zap"
)

// WindowBuilder is satisfied by social.Engine.
type WindowBuilder interface {
	BuildWindow(ctx context.Context, start, end time.Time) error
	Configured() bool
}

type Scheduler struct {
	builder  WindowBuilder
	interval time.Duration
	window   time.Duration
	log      *zap.Logger
}

func NewScheduler(builder WindowBuilder, interval, window time.Duration, log *zap.Logger) *Scheduler {
	if interval <= 0 {
		interval = 15 * time.Minute
	}
	if window <= 0 {
		window = time.Hour
	}
	return &Scheduler{builder: builder, interval: interval, window: window, log: log}
}

func (s *Scheduler) Run(ctx context.Context) error {
	if !s.builder.Configured() {
		s.log.Info("social scheduler idle: no providers configured")
		<-ctx.Done()
		return ctx.Err()
	}
	t := time.NewTicker(s.interval)
	defer t.Stop()
	s.once(ctx)
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-t.C:
			s.once(ctx)
		}
	}
}

func (s *Scheduler) once(ctx context.Context) {
	end := time.Now().UTC()
	start := end.Add(-s.window)
	if err := s.builder.BuildWindow(ctx, start, end); err != nil {
		s.log.Warn("social build failed", zap.Error(err))
	}
}
