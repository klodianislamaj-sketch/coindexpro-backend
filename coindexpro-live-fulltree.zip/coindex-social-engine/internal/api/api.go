// Package api serves social + sentiment reads. The unavailable contract matches
// Phase 3 exactly: with NO configured provider, /social and /sentiment return
// {available:false, reason:"not configured"}; with providers configured but no
// data yet for a token, they return {available:false, reason:"not indexed"}. The
// API never returns a fabricated score.
package api

import (
	"regexp"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"

	"github.com/coindexpro/coindex-social-engine/internal/db"
	"github.com/coindexpro/coindex-social-engine/internal/metrics"
	"github.com/coindexpro/coindex-social-engine/internal/providers"
)

type API struct {
	store *db.Store
	reg   *providers.Registry
}

func New(store *db.Store, reg *providers.Registry) *API {
	return &API{store: store, reg: reg}
}

func (a *API) Register(app *fiber.App) {
	app.Use(a.observe)
	app.Get("/social/providers", a.providersList)
	app.Get("/social/:chain/:token", a.social)
	app.Get("/sentiment/:chain/:token", a.sentiment)
	app.Get("/social/:chain/:token/mentions", a.mentions)
}

func (a *API) observe(c *fiber.Ctx) error {
	start := time.Now()
	err := c.Next()
	metrics.APILatency.WithLabelValues(c.Route().Path, statusClass(c.Response().StatusCode())).
		Observe(time.Since(start).Seconds())
	return err
}

var evmAddr = regexp.MustCompile(`^0x[0-9a-fA-F]{40}$`)

func params(c *fiber.Ctx) (chain, token string, ok bool) {
	chain = strings.ToLower(c.Params("chain"))
	token = strings.ToLower(c.Params("token"))
	if chain == "" || !evmAddr.MatchString(token) {
		return "", "", false
	}
	return chain, token, true
}

// unavailable returns the right reason: "not configured" when no provider exists
// at all, "not indexed" when configured but nothing stored yet.
func (a *API) unavailable(c *fiber.Ctx, chain, token string) error {
	reason := "not indexed"
	if !a.reg.Any() {
		reason = "not configured"
	}
	return c.JSON(fiber.Map{"chain": chain, "token": token, "available": false, "reason": reason})
}

// GET /social/providers — which platforms are actually configured (honest surface)
func (a *API) providersList(c *fiber.Ctx) error {
	configured := a.reg.Configured()
	return c.JSON(fiber.Map{
		"available":  len(configured) > 0,
		"configured": configured,
		"all":        []string{db.PlatformTwitter, db.PlatformReddit, db.PlatformTelegram, db.PlatformDiscord, db.PlatformFarcaster},
	})
}

// GET /social/:chain/:token
func (a *API) social(c *fiber.Ctx) error {
	chain, token, ok := params(c)
	if !ok {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid chain or token"})
	}
	sc, found, err := a.store.LatestSocialScore(c.UserContext(), chain, token)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !found {
		return a.unavailable(c, chain, token)
	}
	return c.JSON(fiber.Map{"chain": chain, "token": token, "available": true, "social": sc})
}

// GET /sentiment/:chain/:token
func (a *API) sentiment(c *fiber.Ctx) error {
	chain, token, ok := params(c)
	if !ok {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid chain or token"})
	}
	st, found, err := a.store.LatestSentiment(c.UserContext(), chain, token)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !found {
		return a.unavailable(c, chain, token)
	}
	// expose the method + coverage so the caller knows this is lexicon-based and partial
	return c.JSON(fiber.Map{"chain": chain, "token": token, "available": true, "sentiment": st})
}

// GET /social/:chain/:token/mentions
func (a *API) mentions(c *fiber.Ctx) error {
	chain, token, ok := params(c)
	if !ok {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid chain or token"})
	}
	limit := clamp(c.QueryInt("limit", 50), 1, 200)
	ms, err := a.store.RecentMentions(c.UserContext(), chain, token, limit)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(ms) == 0 {
		return a.unavailable(c, chain, token)
	}
	return c.JSON(fiber.Map{"chain": chain, "token": token, "available": true, "mentions": ms})
}

func clamp(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}

func statusClass(code int) string {
	switch {
	case code >= 500:
		return "5xx"
	case code >= 400:
		return "4xx"
	default:
		return "2xx"
	}
}
