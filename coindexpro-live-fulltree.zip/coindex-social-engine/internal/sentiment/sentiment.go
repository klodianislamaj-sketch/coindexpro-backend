// Package sentiment provides a deterministic, transparent lexicon scorer over
// real post text. It is explicitly a LEXICON method — not a claim of model-grade
// understanding — and it reports that method on every score. Text it cannot score
// (empty, or no lexicon hits) is left UNSCORED (nil), never assigned a fake
// neutral, so the aggregate's coverage reflects how much was actually scored.
package sentiment

import (
	"strings"

	"github.com/coindexpro/coindex-social-engine/internal/db"
)

// small, transparent crypto-aware polarity lexicon. Weights in [-1,1].
var lexicon = map[string]float64{
	// positive
	"moon": 0.8, "bullish": 0.9, "pump": 0.5, "gem": 0.6, "buy": 0.4, "long": 0.4,
	"breakout": 0.6, "ath": 0.5, "undervalued": 0.6, "accumulate": 0.5, "send": 0.4,
	"green": 0.4, "win": 0.5, "strong": 0.5, "support": 0.3, "good": 0.4, "great": 0.6,
	"love": 0.6, "huge": 0.5, "lfg": 0.7,
	// negative
	"dump": -0.7, "bearish": -0.9, "rug": -0.95, "scam": -0.95, "sell": -0.4,
	"short": -0.4, "rekt": -0.8, "crash": -0.8, "down": -0.4, "red": -0.4,
	"avoid": -0.6, "honeypot": -0.9, "ponzi": -0.9, "dead": -0.7, "bad": -0.5,
	"weak": -0.5, "fud": -0.5, "exit": -0.4, "fear": -0.5, "loss": -0.6,
}

// negators flip the polarity of the next matched term.
var negators = map[string]bool{"not": true, "no": true, "never": true, "isnt": true, "dont": true, "cant": true}

// Score returns a polarity in [-1,1] and ok=false when the text has no scoreable
// signal (so the caller can leave it unscored rather than record a fake neutral).
func Score(text string) (float64, bool) {
	if strings.TrimSpace(text) == "" {
		return 0, false
	}
	toks := tokenize(strings.ToLower(text))
	var sum float64
	var hits int
	neg := false
	for _, tok := range toks {
		if negators[tok] {
			neg = true
			continue
		}
		if w, ok := lexicon[tok]; ok {
			if neg {
				w = -w
			}
			sum += w
			hits++
		}
		neg = false
	}
	if hits == 0 {
		return 0, false // no lexicon signal -> unscored, not fake-neutral
	}
	avg := sum / float64(hits)
	if avg > 1 {
		avg = 1
	}
	if avg < -1 {
		avg = -1
	}
	return round4(avg), true
}

// Aggregate computes a per-token sentiment aggregate over a window's mentions.
// Mentions whose text cannot be scored are counted in total but not scored;
// coverage = scored/total is exposed so a partial aggregate is never presented as
// complete. Returns ok=false when nothing could be scored at all.
func Aggregate(chain, token string, mentions []db.Mention, textOf func(db.Mention) string) (db.Sentiment, bool) {
	var sum float64
	var pos, neg, neu, scored int64
	total := int64(len(mentions))
	for i := range mentions {
		// prefer an already-attached provider sentiment if present (method=provider)
		if mentions[i].Sentiment != nil {
			s := *mentions[i].Sentiment
			sum += s
			scored++
			bucket(&pos, &neg, &neu, s)
			continue
		}
		s, ok := Score(textOf(mentions[i]))
		if !ok {
			continue
		}
		ms := s // attach the lexicon score back to the row
		mentions[i].Sentiment = &ms
		mentions[i].SentimentMethod = db.MethodLexicon
		sum += s
		scored++
		bucket(&pos, &neg, &neu, s)
	}
	if scored == 0 {
		return db.Sentiment{}, false
	}
	cov := float64(scored) / float64(total)
	return db.Sentiment{
		Chain: chain, Token: token,
		MeanSentiment: round4(sum / float64(scored)),
		Pos:           pos, Neg: neg, Neu: neu,
		Scored: scored, Total: total, Coverage: round4(cov),
		Method: db.MethodLexicon,
	}, true
}

func bucket(pos, neg, neu *int64, s float64) {
	switch {
	case s > 0.15:
		*pos++
	case s < -0.15:
		*neg++
	default:
		*neu++
	}
}

func tokenize(s string) []string {
	return strings.FieldsFunc(s, func(r rune) bool {
		return !(r >= 'a' && r <= 'z') && !(r >= '0' && r <= '9')
	})
}

func round4(x float64) float64 { return float64(int(x*10000+0.5)) / 10000 }
