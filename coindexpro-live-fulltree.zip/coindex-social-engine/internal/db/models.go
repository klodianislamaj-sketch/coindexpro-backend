// Package db holds the social-engine persistence layer and shared domain types.
// The honesty invariant lives in the data model: a Mention only exists if a
// configured provider actually returned it, and a Sentiment aggregate always
// carries its coverage (fraction of mentions actually scored) so a partial score
// is never presented as a complete one.
package db

import "time"

// Platforms.
const (
	PlatformTwitter   = "twitter"
	PlatformReddit    = "reddit"
	PlatformTelegram  = "telegram"
	PlatformDiscord   = "discord"
	PlatformFarcaster = "farcaster"
)

// Sentiment scoring methods.
const (
	MethodLexicon  = "lexicon"  // local deterministic lexicon scorer (no external key)
	MethodProvider = "provider" // sentiment supplied by the social provider itself
	MethodModel    = "model"    // external model API (only if configured)
)

// Mention is one real observed post from a provider.
type Mention struct {
	Platform        string         `json:"platform"`
	ExternalID      string         `json:"external_id"`
	Chain           string         `json:"chain,omitempty"`
	Token           string         `json:"token,omitempty"`
	Symbol          string         `json:"symbol,omitempty"`
	Author          string         `json:"author,omitempty"`
	AuthorFollowers *int64         `json:"author_followers,omitempty"` // nil when provider didn't report
	URL             string         `json:"url,omitempty"`
	PostedAt        time.Time      `json:"posted_at"`
	Engagement      int64          `json:"engagement"`
	Lang            string         `json:"lang,omitempty"`
	Sentiment       *float64       `json:"sentiment,omitempty"`        // nil when not scored
	SentimentMethod string         `json:"sentiment_method,omitempty"`
	Raw             map[string]any `json:"raw,omitempty"`
}

// SocialScore is a per-token windowed activity aggregate.
type SocialScore struct {
	Chain            string         `json:"chain"`
	Token            string         `json:"token"`
	WindowStart      time.Time      `json:"window_start"`
	WindowEnd        time.Time      `json:"window_end"`
	Mentions         int64          `json:"mentions"`
	Engagement       int64          `json:"engagement"`
	DistinctAuthors  int64          `json:"distinct_authors"`
	Velocity         *float64       `json:"velocity,omitempty"` // nil when no baseline
	InfluencerWeight int64          `json:"influencer_weight"`
	Platforms        map[string]int `json:"platforms"`
}

// Sentiment is a per-token windowed sentiment aggregate.
type Sentiment struct {
	Chain         string    `json:"chain"`
	Token         string    `json:"token"`
	WindowStart   time.Time `json:"window_start"`
	WindowEnd     time.Time `json:"window_end"`
	MeanSentiment float64   `json:"mean_sentiment"`
	Pos           int64     `json:"pos"`
	Neg           int64     `json:"neg"`
	Neu           int64     `json:"neu"`
	Scored        int64     `json:"scored"`
	Total         int64     `json:"total"`
	Coverage      float64   `json:"coverage"`
	Method        string    `json:"method"`
}

// TrackedToken is a token the engine should fetch mentions for, derived from the
// real token_registry (symbol + configured socials), not invented.
type TrackedToken struct {
	Chain   string
	Token   string
	Symbol  string
	Socials map[string]any // from token_registry.socials (real configured handles)
}
