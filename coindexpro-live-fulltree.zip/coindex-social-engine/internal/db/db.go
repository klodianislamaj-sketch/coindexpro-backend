package db

import (
	"context"
	"encoding/json"
	"errors"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

type Store struct{ pg *pgxpool.Pool }

func Open(ctx context.Context, dsn string) (*Store, error) {
	pg, err := pgxpool.New(ctx, dsn)
	if err != nil {
		return nil, err
	}
	if err := pg.Ping(ctx); err != nil {
		return nil, err
	}
	return &Store{pg: pg}, nil
}

func (s *Store) Close()                         { s.pg.Close() }
func (s *Store) Ping(ctx context.Context) error { return s.pg.Ping(ctx) }

// ---------- sources ----------

// TrackedTokens returns tokens to fetch social data for, from the REAL
// token_registry: those with a symbol (a real cashtag to search) and/or
// configured socials. We never invent tokens to track.
func (s *Store) TrackedTokens(ctx context.Context, limit int) ([]TrackedToken, error) {
	const q = `
		SELECT chain, address, coalesce(symbol,''), socials
		FROM token_registry
		WHERE symbol IS NOT NULL AND symbol <> ''
		ORDER BY indexed_at DESC
		LIMIT $1`
	rows, err := s.pg.Query(ctx, q, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []TrackedToken
	for rows.Next() {
		var t TrackedToken
		var socials []byte
		if err := rows.Scan(&t.Chain, &t.Token, &t.Symbol, &socials); err != nil {
			return nil, err
		}
		_ = json.Unmarshal(socials, &t.Socials)
		out = append(out, t)
	}
	return out, rows.Err()
}

// BaselineMentions returns the mean mention count of the prior n windows for a
// token (from social_scores). ok=false when there is no prior history, so the
// caller leaves velocity unavailable instead of dividing by a fabricated base.
func (s *Store) BaselineMentions(ctx context.Context, chain, token string, before time.Time, n int) (float64, bool, error) {
	const q = `
		SELECT mentions FROM social_scores
		WHERE chain=$1 AND token=$2 AND window_start < $3
		ORDER BY window_start DESC LIMIT $4`
	rows, err := s.pg.Query(ctx, q, chain, token, before, n)
	if err != nil {
		return 0, false, err
	}
	defer rows.Close()
	var sum float64
	var cnt int
	for rows.Next() {
		var m int64
		if err := rows.Scan(&m); err != nil {
			return 0, false, err
		}
		sum += float64(m)
		cnt++
	}
	if err := rows.Err(); err != nil {
		return 0, false, err
	}
	if cnt == 0 {
		return 0, false, nil
	}
	return sum / float64(cnt), true, nil
}

// ---------- sink (idempotent) ----------

// UpsertMentions inserts real mentions, deduped on (platform, external_id).
func (s *Store) UpsertMentions(ctx context.Context, ms []Mention) (int, error) {
	if len(ms) == 0 {
		return 0, nil
	}
	tx, err := s.pg.Begin(ctx)
	if err != nil {
		return 0, err
	}
	defer tx.Rollback(ctx)
	n := 0
	for _, m := range ms {
		raw, _ := json.Marshal(m.Raw)
		const q = `
			INSERT INTO social_mentions
				(platform, external_id, chain, token, symbol, author, author_followers, url,
				 posted_at, engagement, lang, sentiment, sentiment_method, raw)
			VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
			ON CONFLICT (platform, external_id) DO UPDATE SET
				engagement=$10, sentiment=$12, sentiment_method=NULLIF($13,''), raw=$14`
		if _, err := tx.Exec(ctx, q, m.Platform, m.ExternalID, nullStr(m.Chain), nullStr(m.Token),
			nullStr(m.Symbol), nullStr(m.Author), m.AuthorFollowers, nullStr(m.URL),
			m.PostedAt, m.Engagement, nullStr(m.Lang), m.Sentiment, m.SentimentMethod, raw); err != nil {
			return n, err
		}
		n++
	}
	if err := tx.Commit(ctx); err != nil {
		return 0, err
	}
	return n, nil
}

func (s *Store) UpsertSocialScore(ctx context.Context, sc SocialScore) error {
	platforms, _ := json.Marshal(sc.Platforms)
	const q = `
		INSERT INTO social_scores
			(chain, token, window_start, window_end, mentions, engagement, distinct_authors,
			 velocity, influencer_weight, platforms)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
		ON CONFLICT (chain, token, window_start) DO UPDATE SET
			window_end=$4, mentions=$5, engagement=$6, distinct_authors=$7,
			velocity=$8, influencer_weight=$9, platforms=$10, updated_at=now()`
	_, err := s.pg.Exec(ctx, q, sc.Chain, sc.Token, sc.WindowStart, sc.WindowEnd,
		sc.Mentions, sc.Engagement, sc.DistinctAuthors, sc.Velocity, sc.InfluencerWeight, platforms)
	return err
}

func (s *Store) UpsertSentiment(ctx context.Context, st Sentiment) error {
	const q = `
		INSERT INTO social_sentiment
			(chain, token, window_start, window_end, mean_sentiment, pos, neg, neu, scored, total, coverage, method)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
		ON CONFLICT (chain, token, window_start) DO UPDATE SET
			window_end=$4, mean_sentiment=$5, pos=$6, neg=$7, neu=$8, scored=$9,
			total=$10, coverage=$11, method=$12, updated_at=now()`
	_, err := s.pg.Exec(ctx, q, st.Chain, st.Token, st.WindowStart, st.WindowEnd,
		st.MeanSentiment, st.Pos, st.Neg, st.Neu, st.Scored, st.Total, st.Coverage, st.Method)
	return err
}

// ---------- API reads ----------

func (s *Store) LatestSocialScore(ctx context.Context, chain, token string) (SocialScore, bool, error) {
	const q = `
		SELECT chain, token, window_start, window_end, mentions, engagement, distinct_authors,
		       velocity, influencer_weight, platforms
		FROM social_scores WHERE chain=$1 AND token=$2
		ORDER BY window_start DESC LIMIT 1`
	var sc SocialScore
	var platforms []byte
	var vel *float64
	err := s.pg.QueryRow(ctx, q, chain, strings.ToLower(token)).Scan(
		&sc.Chain, &sc.Token, &sc.WindowStart, &sc.WindowEnd, &sc.Mentions, &sc.Engagement,
		&sc.DistinctAuthors, &vel, &sc.InfluencerWeight, &platforms)
	if err != nil {
		return SocialScore{}, false, errNoRows(err)
	}
	sc.Velocity = vel
	_ = json.Unmarshal(platforms, &sc.Platforms)
	return sc, true, nil
}

func (s *Store) LatestSentiment(ctx context.Context, chain, token string) (Sentiment, bool, error) {
	const q = `
		SELECT chain, token, window_start, window_end, mean_sentiment, pos, neg, neu, scored, total, coverage, method
		FROM social_sentiment WHERE chain=$1 AND token=$2
		ORDER BY window_start DESC LIMIT 1`
	var st Sentiment
	err := s.pg.QueryRow(ctx, q, chain, strings.ToLower(token)).Scan(
		&st.Chain, &st.Token, &st.WindowStart, &st.WindowEnd, &st.MeanSentiment,
		&st.Pos, &st.Neg, &st.Neu, &st.Scored, &st.Total, &st.Coverage, &st.Method)
	if err != nil {
		return Sentiment{}, false, errNoRows(err)
	}
	return st, true, nil
}

func (s *Store) RecentMentions(ctx context.Context, chain, token string, limit int) ([]Mention, error) {
	const q = `
		SELECT platform, external_id, coalesce(symbol,''), coalesce(author,''), author_followers,
		       coalesce(url,''), posted_at, engagement, sentiment, coalesce(sentiment_method,'')
		FROM social_mentions WHERE chain=$1 AND token=$2
		ORDER BY posted_at DESC LIMIT $3`
	rows, err := s.pg.Query(ctx, q, chain, strings.ToLower(token), limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []Mention
	for rows.Next() {
		var m Mention
		if err := rows.Scan(&m.Platform, &m.ExternalID, &m.Symbol, &m.Author, &m.AuthorFollowers,
			&m.URL, &m.PostedAt, &m.Engagement, &m.Sentiment, &m.SentimentMethod); err != nil {
			return nil, err
		}
		m.Chain, m.Token = chain, strings.ToLower(token)
		out = append(out, m)
	}
	return out, rows.Err()
}

func nullStr(s string) any {
	if s == "" {
		return nil
	}
	return s
}

// errNoRows normalizes pgx.ErrNoRows to nil so callers treat "no rows" as
// not-found (false) rather than an error.
func errNoRows(err error) error {
	if errors.Is(err, pgx.ErrNoRows) {
		return nil
	}
	return err
}
