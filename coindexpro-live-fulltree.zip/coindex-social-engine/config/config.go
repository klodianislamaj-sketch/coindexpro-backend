// Package config loads social-engine configuration from YAML with ${ENV} expansion.
// Provider credentials are all OPTIONAL: a blank credential means that provider is
// simply not configured (and its platform is absent), never mocked.
package config

import (
	"fmt"
	"os"
	"time"

	"gopkg.in/yaml.v3"
)

type Config struct {
	Server    ServerConfig    `yaml:"server"`
	Postgres  PostgresConfig  `yaml:"postgres"`
	Redis     RedisConfig     `yaml:"redis"`
	Providers ProvidersConfig `yaml:"providers"`
	Build     BuildConfig     `yaml:"build"`
	Log       LogConfig       `yaml:"log"`
}

type ServerConfig struct {
	APIAddr     string `yaml:"api_addr"`
	MetricsAddr string `yaml:"metrics_addr"`
}
type PostgresConfig struct {
	DSN string `yaml:"dsn"`
}
type RedisConfig struct {
	Addr string `yaml:"addr"`
}
type ProvidersConfig struct {
	HTTPTimeout    time.Duration `yaml:"http_timeout"`
	TwitterBearer  string        `yaml:"twitter_bearer"`
	RedditToken    string        `yaml:"reddit_token"`
	TelegramBot    string        `yaml:"telegram_bot_token"`
	DiscordBot     string        `yaml:"discord_bot_token"`
	FarcasterKey   string        `yaml:"farcaster_api_key"`
	FarcasterBase  string        `yaml:"farcaster_base_url"`
}
type BuildConfig struct {
	Enabled         bool          `yaml:"enabled"`
	Interval        time.Duration `yaml:"interval"`
	Window          time.Duration `yaml:"window"`
	MaxTokens       int           `yaml:"max_tokens"`
	PerTokenLimit   int           `yaml:"per_token_limit"`
	BaselineWindows int           `yaml:"baseline_windows"`
	CacheTTL        time.Duration `yaml:"cache_ttl"`
}
type LogConfig struct {
	Level string `yaml:"level"`
}

func Load(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}
	var c Config
	if err := yaml.Unmarshal([]byte(os.Expand(string(raw), os.Getenv)), &c); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}
	c.defaults()
	return &c, c.validate()
}

func (c *Config) defaults() {
	if c.Server.APIAddr == "" {
		c.Server.APIAddr = ":8098"
	}
	if c.Server.MetricsAddr == "" {
		c.Server.MetricsAddr = ":9110"
	}
	if c.Providers.HTTPTimeout == 0 {
		c.Providers.HTTPTimeout = 10 * time.Second
	}
	if c.Build.Interval == 0 {
		c.Build.Interval = 15 * time.Minute
	}
	if c.Build.Window == 0 {
		c.Build.Window = time.Hour
	}
	if c.Build.MaxTokens == 0 {
		c.Build.MaxTokens = 500
	}
	if c.Build.PerTokenLimit == 0 {
		c.Build.PerTokenLimit = 100
	}
	if c.Build.BaselineWindows == 0 {
		c.Build.BaselineWindows = 24
	}
	if c.Build.CacheTTL == 0 {
		c.Build.CacheTTL = 60 * time.Second
	}
}

func (c *Config) validate() error {
	if c.Postgres.DSN == "" {
		return fmt.Errorf("postgres.dsn empty")
	}
	if c.Redis.Addr == "" {
		return fmt.Errorf("redis.addr empty")
	}
	// NOTE: provider credentials are intentionally NOT required. With none set,
	// the engine runs idle and the API reports social/sentiment "not configured".
	return nil
}
