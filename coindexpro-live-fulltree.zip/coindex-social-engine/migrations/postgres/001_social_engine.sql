-- =============================================================================
-- CoinDex Social / Sentiment Engine — PostgreSQL migration (Phase 12)
-- =============================================================================
-- Stores ONLY real posts/mentions fetched from configured providers (X/Twitter,
-- Reddit, Telegram, Discord, Farcaster). There is no path that writes a synthetic
-- mention or a fabricated sentiment. If no provider is configured for a platform,
-- nothing is written for it and the API reports unavailable.
--
-- No prior phase defines social tables (Phase 2 only has token_registry.socials,
-- a jsonb of configured handles), so these are new, non-colliding tables.
-- All statements are idempotent.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- social_mentions — one row per real observed post/mention from a provider
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS social_mentions (
    id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    platform     text        NOT NULL CHECK (platform IN ('twitter','reddit','telegram','discord','farcaster')),
    external_id  text        NOT NULL,                  -- provider's post id (dedupe key)
    chain        text,                                   -- nullable: a post may reference a token w/o chain
    token        text,                                   -- token address if resolved, else NULL
    symbol       text,                                   -- matched symbol/cashtag as observed
    author       text,                                   -- provider handle/id as given
    author_followers bigint,                             -- provider-reported; NULL if not provided
    url          text,
    posted_at    timestamptz NOT NULL,                   -- provider timestamp
    engagement   bigint      NOT NULL DEFAULT 0,         -- likes+reposts+replies as reported (0 if unknown)
    lang         text,
    -- sentiment of THIS post if a sentiment method ran; NULL when not scored
    sentiment    numeric     CHECK (sentiment IS NULL OR (sentiment BETWEEN -1 AND 1)),
    sentiment_method text    CHECK (sentiment_method IN ('lexicon','provider','model') OR sentiment_method IS NULL),
    fetched_at   timestamptz NOT NULL DEFAULT now(),
    raw          jsonb       NOT NULL DEFAULT '{}'::jsonb,   -- original provider payload (real)
    CONSTRAINT uq_mention UNIQUE (platform, external_id)
);
CREATE INDEX IF NOT EXISTS idx_sm_token ON social_mentions (chain, token, posted_at DESC);
CREATE INDEX IF NOT EXISTS idx_sm_symbol ON social_mentions (symbol, posted_at DESC);
CREATE INDEX IF NOT EXISTS idx_sm_platform ON social_mentions (platform, posted_at DESC);

-- -----------------------------------------------------------------------------
-- social_scores — per-token windowed activity aggregates (mentions/engagement/
-- velocity/influencer-weight). Velocity is mentions(window) vs a real prior-window
-- baseline; influencer weight sums provider-reported follower counts (NULL-safe).
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS social_scores (
    id            bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    chain         text        NOT NULL,
    token         text        NOT NULL,
    window_start  timestamptz NOT NULL,
    window_end    timestamptz NOT NULL,
    mentions      bigint      NOT NULL DEFAULT 0,
    engagement    bigint      NOT NULL DEFAULT 0,
    distinct_authors bigint   NOT NULL DEFAULT 0,
    velocity      numeric,                                -- mentions / baseline_mentions; NULL if no baseline
    influencer_weight bigint  NOT NULL DEFAULT 0,         -- sum of author_followers where reported
    platforms     jsonb       NOT NULL DEFAULT '{}'::jsonb, -- {platform: mention_count} actually observed
    updated_at    timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_social_score UNIQUE (chain, token, window_start)
);
CREATE INDEX IF NOT EXISTS idx_ss_token ON social_scores (chain, token, window_start DESC);

-- -----------------------------------------------------------------------------
-- social_sentiment — per-token windowed sentiment aggregate. coverage is the
-- fraction of mentions in the window that were actually sentiment-scored; when
-- coverage is low the score is partial and we expose it rather than hide it.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS social_sentiment (
    id            bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    chain         text        NOT NULL,
    token         text        NOT NULL,
    window_start  timestamptz NOT NULL,
    window_end    timestamptz NOT NULL,
    mean_sentiment numeric    NOT NULL CHECK (mean_sentiment BETWEEN -1 AND 1),
    pos           bigint      NOT NULL DEFAULT 0,
    neg           bigint      NOT NULL DEFAULT 0,
    neu           bigint      NOT NULL DEFAULT 0,
    scored        bigint      NOT NULL DEFAULT 0,         -- mentions actually scored
    total         bigint      NOT NULL DEFAULT 0,         -- mentions in window
    coverage      numeric     NOT NULL DEFAULT 0 CHECK (coverage BETWEEN 0 AND 1),
    method        text        NOT NULL CHECK (method IN ('lexicon','provider','model')),
    updated_at    timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_social_sentiment UNIQUE (chain, token, window_start)
);
CREATE INDEX IF NOT EXISTS idx_sent_token ON social_sentiment (chain, token, window_start DESC);
