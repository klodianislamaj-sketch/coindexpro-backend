## coindex-social-engine — Phase 12

Fetches **real social mentions** for tracked tokens from configured providers,
computes activity + sentiment aggregates, and serves them. The defining rule:
**social/sentiment data comes only from configured providers.** With no provider
configured, the engine runs idle and the API returns
`{available:false, reason:"not configured"}` — it never invents mentions or
sentiment.

### Architecture

```
real sources                         social engine                     storage
────────────                         ─────────────                     ───────
token_registry (symbol, socials) ─► engine.BuildWindow ─► fetch ─► social_mentions
configured providers:                  per tracked token   real    social_scores
  X/Twitter, Reddit, Telegram,         ▼                   posts   social_sentiment
  Discord, Farcaster              social.Score (activity)
                                  sentiment.Aggregate (lexicon + coverage)
```

The scheduler polls providers on an interval. Tokens to track come from the
**real `token_registry`** (those with a symbol / configured socials) — never an
invented watchlist.

### Providers (configured-only registry)

Each provider (`twitter`, `reddit`, `telegram`, `discord`, `farcaster`) is a real
HTTP client. A provider enters the registry **only if it reports `Configured()`**
(has a credential). Two honest consequences:

- An **unconfigured** platform is simply absent — `GET /social/providers` shows
  exactly which platforms can return real data.
- A provider with bad/expired credentials returns `ErrNotConfigured` (not an
  empty success), so a credential problem is never mistaken for "no chatter."

Telegram/Discord have no global search, so they additionally require a per-token
channel in `token_registry.socials`; without one there is nothing real to read.

### The unavailable contract (matches Phase 3)

| Situation | Response |
|---|---|
| No provider configured at all | `{available:false, reason:"not configured"}` |
| Providers configured, no data for this token yet | `{available:false, reason:"not indexed"}` |
| Real data present | `{available:true, ...}` |

This mirrors the Phase 3 Read API stub, which already defers `/social` and
`/sentiment` to "Phase 12" and names the required providers.

### Sentiment (lexicon method + coverage)

Sentiment uses a **deterministic, transparent lexicon scorer** over real post
text. It is explicitly labelled `method:"lexicon"` — not a claim of model-grade
understanding. Text with no lexicon signal is left **unscored** (never assigned a
fake neutral), and every aggregate exposes **`coverage` = scored ÷ total** so a
partial sentiment is never presented as complete. If a provider supplies its own
sentiment, that is used with `method:"provider"`; an external model is only used
when configured (`method:"model"`).

### Social activity scoring

Per-token, per-window from **real mentions**: `mentions`, `engagement` (sum of
provider-reported likes/replies/reposts), `distinct_authors`, `influencer_weight`
(sum of provider-reported follower counts; absent counts contribute nothing), and
a per-platform breakdown. **Velocity** = current mentions ÷ a real prior-window
baseline; with no baseline it is left `null`, not fabricated.

### API

| Route | Returns |
|---|---|
| `GET /social/providers` | configured vs all platforms (honest capability surface) |
| `GET /social/:chain/:token` | latest social activity score (or unavailable) |
| `GET /sentiment/:chain/:token` | latest sentiment aggregate w/ method + coverage (or unavailable) |
| `GET /social/:chain/:token/mentions` | recent real mentions (or unavailable) |

Ops: `/healthz`, `/readyz`, `/metrics`.

### Idempotency & replay

Mentions dedupe on `(platform, external_id)`; scores and sentiment upsert on
`(chain, token, window_start)`. Re-running a window converges rather than
duplicating. Aggregation is deterministic over the same stored mentions.

### Honest boundaries / runtime limitations

- **Real, production-shaped code, NOT compiled or run here** (no Go toolchain, no
  Postgres/Redis, no network, no provider credentials in this environment).
  Statically reviewed (imports/symbols/interfaces resolve; no import cycle; routes
  distinct; no dead code — `Registry.Has` and a leftover var were removed;
  `errNoRows` uses `errors.Is(pgx.ErrNoRows)`). The lexicon scorer and its
  coverage behaviour were verified by simulation. Before production:
  `go build` + `vet` + lint and an integration run against real provider APIs.
- **No fabricated sentiment.** With no provider configured, nothing is fetched and
  the API reports `not configured`. Unscoreable posts stay unscored (coverage
  reflects it). The lexicon is a transparent heuristic, surfaced as `method`.
- **Provider HTTP bodies were written to the documented real API shapes** (X v2
  recent search, Reddit search, Neynar-style Farcaster). They are not exercised
  here; field mappings should be confirmed against current provider docs at
  integration time. Telegram/Discord history fetching is gated on a configured
  channel and is left as a no-op (returns nothing, never synthetic) until wired to
  a live bot.
- **Only as real as the providers.** A token with no posts in a window produces no
  row — there are no zero-filled placeholders.
