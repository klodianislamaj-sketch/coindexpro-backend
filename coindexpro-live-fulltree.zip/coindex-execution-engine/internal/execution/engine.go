package execution

import (
	"context"
	"time"

	"go.uber.org/zap"

	"github.com/coindexpro/coindex-execution-engine/internal/metrics"
	"github.com/coindexpro/coindex-execution-engine/internal/models"
)

// Sources reads real upstream inputs (implemented by db.Store).
type Sources interface {
	TrackedTokens(ctx context.Context, limit int) ([]models.TokenRef, error)
	ExecInputs(ctx context.Context, chain, token string) (models.ExecInputs, error)
	LiquidityProfile(ctx context.Context, chain, token string) (models.LiquidityProfile, bool, error)
}

// Sink persists execution outputs (implemented by db.Store).
type Sink interface {
	UpsertPlan(ctx context.Context, p models.ExecutionPlan) error
	UpsertLiquidityProfile(ctx context.Context, lp models.LiquidityProfile) error
	ReplaceSlippageCurve(ctx context.Context, chain, token string, pts []models.SlippagePoint) error
}

type Engine struct {
	src    Sources
	sink   Sink
	cfg    Config
	w      Weights
	ladder []float64
	log    *zap.Logger
}

type Config struct {
	MaxTokens     int
	SlippageLadder []float64 // probe sizes (USD) for the slippage curve
}

func NewEngine(src Sources, sink Sink, cfg Config, w Weights, log *zap.Logger) *Engine {
	ladder := cfg.SlippageLadder
	if len(ladder) == 0 {
		ladder = []float64{1000, 5000, 25000, 100000}
	}
	return &Engine{src: src, sink: sink, cfg: cfg, w: w, ladder: ladder, log: log}
}

// BuildOnce computes execution plans for tracked tokens.
func (e *Engine) BuildOnce(ctx context.Context) error {
	t0 := time.Now()
	tokens, err := e.src.TrackedTokens(ctx, e.cfg.MaxTokens)
	if err != nil {
		return err
	}
	plans := 0
	for _, t := range tokens {
		in, err := e.src.ExecInputs(ctx, t.Chain, t.Token)
		if err != nil {
			return err
		}

		// persist the liquidity profile (real measured context) if present
		if lp, ok, err := e.src.LiquidityProfile(ctx, t.Chain, t.Token); err != nil {
			return err
		} else if ok {
			if err := e.sink.UpsertLiquidityProfile(ctx, lp); err != nil {
				return err
			}
		}

		// buy + sell plans
		built := false
		for _, side := range []string{models.SideBuy, models.SideSell} {
			plan, ok := BuildPlan(in, side, e.w)
			if !ok {
				// no real input available for this token -> no plan (not fabricated)
				continue
			}
			if err := e.sink.UpsertPlan(ctx, plan); err != nil {
				return err
			}
			metrics.Plans.WithLabelValues(side).Inc()
			plans++
			built = true
		}
		if !built {
			metrics.Skipped.WithLabelValues("no_inputs").Inc()
			continue
		}

		// slippage curve from real liquidity (only when liquidity is known)
		if in.LiqUSD != nil && *in.LiqUSD > 0 {
			conf := 1.0 // model confidence is full when the real liquidity input exists
			pts := SlippageCurve(*in.LiqUSD, e.ladder, conf)
			if len(pts) > 0 {
				if err := e.sink.ReplaceSlippageCurve(ctx, t.Chain, t.Token, pts); err != nil {
					return err
				}
			}
		}
	}

	metrics.Builds.Inc()
	metrics.BuildDuration.Observe(time.Since(t0).Seconds())
	e.log.Info("execution build complete", zap.Int("tokens", len(tokens)), zap.Int("plans", plans))
	return nil
}
