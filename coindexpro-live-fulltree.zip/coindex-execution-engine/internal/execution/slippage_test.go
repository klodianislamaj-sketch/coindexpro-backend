package execution

import (
	"math"
	"testing"
)

// Constant-product: a notional equal to the one-sided reserve (liq/2) gives
// impact = n/(R+n) = 0.5 => 5000 bps. This pins the real math exactly.
func TestSlippageBps_ConstantProductExact(t *testing.T) {
	liq := 1_000_000.0
	notional := liq / 2 // equals reserve
	bps, ok := SlippageBps(notional, liq)
	if !ok {
		t.Fatal("expected ok with real liquidity")
	}
	if math.Abs(bps-5000) > 0.01 {
		t.Fatalf("notional==reserve must be 5000 bps, got %v", bps)
	}
}

// Without a real liquidity figure, no number is produced (no default/guess).
func TestSlippageBps_UnavailableWithoutLiquidity(t *testing.T) {
	if _, ok := SlippageBps(1000, 0); ok {
		t.Fatal("liq<=0 must return ok=false (unavailable)")
	}
	if _, ok := SlippageBps(0, 1000); ok {
		t.Fatal("notional<=0 must return ok=false")
	}
}

// Smaller notional => smaller impact (monotonic), all from real liquidity.
func TestSlippageBps_MonotonicInNotional(t *testing.T) {
	liq := 2_000_000.0
	small, _ := SlippageBps(10_000, liq)
	big, _ := SlippageBps(100_000, liq)
	if !(small < big) {
		t.Fatalf("impact must grow with notional: small=%v big=%v", small, big)
	}
}

// MaxNotionalForImpact inverts SlippageBps: feeding its output back into
// SlippageBps should land at ~the requested bps cap.
func TestMaxNotionalForImpact_RoundTrip(t *testing.T) {
	liq := 1_000_000.0
	maxBps := 100.0 // 1%
	n, ok := MaxNotionalForImpact(liq, maxBps)
	if !ok {
		t.Fatal("expected ok with real liquidity")
	}
	bps, ok := SlippageBps(n, liq)
	if !ok {
		t.Fatal("round-trip slippage must be available")
	}
	if math.Abs(bps-maxBps) > 1.0 {
		t.Fatalf("round-trip: want ~%v bps, got %v", maxBps, bps)
	}
}

func TestMaxNotionalForImpact_UnavailableWithoutLiquidity(t *testing.T) {
	if _, ok := MaxNotionalForImpact(0, 100); ok {
		t.Fatal("no liquidity must be unavailable")
	}
}

// Empirical slippage is only available when real swaps exist (maxSwapUSD>0).
func TestEmpiricalSlippageBps_UnavailableWithoutRealSwaps(t *testing.T) {
	if _, ok := EmpiricalSlippageBps(50_000, 0); ok {
		t.Fatal("no real swaps must be unavailable (not fabricated)")
	}
}

func TestEmpiricalSlippageBps_MonotonicAndBounded(t *testing.T) {
	a, ok1 := EmpiricalSlippageBps(50_000, 100_000)
	b, ok2 := EmpiricalSlippageBps(500_000, 100_000)
	if !ok1 || !ok2 {
		t.Fatal("expected available with real swaps")
	}
	if !(a < b) {
		t.Fatalf("bigger notional vs same pool must give >= impact: a=%v b=%v", a, b)
	}
	if b > 2000.01 {
		t.Fatalf("empirical bps saturates near 2000, got %v", b)
	}
}
