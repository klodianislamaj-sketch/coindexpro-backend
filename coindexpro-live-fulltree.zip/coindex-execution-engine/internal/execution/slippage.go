// Package execution holds the execution-intelligence logic: a transparent
// price-impact (slippage) model, position sizing bounded by real liquidity, and
// the explainable quality scorer. Every numeric output is a function of a REAL
// measured input. None of these functions invents liquidity, slippage, or size;
// when the required real input is absent they report unavailability to the caller.
package execution

import "math"

// SlippageBps estimates price impact in basis points for a trade of notionalUSD
// against a pool with liqUSD of real liquidity, using the constant-product (x*y=k)
// model. For a notional n against reserve R (one side ~= liq/2), the impact is
// n / (R + n); we express it in bps. This is a transparent, widely-used
// approximation — it is labeled as a model estimate, not a measured fill.
//
// ok=false when liqUSD<=0: without a real liquidity figure we do NOT produce a
// number (no default, no guess).
func SlippageBps(notionalUSD, liqUSD float64) (float64, bool) {
	if liqUSD <= 0 || notionalUSD <= 0 {
		return 0, false
	}
	// constant-product: one-sided reserve approximated as half the pool TVL.
	reserve := liqUSD / 2
	impact := notionalUSD / (reserve + notionalUSD) // fraction in [0,1)
	return round2(impact * 10000), true
}

// MaxNotionalForImpact solves for the largest notional whose modeled impact stays
// at or below maxBps, given real liqUSD. Inverting impact = n/(R+n) <= b gives
// n <= b*R/(1-b). ok=false without real liquidity.
func MaxNotionalForImpact(liqUSD, maxBps float64) (float64, bool) {
	if liqUSD <= 0 || maxBps <= 0 {
		return 0, false
	}
	b := maxBps / 10000
	if b >= 1 {
		b = 0.999
	}
	reserve := liqUSD / 2
	return round2(b * reserve / (1 - b)), true
}

// EmpiricalSlippageBps derives a coarse slippage proxy from REAL observed swaps:
// the ratio of a target notional to the largest real swap seen. If a notional is
// far larger than anything the pool has actually absorbed, impact is higher. This
// is only available when real swaps exist (maxSwapUSD>0). It complements, and is
// reconciled with, the AMM model in the scorer. ok=false without real swaps.
func EmpiricalSlippageBps(notionalUSD, maxSwapUSD float64) (float64, bool) {
	if maxSwapUSD <= 0 || notionalUSD <= 0 {
		return 0, false
	}
	ratio := notionalUSD / maxSwapUSD
	// map ratio to bps with a saturating curve: <=1x ~ small, growing thereafter.
	bps := math.Tanh(ratio/4) * 2000 // saturates near 2000 bps (20%)
	return round2(bps), true
}

func round2(x float64) float64 { return math.Round(x*100) / 100 }
