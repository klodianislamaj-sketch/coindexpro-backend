package execution

import (
	"github.com/coindexpro/coindex-execution-engine/internal/models"
)

// scoreBuilder accumulates explainable inputs for an execution quality score.
// It is the same coverage-aware pattern used across the platform: an available
// input contributes value*weight to the score and weight to the available pool;
// an unavailable input contributes only to the total weight (lowering confidence)
// and is recorded in missing. A score is never produced from zero available
// inputs.
type scoreBuilder struct {
	inputs    []models.Input
	missing   []string
	totalW    float64
	availW    float64
	availValW float64
}

func newScore() *scoreBuilder { return &scoreBuilder{} }

// add records an input. value is normalized to [0,1] (clamped) and only counts
// toward the score when available.
func (b *scoreBuilder) add(name, source string, value, weight float64, available bool, reason string) {
	b.totalW += weight
	in := models.Input{Name: name, Source: source, Weight: weight, Available: available, Reason: reason}
	if available {
		v := clamp01(value)
		in.Value = round4(v)
		b.availW += weight
		b.availValW += v * weight
	} else {
		b.missing = append(b.missing, name)
	}
	b.inputs = append(b.inputs, in)
}

// build finalizes the score. ok=false when no input was available. The score is
// the weighted average of available inputs scaled to 0..100; confidence is the
// available-weight share. Contributions are re-expressed as their share of the
// final score so they sum to it.
func (b *scoreBuilder) build() (score, confidence float64, inputs []models.Input, missing []string, ok bool) {
	if b.availW == 0 {
		return 0, 0, nil, nil, false
	}
	score = round2((b.availValW / b.availW) * 100)
	confidence = round4(b.availW / b.totalW)
	out := make([]models.Input, len(b.inputs))
	for i, in := range b.inputs {
		if in.Available {
			in.Contribution = round4((in.Value * in.Weight / b.availW) * 100)
		} else {
			in.Contribution = 0
		}
		out[i] = in
	}
	if b.missing == nil {
		b.missing = []string{}
	}
	return score, confidence, out, b.missing, true
}

func clamp01(x float64) float64 {
	if x < 0 {
		return 0
	}
	if x > 1 {
		return 1
	}
	return x
}
func round4(x float64) float64 { return mathRound(x*10000) / 10000 }

// mathRound avoids importing math twice; small local helper.
func mathRound(x float64) float64 {
	if x < 0 {
		return float64(int(x - 0.5))
	}
	return float64(int(x + 0.5))
}
