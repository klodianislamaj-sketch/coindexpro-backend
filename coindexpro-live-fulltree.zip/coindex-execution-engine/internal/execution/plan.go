package execution

import "github.com/coindexpro/coindex-execution-engine/internal/models"

// Weights are the configurable component weights for the execution quality score.
type Weights struct {
	Liquidity     float64 // deeper real liquidity = better execution
	LowSlippage   float64 // lower modeled slippage at the reference size = better
	EmpiricalDepth float64 // empirical fill depth from real observed swaps
	VolumeSupport float64 // real 24h volume supports execution (more counterparties)
	LowVol        float64 // lower real volatility = steadier fills
	Safety        float64 // lower contract risk = safer to execute
	FlowScale
}

// FlowScale holds normalization scales (embedded for tidy config mapping).
type FlowScale struct {
	LiqFullUSD   float64 // liquidity at/above which the depth component is "full" (1.0)
	RefNotional  float64 // reference trade size used to score slippage
	MaxImpactBps float64 // sizing cap: recommended max size keeps modeled impact <= this
	VolFullStdev float64 // volatility at/above which the low-vol component is 0
	VolFullUSD   float64 // 24h volume at/above which the volume-support component is 1.0
	MinSwaps     float64 // minimum real swaps in window to trust an empirical depth view
}

// DefaultWeights returns documented defaults.
func DefaultWeights() Weights {
	return Weights{
		Liquidity: 0.30, LowSlippage: 0.25, EmpiricalDepth: 0.15, VolumeSupport: 0.10,
		LowVol: 0.10, Safety: 0.10,
		FlowScale: FlowScale{
			LiqFullUSD: 1000000, RefNotional: 10000, MaxImpactBps: 100, VolFullStdev: 0.5,
			VolFullUSD: 1000000, MinSwaps: 5,
		},
	}
}

// BuildPlan computes the execution plan for (token, side) from real inputs. It
// returns ok=false when no real input is available (no fabricated plan). Sizing
// and slippage are only populated when real liquidity exists.
func BuildPlan(in models.ExecInputs, side string, w Weights) (models.ExecutionPlan, bool) {
	b := newScore()

	// --- liquidity depth (real token_metrics.liq_usd) ---
	var liq float64
	hasLiq := in.LiqUSD != nil && *in.LiqUSD > 0
	if hasLiq {
		liq = *in.LiqUSD
		v := normLinear(liq, 0, w.LiqFullUSD)
		b.add("liquidity_depth", "token_metrics.liq_usd", v, w.Liquidity, true, "")
	} else {
		b.add("liquidity_depth", "token_metrics.liq_usd", 0, w.Liquidity, false, "not indexed")
	}

	// --- modeled slippage at reference size (needs real liquidity) ---
	var estSlip *float64
	if hasLiq {
		if bps, ok := SlippageBps(w.RefNotional, liq); ok {
			// lower slippage -> higher quality. map 0..1000bps -> 1..0
			v := normLinear(bps, 1000, 0) // inverted
			b.add("low_slippage", "amm_constant_product(liq_usd)", v, w.LowSlippage, true, "")
			s := bps
			estSlip = &s
		}
	} else {
		b.add("low_slippage", "amm_constant_product(liq_usd)", 0, w.LowSlippage, false, "not indexed")
	}

	// --- empirical fill depth (real observed swaps) ---
	// Only trusted when there are enough real priced swaps in the window; an
	// empirical view from one or two trades is not reliable, so it is reported
	// unavailable rather than overstated. Uses the largest real swap the pool has
	// actually absorbed, adjusted by how the reference size compares to the typical
	// real fill — never an invented depth.
	if in.PricedSwaps > 0 && int64(w.MinSwaps) <= in.SwapCount && in.MaxSwapUSD != nil && *in.MaxSwapUSD > 0 {
		if empBps, ok := EmpiricalSlippageBps(w.RefNotional, *in.MaxSwapUSD); ok {
			v := normLinear(empBps, 2000, 0) // lower empirical slippage -> higher quality
			if in.AvgSwapUSD != nil && *in.AvgSwapUSD > 0 {
				// comfort: reference size near/below the typical real fill = routinely handled
				comfort := normLinear(w.RefNotional/(*in.AvgSwapUSD), 5, 0)
				v = (v + comfort) / 2
			}
			b.add("empirical_depth", "swaps(max/avg over window)", v, w.EmpiricalDepth, true, "")
		} else {
			b.add("empirical_depth", "swaps", 0, w.EmpiricalDepth, false, "not indexed")
		}
	} else {
		reason := "not indexed"
		if in.SwapCount > 0 && in.SwapCount < int64(w.MinSwaps) {
			reason = "insufficient real swaps for an empirical view"
		}
		b.add("empirical_depth", "swaps", 0, w.EmpiricalDepth, false, reason)
	}

	// --- volume support (real token_metrics.vol24h_usd) ---
	if in.Vol24hUSD != nil && *in.Vol24hUSD > 0 {
		v := normLinear(*in.Vol24hUSD, 0, w.VolFullUSD)
		b.add("volume_support", "token_metrics.vol24h_usd", v, w.VolumeSupport, true, "")
	} else {
		b.add("volume_support", "token_metrics.vol24h_usd", 0, w.VolumeSupport, false, "not indexed")
	}

	// --- volatility (real token_metrics.volatility) ---
	if in.Volatility != nil {
		v := normLinear(*in.Volatility, w.VolFullStdev, 0) // inverted: lower vol -> higher
		b.add("low_volatility", "token_metrics.volatility", v, w.LowVol, true, "")
	} else {
		b.add("low_volatility", "token_metrics.volatility", 0, w.LowVol, false, "not indexed")
	}

	// --- contract safety (real contract_analysis.score, inverted) ---
	if in.RiskScore != nil {
		v := normLinear(float64(*in.RiskScore), 100, 0) // inverted: lower risk -> higher
		b.add("contract_safety", "contract_analysis.score(inverted)", v, w.Safety, true, "")
	} else {
		b.add("contract_safety", "contract_analysis.score", 0, w.Safety, false, "not indexed")
	}

	score, confidence, inputs, missing, ok := b.build()
	if !ok {
		return models.ExecutionPlan{}, false
	}

	plan := models.ExecutionPlan{
		PlanID:     side + ":" + in.Chain + ":" + in.Token,
		Chain:      in.Chain, Token: in.Token, Side: side,
		QualityScore: score, Confidence: confidence,
		EstSlippageBps: estSlip,
		Inputs:         inputs, Missing: missing,
		Timing:    timingFor(side, in),
		Rationale: "execution quality = liquidity depth + low modeled slippage + low volatility + contract safety; sizing bounded by real liquidity",
	}

	// --- sizing: recommended max notional bounded by real liquidity + impact cap ---
	if hasLiq {
		if maxN, ok := MaxNotionalForImpact(liq, w.MaxImpactBps); ok {
			plan.MaxNotionalUSD = &maxN
		}
	}
	return plan, true
}

// timingFor derives a timing hint from real strategy signals. A buy is favorable
// when entry is strong; a sell is favorable when exit is strong. Without the
// relevant strategy score, timing is "unknown" (not guessed).
func timingFor(side string, in models.ExecInputs) string {
	switch side {
	case models.SideBuy:
		if in.EntryScore == nil {
			return models.TimingUnknown
		}
		return bandTiming(*in.EntryScore)
	case models.SideSell:
		if in.ExitScore == nil {
			return models.TimingUnknown
		}
		return bandTiming(*in.ExitScore)
	}
	return models.TimingUnknown
}

func bandTiming(score float64) string {
	switch {
	case score >= 66:
		return models.TimingFavorable
	case score >= 33:
		return models.TimingNeutral
	default:
		return models.TimingUnfavorable
	}
}

// SlippageCurve produces modeled slippage at a real probe ladder of sizes, from
// real liquidity. Returns nil when liquidity is unknown (no fabricated curve).
func SlippageCurve(liqUSD float64, ladder []float64, confidence float64) []models.SlippagePoint {
	if liqUSD <= 0 || len(ladder) == 0 {
		return nil
	}
	out := make([]models.SlippagePoint, 0, len(ladder))
	for _, n := range ladder {
		bps, ok := SlippageBps(n, liqUSD)
		if !ok {
			continue
		}
		out = append(out, models.SlippagePoint{
			NotionalUSD: n, EstSlippageBps: bps,
			Method: models.MethodAMM, LiqUSDUsed: liqUSD, Confidence: confidence,
		})
	}
	return out
}

// normLinear maps x in [lo,hi] to [0,1] (clamped). lo>hi inverts (lower-is-better).
func normLinear(x, lo, hi float64) float64 {
	if lo == hi {
		return 0.5
	}
	if lo < hi {
		return clamp01((x - lo) / (hi - lo))
	}
	return clamp01((lo - x) / (lo - hi))
}

