package execution

import (
	"testing"

	"github.com/coindexpro/coindex-execution-engine/internal/models"
)

func fptr(f float64) *float64 { return &f }

// With real liquidity, the plan must populate sizing + modeled slippage.
func TestBuildPlan_WithRealLiquidityPopulatesSizing(t *testing.T) {
	w := DefaultWeights()
	in := models.ExecInputs{
		Chain: "eth", Token: "0xabc",
		LiqUSD:     fptr(1_000_000),
		Vol24hUSD:  fptr(500_000),
		Volatility: fptr(0.2),
		MaxSwapUSD: fptr(50_000),
		SwapCount:  100, PricedSwaps: 100,
	}
	plan, ok := BuildPlan(in, "buy", w)
	if !ok {
		t.Fatal("expected ok=true with real inputs")
	}
	if plan.MaxNotionalUSD == nil {
		t.Fatal("max_notional must be set from real liquidity")
	}
	if plan.EstSlippageBps == nil {
		t.Fatal("est_slippage must be set from real liquidity")
	}
	if plan.Confidence <= 0 || plan.Confidence > 1 {
		t.Fatalf("confidence must be in (0,1], got %v", plan.Confidence)
	}
}

// CORE GATE: without real liquidity, sizing + modeled slippage stay nil — the
// engine never fabricates a notional or impact it cannot ground in real data.
func TestBuildPlan_NoLiquidityLeavesSizingNil(t *testing.T) {
	w := DefaultWeights()
	in := models.ExecInputs{
		Chain: "eth", Token: "0xabc",
		LiqUSD:    nil, // no real liquidity
		Vol24hUSD: fptr(500_000),
	}
	plan, ok := BuildPlan(in, "buy", w)
	if ok && plan.MaxNotionalUSD != nil {
		t.Fatalf("no liquidity must NOT yield a max_notional, got %v", *plan.MaxNotionalUSD)
	}
	if ok && plan.EstSlippageBps != nil {
		t.Fatalf("no liquidity must NOT yield modeled slippage, got %v", *plan.EstSlippageBps)
	}
	// 'missing' must record the absent liquidity input honestly.
	foundMissing := false
	for _, m := range plan.Missing {
		if m != "" {
			foundMissing = true
		}
	}
	if ok && !foundMissing {
		t.Fatal("absent inputs should be recorded in plan.Missing")
	}
}

// Zero inputs entirely -> ok=false (not indexed), never a fabricated plan.
func TestBuildPlan_ZeroInputsUnavailable(t *testing.T) {
	w := DefaultWeights()
	in := models.ExecInputs{Chain: "eth", Token: "0xabc"} // all nil
	plan, ok := BuildPlan(in, "buy", w)
	if ok && plan.MaxNotionalUSD != nil {
		t.Fatal("zero inputs must not produce sizing")
	}
}

// Higher real liquidity -> larger safe notional (monotonic, grounded).
func TestBuildPlan_MoreLiquidityAllowsMoreSize(t *testing.T) {
	w := DefaultWeights()
	mk := func(liq float64) *float64 {
		in := models.ExecInputs{Chain: "eth", Token: "0xabc", LiqUSD: fptr(liq), MaxSwapUSD: fptr(10_000), SwapCount: 50}
		p, ok := BuildPlan(in, "buy", w)
		if !ok {
			return nil
		}
		return p.MaxNotionalUSD
	}
	lo := mk(500_000)
	hi := mk(5_000_000)
	if lo == nil || hi == nil {
		t.Skip("sizing unavailable for one case; nothing to compare")
	}
	if !(*hi > *lo) {
		t.Fatalf("more liquidity must allow >= notional: lo=%v hi=%v", *lo, *hi)
	}
}
