// Package metrics holds the execution-engine's Prometheus instruments. The symbol
// set matches exactly what internal/execution/engine.go references.
package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	Builds = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_execution_builds_total", Help: "Execution build cycles.",
	})
	BuildDuration = promauto.NewHistogram(prometheus.HistogramOpts{
		Name: "coindex_execution_build_seconds", Help: "Execution build duration.",
		Buckets: []float64{0.1, 0.5, 1, 5, 15, 30, 60, 120},
	})
	Plans = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_execution_plans_total", Help: "Execution plans written by side.",
	}, []string{"side"})
	Skipped = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_execution_skipped_total", Help: "Tokens skipped (no available inputs) by reason.",
	}, []string{"reason"})
	APILatency = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name: "coindex_execution_api_seconds", Help: "API latency by route + status.",
		Buckets: prometheus.DefBuckets,
	}, []string{"route", "status"})
	DBErrors = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_execution_db_errors_total", Help: "DB errors.",
	})
)
