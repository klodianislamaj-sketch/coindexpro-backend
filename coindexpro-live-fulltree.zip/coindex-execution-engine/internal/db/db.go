// Package db is the execution-engine persistence layer. It reads REAL upstream
// outputs — ClickHouse token_metrics + swaps (Phase 2) and Postgres
// contract_analysis (Phase 8) + entry_scores/exit_scores (Phase 13) — and persists
// the derived execution plans / liquidity profiles / slippage curves. Every
// nullable upstream value is scanned into a pointer so that "no row" becomes nil
// (unavailable) and never a fabricated zero. This package imports only the models
// package, so there is no import cycle with internal/execution.
package db

import (
	"context"
	"encoding/json"
	"errors"
	"strings"
	"time"

	"github.com/ClickHouse/clickhouse-go/v2"
	"github.com/ClickHouse/clickhouse-go/v2/lib/driver"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/coindexpro/coindex-execution-engine/internal/models"
)

// Store reads upstream signals and persists execution outputs.
type Store struct {
	pg     *pgxpool.Pool
	ch     driver.Conn
	window time.Duration // swap-history lookback for empirical fill stats
}

func Open(ctx context.Context, pgDSN string, chAddrs []string, chDB, chUser, chPass string, swapWindow time.Duration) (*Store, error) {
	pg, err := pgxpool.New(ctx, pgDSN)
	if err != nil {
		return nil, err
	}
	if err := pg.Ping(ctx); err != nil {
		return nil, err
	}
	ch, err := clickhouse.Open(&clickhouse.Options{
		Addr: chAddrs,
		Auth: clickhouse.Auth{Database: chDB, Username: chUser, Password: chPass},
	})
	if err != nil {
		return nil, err
	}
	if err := ch.Ping(ctx); err != nil {
		return nil, err
	}
	if swapWindow <= 0 {
		swapWindow = 24 * time.Hour
	}
	return &Store{pg: pg, ch: ch, window: swapWindow}, nil
}

func (s *Store) Close() {
	s.pg.Close()
	_ = s.ch.Close()
}
func (s *Store) Ping(ctx context.Context) error {
	if err := s.pg.Ping(ctx); err != nil {
		return err
	}
	return s.ch.Ping(ctx)
}

// ---------- sources: tracked subjects ----------

// TrackedTokens draws the execution universe from REAL measured market data:
// distinct tokens with a recent token_metrics row in ClickHouse. These are exactly
// the tokens for which we have real liquidity/volatility to reason about; we do
// not invent a watchlist.
func (s *Store) TrackedTokens(ctx context.Context, limit int) ([]models.TokenRef, error) {
	const q = `
		SELECT DISTINCT chain, token
		FROM coindex.token_metrics
		ORDER BY chain, token
		LIMIT ?`
	rows, err := s.ch.Query(ctx, q, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.TokenRef
	for rows.Next() {
		var t models.TokenRef
		if err := rows.Scan(&t.Chain, &t.Token); err != nil {
			return nil, err
		}
		t.Token = strings.ToLower(t.Token)
		out = append(out, t)
	}
	return out, rows.Err()
}

// ---------- sources: real inputs per subject (nil = unavailable) ----------

// ExecInputs gathers every real execution input for a token. Each field is left
// nil when its source has no row, so the scorer records it unavailable.
func (s *Store) ExecInputs(ctx context.Context, chain, token string) (models.ExecInputs, error) {
	token = strings.ToLower(token)
	in := models.ExecInputs{Chain: chain, Token: token}

	// Phase 2 token_metrics (latest row) — liquidity / volume / volatility
	liq, vol24, volat, hasMetrics := s.latestMetrics(ctx, chain, token)
	if hasMetrics {
		if liq > 0 {
			l := liq
			in.LiqUSD = &l
		}
		if vol24 > 0 {
			v := vol24
			in.Vol24hUSD = &v
		}
		if volat > 0 {
			vv := volat
			in.Volatility = &vv
		}
	}

	// Phase 2 swaps — empirical fill stats over the window
	cnt, avg, mx, priced := s.swapStats(ctx, chain, token)
	in.SwapCount = cnt
	in.PricedSwaps = priced
	if priced > 0 {
		if avg > 0 {
			a := avg
			in.AvgSwapUSD = &a
		}
		if mx > 0 {
			m := mx
			in.MaxSwapUSD = &m
		}
	}

	// Phase 8 contract_analysis.score (Postgres)
	{
		const q = `SELECT score FROM contract_analysis WHERE chain=$1 AND address=$2`
		var sc int
		err := s.pg.QueryRow(ctx, q, chain, token).Scan(&sc)
		if err == nil {
			in.RiskScore = &sc
		} else if !errors.Is(err, pgx.ErrNoRows) {
			return in, err
		}
	}

	// Phase 13 entry_scores / exit_scores (Postgres)
	{
		const q = `SELECT score FROM entry_scores WHERE chain=$1 AND token=$2`
		var sc float64
		err := s.pg.QueryRow(ctx, q, chain, token).Scan(&sc)
		if err == nil {
			in.EntryScore = &sc
		} else if !errors.Is(err, pgx.ErrNoRows) {
			return in, err
		}
	}
	{
		const q = `SELECT score FROM exit_scores WHERE chain=$1 AND token=$2`
		var sc float64
		err := s.pg.QueryRow(ctx, q, chain, token).Scan(&sc)
		if err == nil {
			in.ExitScore = &sc
		} else if !errors.Is(err, pgx.ErrNoRows) {
			return in, err
		}
	}
	return in, nil
}

// latestMetrics reads the most recent token_metrics row. Absence surfaces as a
// scan error from ClickHouse, which we treat as "not measured" (hasMetrics=false)
// rather than failing the whole token.
func (s *Store) latestMetrics(ctx context.Context, chain, token string) (liq, vol24, volat float64, ok bool) {
	const q = `
		SELECT liq_usd, vol24h_usd, volatility
		FROM coindex.token_metrics
		WHERE chain = ? AND token = ?
		ORDER BY ts DESC LIMIT 1`
	if err := s.ch.QueryRow(ctx, q, chain, token).Scan(&liq, &vol24, &volat); err != nil {
		return 0, 0, 0, false
	}
	return liq, vol24, volat, true
}

// swapStats aggregates real swaps over the window for empirical fill context.
// Returns zeros when there are no swaps (the caller then leaves the pointers nil).
func (s *Store) swapStats(ctx context.Context, chain, token string) (count int64, avgUSD, maxUSD float64, priced int64) {
	since := time.Now().Add(-s.window)
	// a swap involves the token on either side (token_in or token_out)
	const q = `
		SELECT
			count() AS c,
			avgIf(amount_usd, amount_usd > 0) AS a,
			maxIf(amount_usd, amount_usd > 0) AS m,
			countIf(amount_usd > 0) AS p
		FROM coindex.swaps
		WHERE chain = ? AND (token_in = ? OR token_out = ?) AND block_time >= ?`
	var c, p uint64
	var a, m float64
	if err := s.ch.QueryRow(ctx, q, chain, token, token, since).Scan(&c, &a, &m, &p); err != nil {
		return 0, 0, 0, 0
	}
	return int64(c), a, m, int64(p)
}

// LiquidityProfile builds the per-token measured liquidity profile from real
// token_metrics + swaps. ok=false when there is neither a metrics row nor any
// swap history — i.e. nothing real to profile.
func (s *Store) LiquidityProfile(ctx context.Context, chain, token string) (models.LiquidityProfile, bool, error) {
	token = strings.ToLower(token)
	lp := models.LiquidityProfile{Chain: chain, Token: token, TS: time.Now().UTC()}

	liq, vol24, volat, hasMetrics := s.latestMetrics(ctx, chain, token)
	if hasMetrics {
		if liq > 0 {
			l := liq
			lp.LiqUSD = &l
		}
		if vol24 > 0 {
			v := vol24
			lp.Vol24hUSD = &v
		}
		if volat > 0 {
			vv := volat
			lp.Volatility = &vv
		}
	}
	cnt, avg, mx, priced := s.swapStats(ctx, chain, token)
	lp.SwapCount = cnt
	lp.PricedSwaps = priced
	if priced > 0 {
		if avg > 0 {
			a := avg
			lp.AvgSwapUSD = &a
		}
		if mx > 0 {
			m := mx
			lp.MaxSwapUSD = &m
		}
	}

	if !hasMetrics && cnt == 0 {
		return models.LiquidityProfile{}, false, nil
	}
	return lp, true, nil
}

// ---------- sink: idempotent persistence ----------

func (s *Store) UpsertPlan(ctx context.Context, p models.ExecutionPlan) error {
	inputs, _ := json.Marshal(p.Inputs)
	missing, _ := json.Marshal(p.Missing)
	const q = `
		INSERT INTO execution_plans
			(plan_id, chain, token, side, max_notional_usd, est_slippage_bps,
			 quality_score, confidence, timing, inputs, missing, rationale)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
		ON CONFLICT (plan_id) DO UPDATE SET
			max_notional_usd=$5, est_slippage_bps=$6, quality_score=$7, confidence=$8,
			timing=$9, inputs=$10, missing=$11, rationale=$12, computed_at=now()`
	_, err := s.pg.Exec(ctx, q, p.PlanID, p.Chain, p.Token, p.Side,
		p.MaxNotionalUSD, p.EstSlippageBps, p.QualityScore, p.Confidence, p.Timing,
		inputs, missing, p.Rationale)
	return err
}

func (s *Store) UpsertLiquidityProfile(ctx context.Context, lp models.LiquidityProfile) error {
	const q = `
		INSERT INTO liquidity_profiles
			(chain, token, ts, liq_usd, vol24h_usd, volatility, swap_count, avg_swap_usd, max_swap_usd, priced_swaps)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
		ON CONFLICT (chain, token) DO UPDATE SET
			ts=$3, liq_usd=$4, vol24h_usd=$5, volatility=$6, swap_count=$7,
			avg_swap_usd=$8, max_swap_usd=$9, priced_swaps=$10, updated_at=now()`
	_, err := s.pg.Exec(ctx, q, lp.Chain, lp.Token, lp.TS, lp.LiqUSD, lp.Vol24hUSD, lp.Volatility,
		lp.SwapCount, lp.AvgSwapUSD, lp.MaxSwapUSD, lp.PricedSwaps)
	return err
}

// ReplaceSlippageCurve rewrites a token's curve in one tx so it always reflects
// the latest liquidity (no stale ladder points).
func (s *Store) ReplaceSlippageCurve(ctx context.Context, chain, token string, pts []models.SlippagePoint) error {
	token = strings.ToLower(token)
	tx, err := s.pg.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	if _, err := tx.Exec(ctx, `DELETE FROM slippage_curves WHERE chain=$1 AND token=$2`, chain, token); err != nil {
		return err
	}
	for _, p := range pts {
		const q = `
			INSERT INTO slippage_curves
				(chain, token, notional_usd, est_slippage_bps, method, liq_usd_used, confidence)
			VALUES ($1,$2,$3,$4,$5,$6,$7)`
		if _, err := tx.Exec(ctx, q, chain, token, p.NotionalUSD, p.EstSlippageBps,
			p.Method, p.LiqUSDUsed, p.Confidence); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

// ---------- API reads ----------

// Plans returns the buy + sell plans for a token (whichever exist).
func (s *Store) Plans(ctx context.Context, chain, token string) ([]models.ExecutionPlan, error) {
	const q = `
		SELECT plan_id, chain, token, side, max_notional_usd, est_slippage_bps,
		       quality_score, confidence, timing, inputs, missing, rationale, computed_at
		FROM execution_plans WHERE chain=$1 AND token=$2 ORDER BY side`
	rows, err := s.pg.Query(ctx, q, chain, strings.ToLower(token))
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanPlans(rows)
}

// PlanByID loads one plan for /execution/explain.
func (s *Store) PlanByID(ctx context.Context, id string) (models.ExecutionPlan, bool, error) {
	const q = `
		SELECT plan_id, chain, token, side, max_notional_usd, est_slippage_bps,
		       quality_score, confidence, timing, inputs, missing, rationale, computed_at
		FROM execution_plans WHERE plan_id=$1`
	rows, err := s.pg.Query(ctx, q, id)
	if err != nil {
		return models.ExecutionPlan{}, false, err
	}
	defer rows.Close()
	ps, err := scanPlans(rows)
	if err != nil {
		return models.ExecutionPlan{}, false, err
	}
	if len(ps) == 0 {
		return models.ExecutionPlan{}, false, nil
	}
	return ps[0], true, nil
}

// SlippageCurve returns the stored modeled curve for a token.
func (s *Store) SlippageCurve(ctx context.Context, chain, token string) ([]models.SlippagePoint, error) {
	const q = `
		SELECT notional_usd, est_slippage_bps, method, liq_usd_used, confidence
		FROM slippage_curves WHERE chain=$1 AND token=$2 ORDER BY notional_usd`
	rows, err := s.pg.Query(ctx, q, chain, strings.ToLower(token))
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.SlippagePoint
	for rows.Next() {
		var p models.SlippagePoint
		if err := rows.Scan(&p.NotionalUSD, &p.EstSlippageBps, &p.Method, &p.LiqUSDUsed, &p.Confidence); err != nil {
			return nil, err
		}
		out = append(out, p)
	}
	return out, rows.Err()
}

// GetLiquidityProfile returns the stored profile for a token.
func (s *Store) GetLiquidityProfile(ctx context.Context, chain, token string) (models.LiquidityProfile, bool, error) {
	const q = `
		SELECT chain, token, ts, liq_usd, vol24h_usd, volatility, swap_count, avg_swap_usd, max_swap_usd, priced_swaps
		FROM liquidity_profiles WHERE chain=$1 AND token=$2`
	var lp models.LiquidityProfile
	err := s.pg.QueryRow(ctx, q, chain, strings.ToLower(token)).Scan(
		&lp.Chain, &lp.Token, &lp.TS, &lp.LiqUSD, &lp.Vol24hUSD, &lp.Volatility,
		&lp.SwapCount, &lp.AvgSwapUSD, &lp.MaxSwapUSD, &lp.PricedSwaps)
	if errors.Is(err, pgx.ErrNoRows) {
		return models.LiquidityProfile{}, false, nil
	}
	if err != nil {
		return models.LiquidityProfile{}, false, err
	}
	return lp, true, nil
}

// RecentPlans returns the most recently computed plans for /execution/feed.
func (s *Store) RecentPlans(ctx context.Context, limit int) ([]models.ExecutionPlan, error) {
	const q = `
		SELECT plan_id, chain, token, side, max_notional_usd, est_slippage_bps,
		       quality_score, confidence, timing, inputs, missing, rationale, computed_at
		FROM execution_plans ORDER BY computed_at DESC LIMIT $1`
	rows, err := s.pg.Query(ctx, q, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanPlans(rows)
}

func scanPlans(rows pgx.Rows) ([]models.ExecutionPlan, error) {
	var out []models.ExecutionPlan
	for rows.Next() {
		var p models.ExecutionPlan
		var inputs, missing []byte
		if err := rows.Scan(&p.PlanID, &p.Chain, &p.Token, &p.Side, &p.MaxNotionalUSD, &p.EstSlippageBps,
			&p.QualityScore, &p.Confidence, &p.Timing, &inputs, &missing, &p.Rationale, &p.ComputedAt); err != nil {
			return nil, err
		}
		_ = json.Unmarshal(inputs, &p.Inputs)
		_ = json.Unmarshal(missing, &p.Missing)
		out = append(out, p)
	}
	return out, rows.Err()
}
