// Package models holds the execution-engine's shared domain types. The
// explainability contract lives in the type model: an ExecutionPlan is built from
// Inputs, each of which records whether its upstream value was Available, its
// Weight, and its Contribution. Confidence is the share of weight backed by real
// inputs — so a plan computed from partial data is never presented as complete,
// and a slippage/size figure is never emitted without the real measurement behind
// it.
package models

import "time"

// Sides.
const (
	SideBuy  = "buy"
	SideSell = "sell"
)

// Slippage estimation methods (both transparent + reproducible).
const (
	MethodAMM       = "amm_constant_product" // modeled from real liq_usd
	MethodEmpirical = "empirical_swaps"       // measured from real swaps
)

// Timing hints.
const (
	TimingFavorable   = "favorable"
	TimingNeutral     = "neutral"
	TimingUnfavorable = "unfavorable"
	TimingUnknown     = "unknown"
)

// Input is one explainable contributor to an execution quality score.
type Input struct {
	Name         string  `json:"name"`
	Value        float64 `json:"value"`        // normalized [0,1] (0 when unavailable)
	Weight       float64 `json:"weight"`
	Contribution float64 `json:"contribution"` // share of the final score; 0 when unavailable
	Available    bool    `json:"available"`
	Source       string  `json:"source"`       // upstream table the value came from
	Reason       string  `json:"reason,omitempty"`
}

// SlippagePoint is one (size -> estimated bps) sample on a token's slippage curve.
type SlippagePoint struct {
	NotionalUSD    float64 `json:"notional_usd"`
	EstSlippageBps float64 `json:"est_slippage_bps"`
	Method         string  `json:"method"`
	LiqUSDUsed     float64 `json:"liq_usd_used"`
	Confidence     float64 `json:"confidence"`
}

// LiquidityProfile is the per-token measured liquidity context.
type LiquidityProfile struct {
	Chain       string    `json:"chain"`
	Token       string    `json:"token"`
	TS          time.Time `json:"ts"`
	LiqUSD      *float64  `json:"liq_usd,omitempty"`
	Vol24hUSD   *float64  `json:"vol24h_usd,omitempty"`
	Volatility  *float64  `json:"volatility,omitempty"`
	SwapCount   int64     `json:"swap_count"`
	AvgSwapUSD  *float64  `json:"avg_swap_usd,omitempty"`
	MaxSwapUSD  *float64  `json:"max_swap_usd,omitempty"`
	PricedSwaps int64     `json:"priced_swaps"`
}

// ExecutionPlan is the explainable execution-quality output for a (token, side).
type ExecutionPlan struct {
	PlanID         string    `json:"plan_id"`
	Chain          string    `json:"chain"`
	Token          string    `json:"token"`
	Side           string    `json:"side"`
	MaxNotionalUSD *float64  `json:"max_notional_usd,omitempty"` // nil when liquidity unknown
	EstSlippageBps *float64  `json:"est_slippage_bps,omitempty"`
	QualityScore   float64   `json:"quality_score"`
	Confidence     float64   `json:"confidence"`
	Timing         string    `json:"timing"`
	Inputs         []Input   `json:"inputs"`
	Missing        []string  `json:"missing"`
	Rationale      string    `json:"rationale"`
	ComputedAt     time.Time `json:"computed_at,omitempty"`
}

// ExecInputs are the REAL upstream signals for a token. Each pointer is nil when
// its source has no row — the scorer treats nil as unavailable, never as zero.
type ExecInputs struct {
	Chain string
	Token string

	// Phase 2 token_metrics (ClickHouse)
	LiqUSD     *float64
	Vol24hUSD  *float64
	Volatility *float64
	// Phase 2 swaps (ClickHouse) — empirical fill context
	SwapCount   int64
	AvgSwapUSD  *float64
	MaxSwapUSD  *float64
	PricedSwaps int64
	// Phase 8 contract_analysis.score (0..100 higher = riskier)
	RiskScore *int
	// Phase 13 strategy timing signals (0..100)
	EntryScore *float64
	ExitScore  *float64
}

// TokenRef is a lightweight subject reference drawn from real upstream tables.
type TokenRef struct {
	Chain string
	Token string
}
