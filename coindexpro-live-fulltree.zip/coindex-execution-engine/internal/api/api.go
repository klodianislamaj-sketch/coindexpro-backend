// Package api serves the execution-intelligence reads. Any "no real data" path
// returns the mandated {available:false, reason:"not indexed"} envelope, and
// /explain returns the full input/weight/confidence/missing breakdown so every
// plan is auditable. A plan with no recommended size says so explicitly (size is
// only present when real liquidity exists).
package api

import (
	"regexp"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"

	"github.com/coindexpro/coindex-execution-engine/internal/db"
	"github.com/coindexpro/coindex-execution-engine/internal/metrics"
)

type API struct{ store *db.Store }

func New(store *db.Store) *API { return &API{store: store} }

// Register orders static routes before parameterized ones.
func (a *API) Register(app *fiber.App) {
	app.Use(a.observe)
	app.Get("/execution/feed", a.feed)
	app.Get("/execution/explain/:plan_id", a.explain)
	app.Get("/execution/plan/:chain/:token", a.plan)
	app.Get("/execution/slippage/:chain/:token", a.slippage)
	app.Get("/execution/liquidity/:chain/:token", a.liquidity)
}

func (a *API) observe(c *fiber.Ctx) error {
	start := time.Now()
	err := c.Next()
	metrics.APILatency.WithLabelValues(c.Route().Path, statusClass(c.Response().StatusCode())).
		Observe(time.Since(start).Seconds())
	return err
}

var evmAddr = regexp.MustCompile(`^0x[0-9a-fA-F]{40}$`)

func tokenParams(c *fiber.Ctx) (chain, token string, ok bool) {
	chain = strings.ToLower(c.Params("chain"))
	token = strings.ToLower(c.Params("token"))
	if chain == "" || !evmAddr.MatchString(token) {
		return "", "", false
	}
	return chain, token, true
}

func notIndexed(c *fiber.Ctx, extra fiber.Map) error {
	m := fiber.Map{"available": false, "reason": "not indexed"}
	for k, v := range extra {
		m[k] = v
	}
	return c.JSON(m)
}

// GET /execution/plan/:chain/:token
func (a *API) plan(c *fiber.Ctx) error {
	chain, token, ok := tokenParams(c)
	if !ok {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid chain or token"})
	}
	plans, err := a.store.Plans(c.UserContext(), chain, token)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(plans) == 0 {
		return notIndexed(c, fiber.Map{"chain": chain, "token": token})
	}
	return c.JSON(fiber.Map{"chain": chain, "token": token, "available": true, "plans": plans})
}

// GET /execution/slippage/:chain/:token
func (a *API) slippage(c *fiber.Ctx) error {
	chain, token, ok := tokenParams(c)
	if !ok {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid chain or token"})
	}
	pts, err := a.store.SlippageCurve(c.UserContext(), chain, token)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(pts) == 0 {
		return notIndexed(c, fiber.Map{"chain": chain, "token": token})
	}
	return c.JSON(fiber.Map{"chain": chain, "token": token, "available": true, "curve": pts})
}

// GET /execution/liquidity/:chain/:token
func (a *API) liquidity(c *fiber.Ctx) error {
	chain, token, ok := tokenParams(c)
	if !ok {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid chain or token"})
	}
	lp, found, err := a.store.GetLiquidityProfile(c.UserContext(), chain, token)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !found {
		return notIndexed(c, fiber.Map{"chain": chain, "token": token})
	}
	return c.JSON(fiber.Map{"chain": chain, "token": token, "available": true, "liquidity": lp})
}

// GET /execution/explain/:plan_id
func (a *API) explain(c *fiber.Ctx) error {
	id := c.Params("plan_id")
	if id == "" {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "missing plan_id"})
	}
	plan, found, err := a.store.PlanByID(c.UserContext(), id)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !found {
		return notIndexed(c, fiber.Map{"plan_id": id})
	}
	return c.JSON(fiber.Map{"available": true, "plan": plan})
}

// GET /execution/feed
func (a *API) feed(c *fiber.Ctx) error {
	limit := clamp(c.QueryInt("limit", 50), 1, 200)
	plans, err := a.store.RecentPlans(c.UserContext(), limit)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(plans) == 0 {
		return notIndexed(c, nil)
	}
	return c.JSON(fiber.Map{"available": true, "feed": plans})
}

func clamp(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}

func statusClass(code int) string {
	switch {
	case code >= 500:
		return "5xx"
	case code >= 400:
		return "4xx"
	default:
		return "2xx"
	}
}
