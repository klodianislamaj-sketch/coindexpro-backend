-- =============================================================================
-- CoinDex Execution Intelligence Engine — PostgreSQL migration (Phase 14)
-- =============================================================================
-- Computes EXECUTION-QUALITY estimates (slippage, liquidity depth, position
-- sizing, timing) strictly from REAL upstream measurements:
--   * token_metrics.liq_usd / vol24h_usd / volatility   (Phase 2, ClickHouse)
--   * swaps.amount_usd / price_usd / side               (Phase 2, ClickHouse)
--   * contract_analysis.score                           (Phase 8)
--   * entry_scores / exit_scores                         (Phase 13)
--
-- HARD RULE: slippage, liquidity, volatility and sizing are NEVER fabricated. If
-- the required real input is absent, the field is recorded unavailable and the API
-- reports {"available": false, "reason": "not indexed"} — there is no default or
-- guessed number anywhere in this schema or its writers.
--
-- All NEW tables (no prior phase defines them); idempotent.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- liquidity_profiles — per-token measured liquidity context for one window.
-- Every value here is copied from a real token_metrics row (or computed directly
-- from real swaps); a token with no token_metrics row gets no profile.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS liquidity_profiles (
    chain          text        NOT NULL,
    token          text        NOT NULL CHECK (token = lower(token)),
    ts             timestamptz NOT NULL,
    liq_usd        numeric,                              -- token_metrics.liq_usd (NULL if not measured)
    vol24h_usd     numeric,                              -- token_metrics.vol24h_usd
    volatility     numeric,                              -- token_metrics.volatility (stdev of returns)
    -- empirical fill stats from real swaps in the window (NULL if no swaps):
    swap_count     bigint      NOT NULL DEFAULT 0,
    avg_swap_usd   numeric,                              -- mean real amount_usd of priced swaps
    max_swap_usd   numeric,                              -- largest real priced swap observed
    priced_swaps   bigint      NOT NULL DEFAULT 0,       -- swaps with amount_usd>0 (coverage basis)
    updated_at     timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (chain, token)
);
CREATE INDEX IF NOT EXISTS idx_lp_liq ON liquidity_profiles (chain, liq_usd DESC) WHERE liq_usd IS NOT NULL;

-- -----------------------------------------------------------------------------
-- slippage_curves — modeled slippage (in basis points) at several REAL trade
-- sizes for a token, derived from its measured liquidity via a transparent
-- constant-product price-impact model. The model + liquidity used are stored so
-- the curve is reproducible. notional_usd are absolute sizes (not invented sizes:
-- they are the configured probe ladder, e.g. 1k/5k/25k/100k).
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS slippage_curves (
    chain         text        NOT NULL,
    token         text        NOT NULL CHECK (token = lower(token)),
    notional_usd  numeric     NOT NULL CHECK (notional_usd > 0),
    est_slippage_bps numeric  NOT NULL CHECK (est_slippage_bps >= 0),
    method        text        NOT NULL CHECK (method IN ('amm_constant_product','empirical_swaps')),
    liq_usd_used  numeric     NOT NULL,                  -- the real liquidity the estimate used
    confidence    numeric     NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    computed_at   timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (chain, token, notional_usd)
);

-- -----------------------------------------------------------------------------
-- execution_plans — the explainable execution-quality record for a (token, side).
-- It bundles a recommended max size (bounded by real liquidity + a max-impact
-- cap), an estimated slippage at that size, a timing hint, and a transparent
-- breakdown of inputs/weights/confidence/missing. A plan is NEVER written without
-- at least one real measured input.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS execution_plans (
    plan_id        text        PRIMARY KEY,              -- "<side>:<chain>:<token>"
    chain          text        NOT NULL,
    token          text        NOT NULL CHECK (token = lower(token)),
    side           text        NOT NULL CHECK (side IN ('buy','sell')),
    -- recommended max notional that keeps modeled impact under the cap; NULL when
    -- liquidity is unknown (cannot size without a real liquidity figure).
    max_notional_usd numeric   CHECK (max_notional_usd IS NULL OR max_notional_usd >= 0),
    est_slippage_bps numeric   CHECK (est_slippage_bps IS NULL OR est_slippage_bps >= 0),
    quality_score  numeric     NOT NULL CHECK (quality_score BETWEEN 0 AND 100),
    confidence     numeric     NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    timing         text        NOT NULL CHECK (timing IN ('favorable','neutral','unfavorable','unknown')),
    inputs         jsonb       NOT NULL,                 -- [{name,value,weight,contribution,available,source,reason}]
    missing        jsonb       NOT NULL DEFAULT '[]'::jsonb,
    rationale      text        NOT NULL,
    computed_at    timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT chk_inputs_nonempty CHECK (jsonb_array_length(inputs) > 0)
);
CREATE INDEX IF NOT EXISTS idx_ep_token ON execution_plans (chain, token, side);
CREATE INDEX IF NOT EXISTS idx_ep_quality ON execution_plans (chain, quality_score DESC);
