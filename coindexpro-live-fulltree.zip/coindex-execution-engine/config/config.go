// Package config loads execution-engine configuration from YAML with ${ENV} expansion.
package config

import (
	"fmt"
	"os"
	"time"

	"gopkg.in/yaml.v3"

	"github.com/coindexpro/coindex-execution-engine/internal/execution"
)

type Config struct {
	Server     ServerConfig     `yaml:"server"`
	Postgres   PostgresConfig   `yaml:"postgres"`
	ClickHouse ClickHouseConfig `yaml:"clickhouse"`
	Redis      RedisConfig      `yaml:"redis"`
	Kafka      KafkaConfig      `yaml:"kafka"`
	Build      BuildConfig      `yaml:"build"`
	Weights    WeightsConfig    `yaml:"weights"`
	Log        LogConfig        `yaml:"log"`
}

type ServerConfig struct {
	APIAddr     string `yaml:"api_addr"`
	MetricsAddr string `yaml:"metrics_addr"`
}
type PostgresConfig struct {
	DSN string `yaml:"dsn"`
}
type ClickHouseConfig struct {
	Addrs    []string `yaml:"addrs"`
	Database string   `yaml:"database"`
	Username string   `yaml:"username"`
	Password string   `yaml:"password"`
}
type RedisConfig struct {
	Addr string `yaml:"addr"`
}
type KafkaConfig struct {
	Enabled  bool          `yaml:"enabled"`
	Brokers  []string      `yaml:"brokers"`
	GroupID  string        `yaml:"group_id"`
	Topics   []string      `yaml:"topics"`
	Debounce time.Duration `yaml:"debounce"`
}
type BuildConfig struct {
	Enabled        bool          `yaml:"enabled"`
	Interval       time.Duration `yaml:"interval"`
	MaxTokens      int           `yaml:"max_tokens"`
	SwapWindow     time.Duration `yaml:"swap_window"`
	SlippageLadder []float64     `yaml:"slippage_ladder"`
	CacheTTL       time.Duration `yaml:"cache_ttl"`
}

// WeightsConfig mirrors execution.Weights (0 => documented default).
type WeightsConfig struct {
	Liquidity    float64 `yaml:"liquidity"`
	LowSlippage  float64 `yaml:"low_slippage"`
	EmpiricalDepth float64 `yaml:"empirical_depth"`
	VolumeSupport float64 `yaml:"volume_support"`
	LowVol       float64 `yaml:"low_volatility"`
	Safety       float64 `yaml:"safety"`
	LiqFullUSD   float64 `yaml:"liq_full_usd"`
	RefNotional  float64 `yaml:"ref_notional_usd"`
	MaxImpactBps float64 `yaml:"max_impact_bps"`
	VolFullStdev float64 `yaml:"vol_full_stdev"`
	VolFullUSD   float64 `yaml:"vol_full_usd"`
	MinSwaps     float64 `yaml:"min_swaps"`
}
type LogConfig struct {
	Level string `yaml:"level"`
}

func Load(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}
	var c Config
	if err := yaml.Unmarshal([]byte(os.Expand(string(raw), os.Getenv)), &c); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}
	c.defaults()
	return &c, c.validate()
}

func (c *Config) defaults() {
	if c.Server.APIAddr == "" {
		c.Server.APIAddr = ":8100"
	}
	if c.Server.MetricsAddr == "" {
		c.Server.MetricsAddr = ":9112"
	}
	if c.Build.Interval == 0 {
		c.Build.Interval = 5 * time.Minute
	}
	if c.Build.MaxTokens == 0 {
		c.Build.MaxTokens = 1000
	}
	if c.Build.SwapWindow == 0 {
		c.Build.SwapWindow = 24 * time.Hour
	}
	if len(c.Build.SlippageLadder) == 0 {
		c.Build.SlippageLadder = []float64{1000, 5000, 25000, 100000}
	}
	if c.Build.CacheTTL == 0 {
		c.Build.CacheTTL = 30 * time.Second
	}
	if c.Kafka.GroupID == "" {
		c.Kafka.GroupID = "coindex-execution-engine"
	}
}

func (c *Config) validate() error {
	if c.Postgres.DSN == "" {
		return fmt.Errorf("postgres.dsn empty")
	}
	if len(c.ClickHouse.Addrs) == 0 {
		return fmt.Errorf("clickhouse.addrs empty")
	}
	if c.Redis.Addr == "" {
		return fmt.Errorf("redis.addr empty")
	}
	if c.Kafka.Enabled && len(c.Kafka.Brokers) == 0 {
		return fmt.Errorf("kafka.enabled but brokers empty")
	}
	return nil
}

// ResolveWeights overlays configured weights onto the documented defaults.
func (c *Config) ResolveWeights() execution.Weights {
	w := execution.DefaultWeights()
	set := func(dst *float64, v float64) {
		if v != 0 {
			*dst = v
		}
	}
	set(&w.Liquidity, c.Weights.Liquidity)
	set(&w.LowSlippage, c.Weights.LowSlippage)
	set(&w.EmpiricalDepth, c.Weights.EmpiricalDepth)
	set(&w.VolumeSupport, c.Weights.VolumeSupport)
	set(&w.LowVol, c.Weights.LowVol)
	set(&w.Safety, c.Weights.Safety)
	set(&w.LiqFullUSD, c.Weights.LiqFullUSD)
	set(&w.RefNotional, c.Weights.RefNotional)
	set(&w.MaxImpactBps, c.Weights.MaxImpactBps)
	set(&w.VolFullStdev, c.Weights.VolFullStdev)
	set(&w.VolFullUSD, c.Weights.VolFullUSD)
	set(&w.MinSwaps, c.Weights.MinSwaps)
	return w
}
