## coindex-execution-engine — Phase 14

Execution-intelligence layer. It turns **real upstream measurements** into
explainable execution-quality outputs: per-token liquidity profiles, modeled
slippage curves, position sizing bounded by real liquidity, and per-side
execution plans. It ingests nothing new — it reads existing tables only.

### The hard rule (rules 5 + 7)

**Slippage, liquidity, volatility, and sizing are never fabricated.** Every number
is a function of a real measured input. When the required real input is absent:

- a component is recorded **unavailable** (lowering confidence, listed in `missing`),
- size / slippage are **omitted** (nil), not defaulted,
- and if a token has **no liquidity and no swap history**, no plan is produced and
  the API returns `{"available": false, "reason": "not indexed"}`.

### Source-of-truth mapping (verified on disk)

| Output / component | Real source |
|---|---|
| `liquidity_depth`, sizing, modeled slippage | Phase 2 `token_metrics.liq_usd` (ClickHouse) |
| `volume_support` | Phase 2 `token_metrics.vol24h_usd` |
| `low_volatility` | Phase 2 `token_metrics.volatility` |
| `empirical_depth` | Phase 2 `swaps.amount_usd` over a window (max/avg/count/priced) |
| `contract_safety` | Phase 8 `contract_analysis.score` (inverted) |
| `timing` (favorable/neutral/unfavorable) | Phase 13 `entry_scores` / `exit_scores` |

Tracked tokens are drawn from real `token_metrics` rows — the tokens for which we
actually have market data — never an invented watchlist.

### Slippage model (transparent, reproducible)

Modeled slippage uses the **constant-product (x·y=k)** price-impact approximation
against the real measured liquidity: for notional `n` and one-sided reserve
`R ≈ liq/2`, impact = `n / (R + n)`, expressed in bps. The `method`
(`amm_constant_product`) and the exact `liq_usd_used` are stored with every curve
point, so each estimate is reproducible. It is labeled a **model estimate**, not a
measured fill.

`empirical_depth` complements the model with what the pool has **actually
absorbed**: it derives a coarse slippage proxy from the largest real priced swap
in the window, adjusted by the typical real fill size. It is only trusted when
there are at least `min_swaps` real swaps — an empirical view from one or two
trades is reported unavailable, not overstated.

### Position sizing

The recommended `max_notional_usd` is the largest notional whose **modeled** impact
stays at or below the configured `max_impact_bps`, solved directly from the real
liquidity (`n ≤ b·R/(1−b)`). With no real liquidity figure, size is left nil — the
engine never guesses a size.

### Explainability contract

Every plan exposes its `inputs` (each with `value`, `weight`, `contribution`,
`available`, `source`), the `missing` inputs, and a `confidence`:

```
confidence = (sum of weights of AVAILABLE inputs) / (sum of ALL weights)
quality    = weighted average of available inputs, scaled to 0..100
```

A plan is **never** produced from zero available inputs. Default component weights:
liquidity 0.30 · low-slippage 0.25 · empirical-depth 0.15 · volume-support 0.10 ·
low-volatility 0.10 · contract-safety 0.10 (all configurable; the builder
normalizes by available weight, so a missing input simply lowers confidence).

### Outputs (tables)

`liquidity_profiles` (real measured context), `slippage_curves` (modeled ladder
from real liquidity), `execution_plans` (the explainable per-side record keyed by
`plan_id = "<side>:<chain>:<token>"`).

### API

| Route | Returns |
|---|---|
| `GET /execution/plan/:chain/:token` | buy + sell plans (or not indexed) |
| `GET /execution/slippage/:chain/:token` | modeled slippage curve (or not indexed) |
| `GET /execution/liquidity/:chain/:token` | measured liquidity profile (or not indexed) |
| `GET /execution/explain/:plan_id` | full inputs + weights + confidence + missing |
| `GET /execution/feed` | most recent plans |

Static routes are registered before parameterized ones. Ops: `/healthz`,
`/readyz`, `/metrics`.

### Idempotency & replay

`execution_plans` and `liquidity_profiles` upsert on their natural keys;
`slippage_curves` is rewritten per token in a transaction (delete+insert) so the
ladder always reflects the latest real liquidity. Builds are deterministic over
the same upstream snapshot.

### Honest boundaries / runtime limitations

- **Real, production-shaped code, NOT compiled or run here** (no Go toolchain, no
  Postgres/ClickHouse/Redis/Kafka, no network). Statically reviewed: imports/
  symbols/interfaces resolve, no import cycle (`db` and `execution` both depend
  only on `models`), routes ordered, metrics symbols match engine references, no
  dead code, **no orphaned upstream reads** (the swap/volume fields are wired into
  the `empirical_depth` and `volume_support` components). The slippage model,
  sizing solver, and scoring contract were verified by simulation. Before
  production: `go build` + `vet` + lint and an integration run.
- **The slippage figure is a model estimate, not a guaranteed fill.** It is
  computed from real measured liquidity via a transparent constant-product
  approximation and labeled as such; real on-chain execution will differ with
  routing, MEV, and depth distribution. The empirical component is bounded by what
  the pool has actually absorbed.
- **No fabricated numbers.** No slippage, liquidity, volatility, or size is ever
  defaulted or guessed; absent inputs are surfaced as unavailable, and a token with
  no real market data produces no plan.
