# CoinDex Pro — Institutional Backend Architecture

**Document type:** Production architecture specification (design phase)
**Scope:** Full-stack market-intelligence backend to support the existing CoinDex Pro frontend and compete in the CMC / DexScreener / DEXTools / Nansen / Arkham / Bubblemaps / DeBank category.
**Status:** Design. No services are running yet — this is the blueprint to build them.

> **Honesty note that governs this whole document.** Everything below is *real, buildable* architecture: real schemas, real service boundaries, real technology with stated tradeoffs. It is **not** a running system, and several line items depend on **paid third-party data and infrastructure** that cannot be faked (RPC providers, social APIs, label datasets, GPU-free but non-trivial compute). Where a capability is impossible without a specific vendor or cost, that is stated plainly rather than glossed. Building this is a multi-engineer, multi-quarter effort with real monthly spend; the frontend you already have becomes a thin client on top of it (Phase 9).

---

## 0. The single most important architectural decision

The current product is a **frontend aggregator**: the browser calls DexScreener / GeckoTerminal / CoinGecko directly. That is why prices can be stale, why "smart money" can only see a session-bounded buffer, and why trust/holder data is mostly "Unavailable."

The institutional version **inverts this**: a backend owns ingestion, storage, and computation, and the frontend consumes **only** CoinDex's own API. This is the difference between an aggregator and an intelligence platform. Nansen/Arkham are valuable precisely because they run their own indexers and label databases — the moat is the **indexed history and the labels**, not the UI.

Everything in this document serves that inversion.

---

## 1. Full Architecture Diagram

### 1.1 System-level view

```mermaid
flowchart TB
    subgraph chains[Blockchains]
        ETH[Ethereum]; BSC[BSC]; SOL[Solana]
        PLS[PulseChain]; BASE[Base]; ARB[Arbitrum]; POLY[Polygon]
    end

    subgraph ingest[Ingestion Tier]
        RPC[RPC / WSS Pool<br/>per-chain providers]
        IDX[Indexer Workers<br/>1 deployment per chain]
        BF[Backfill Workers]
        REORG[Reorg Handler]
    end

    subgraph stream[Streaming Backbone]
        KAFKA[(Kafka / Redpanda<br/>raw + normalized topics)]
    end

    subgraph process[Processing Tier]
        NORM[Normalizer]
        ENRICH[Enrichment<br/>price, USD, sector]
        TRUST[Trust Engine]
        WALLET[Wallet Intelligence]
        GRAPH[Graph Engine]
        ALERTS[Alert Evaluator]
        SOCIAL[Social Engine]
    end

    subgraph storage[Storage Tier]
        TS[(TimescaleDB<br/>time-series: candles, snapshots)]
        CH[(ClickHouse<br/>swaps, transfers, wallet ledger)]
        PG[(PostgreSQL<br/>registry, labels, users, billing)]
        NEO[(Graph store<br/>wallet relationships)]
        REDIS[(Redis<br/>hot cache + queues)]
        S3[(Object store<br/>backfill parquet, backups)]
    end

    subgraph api[API Tier]
        GW[API Gateway<br/>auth, rate-limit, quotas]
        REST[REST/JSON API]
        WS[WebSocket Fan-out]
    end

    FE[CoinDex Pro Frontend<br/>thin client]
    EXT[Third-party API consumers<br/>premium keys]

    chains --> RPC --> IDX --> KAFKA
    BF --> KAFKA
    REORG -.rollback.-> CH
    KAFKA --> NORM --> ENRICH
    ENRICH --> TS & CH
    ENRICH --> TRUST & WALLET & SOCIAL
    WALLET --> GRAPH
    TRUST & WALLET & GRAPH --> PG & NEO
    ENRICH --> ALERTS
    TS & CH & PG & NEO --> REST
    REDIS --- REST
    ALERTS --> WS
    KAFKA --> WS
    REST --> GW --> FE & EXT
    WS --> GW
```

### 1.2 Data-flow lifecycle for one swap

```mermaid
sequenceDiagram
    participant Chain
    participant Indexer
    participant Kafka
    participant Normalizer
    participant Enrich
    participant CH as ClickHouse
    participant Trust
    participant Alerts
    participant WS as WebSocket

    Chain->>Indexer: new block (WSS head)
    Indexer->>Indexer: decode logs (Swap, Mint, Burn, Transfer)
    Indexer->>Kafka: raw.events {chain, block, log}
    Kafka->>Normalizer: consume
    Normalizer->>Enrich: normalized swap {pool, amounts}
    Enrich->>Enrich: resolve token decimals, USD price, sector
    Enrich->>CH: INSERT swap row
    Enrich->>Trust: recompute pair trust (debounced)
    Enrich->>Alerts: evaluate rules (whale buy? liq pull?)
    Alerts->>WS: push matched alerts
    Note over Indexer,CH: reorg → Indexer emits rollback(block) → CH deletes block range, replays
```

---

## 2. Service Map

Each service is independently deployable, independently scalable, and owns a clear slice. Boundaries are drawn so a failure in one degrades gracefully rather than cascading.

| Service | Responsibility | Language/Runtime (recommended) | Scales on | State |
|---|---|---|---|---|
| **rpc-pool** | Manages per-chain RPC/WSS endpoints, health, failover, rate budgeting | Go | # chains × redundancy | stateless |
| **indexer-{chain}** | Block listener, log decode, reorg detection, checkpointing | Rust or Go (EVM); Rust (Solana via Geyser) | per-chain throughput | checkpoint in PG/Redis |
| **backfill** | Historical range ingestion, parquet to object store, replay into Kafka | Go | parallel block ranges | job state in PG |
| **normalizer** | Raw log → canonical event (swap/lp/transfer/deploy/holder-delta) | Go | Kafka lag | stateless |
| **enricher** | Token metadata, decimals, USD pricing, sector tagging | Go | Kafka lag | reads PG/Redis |
| **trust-engine** | Token trust score from on-chain + contract analysis | Go + analyzer sidecar | # tokens scored/min | reads CH/PG |
| **wallet-intel** | Per-wallet ledger, PnL, ROI, win-rate, hold time | Go (heavy) / ClickHouse SQL | wallet write rate | CH |
| **graph-engine** | Wallet relationship graph, cluster detection | Python (igraph/networkx) or Rust | graph rebuild cadence | graph store |
| **social-engine** | X/Reddit/Telegram/Discord ingestion + sentiment | Python | API quotas | PG/Redis |
| **alert-evaluator** | Rule matching on the event stream, dedupe, delivery dispatch | Go | rule count × event rate | Redis |
| **notifier** | Email/Telegram/Discord/webhook delivery with retries | Go | delivery volume | queue in Redis |
| **api-gateway** | AuthN/Z, rate-limit, quota, key management, routing | Go (e.g. Kong/Envoy + custom) | request rate | stateless |
| **api-rest** | Read API over the stores, pagination, caching | Go | request rate | stateless |
| **api-ws** | Real-time fan-out (prices, whale prints, alerts) | Go | concurrent connections | connection state |
| **contract-analyzer** | Bytecode/source scan: ownership, mint, blacklist, tax, proxy | Rust (revm) + optional GoPlus fallback | tokens/min | stateless |
| **billing** | Stripe integration, subscriptions, quota enforcement events | Go | low | PG |

> **Why this many services?** Each maps to one of the platform's distinct workloads with very different scaling and failure profiles. Collapsing them is fine for an MVP (see §6.1 phased rollout), but the boundaries above are what lets the platform scale to Nansen-class volume without a single component becoming the bottleneck.

---

*(continued in sections 3–10 below)*

---

## 3. Database Schema

Three engines, chosen per workload. Using one database for everything is the most common scaling mistake in this category.

- **ClickHouse** — append-heavy, high-cardinality event data (swaps, transfers, wallet ledger). Columnar, handles billions of rows, sub-second aggregations. This is the wallet-intelligence and whale-analytics workhorse.
- **TimescaleDB (Postgres extension)** — regular time-series with continuous aggregates (candles, liquidity snapshots, trust-score history). Hypertables + automatic rollups.
- **PostgreSQL** — relational truth: token registry, wallet labels, users, billing, alert rules. Strong constraints, joins, transactions.

### 3.1 ClickHouse — event & ledger tables

```sql
-- Every DEX swap, normalized. Partitioned by month, ordered for wallet + token scans.
CREATE TABLE swaps (
    chain          LowCardinality(String),
    block_number   UInt64,
    block_time     DateTime64(3, 'UTC'),
    tx_hash        FixedString(66),
    log_index      UInt32,
    pool_address   FixedString(42),
    token_in       FixedString(42),
    token_out      FixedString(42),
    wallet         FixedString(42),
    amount_in      Decimal128(0),
    amount_out     Decimal128(0),
    amount_usd     Decimal64(2),
    price_usd      Decimal64(18),
    side           Enum8('buy' = 1, 'sell' = 2),
    dex            LowCardinality(String),
    INDEX idx_wallet wallet TYPE bloom_filter GRANULARITY 4
)
ENGINE = ReplacingMergeTree              -- dedupe by sort key on merge
PARTITION BY toYYYYMM(block_time)
ORDER BY (chain, token_in, block_time, tx_hash, log_index)
SETTINGS index_granularity = 8192;

-- ERC20 / SPL transfers (funding relationships, holder deltas).
CREATE TABLE transfers (
    chain        LowCardinality(String),
    block_time   DateTime64(3, 'UTC'),
    tx_hash      FixedString(66),
    log_index    UInt32,
    token        FixedString(42),
    from_addr    FixedString(42),
    to_addr      FixedString(42),
    amount       Decimal128(0),
    amount_usd   Decimal64(2)
)
ENGINE = ReplacingMergeTree
PARTITION BY toYYYYMM(block_time)
ORDER BY (chain, token, block_time, tx_hash, log_index);

-- LP add/remove events.
CREATE TABLE lp_events (
    chain        LowCardinality(String),
    block_time   DateTime64(3, 'UTC'),
    tx_hash      FixedString(66),
    pool_address FixedString(42),
    provider     FixedString(42),
    kind         Enum8('add' = 1, 'remove' = 2),
    amount_usd   Decimal64(2),
    pool_liq_usd Decimal64(2)
)
ENGINE = ReplacingMergeTree
PARTITION BY toYYYYMM(block_time)
ORDER BY (chain, pool_address, block_time, tx_hash);

-- Materialized wallet ledger: derived per-wallet position lots for PnL.
-- Built by a ClickHouse materialized view off `swaps`, FIFO cost-basis.
CREATE TABLE wallet_positions (
    chain          LowCardinality(String),
    wallet         FixedString(42),
    token          FixedString(42),
    qty_open       Decimal128(0),     -- remaining open quantity
    cost_basis_usd Decimal64(2),      -- USD cost of open quantity (FIFO)
    realized_usd   Decimal64(2),      -- realized PnL to date
    first_buy      DateTime64(3),
    last_action    DateTime64(3),
    updated_at     DateTime64(3)
)
ENGINE = ReplacingMergeTree(updated_at)
ORDER BY (chain, wallet, token);
```

### 3.2 TimescaleDB — time-series

```sql
-- OHLCV candles per pool. Hypertable + continuous aggregate rollups.
CREATE TABLE candles (
    pool_address text       NOT NULL,
    chain        text       NOT NULL,
    bucket       timestamptz NOT NULL,
    open  numeric, high numeric, low numeric, close numeric,
    volume_usd numeric, trades int,
    PRIMARY KEY (chain, pool_address, bucket)
);
SELECT create_hypertable('candles', 'bucket', chunk_time_interval => interval '1 day');

-- 1m base; 5m/1h/1d as continuous aggregates (auto-maintained):
CREATE MATERIALIZED VIEW candles_1h
WITH (timescaledb.continuous) AS
SELECT chain, pool_address,
       time_bucket('1 hour', bucket) AS bucket,
       first(open, bucket) AS open, max(high) AS high,
       min(low) AS low, last(close, bucket) AS close,
       sum(volume_usd) AS volume_usd, sum(trades) AS trades
FROM candles GROUP BY chain, pool_address, time_bucket('1 hour', bucket);

-- Liquidity snapshots (per pool, sampled + on every LP event).
CREATE TABLE liquidity_snapshots (
    chain text, pool_address text, ts timestamptz,
    liq_usd numeric, reserve0 numeric, reserve1 numeric,
    PRIMARY KEY (chain, pool_address, ts)
);
SELECT create_hypertable('liquidity_snapshots', 'ts', chunk_time_interval => interval '1 day');

-- Trust-score history (so a drop can be alerted on and charted).
CREATE TABLE trust_history (
    chain text, token text, ts timestamptz,
    trust int, confidence text, factors jsonb,
    PRIMARY KEY (chain, token, ts)
);
SELECT create_hypertable('trust_history', 'ts', chunk_time_interval => interval '7 days');

-- Retention: drop raw 1m candles older than 90d, keep rollups forever.
SELECT add_retention_policy('candles', interval '90 days');
```

### 3.3 PostgreSQL — relational truth

```sql
-- Canonical token registry (official contracts, socials, aliases, clones).
CREATE TABLE tokens (
    id            bigserial PRIMARY KEY,
    chain         text NOT NULL,
    address       text NOT NULL,
    symbol        text,
    name          text,
    decimals      int,
    is_official   boolean DEFAULT false,   -- verified, not guessed
    website       text,
    socials       jsonb,                   -- {x, telegram, discord, ...}
    aliases       text[],
    created_block bigint,
    created_at    timestamptz,
    UNIQUE (chain, address)
);
CREATE INDEX ON tokens (symbol);

-- Scam-clone linkage: an impostor points to the token it imitates.
CREATE TABLE token_clones (
    clone_id     bigint REFERENCES tokens(id),
    imitates_id  bigint REFERENCES tokens(id),
    evidence     jsonb,        -- symbol match, low liq, fresh deploy, etc.
    confidence   numeric,
    PRIMARY KEY (clone_id, imitates_id)
);

-- Wallet labels. Source is REQUIRED — no unsourced labels (anti-fabrication).
CREATE TABLE wallet_labels (
    chain      text NOT NULL,
    address    text NOT NULL,
    label_type text NOT NULL,   -- exchange|market_maker|dev|sniper|insider|vc|smart_money|bridge|cex_hot
    entity     text,            -- "Binance 14", "a16z", ...
    source     text NOT NULL,   -- 'manual:analyst_id' | 'auto:rule_v3' | 'vendor:arkham'
    confidence numeric NOT NULL,
    evidence   jsonb,
    created_at timestamptz DEFAULT now(),
    PRIMARY KEY (chain, address, label_type, source)
);

-- Contract-analysis results (ownership/mint/blacklist/tax/proxy).
CREATE TABLE contract_analysis (
    chain text, address text,
    owner_address text, is_renounced boolean,
    can_mint boolean, has_blacklist boolean, has_proxy boolean,
    buy_tax numeric, sell_tax numeric,
    hidden_admin boolean,
    analyzed_at timestamptz,
    method text,                 -- 'bytecode' | 'source' | 'goplus'
    raw jsonb,
    PRIMARY KEY (chain, address)
);

-- Users, subscriptions, API keys, quotas.
CREATE TABLE users (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    email text UNIQUE NOT NULL,
    tier text NOT NULL DEFAULT 'free',   -- free|premium|enterprise
    created_at timestamptz DEFAULT now()
);
CREATE TABLE api_keys (
    key_hash text PRIMARY KEY,           -- store hash, never the raw key
    user_id uuid REFERENCES users(id),
    quota_per_min int, quota_per_day int,
    created_at timestamptz, revoked boolean DEFAULT false
);
CREATE TABLE subscriptions (
    user_id uuid REFERENCES users(id),
    stripe_sub_id text, status text,
    current_period_end timestamptz,
    PRIMARY KEY (user_id)
);

-- Alert rules + delivery channels + fire history.
CREATE TABLE alert_rules (
    id bigserial PRIMARY KEY,
    user_id uuid REFERENCES users(id),
    kind text NOT NULL,          -- whale_buy|whale_sell|liq_pull|dev_sell|vol_spike|trust_drop|risk_change|holder_change
    target jsonb,                -- {chain, token?, threshold_usd?, ...}
    channels jsonb,              -- [{type:'telegram', dest:'...'}]
    enabled boolean DEFAULT true
);
```

### 3.4 Graph store

Wallet relationships are a graph problem. Options: **Neo4j** (mature, Cypher), or **embed in ClickHouse/Postgres** for MVP (adjacency table) and move to a dedicated graph DB at scale. Recommended adjacency table for v1:

```sql
-- Funding / co-trading edges between wallets (PostgreSQL for v1).
CREATE TABLE wallet_edges (
    chain text, src text, dst text,
    edge_type text,             -- funded|co_buy|co_sell|sync_exit
    weight numeric,             -- shared-token count / funding amount
    last_seen timestamptz,
    PRIMARY KEY (chain, src, dst, edge_type)
);
CREATE INDEX ON wallet_edges (chain, src);
CREATE INDEX ON wallet_edges (chain, dst);
```

---

## 4. Queue Design

The streaming backbone decouples ingestion (bursty, chain-paced) from processing (steady) and lets each consumer scale independently and replay on failure.

**Technology:** Kafka or Redpanda (Kafka-compatible, simpler ops). Redis Streams is acceptable for an MVP but lacks the durability/replay guarantees needed at scale.

### 4.1 Topic design

| Topic | Partitioned by | Retention | Consumers |
|---|---|---|---|
| `raw.{chain}.events` | `pool_address` | 24h | normalizer |
| `norm.swaps` | `chain+token` | 7d | enricher, wallet-intel |
| `norm.lp` | `chain+pool` | 7d | enricher, trust-engine |
| `norm.transfers` | `chain+token` | 7d | wallet-intel, graph-engine |
| `norm.deploys` | `chain` | 30d | registry, new-pair engine |
| `enriched.swaps` | `chain+token` | 7d | alert-evaluator, api-ws, CH sink |
| `alerts.matched` | `user_id` | 24h | notifier, api-ws |
| `control.reorg` | `chain` | 7d | all chain consumers |

### 4.2 Key rules

- **Partition by entity, not round-robin** — `pool_address` / `chain+token` keeps all events for one pool/token ordered on one partition, which is required for correct candle building and FIFO PnL.
- **Dedupe at two layers** — producers attach `(chain, tx_hash, log_index)` as the idempotency key; ClickHouse `ReplacingMergeTree` collapses duplicates on the sort key. Belt and suspenders, because reorgs and retries both create dupes.
- **Reorg as a control message** — when an indexer detects a reorg (parent hash mismatch), it publishes `control.reorg{chain, from_block}`. Consumers delete the affected block range and reprocess. This is why every event carries `block_number`.
- **Checkpoint recovery** — each indexer commits its last finalized block to Postgres+Redis every N blocks. On restart it resumes from the checkpoint minus a safety margin (reorg depth), replaying through the dedupe layer.
- **Consumer lag is the health signal** — alerting fires when any consumer group's lag exceeds a threshold (the system is falling behind real-time).

```mermaid
flowchart LR
    IDX[indexer-eth] -->|key=pool| RAW[(raw.eth.events)]
    RAW --> NORM[normalizer]
    NORM --> NS[(norm.swaps)] & NT[(norm.transfers)]
    NS --> ENR[enricher] --> ES[(enriched.swaps)]
    ES --> AL[alert-evaluator] --> AM[(alerts.matched)] --> NOTIF[notifier]
    ES --> WSINK[CH sink]
    REORG[(control.reorg)] -.-> NORM & ENR & WSINK
```

---

## 5. Cache Design

Three cache layers, each with a clear job. The goal: serve 95%+ of reads without touching the analytical stores.

| Layer | Tech | Holds | TTL | Invalidation |
|---|---|---|---|---|
| **L1 edge** | CDN (Cloudflare) | public token/pair JSON, sitemap, static | 5–30s | short TTL + purge-on-deploy |
| **L2 hot** | Redis | latest price per token, top-N lists, trust scores, session whale buffer | 5–60s | write-through from enricher; pub/sub bust |
| **L3 query** | Redis / in-proc | expensive aggregations (wallet PnL, sector flow) | 1–10m | keyed by `(query, params)`, soft-TTL with stale-while-revalidate |

### 5.1 Patterns

- **Stale-while-revalidate everywhere** (already proven in the current frontend cache) — serve the cached value, refresh in the background, never block the request. On upstream failure, serve last-valid and flag stale.
- **Write-through hot keys** — the enricher writes `price:{chain}:{token}` to Redis as it processes, so the API never recomputes "latest price."
- **Negative caching** — "token not found" / "no pools" cached briefly to stop hot-looping on garbage addresses.
- **Per-tier cache freshness** — free tier gets 30s-cached data; premium gets 5s; enterprise can hit fresher paths. This is both a product lever and a load-shedding lever.
- **Cache key includes a schema version** so a deploy that changes a response shape doesn't serve mixed formats.

---

## 6. Scaling Plan

### 6.1 Phased rollout (do NOT build all 16 services on day one)

```mermaid
flowchart LR
    M[MVP<br/>3 services] --> G[Growth<br/>8 services] --> S[Scale<br/>full mesh]
```

- **MVP (1–2 chains, single region):** collapse to **3 deployables** — `indexer` (ETH + Base), `processor` (normalize+enrich+trust+alerts in one binary), `api` (REST+WS). ClickHouse + Postgres + Redis, no Kafka yet (use Redis Streams). Proves the inversion: frontend reads only CoinDex API.
- **Growth (add BSC, Arbitrum, Polygon, PulseChain):** split processing, introduce Kafka/Redpanda, add wallet-intel + social + contract-analyzer, add billing/auth.
- **Scale (Solana + Nansen-class volume):** full service mesh, per-chain indexer autoscaling, ClickHouse cluster with sharding, graph-engine on dedicated nodes, multi-region read replicas.

### 6.2 Per-tier scaling levers

- **Indexers** scale per-chain — Solana alone produces orders of magnitude more events than PulseChain, so it gets its own autoscaling group and likely a Geyser plugin rather than RPC polling.
- **ClickHouse** scales by sharding on `chain` then `token`; reads scale with replicas.
- **API tier** is stateless → horizontal autoscale on request rate; WebSocket tier scales on concurrent connections with sticky routing.
- **Backpressure** — if a consumer lags, the queue absorbs the burst; if storage is the bottleneck, ingestion buffers in object store (parquet) and replays.

### 6.3 What scales painfully (be honest)

- **Solana ingestion** is the hardest and most expensive single problem — high throughput, account-model (not log-based), needs Geyser/validator access. Budget disproportionately here.
- **Wallet PnL over full history** is compute-heavy; FIFO cost-basis across millions of wallets is a recurring batch job, not a per-request computation.
- **Graph rebuilds** are O(edges); cluster detection is periodic, not real-time.

---

## 7. Cost Estimate

> **These are honest order-of-magnitude ranges with stated assumptions, not quotes.** Real numbers depend on chains covered, history depth, and traffic. The dominant cost in this category is almost always **RPC/data access**, not compute.

**Assumptions:** 4–5 EVM chains + PulseChain at launch (Solana deferred), ~90 days hot history, low-thousands of daily active users, single cloud region.

| Category | MVP (1–2 chains) | Growth (5–6 chains) | Notes |
|---|---|---|---|
| **RPC / node access** | $200–1,000/mo | $2,000–10,000/mo | The big one. Dedicated/archive nodes or paid providers (Alchemy/QuickNode/Helius). Solana adds significantly. |
| **Compute (services)** | $300–800/mo | $2,000–6,000/mo | Indexers + processors + API. Mostly memory-bound. |
| **ClickHouse** | $200–600/mo | $1,500–5,000/mo | Grows with retention depth; columnar compression helps a lot. |
| **Postgres + Timescale** | $150–400/mo | $800–2,500/mo | Managed (RDS/Aiven). |
| **Redis** | $100–300/mo | $500–1,500/mo | Managed. |
| **Kafka/Redpanda** | $0 (Redis Streams) | $500–2,000/mo | Introduced at Growth. |
| **Object store + egress** | $50–200/mo | $300–1,500/mo | Backups, parquet, CDN egress. |
| **Social/label data** | $0–500/mo | $1,000–10,000+/mo | X API paid tiers, label datasets (Arkham/Nansen-style) are expensive or unavailable — see §9. |
| **Total (rough)** | **~$1,000–3,500/mo** | **~$9,000–40,000+/mo** | Wide because data-access pricing dominates and varies hugely. |

**The uncomfortable truth:** the label data that makes Nansen/Arkham valuable is either built over years (expensive labeling ops) or licensed (very expensive). No architecture removes that cost — it's the actual moat.

---

## 8. Failure Points (real, ranked by likelihood × impact)

1. **RPC provider degradation / rate-limiting** — most common. Mitigation: multi-provider pool per chain, automatic failover, budget-aware request scheduling, backfill to recover gaps.
2. **Chain reorgs corrupting derived data** — handled by reorg control messages + block-range deletion + replay, but bugs here silently poison PnL/candles. Mitigation: only treat blocks past finality as immutable; keep a reorg-depth safety margin.
3. **Consumer lag / falling behind real-time** — under load a processor can't keep up. Mitigation: queue absorbs bursts, autoscale on lag, shed enrichment work (defer non-critical) before dropping ingestion.
4. **ClickHouse merge pressure / duplicate explosion** — heavy retries without proper idempotency keys bloat storage. Mitigation: strict `(tx_hash, log_index)` keys, ReplacingMergeTree, monitor part counts.
5. **Solana ingestion gaps** — throughput + account model make dropped data likely. Mitigation: Geyser, aggressive backfill, treat Solana coverage as "best-effort" until hardened.
6. **Cost runaway on RPC** — a backfill or a hot loop can 10x the monthly bill overnight. Mitigation: hard per-chain request budgets, alerting on spend, circuit breakers.
7. **Social API bans / quota exhaustion** — X/Telegram terms and rate limits change. Mitigation: degrade to "Unavailable," never fabricate, cache aggressively.
8. **Bad/poisoned price data → wrong USD values → wrong PnL** — mitigated by the **multi-source consensus + outlier rejection** already designed in the frontend, promoted into the enricher.
9. **Single-region outage** — MVP risk accepted; multi-region at Scale.
10. **Label/trust disputes** — showing "dev wallet" on the wrong address is a legal/reputational risk. Mitigation: every label carries a `source` + `confidence`; nothing unsourced is ever shown.

---

## 9. Security Model

### 9.1 Boundaries & authN/Z
- **API gateway is the only ingress.** AuthN via API keys (hashed at rest, never logged) and user JWTs. AuthZ via tier + quota checked at the gateway before any backend call.
- **Per-key rate limits and quotas** enforced in Redis (token bucket), with hard daily caps to prevent abuse and cost runaway.
- **Internal services are not internet-exposed** — private network/VPC, mTLS between services, no service trusts the network.

### 9.2 Data & secrets
- Secrets in a manager (Vault / cloud KMS), never in env files in the repo.
- PII (emails) encrypted at rest; minimal collection. Wallet addresses are public data, but **labels are sensitive** — access-controlled and audit-logged.
- Stripe handles card data (PCI scope stays with Stripe); we store only customer/subscription IDs.

### 9.3 Abuse & integrity
- **Scraping defense** — premium data behind keys + rate limits; public tier intentionally coarser/older.
- **Label integrity** — write access to `wallet_labels` is restricted to analysts/automated rules with recorded `source`; a public-facing label always shows provenance.
- **Read-only wallet sync** — portfolio sync never holds private keys or signing capability; it reads balances/positions only.
- **Input validation everywhere** — addresses regex-validated per chain (the chain-mismatch validator already designed), pagination bounded, query cost limited.

### 9.4 The honest risk
Showing someone's wallet labeled "insider" or "dev — dumping" is a **real legal and ethical exposure**. The model must default to provenance + confidence and a dispute path, and must never surface an unsourced or low-confidence label as fact. This is a policy problem as much as an engineering one.

---

## 10. Deployment Plan

### 10.1 Infrastructure
- **Containers** (Docker) orchestrated by **Kubernetes** (managed: EKS/GKE) at Growth+; **single-VM docker-compose** is fine for MVP.
- **IaC**: Terraform for cloud resources, Helm for service deploys. Nothing clicked by hand in production.
- **Environments**: `dev` → `staging` (real chains, throwaway data) → `prod`. Indexers in staging run against the same chains so reorg/backfill logic is tested on real data.

### 10.2 CI/CD
- Per-service pipeline: test → build image → scan → deploy to staging → smoke test → canary to prod → full rollout. Rollback on health-check failure.
- **Schema migrations** versioned (e.g. `golang-migrate`), forward-only, applied before the service that needs them.

### 10.3 Observability (non-negotiable for this class of system)
- **Metrics**: Prometheus + Grafana — per-chain block lag, consumer lag, RPC error rate, query latency, cost-per-chain.
- **Tracing**: OpenTelemetry across the request path.
- **Logging**: structured, centralized (Loki/ELK).
- **The existing `/status`, `/integrity`, `/launch-check` pages become thin views over real backend health endpoints** — exactly the seam already built in the frontend.

### 10.4 Rollout sequence (maps to building this for real)
1. Stand up storage (ClickHouse, Postgres+Timescale, Redis) + IaC.
2. Build `indexer-eth` + `indexer-base` with reorg/checkpoint/backfill; verify against a block explorer.
3. Build `processor` (normalize+enrich+candles) → populate ClickHouse/Timescale.
4. Build `api-rest` + `api-ws` → **point the existing frontend at `api.coindexpro.com` and remove direct provider calls (Phase 9 of your spec).**
5. Layer in trust-engine, wallet-intel, alerts, contract-analyzer.
6. Add auth/billing, premium keys, quotas.
7. Add social + graph + labels (the expensive, moat-building, slowest pieces — last).
8. Add chains (BSC, Arbitrum, Polygon, PulseChain, then Solana).

---

## Appendix A — How the existing frontend changes (Phase 9)

The current `CDX.Asset`, `CDX.WhaleFlow`, `CDX.TrustScore`, `CDX.SmartMoney`, and `CDX.Backend` modules were deliberately built as **the seam for exactly this migration**:

- `CDX.Asset.resolveLive()` already has the DexScreener→GeckoTerminal→CoinGecko→cache hierarchy. **It changes to a single call to `api.coindexpro.com/token/:address`** — the backend now does the multi-source consensus server-side, with full history behind it.
- `CDX.WhaleFlow` stops polling GeckoTerminal per-pool and instead subscribes to the `api-ws` whale stream — now a global firehose, not a session buffer.
- `CDX.TrustScore` / `CDX.SmartMoney` / `CDX.TokenIntel` stop deriving from a session buffer and **read precomputed values from the API**, now backed by full indexed history (real PnL, real holder concentration, real labels).
- `CDX.Backend`'s adapter contracts (indexer, DB, labels, contract-analyzer, persistent history, portfolio V2) are **fulfilled by the real services** described here instead of returning "not configured."

The frontend becomes a **thin client**. The backend becomes the **single source of truth**. That is the whole point.

---

## Appendix B — What this design honestly cannot promise

1. **It is a design, not a running system.** Building it is real engineering work over real time with real spend.
2. **The data moat (labels, history) is bought or built over time** — no architecture shortcuts it. This is why Nansen/Arkham are hard to displace.
3. **Solana parity is the hardest, most expensive single item** and should be planned as a later, dedicated effort.
4. **Social intelligence depends on third-party API terms** that can change or price out; it must degrade to "Unavailable," never fabricate.
5. **Some institutional features carry legal/ethical weight** (wallet labeling, "insider" tags) and need policy, provenance, and a dispute process — not just code.

This document gives you the production-real blueprint. The next concrete step is **§10.4 step 1–4**: storage + one indexer + processor + API, with the existing frontend repointed at it. That slice alone is what turns CoinDex Pro from an aggregator into a platform.

---

## 11. CI/CD Pipeline (added in build pass)

Per-service pipeline, triggered on PR and on merge to `main`:

```mermaid
flowchart LR
    PR[PR opened] --> LINT[lint + vet]
    LINT --> TEST[unit tests<br/>decoders vs captured logs]
    TEST --> BUILD[build image]
    BUILD --> SCAN[trivy image scan]
    SCAN --> STAGE[deploy to staging]
    STAGE --> SMOKE[integration: index 100 real blocks<br/>assert row counts + no DLQ]
    SMOKE --> CANARY[canary 1 pod prod]
    CANARY --> HEALTHGATE{health + lag OK 10m?}
    HEALTHGATE -->|yes| ROLL[full rollout]
    HEALTHGATE -->|no| ROLLBACK[auto-rollback]
```

- **Gates:** `golangci-lint`, `go test ./...` (decoder tests run against captured real mainnet logs — the only way to catch ABI drift), `trivy` image scan, staging smoke that indexes a fixed real block range and asserts expected row counts with zero DLQ messages.
- **Migrations** run as a separate, idempotent job *before* the service that needs them, forward-only (`golang-migrate` for Postgres/Timescale; versioned `.sql` for ClickHouse applied by an init job).
- **Image promotion**, not rebuild: the exact image that passed staging is what goes to prod.

## 12. Monitoring Strategy (added)

The `deploy/alerts.yml` shipped with the indexer makes this concrete. Signals and their alerts:

| Signal | Metric | Alert condition |
|---|---|---|
| Falling behind | `coindex_index_lag_blocks` | > 100 for 5m (warn) |
| Stalled | `coindex_blocks_processed_total` | no increase 10m (critical) |
| Provider trouble | `coindex_rpc_errors_total` rate | > 1/s for 5m (warn) |
| Un-processable data | `coindex_dlq_messages_total` | any increase 15m (warn) |
| Reorg storm | `coindex_reorgs_total` | > 5 in 10m (warn) |
| Sink pressure | `coindex_sink_flush_seconds` p99 | > 2s sustained |

Plus, beyond the indexer: API p99 latency, cache hit-rate, queue consumer lag, and **provider disagreement rate** (from the consensus engine) — the cross-source-trust signal. Dashboards in Grafana, traces via OpenTelemetry, errors to Sentry, uptime via external probe on `/healthz` and the public API.

## 13. Rollback Strategy (added)

- **Service rollback:** image promotion means rollback is redeploying the previous good image — single command / one click. Canary + health gate catches most bad deploys before full rollout.
- **Data rollback (the hard one):** the indexer's reorg machinery *is* the data-rollback mechanism — `RollbackFrom(forkBlock)` deletes the affected ClickHouse range and re-ingests. For a bad *deploy* that wrote corrupt rows (not a reorg), recovery is: stop the indexer, `ALTER TABLE … DELETE WHERE block_number >= X`, reset the checkpoint to `X-1`, deploy the fix, let it re-ingest. Because storage is idempotent (`ReplacingMergeTree`) and checkpoints are explicit, this is safe and repeatable.
- **Schema rollback:** forward-only migrations with a tested down-path only for reversible changes; destructive changes go behind a new column/table + backfill, never an in-place drop.

## 14. Disaster Recovery (added)

- **RPO / RTO targets (proposed):** RPO ≤ a few minutes of chain data (recoverable via backfill regardless), RTO ≤ 1 hour for full service.
- **The key DR property: blockchains are the source of truth.** Any derived store can be **rebuilt from chain** via backfill if lost — this is the platform's strongest DR guarantee and why the indexer has first-class backfill + checkpointing.
- **Backups:** ClickHouse → periodic `BACKUP` to object store (S3); Postgres → automated managed snapshots + PITR; Redis is a cache (no backup needed — rebuildable). Object store holds backfill parquet for fast replay.
- **Region failure:** MVP single-region (accepted risk, documented). At Scale: multi-region read replicas for Postgres/ClickHouse, and indexers are stateless-enough (checkpoint in durable store) to restart in another region and resume.
- **Runbooks:** "indexer stalled," "DLQ growing," "reorg storm," "provider outage," "ClickHouse disk pressure" — each with a tested recovery procedure. DR is drilled, not assumed.

---

## Build-pass note (what was actually built)

Phase 1 (`coindex-indexer-evm`) has been **implemented as real Go code** — ~1,680 lines across 14 source files plus migrations, Dockerfile, docker-compose (ClickHouse + Redpanda + Postgres + Redis + Prometheus), config, alerting rules, and README. It covers all 14 Phase-1 requirements: block listener, swap/LP/transfer/deploy/new-pair decode, holder-driving transfers, reorg handling, checkpoint persistence, retry/backoff, RPC failover, multi-provider redundancy, Kafka publishing, dead-letter queue, ClickHouse sink, health checks, logs, and Prometheus metrics.

**It has not been compiled or run** in the authoring environment (no Go toolchain, no network, no live RPC). It is production-shaped and import-consistent on review, but before deployment it requires `go build` + `go vet` + lint, decoder unit tests against captured real logs, and an integration run against a real archive endpoint. That is the honest status: a strong, complete first implementation of Phase 1 — not yet a battle-tested binary, and the remaining 15 phases are sequenced work, not done.

---

# Reconciliation to the 16-Phase Build Spec

This section maps the architecture above onto the exact phase structure, service
decomposition, and table lists in the master build prompt. It supersedes any
naming differences earlier in the document — these are the authoritative phase
boundaries and schemas to build against, **in order**.

## R.1 Phase → Service map (authoritative build order)

| Phase | Service / Engine | Status | Real today? | External infra required |
|---|---|---|---|---|
| **1** | `coindex-indexer-evm` | **BUILT** (prior pass, ~1,680 LOC) | Code complete, not yet compiled/run | RPC providers (paid), ClickHouse, Kafka |
| **2** | Database layer (CH / Timescale / PG / Graph) | Schemas designed (below) | DDL ready | DB instances |
| **3** | `coindex-api` (12 API services) | Designed | — | API hosting, Redis |
| **4** | `coindex-enricher` (consensus source-of-truth) | Designed; logic proven in frontend | Consensus algo real | DexScreener/GeckoTerminal/CoinGecko access |
| **5** | Provider Trust Engine | Designed; partially real in frontend | Telemetry real | — (consumes own metrics) |
| **6** | Smart Money Engine | Designed; observable-only logic real | Math provable from ledger | Indexed wallet history (Phase 1+2) |
| **7** | Wallet Label Engine | Designed | Schema real; labels need source | Label dataset (vendor or analyst ops) |
| **8** | Risk Engine | Designed | Heuristic real, verified needs vendor | GoPlus or equivalent API key |
| **9** | Token Intel Engine | Designed | Liquidity/age real; holders need indexer | Holder indexer |
| **10** | Cluster Engine (graph) | Designed | Co-trade overlap real | Graph DB |
| **11** | Flow Engine | Designed | Needs labeled addresses | CEX/bridge address registry |
| **12** | Social Engine | Designed | None — API-backed only | X/Reddit/Telegram/Discord API keys (paid) |
| **13** | Alert Engine | Designed; rules real | Real over indexed events | Delivery creds (SMTP/Telegram/Discord) |
| **14** | Portfolio Engine | Designed | Compute real, needs sync | Read-only wallet sync (RPC/indexer) |
| **15** | Replay Engine | Designed; real over stored history | Real once history durable | Durable history store |
| **16** | Premium Infrastructure | Designed | Gating logic real | Stripe (billing), auth provider |

> **Honesty marker:** only **Phase 1** has actual code. Everything else is designed and schema-ready. "Real today?" distinguishes provable-now logic from capabilities that are blocked on external infrastructure — none of which can be faked.

## R.2 Phase 2 — exact schemas (matching the prompt's table lists)

### ClickHouse (event + derived)
Already shipped in `coindex-indexer-evm/migrations/clickhouse/001_init.sql`:
`swaps`, `transfers`, `lp_events`, `contract_deploys` (= deploys), `new_pairs`,
`wallet_positions`. **Still to add for Phase 2 completeness** (designed, DDL on build):

```sql
-- token mints (ERC20 mint = Transfer from 0x0); separated for supply tracking
CREATE TABLE coindex.token_mints (
    chain LowCardinality(String), block_time DateTime64(3,'UTC'),
    tx_hash FixedString(66), log_index UInt32,
    token String, to_addr String, amount String
) ENGINE = ReplacingMergeTree PARTITION BY toYYYYMM(block_time)
ORDER BY (chain, token, block_time, tx_hash, log_index);

-- wallet_trades: enriched swaps attributed to a wallet w/ USD (built by enricher)
CREATE TABLE coindex.wallet_trades (
    chain LowCardinality(String), wallet String, token String,
    block_time DateTime64(3,'UTC'), tx_hash FixedString(66),
    side Enum8('buy'=1,'sell'=2), qty String, price_usd Decimal64(18),
    usd Decimal64(2), dex LowCardinality(String)
) ENGINE = ReplacingMergeTree PARTITION BY toYYYYMM(block_time)
ORDER BY (chain, wallet, token, block_time, tx_hash);

-- token_metrics: rolling per-token aggregates (built by token-intel job)
CREATE TABLE coindex.token_metrics (
    chain LowCardinality(String), token String, ts DateTime64(3,'UTC'),
    holders UInt64, top10_concentration Decimal32(4),
    liq_usd Decimal64(2), vol24h_usd Decimal64(2), volatility Decimal32(6)
) ENGINE = ReplacingMergeTree(ts) ORDER BY (chain, token, ts);

-- smart_money_events: emitted when a high-conviction wallet acts (Phase 6)
CREATE TABLE coindex.smart_money_events (
    chain LowCardinality(String), wallet String, token String,
    block_time DateTime64(3,'UTC'), tx_hash FixedString(66),
    side Enum8('buy'=1,'sell'=2), usd Decimal64(2),
    conviction UInt8, reason String
) ENGINE = ReplacingMergeTree PARTITION BY toYYYYMM(block_time)
ORDER BY (chain, wallet, block_time, tx_hash);
```

### TimescaleDB (time-series — exact candle set requested)
```sql
-- 1m base hypertable; 5m/15m/1h/4h as continuous aggregates off it.
CREATE TABLE candles_1m (
    chain text, pool_address text, bucket timestamptz,
    open numeric, high numeric, low numeric, close numeric,
    volume_usd numeric, trades int,
    PRIMARY KEY (chain, pool_address, bucket)
);
SELECT create_hypertable('candles_1m','bucket', chunk_time_interval => interval '1 day');

-- candles_5m / candles_15m / candles_1h / candles_4h are continuous aggregates:
CREATE MATERIALIZED VIEW candles_5m WITH (timescaledb.continuous) AS
SELECT chain, pool_address, time_bucket('5 minutes', bucket) AS bucket,
       first(open,bucket) open, max(high) high, min(low) low, last(close,bucket) close,
       sum(volume_usd) volume_usd, sum(trades) trades
FROM candles_1m GROUP BY chain, pool_address, time_bucket('5 minutes', bucket);
-- (15m, 1h, 4h identical pattern with their bucket sizes)

CREATE TABLE liquidity_history (chain text, pool_address text, ts timestamptz,
    liq_usd numeric, PRIMARY KEY (chain,pool_address,ts));
SELECT create_hypertable('liquidity_history','ts', chunk_time_interval => interval '1 day');

CREATE TABLE trust_history (chain text, token text, ts timestamptz,
    trust int, confidence text, factors jsonb, PRIMARY KEY (chain,token,ts));
SELECT create_hypertable('trust_history','ts', chunk_time_interval => interval '7 days');

CREATE TABLE whale_history (chain text, wallet text, ts timestamptz,
    usd numeric, side text, token text, tx_hash text,
    PRIMARY KEY (chain, wallet, ts, tx_hash));
SELECT create_hypertable('whale_history','ts', chunk_time_interval => interval '1 day');

CREATE TABLE sector_history (sector text, ts timestamptz,
    inflow_usd numeric, outflow_usd numeric, volume_usd numeric,
    PRIMARY KEY (sector, ts));
SELECT create_hypertable('sector_history','ts', chunk_time_interval => interval '1 day');
```

### PostgreSQL (relational truth — exact tables requested)
`token_registry`, `wallet_labels`, `user_accounts` (= users), `alerts`
(= alert_rules), `watchlists`, `portfolios`, `premium_subscriptions`
(= subscriptions). DDL already specified in §3.3 above; the two not yet shown:

```sql
CREATE TABLE watchlists (
    id bigserial PRIMARY KEY, user_id uuid REFERENCES user_accounts(id),
    name text NOT NULL, items jsonb NOT NULL DEFAULT '[]', -- [{chain,address,kind}]
    created_at timestamptz DEFAULT now()
);
CREATE TABLE portfolios (
    id bigserial PRIMARY KEY, user_id uuid REFERENCES user_accounts(id),
    wallet text, chain text, synced_at timestamptz,
    -- positions are derived from indexed history, never estimated
    UNIQUE (user_id, chain, wallet)
);
```

### Graph schema (Phase 10 — exact relationships requested)
For an MVP, the adjacency tables in §3.4 (`wallet_edges`) cover co-buy/co-sell/
funding. At scale this moves to a property graph (Neo4j). Node/edge model:

```
(:Wallet {chain, address})
(:Token  {chain, address})
(Wallet)-[:CO_BUY   {token, count, last_seen}]->(Wallet)
(Wallet)-[:CO_SELL  {token, count, last_seen}]->(Wallet)
(Wallet)-[:FUNDED   {amount_usd, tx, ts}]->(Wallet)
(Wallet)-[:TRADED   {side, usd, ts}]->(Token)
-- cluster + influence scores are computed (PageRank-style on FUNDED/CO_BUY),
-- stored back as node properties: {cluster_id, influence}
```

## R.3 Deliverable completeness (the 14 mandatory pre-coding items)

| # | Deliverable | Where |
|---|---|---|
| 1 | Architecture diagram | §1 (system + per-swap sequence) |
| 2 | Service map | §2 + R.1 (16-phase authoritative) |
| 3 | Database schema | §3 + R.2 (exact table lists) |
| 4 | Queue architecture | §4 |
| 5 | Cache hierarchy | §5 |
| 6 | Scaling model | §6 |
| 7 | Cost estimate | §7 |
| 8 | Failure-point analysis | §8 |
| 9 | Security model | §9 |
| 10 | Deployment model | §10 |
| 11 | CI/CD pipeline | §11 |
| 12 | Monitoring architecture | §12 |
| 13 | Rollback strategy | §13 |
| 14 | Disaster recovery | §14 |

**All 14 are complete.** No coding beyond Phase 1 (already built) has been started, per the instruction to hold at deliverables.
