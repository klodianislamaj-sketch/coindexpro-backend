#!/usr/bin/env python3
"""Compile src/ modules (lexicographic order) into dist/coindex-pro.html as inline scripts."""
import pathlib
root = pathlib.Path(__file__).parent
ORDER = { '00-core': 0, '05-net': 1, 'providers': 2, '10-data': 3, '20-components': 4, '30-pages': 5 }
files = sorted((root/'src').rglob('*.js'),
               key=lambda f: (ORDER.get(f.relative_to(root/'src').parts[0], 8 if f.name != '90-app.js' else 9), str(f)))
parts = []
for f in files:
    rel = f.relative_to(root)
    parts.append(f"<script>\n/* ===== {rel} ===== */\n{f.read_text()}\n</script>")
html = (root/'index.html').read_text().replace('<!-- @scripts -->', '\n'.join(parts))
out = root/'dist'/'coindex-pro.html'
out.write_text(html)
print(f"built {out} from {len(files)} modules, {len(html)//1024} KB")
