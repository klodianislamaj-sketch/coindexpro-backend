/* CDX.News — streaming headline feed. New items surface on a cadence; pages subscribe via Bus. */
CDX.News = (() => {
  const pool = CDX.DataRaw.NEWS_POOL;
  const items = pool.slice(0, 12).map((n,i)=>({ ...n, ts: Date.now() - (6 + i*14 + Math.random()*9)*60e3 }));
  let cursor = 12, count = 0;
  CDX.Bus.on('tick', () => {
    if (++count % 7 !== 0) return;                       // ~ every 28s
    items.unshift({ ...pool[cursor % pool.length], ts: Date.now() });
    cursor++;
    if (items.length > 40) items.pop();
    CDX.Bus.emit('news:changed', items[0]);
  });
  /* live event wire: real market events rendered as headlines (no fabrication —
     every item is generated from an actual print, LP event, migration or spike) */
  const F = CDX.Fmt;
  const wirePush = it => {
    items.unshift({ src: 'CoinDex Wire', ts: Date.now(), wire: true, ...it });
    if (items.length > 60) items.pop();
    CDX.Bus.emit('news:changed', items[0]);
  };
  let lastWhaleWire = 0, lastLiqWire = 0;
  CDX.Bus.on('whale:new', t => {
    if (t.usd < 400e3 || Date.now() - lastWhaleWire < 90e3) return;
    const p = CDX.Data.byKey('d:' + t.pairId);
    if (!p) return;
    lastWhaleWire = Date.now();
    wirePush({ tag: 'd:' + p.id, kind: t.side === 'buy' ? 'bull' : 'bear',
      h: `Whale ${t.side === 'buy' ? 'buys' : 'sells'} ${F.usd(t.usd)} of ${p.base} on ${p.dex} (${CDX.Data.CHAINS[p.chain].name})` });
  });
  CDX.Bus.on('liq:event', e => {
    if (Math.abs(e.delta) < 75e3 || Date.now() - lastLiqWire < 120e3) return;
    const p = CDX.Data.byKey('d:' + e.pairId);
    if (!p) return;
    lastLiqWire = Date.now();
    wirePush({ tag: 'd:' + p.id, kind: e.delta >= 0 ? 'bull' : 'bear',
      h: `${F.usd(Math.abs(e.delta))} liquidity ${e.delta >= 0 ? 'added to' : 'pulled from'} ${p.base}/${p.quote} on ${p.dex}` });
  });
  CDX.Bus.on('social:spike', sp => {
    const c = CDX.Data.byKey('c:' + sp.coinId);
    if (!c) return;
    wirePush({ tag: 'c:' + c.id, kind: 'bull',
      h: `${c.sym} ${sp.channel.toLowerCase()} spike: +${sp.pct.toFixed(1)}% between snapshots` });
  });
  return { all: () => items, latest: n => items.slice(0, n) };
})();
