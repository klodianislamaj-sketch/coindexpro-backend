/* Phase 2 — narrative taxonomy, asset tagging, whale wallets & trade events.
   Decorates existing datasets in place; never mutates their schema destructively. */
(() => {
  const R = CDX.DataRaw, F = CDX.Fmt;

  R.NARRATIVES = {
    ai:            { id:'ai',            name:'AI',             color:'#5B8CFF', desc:'Agents, inference, decentralized compute and AI-aligned infrastructure.' },
    memecoins:     { id:'memecoins',     name:'Memecoins',      color:'#F5C04E', desc:'Attention assets. Flow is reflexive, sentiment-driven and fast in both directions.' },
    rwa:           { id:'rwa',           name:'RWA',            color:'#2DD480', desc:'Tokenized real-world assets, stable value and payment rails.' },
    defi:          { id:'defi',          name:'DeFi',           color:'#9B5CFF', desc:'Exchanges, perps, lending and yield — the on-chain capital markets stack.' },
    gaming:        { id:'gaming',        name:'Gaming',         color:'#FF7849', desc:'Game economies, distribution chains and consumer crypto.' },
    infrastructure:{ id:'infrastructure',name:'Infrastructure', color:'#2D9CDB', desc:'L1s, L2s, oracles and the plumbing everything else settles on.' },
    pulsechain:    { id:'pulsechain',    name:'PulseChain',     color:'#FF0080', desc:'The PulseChain ecosystem — PLS, PulseX, HEX and the PRC-20 long tail.' },
    l2:            { id:'l2',            name:'Layer 2',        color:'#61DFFF', desc:'Rollups and scaling layers settling to Ethereum and beyond.' },
    depin:         { id:'depin',         name:'DePIN',          color:'#46C2CB', desc:'Decentralized physical infrastructure — wireless, compute, sensors, energy.' },
    staking:       { id:'staking',       name:'Staking / LST',  color:'#7FD1AE', desc:'Liquid staking and restaking — yield-bearing base-asset wrappers.' }
  };
  R.NARRATIVE_ORDER = ['pulsechain','memecoins','ai','defi','rwa','gaming','infrastructure','l2','depin','staking'];
  /* dynamic coin → narrative map filled by the live layer from real CoinGecko categories */
  R.DYNAMIC_COIN_TAGS = R.DYNAMIC_COIN_TAGS || {};

  const COIN_TAGS = {
    btc:['infrastructure'], eth:['infrastructure','defi'], usdt:['rwa','defi'], usdc:['rwa','defi'],
    bnb:['infrastructure'], xrp:['rwa'], sol:['infrastructure'], trx:['infrastructure'],
    doge:['memecoins'], hype:['defi','infrastructure'], ada:['infrastructure'], wbtc:['defi'],
    link:['infrastructure','rwa'], avax:['infrastructure','rwa'], ltc:['rwa'], ton:['gaming','infrastructure'],
    dot:['infrastructure'], shib:['memecoins'], uni:['defi'], near:['ai','infrastructure'],
    icp:['ai','infrastructure'], apt:['infrastructure','gaming'], pepe:['memecoins'], arb:['infrastructure'],
    pls:['pulsechain','infrastructure'], pol:['infrastructure'], plsx:['pulsechain','defi'],
    hex:['pulsechain','defi'], op:['infrastructure'], bonk:['memecoins'], wif:['memecoins'],
    inc:['pulsechain','memecoins']
  };
  const PAIR_TAGS = {
    PLSX:['pulsechain','defi'], INC:['pulsechain','memecoins'], HEX:['pulsechain','defi'],
    eHEX:['pulsechain','defi'], HDRN:['pulsechain','defi'], ICSA:['pulsechain','defi'],
    TEDDY:['pulsechain','memecoins'], BEAR:['pulsechain','memecoins'], DWB:['pulsechain','memecoins'],
    '9MM':['pulsechain','defi'],
    pDAI:['pulsechain','rwa'], PCOCK:['pulsechain','memecoins'], ATROPA:['pulsechain','memecoins'],
    PRVX:['pulsechain','ai'], WPLS:['pulsechain','infrastructure'],
    PEPE:['memecoins'], MOG:['memecoins'], SHIB:['memecoins'], SPX:['memecoins'],
    WBTC:['defi'], LINK:['infrastructure','rwa'], WIF:['memecoins'], BONK:['memecoins'],
    POPCAT:['memecoins'], HONK:['memecoins'], JUP:['defi'], PYTH:['infrastructure','ai'],
    BRETT:['memecoins'], TOSHI:['memecoins'], DEGEN:['memecoins'], BASEDOG:['memecoins'],
    AERO:['defi'], GMX:['defi'], ARB:['infrastructure'], CAKE:['defi'],
    FLOKI:['memecoins','gaming'], OP:['infrastructure'], VELO:['defi'], JOE:['defi'], POL:['infrastructure']
  };
  R.applyTags = function(){
    R.coins.forEach(c => {
      const dyn = R.DYNAMIC_COIN_TAGS[c.id] || [];
      c.tags = [...new Set([...(COIN_TAGS[c.id] || (c.cat === 'meme' ? ['memecoins'] : [])), ...dyn])];
    });
    R.pairs.forEach(p => {
      p.tags = [...(PAIR_TAGS[p.base] || (p.vol && p.liq && p.fdv && p.fdv < 60e6 ? ['memecoins'] : []))];
      if (p.chain === 'pulsechain' && !p.tags.includes('pulsechain')) p.tags.push('pulsechain');
    });
  };
  R.applyTags();

  /* ---- whale wallets (deterministic) ---- */
  const rnd = F.mulberry32(1337);
  const hex = n => [...Array(n)].map(() => '0123456789abcdef'[Math.floor(rnd()*16)]).join('');
  const mkAddr = () => '0x' + hex(40);
  const W = (label, type, chains, pnl, win, trades, score, since) =>
    ({ addr: mkAddr(), label, type, chains, pnl30d: pnl, winRate: win, trades30d: trades, score, since });
  R.WALLETS = [
    W('Pulse OG #1',      'Pulse OG',     ['pulsechain'],                 842e3,  74, 96,  91, 'May 2023'),
    W('Sacrifice Whale',  'Pulse OG',     ['pulsechain','ethereum'],      612e3,  68, 41,  86, 'May 2023'),
    W('Sigma Capital',    'Fund',         ['ethereum','arbitrum','base'], 2.41e6, 71, 188, 89, 'Jan 2024'),
    W('Basilisk',         'Smart Money',  ['solana','base'],              1.86e6, 77, 240, 94, 'Aug 2024'),
    W('HEX Maxi Prime',   'Pulse OG',     ['pulsechain'],                 -184e3, 52, 64,  61, 'Nov 2022'),
    W('Quiet Accumulator','Smart Money',  ['ethereum','pulsechain'],      934e3,  81, 58,  93, 'Mar 2024'),
    W('Memetic Flow',     'Degen',        ['solana','base'],              428e3,  58, 412, 72, 'Feb 2025'),
    W('North Rock Digital','Fund',        ['ethereum','arbitrum'],        3.84e6, 69, 92,  88, 'Sep 2023'),
    W('PulseX LP Titan',  'Market Maker', ['pulsechain'],                 296e3,  64, 820, 76, 'Jun 2023'),
    W('Fresh Sniper 0x9', 'Fresh Wallet', ['base','solana'],              182e3,  62, 96,  58, 'Apr 2026'),
    W('Glacier Fund',     'Fund',         ['ethereum','avalanche'],       1.21e6, 66, 74,  82, 'Dec 2023'),
    W('Bonk Architect',   'Smart Money',  ['solana'],                     764e3,  73, 156, 87, 'Oct 2024'),
    W('Atropa Believer',  'Degen',        ['pulsechain'],                 -96e3,  44, 188, 41, 'Jul 2024'),
    W('Basement Quant',   'Smart Money',  ['arbitrum','optimism'],        518e3,  79, 132, 90, 'Jan 2025'),
    W('CEX Outflow 0xB4', 'Whale',        ['ethereum','bnb'],             1.48e6, 61, 38,  74, 'Mar 2025'),
    W('Inc Insider',      'Pulse OG',     ['pulsechain'],                 224e3,  70, 52,  79, 'Aug 2023')
  ];
  R.WALLETS.push({ addr: 'cexflow-binance-spot', label: 'Binance Spot Flow', type: 'Market Maker',
                   chains: ['ethereum'], pnl30d: 0, winRate: 50, trades30d: 0, score: 65, since: 'live feed' });
  R.walletByAddr = new Map(R.WALLETS.map(w => [w.addr, w]));

  /* ---- whale trade events (seeded history; live engine appends) ---- */
  R.WHALE_TRADES = [];
  R.buildWhaleTrades = function(){
    const trades = [];
    const live = R.pairs.filter(p => p.price > 0 && p.buys + p.sells > 0);
    if (!live.length) return;
    const g = CDX.Fmt.mulberry32(7331);
    for (let i = 0; i < 36; i++){
      const p = live[Math.floor(g() * live.length)];
      const w = R.WALLETS[Math.floor(g() * R.WALLETS.length)];
      const side = g() < (p.buys / (p.buys + p.sells)) ? 'buy' : 'sell';
      const usd = Math.min(p.liq * (0.04 + g()*0.08), 28e3 * Math.exp(g() * 4.4));
      trades.push({ id: 'wt' + i, ts: Date.now() - (4 + i*9 + g()*7)*60e3, wallet: w.addr,
        pairId: p.id, side, usd, price: p.price, tx: '0x' + hex(12) + '…' });
    }
    R.WHALE_TRADES = trades.sort((a,b) => b.ts - a.ts);
  };
  R.buildWhaleTrades();
  R.mkWhaleTrade = () => {
    const live = R.pairs.filter(p => p.price > 0 && p.buys + p.sells > 0);
    if (!live.length) return null;
    const p = live[Math.floor(Math.random() * live.length)];
    const w = R.WALLETS[Math.floor(Math.random() * R.WALLETS.length)];
    const side = Math.random() < (p.buys / (p.buys + p.sells)) ? 'buy' : 'sell';
    const usd = Math.min(p.liq * (0.04 + Math.random()*0.08), 28e3 * Math.exp(Math.random() * 4.4));
    return { id: 'wt' + Date.now(), ts: Date.now(), wallet: w.addr, pairId: p.id, side, usd,
      price: p.price, tx: '0x' + Math.random().toString(16).slice(2, 14) + '…' };
  };
})();
