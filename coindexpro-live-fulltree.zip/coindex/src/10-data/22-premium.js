/* CDX.Premium — feature gating (Phase 16). Separates free vs premium features
   behind a single gate. No billing logic here — just the policy layer and a
   tier flag the rest of the app can read. Default tier is 'free'. Setting the
   tier is a host responsibility (auth/billing integration), not faked here. */
CDX.Premium = (() => {
  /* feature → minimum tier required */
  const POLICY = {
    // free
    'markets': 'free', 'dex': 'free', 'pairs': 'free', 'charts': 'free',
    'whales': 'free', 'news': 'free', 'chains': 'free', 'search': 'free',
    'status': 'free', 'liquidity': 'free',
    // premium
    'smartMoney': 'premium', 'whaleClusters': 'premium', 'sectorFlow': 'premium',
    'walletProfiler': 'premium', 'alertsAdvanced': 'premium', 'screenerBuilder': 'premium',
    'portfolioSync': 'premium', 'chartOverlays': 'premium', 'personalDashboard': 'premium',
    'eventReplay': 'premium', 'historicalExport': 'premium'
  };
  const RANK = { free: 0, premium: 1 };

  let tier = 'free';   // host sets this after real auth; never assumed paid

  function setTier(t){ if (RANK[t] != null) tier = t; return tier; }
  function getTier(){ return tier; }
  function required(feature){ return POLICY[feature] || 'free'; }
  function allowed(feature){ return RANK[tier] >= RANK[required(feature)]; }

  /* gate(feature): returns true if allowed; else returns false. UI decides how
     to present the upsell — this never fabricates access. */
  function gate(feature){ return allowed(feature); }

  /* upsell descriptor for locked features (for UI badges) */
  function lock(feature){
    if (allowed(feature)) return null;
    return { locked: true, feature, requires: required(feature),
             label: 'Premium', note: 'Upgrade to unlock ' + feature };
  }

  function features(t){
    const want = t || tier;
    return Object.keys(POLICY).filter(f => RANK[want] >= RANK[POLICY[f]]);
  }

  return { setTier, getTier, required, allowed, gate, lock, features, POLICY };
})();
