/* CDX.LiveData — unified normalization layer over the three providers.
   Mutates CDX.DataRaw.coins in place and rebuilds CDX.DataRaw.pairs from live pools,
   so every existing module (Intel, pages, heatmaps, screeners) consumes real data unchanged.
   Emits the same 'tick' bus payloads the simulation used, from real provider diffs. */
CDX.LiveData = (() => {
  const R = () => CDX.DataRaw;
  /* our coin id → CoinGecko id */
  const CG_IDS = {
    btc:'bitcoin', eth:'ethereum', usdt:'tether', bnb:'binancecoin', usdc:'usd-coin', xrp:'ripple',
    sol:'solana', trx:'tron', doge:'dogecoin', hype:'hyperliquid', ada:'cardano', wbtc:'wrapped-bitcoin',
    link:'chainlink', avax:'avalanche-2', ltc:'litecoin', ton:'the-open-network', dot:'polkadot',
    shib:'shiba-inu', uni:'uniswap', near:'near', icp:'internet-computer', apt:'aptos', pepe:'pepe',
    arb:'arbitrum', pls:'pulsechain', pol:'polygon-ecosystem-token', plsx:'pulsex', hex:'hex-pulsechain',
    op:'optimism', bonk:'bonk', wif:'dogwifcoin', inc:'incentive'
  };
  const PAIRS_PER_CHAIN = { pulsechain: 14, ethereum: 9, solana: 9, base: 9, arbitrum: 6, bnb: 6, avalanche: 4, optimism: 4, polygon: 4, sui: 4, ton: 4, linea: 3, sonic: 3 };
  const prev = {};               // key → last price (diff source)
  const candleCache = new Map(); // `${key}|${tf}` → { ts, candles, volumes }
  let started = false, ready = false, overlay = null, failTimer = null;

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function diff(key, price){
    const p = prev[key];
    prev[key] = price;
    if (p == null || p === price || !price) return null;
    return { key, dir: price > p ? 1 : -1 };
  }
  function emit(changes){
    const c = changes.filter(Boolean);
    if (c.length) CDX.Bus.emit('tick', c);
  }

  /* ---------- coins (CoinGecko, DexScreener fallback) ---------- */
  const COIN_COLORS = ['#5B8CFF','#F5C04E','#2DD480','#9B5CFF','#FF7849','#2D9CDB','#FF5C5C','#E2B93B','#46C2CB','#C490D1'];
  const colorOf = id => COIN_COLORS[[...id].reduce((a, ch) => a + ch.charCodeAt(0), 0) % COIN_COLORS.length];
  const coinByCg = () => { const m = new Map(); for (const c of R().coins) if (CG_IDS[c.id]) m.set(CG_IDS[c.id], c); return m; };
  function upsertCoin(row, changes){
    const byCg = coinByCg();
    let c = byCg.get(row.cgId);
    if (!c){
      const id = row.cgId.replace(/[^a-z0-9-]/gi, '').toLowerCase();
      if (!id || R().coins.some(x => x.id === id)) return null;
      c = { id, sym: row.sym || id.toUpperCase(), name: row.name, cat: '', color: colorOf(id),
            price: 0, ch1h: 0, ch24: 0, ch7d: 0, mcap: 0, vol: 0, supply: 0, fdv: 0,
            rank: row.rank, spark7d: null, img: null, tags: [] };
      CG_IDS[id] = row.cgId;                    // candles + social resolve for dynamic assets
      R().coins.push(c);
    }
    Object.assign(c, { price: row.price, mcap: row.mcap, vol: row.vol, supply: row.supply || c.supply,
                       fdv: row.fdv, ch1h: +(+row.ch1h).toFixed(2), ch24: +(+row.ch24).toFixed(2), ch7d: +(+row.ch7d).toFixed(2),
                       img: row.img || c.img, totalSupply: row.totalSupply, maxSupply: row.maxSupply,
                       ath: row.ath, athCh: row.athCh, athDate: row.athDate,
                       atl: row.atl, atlCh: row.atlCh, atlDate: row.atlDate });
    if (row.spark && row.spark.length > 10) c.spark7d = row.spark;
    bumpLastBars('c:' + c.id, c.price);
    if (changes) changes.push(diff('c:' + c.id, c.price));
    return c;
  }
  /* top-500 by market cap: two pages of 250, page 1 every cycle (hot), page 2 alternating */
  let coinCycle = 0, depthLoaded = false;
  async function loadDepthCoins(){
    const changes = [];
    const wantPage2 = !depthLoaded || coinCycle % 2 === 1;
    const p1 = await CDX.Net.Cache.swr('cg:top1',
      () => CDX.Providers.coingecko.marketsPage(1, true), { ttl: 50e3, stale: 600e3 });
    p1.forEach(r => upsertCoin(r, changes));
    if (wantPage2){
      try {
        const p2 = await CDX.Net.Cache.swr('cg:top2',
          () => CDX.Providers.coingecko.marketsPage(2, false), { ttl: 110e3, stale: 900e3 });
        p2.forEach(r => upsertCoin(r, changes));
        depthLoaded = true;
      } catch(e){}
    }
    /* cold lane: ranks 501-1000, one page per cycle, no sparklines */
    const coldPage = 3 + (coinCycle % 2);
    try {
      const pc = await CDX.Net.Cache.swr('cg:top' + coldPage,
        () => CDX.Providers.coingecko.marketsPage(coldPage, false), { ttl: 8 * 60e3, stale: 3600e3 });
      pc.forEach(r => upsertCoin(r, changes));
    } catch(e){}
    coinCycle++;
    emit(changes);
  }
  /* sector depth: real CG categories → memecoins · AI · DeFi · RWA · Gaming · L1 · L2 */
  const SECTORS = [
    ['meme-token', 'memecoins'], ['artificial-intelligence', 'ai'],
    ['decentralized-finance-defi', 'defi'], ['real-world-assets-rwa', 'rwa'],
    ['gaming', 'gaming'], ['layer-1', 'infrastructure'], ['layer-2', 'l2'],
    ['depin', 'depin'], ['liquid-staking-tokens', 'staking']
  ];
  let sectorIdx = 0;
  async function loadNextSector(){
    const [cat, narrative] = SECTORS[sectorIdx++ % SECTORS.length];
    try {
      const rows = await CDX.Net.Cache.swr('cg:cat:' + cat,
        () => CDX.Providers.coingecko.categoryMarkets(cat, 100), { ttl: 15 * 60e3, stale: 60 * 60e3 });
      const changes = [];
      for (const r of rows.slice(0, 100)){
        const c = upsertCoin(r, changes);
        if (!c) continue;
        const dyn = R().DYNAMIC_COIN_TAGS[c.id] || (R().DYNAMIC_COIN_TAGS[c.id] = []);
        if (!dyn.includes(narrative)) dyn.push(narrative);
      }
      emit(changes);
      rerank(); CDX.Data.reindex(); R().applyTags();
    } catch(e){}
  }
  const rerank = () => [...R().coins].sort((a, b) => b.mcap - a.mcap).forEach((c, i) => c.rank = i + 1);
  async function loadCoins(){
    const ids = Object.values(CG_IDS).slice(0, 50);   // curated fast lane (1 call) — depth lane covers the rest
    const byCg = await CDX.Net.Cache.swr('cg:markets',
      () => CDX.Providers.coingecko.markets(ids), { ttl: 45e3, stale: 600e3 });
    const changes = [];
    const missing = [];
    for (const c of R().coins){
      const m = byCg[CG_IDS[c.id]];
      if (!m || !m.price){ if (!prev['c:' + c.id]) missing.push(c); continue; }
      Object.assign(c, { price: m.price, mcap: m.mcap, vol: m.vol, supply: m.supply || c.supply,
                         fdv: m.fdv, ch1h: +m.ch1h.toFixed(2), ch24: +m.ch24.toFixed(2), ch7d: +m.ch7d.toFixed(2),
                         img: m.img || c.img, totalSupply: m.totalSupply, maxSupply: m.maxSupply,
                         ath: m.ath, athCh: m.athCh, athDate: m.athDate,
                         atl: m.atl, atlCh: m.atlCh, atlDate: m.atlDate });
      if (m.spark && m.spark.length > 10) c.spark7d = m.spark;
      bumpLastBars('c:' + c.id, c.price);
      changes.push(diff('c:' + c.id, c.price));
    }
    rerank();
    fallbackFill(missing, changes);
    emit(changes);
    lastMissing = missing.map(c => c.id);
  }
  let lastMissing = [];
  /* resolve coins absent from CoinGecko from a live DEX pool of the same base symbol */
  function fallbackFill(missing, changes){
    for (const c of missing){
      const pool = R().pairs.find(p => p.base === c.sym && p.price > 0);
      if (!pool) continue;
      Object.assign(c, { price: pool.price, ch24: pool.ch.h24, ch1h: pool.ch.h1,
                         vol: pool.vol, fdv: pool.fdv, mcap: pool.fdv });
      changes.push(diff('c:' + c.id, c.price));
    }
  }
  async function loadFearGreed(){
    try { CDX.Data.setFearGreed(await CDX.Providers.coingecko.fearGreed()); } catch(e){}
  }

  /* ---------- pairs (GeckoTerminal discovery, DexScreener refresh) ---------- */
  function toPair(n){
    return { id: n.chain + '_' + n.address, base: n.base, quote: n.quote, name: n.name, dex: n.dex, img: n.img || null,
             chain: n.chain, price: n.price, ch: n.ch, liq: n.liq, vol: n.vol, buys: n.buys, sells: n.sells,
             ageH: n.ageH, fdv: n.fdv, ca: n.ca, address: n.address, tags: [] };
  }
  /* dedup ingest: keyed by chain|pool-address, with a chain|token-ca fallback so live
     pools overwrite seed pairs that carry only a token contract (ca) and no pool address.
     Guards undefined address (seeds lack a pool address) so keys never throw. */
  function ingestPools(pools, opts){
    const arr = R().pairs;
    const aKey = p => p.address ? (p.chain + '|' + p.address.toLowerCase()) : null;   // pool-address key
    const cKey = p => p.ca ? (p.chain + '|ca:' + p.ca.toLowerCase()) : null;          // token-contract key
    const idx = new Map();
    for (const p of arr){
      const ak = aKey(p); if (ak) idx.set(ak, p);
      const ck = cKey(p); if (ck && !idx.has(ck)) idx.set(ck, p);   // seeds resolvable by ca
    }
    const changes = [];
    let added = 0;
    for (const n of pools || []){
      if (!n.address || !(n.price > 0) || n.liq < ((opts && opts.minLiq) || 1500)) continue;
      const STB = ['USDT','USDC','DAI','PDAI','USDC.E','FUSD','USDL','TUSD','USDE'];
      if (STB.includes((n.base || '').toUpperCase()) && STB.includes((n.quote || '').toUpperCase())) continue;
      const ak = n.chain + '|' + n.address.toLowerCase();
      const ck = n.ca ? (n.chain + '|ca:' + n.ca.toLowerCase()) : null;
      let cur = idx.get(ak) || (ck && idx.get(ck)) || null;        // pool-address first, then ca fallback
      if (cur){
        applyPairUpdate(cur, n, changes);
        if (!cur.address){ cur.address = n.address; idx.set(ak, cur); }  // backfill pool addr; no dupes later
        continue;
      }
      const p = toPair(n);
      idx.set(ak, p);
      if (ck && !idx.has(ck)) idx.set(ck, p);
      arr.push(p);
      prev['d:' + p.id] = p.price;
      added++;
    }
    emit(changes);
    return added;
  }
  /* boot discovery: one fast top-pools page per chain (depth jobs stream the rest) */
  async function discoverPairs(){
    let total = 0;
    for (const chain of CDX.DataRaw.CHAIN_ORDER){
      try { total += ingestPools(await CDX.Providers.geckoterminal.topPools(chain, 1)); }
      catch(e){ console.warn('[live] discovery failed', chain, e.message); }
    }
    return total;
  }
  /* depth expansion: cyclic job list across every chain — top pools p1..5,
     trending p1..2, newest p1 ≈ 72 GT endpoints → 2000+ indexed pairs,
     continuously re-walked so the whole universe stays fresh */
  const depthJobs = [];
  for (const chain of CDX.DataRaw.CHAIN_ORDER){
    const major = ['ethereum','solana','base','bnb','pulsechain'].includes(chain);
    for (let pg = 1; pg <= (major ? 8 : 5); pg++) depthJobs.push({ chain, kind: 'top', pg });
    for (let pg = 1; pg <= (major ? 3 : 2); pg++) depthJobs.push({ chain, kind: 'trending', pg });
    for (let pg = 1; pg <= 2; pg++) depthJobs.push({ chain, kind: 'new', pg });
  }
  let depthIdx = 0, depthAddedSinceIndex = 0;
  async function depthStep(){
    const job = depthJobs[depthIdx++ % depthJobs.length];
    try {
      const fn = job.kind === 'top' ? 'topPools' : job.kind === 'trending' ? 'trendingPools' : 'newPools';
      const floor = job.chain === 'pulsechain' ? (job.kind === 'new' ? 300 : 500)
                  : (job.kind === 'new' ? 800 : 1500);
      depthAddedSinceIndex += ingestPools(await CDX.Providers.geckoterminal[fn](job.chain, job.pg), { minLiq: floor });
    } catch(e){}
    if (depthAddedSinceIndex >= 25 || depthIdx % depthJobs.length === 0){
      depthAddedSinceIndex = 0;
      prunePairs();
      CDX.Data.reindex(); R().applyTags();
    }
  }
  /* smart pruning: cap the universe at 2600 — keep by composite pair rank */
  const pairScore = p => Math.log10(p.vol + 1) * 2 + Math.log10(p.liq + 1) * 1.5
    + Math.log10(p.buys + p.sells + 1) + (p.ageH <= 48 ? 1.5 : 0);
  function prunePairs(){
    const arr = R().pairs;
    if (arr.length <= 4000) return;
    const keep = new Set(CDX.Store.state.watch);
    const ranked = [...arr].sort((a, b) => pairScore(b) - pairScore(a));
    const next = [];
    for (const p of ranked){
      if (next.length < 4000 || keep.has('d:' + p.id) || p.chain === 'pulsechain') next.push(p);
    }
    const kept = new Set(next.map(p => p.id));
    for (const p of arr) if (!kept.has(p.id)) delete prev['d:' + p.id];   // free diff baselines
    arr.length = 0;
    arr.push(...next);
    CDX.Bus.emit('pairs:pruned', kept);                                   // engines drop dead series
  }
  /* one DexScreener batch per chain; on-demand single-pair refreshes coalesce into it */
  const pairBatches = new Map();
  function pairBatch(chain){
    if (!pairBatches.has(chain)){
      pairBatches.set(chain, CDX.Net.Batch.create({ windowMs: 120, max: 30,
        exec: async addrs => {
          const fresh = await CDX.Providers.dexscreener.pairs(chain, addrs);
          return new Map(fresh.map(f => [f.address.toLowerCase(), f]));
        } }));
    }
    return pairBatches.get(chain);
  }
  function applyPairUpdate(p, f, changes){
    if (!f || !f.price) return;
    Object.assign(p, { price: f.price, ch: f.ch, liq: f.liq ?? p.liq, vol: f.vol ?? p.vol,
                       buys: f.buys ?? p.buys, sells: f.sells ?? p.sells,
                       fdv: f.fdv ?? p.fdv, ageH: f.ageH ?? p.ageH, ca: f.ca || p.ca,
                       img: p.img || f.img || null });
    changes.push(diff('d:' + p.id, p.price));
    bumpLastBars('d:' + p.id, p.price);
  }
  /* ---- PulseChain tracked universe (chain adapter) ---- */
  function pulseMissingSyms(){
    const have = new Set(R().pairs.filter(p => p.chain === 'pulsechain').map(p => p.base.toUpperCase()));
    return CDX.Providers.pulsex.TOKENS.map(t => t.baseSym).filter(s => !have.has(s.toUpperCase()));
  }
  async function ensurePulse(filterSyms){
    try {
      const pools = await CDX.Providers.pulsex.trackedPairs(filterSyms);
      const arr = R().pairs;
      const have = new Set(arr.map(p => p.chain + '|' + p.address.toLowerCase()));
      let added = 0;
      for (const n of pools){
        const k = 'pulsechain|' + n.address.toLowerCase();
        if (!n.price || have.has(k)) continue;
        have.add(k);
        const p = toPair(n);
        arr.push(p);
        prev['d:' + p.id] = p.price;
        added++;
      }
      if (added && ready){
        CDX.Data.reindex();
        if (CDX.DataRaw.applyTags) CDX.DataRaw.applyTags();
      }
      return added;
    } catch(e){ console.warn('[live] pulse tracked set failed', e.message); return 0; }
  }
  /* pulse expansion is served by the live:depth job walk (pulse top p1-5 + trending + new
     run at lower liq floors there); boot gets one immediate page so the hub is never empty */
  async function expandPulsePools(){
    try {
      const added = ingestPools(await CDX.Providers.geckoterminal.topPools('pulsechain', 1), { minLiq: 1000 });
      if (added){ CDX.Data.reindex(); R().applyTags(); }
    } catch(e){}
  }
  let pulseBootExpanded = false;
  async function topUpPulse(){
    if (!pulseBootExpanded){ pulseBootExpanded = true; await expandPulsePools(); }
    const missing = pulseMissingSyms();
    if (missing.length) await ensurePulse(missing);
  }
  const pulseTracked = () => R().pairs.filter(p => p.chain === 'pulsechain');
  async function refreshPulseHolders(){
    const seen = new Set();
    const tops = [...pulseTracked()].sort((a, b) => b.liq - a.liq).slice(0, 20);
    for (const p of tops){
      const addr = p.ca && p.ca.startsWith('0x') && p.ca.toLowerCase() !== p.address.toLowerCase() ? p.ca : null;
      if (!addr || seen.has(addr.toLowerCase())) continue;
      seen.add(addr.toLowerCase());
      const stats = await CDX.Providers.pulsex.tokenStats(addr);
      if (!stats) continue;
      for (const q of R().pairs){
        if (q.chain !== 'pulsechain' || (q.ca || '').toLowerCase() !== addr.toLowerCase()) continue;
        if (stats.holders != null) q.holders = stats.holders;
        if (stats.supply != null){
          q.supplyOnChain = stats.supply;
          if (!q.fdv && q.price) q.fdv = q.price * stats.supply;
        }
      }
    }
  }
  const seenWhaleTx = new Set();
  const capSet = (set, max) => { if (set.size > max) for (const k of set){ set.delete(k); if (set.size <= max * 0.7) break; } };
  const walletSeen = new Map();
  function noteSmartMoney(addr){
    if (!addr || !addr.startsWith('0x')) return;
    const n = (walletSeen.get(addr) || 0) + 1;
    walletSeen.set(addr, n);
    const w = CDX.DataRaw.walletByAddr.get(addr);
    if (w){ if (w.type === 'Smart Money') w.trades30d = n; return; }
    if (n < 3) return;
    const reg = { addr, label: 'Pulse Whale ' + addr.slice(0, 6) + '…' + addr.slice(-4),
                  type: 'Smart Money', chains: ['pulsechain'], pnl30d: 0, winRate: 50,
                  trades30d: n, score: 70, since: 'live feed' };
    CDX.DataRaw.WALLETS.push(reg);
    CDX.DataRaw.walletByAddr.set(addr, reg);
  }
  async function refreshPulseWhales(){
    const tops = [...pulseTracked()].sort((a, b) => b.vol - a.vol).slice(0, 5);
    for (const p of tops){
      let trades;
      try { trades = await CDX.Providers.pulsex.poolTrades(p.address, 3000); }
      catch(e){ continue; }
      if (!trades.length) continue;
      const flow = CDX.Providers.pulsex.flowFromTrades(trades);
      if (flow.buyVol + flow.sellVol > 0) p.flowMeasured = { buyVol: flow.buyVol, sellVol: flow.sellVol, ts: Date.now() };
      for (const t of trades.slice(0, 6).reverse()){
        if (!t.tx || seenWhaleTx.has(t.tx)) continue;
        seenWhaleTx.add(t.tx);
        capSet(seenWhaleTx, 4000);
        const trade = { id: t.tx, ts: t.ts, wallet: t.wallet, pairId: p.id,
                        side: t.side, usd: t.usd, price: t.price || p.price, tx: t.tx };
        CDX.DataRaw.WHALE_TRADES.unshift(trade);
        noteSmartMoney(t.wallet);
        CDX.Bus.emit('whale:new', trade);
      }
    }
    CDX.DataRaw.WHALE_TRADES.sort((a, b) => b.ts - a.ts);
    if (CDX.DataRaw.WHALE_TRADES.length > 80) CDX.DataRaw.WHALE_TRADES.length = 80;
    if (seenWhaleTx.size > 400){
      const keep = [...seenWhaleTx].slice(-200);
      seenWhaleTx.clear();
      keep.forEach(x => seenWhaleTx.add(x));
    }
  }
  let chainCursor = 0;
  async function refreshNextChain(){
    const chain = CDX.DataRaw.CHAIN_ORDER[chainCursor++ % CDX.DataRaw.CHAIN_ORDER.length];
    const mine = R().pairs.filter(p => p.chain === chain);
    if (!mine.length) return;
    try {
      const b = pairBatch(chain);
      const results = await Promise.all(mine.map(p => b.add(p.address.toLowerCase())));
      const changes = [];
      mine.forEach((p, i) => applyPairUpdate(p, results[i], changes));
      emit(changes);
    } catch(e){ console.warn('[live] refresh failed', chain, e.message); }
  }
  async function requestPairRefresh(pairId){
    const p = R().pairs.find(x => x.id === pairId);
    if (!p) return;
    const f = await pairBatch(p.chain).add(p.address.toLowerCase());
    const changes = [];
    applyPairUpdate(p, f, changes);
    emit(changes);
  }
  /* WS ingestion: throttled flushes from Streams land here */
  function pushPrices(updates){
    const changes = [];
    for (const u of updates){
      const c = R().coins.find(x => x.id === u.id);
      if (!c || !u.price) continue;
      c.price = u.price;
      if (u.ch24 != null) c.ch24 = +u.ch24.toFixed(2);
      c.mcap = c.supply ? c.price * c.supply : c.mcap;
      bumpLastBars('c:' + c.id, c.price);
      changes.push(diff('c:' + c.id, c.price));
    }
    emit(changes);
  }

  /* ---------- real candles ---------- */
  const COIN_DAYS = { '1m': 1, '15m': 1, '1H': 1, '4H': 30, '1D': 365 };
  const GT_TF = { '1m': ['minute', 1], '15m': ['minute', 15], '1H': ['hour', 1], '4H': ['hour', 4], '1D': ['day', 1] };
  const cacheIdFor = (key, tf) => key.startsWith('c:') ? key + '|d' + (COIN_DAYS[tf] || 1) : key + '|' + tf;
  async function candles(key, tf, item){
    const id = cacheIdFor(key, tf);
    const out = await CDX.Net.Cache.swr('cnd:' + id,
      () => fetchCandles(key, tf, item, id), { ttl: 60e3, stale: 900e3 });
    if (candleCache.size > 40) candleCache.delete(candleCache.keys().next().value);
    candleCache.set(id, out);                            // keep live last-bar mutation working
    return out;
  }
  async function fetchCandles(key, tf, item, id){
    let out;
    if (key.startsWith('c:')){
      let rows;
      try {
        rows = await CDX.Providers.coingecko.ohlc(CG_IDS[key.slice(2)] || key.slice(2), COIN_DAYS[tf] || 1);
        out = { ts: Date.now(), candles: rows, volumes: [] };
      } catch(e){                                        // failover: coin's primary DEX pool via GT
        const coin = CDX.Data.byKey(key);
        const pool = coin && CDX.Data.pairsForToken(coin)[0];
        if (!pool) throw e;
        const [gtf, agg] = GT_TF[tf] || GT_TF['1H'];
        const alt = await CDX.Providers.geckoterminal.ohlcv(pool.chain, pool.address, gtf, agg);
        out = { ts: Date.now(),
                candles: alt.map(r => r.candle),
                volumes: alt.map(r => ({ time: r.candle.time, value: r.vol,
                  color: r.candle.close >= r.candle.open ? 'rgba(45,212,128,0.35)' : 'rgba(255,92,92,0.35)' })) };
      }
    } else {
      const p = item || CDX.Data.byKey(key);
      const [gtf, agg] = GT_TF[tf] || GT_TF['1H'];
      const rows = await CDX.Providers.geckoterminal.ohlcv(p.chain, p.address, gtf, agg);
      out = { ts: Date.now(),
              candles: rows.map(r => r.candle),
              volumes: rows.map(r => ({ time: r.candle.time, value: r.vol,
                color: r.candle.close >= r.candle.open ? 'rgba(45,212,128,0.35)' : 'rgba(255,92,92,0.35)' })) };
    }
    if (candleCache.size > 40) candleCache.delete(candleCache.keys().next().value);
    candleCache.set(id, out);
    return out;
  }
  function bumpLastBars(key, price){
    for (const [id, s] of candleCache){
      if (!id.startsWith(key + '|') || !s.candles.length) continue;
      const last = s.candles[s.candles.length - 1];
      last.close = price;
      last.high = Math.max(last.high, price);
      last.low = Math.min(last.low, price);
      s.lastChanged = last;
    }
  }
  const lastBar = (key, tf) => { const s = candleCache.get(cacheIdFor(key, tf)); return s && s.lastChanged; };
  const logoOf = sym => {
    if (!sym) return null;
    const S = String(sym).toUpperCase();
    const c = R().coins.find(x => x.sym === S && x.img);
    if (c) return c.img;
    const p = R().pairs.find(x => x.base.toUpperCase() === S && x.img);
    return p ? p.img : null;
  };
  const sparkOf = id => {
    const m = /^(sp|sc)(.+)$/.exec(id);
    if (!m) return null;
    const c = R().coins.find(x => x.id === m[2]);
    return c && c.spark7d;
  };

  /* ---------- boot + overlay ---------- */
  function showOverlay(){
    overlay = CDX.Dom.el('div', 'fixed inset-0 z-[95] bg-ink/96 grid place-items-center',
      `<div class="text-center">
        <div class="w-10 h-10 rounded-xl pls-grad grid place-items-center font-disp font-bold text-white text-lg mx-auto animate-pulse">C</div>
        <div class="font-disp font-semibold text-white mt-3">Connecting live market data</div>
        <div class="text-[11px] text-mut mt-1">CoinGecko · DexScreener · GeckoTerminal</div></div>`);
    document.body.appendChild(overlay);
  }
  function hideOverlay(){ if (overlay){ overlay.remove(); overlay = null; } if (failTimer){ clearTimeout(failTimer); failTimer = null; } }
  function finish(ok){
    if (ready) return;
    CDX.DataRaw.coins.forEach(c => { prev['c:' + c.id] = c.price; });
    CDX.Data.reindex();
    if (CDX.DataRaw.applyTags) CDX.DataRaw.applyTags();
    if (CDX.DataRaw.buildWhaleTrades) CDX.DataRaw.buildWhaleTrades();
    /* prune persisted keys that no longer resolve against the live universe */
    let pruned = false;
    for (const l of CDX.Store.state.lists){
      const next = l.keys.filter(k => CDX.Data.byKey(k));
      if (next.length !== l.keys.length){ l.keys = next; pruned = true; }
    }
    const liveHoldings = CDX.Store.state.holdings.filter(h => CDX.Data.byKey(h.key));
    if (liveHoldings.length !== CDX.Store.state.holdings.length){ CDX.Store.state.holdings = liveHoldings; pruned = true; }
    if (pruned){ CDX.Store.persist(); CDX.Bus.emit('lists:changed'); }
    ready = true;
    hideOverlay();
    CDX.Bus.emit('data:ready');
    CDX.Router.go(location.hash.slice(1) || '/');
    if (!ok) CDX.UI.toast('Some live feeds unreachable — data may be partial.', 'warn');
  }
  async function boot(){
    CDX.Net.Conn.init();
    showOverlay();
    failTimer = setTimeout(() => { if (!ready) finish(false); }, 25000);
    const results = await Promise.allSettled([discoverPairs().then(() => ensurePulse()), loadCoins(), loadFearGreed()]);
    /* defer universe-wide depth hydration off the first-paint critical path (mobile lag fix) */
    const deferDepth = () => loadDepthCoins().then(() => { rerank(); CDX.Data.reindex(); R().applyTags(); }).catch(() => {});
    (window.requestIdleCallback ? requestIdleCallback(deferDepth, { timeout: 4000 }) : setTimeout(deferDepth, 1200));
    {   // second pass without another API call: fill stragglers from discovered pools
      const changes = [];
      fallbackFill(R().coins.filter(c => lastMissing.includes(c.id) || !prev['c:' + c.id]), changes);
      emit(changes);
    }
    finish(results.some(r => r.status === 'fulfilled'));
    CDX.Net.Conn.poller('live:coins', () => loadCoins(), 60000).start();
    CDX.Net.Conn.poller('live:coins500', () => loadDepthCoins().then(rerank), 90000).start();
    CDX.Net.Conn.poller('live:sectors', () => loadNextSector(), 45000, { immediate: true }).start();
    CDX.Net.Conn.poller('live:depth', () => depthStep(), 2700).start();          // ≈22 GT req/min · full walk ≈6min
    CDX.Net.Conn.poller('pls:fresh', async () => {                                 // pulse fast lane: launches minutes old
      try {
        const added = ingestPools(await CDX.Providers.geckoterminal.newPools('pulsechain', 1), { minLiq: 250 });
        if (added){ CDX.Data.reindex(); R().applyTags(); }
      } catch(e){}
    }, 90000).start();
    CDX.Net.Conn.poller('live:pairs', () => refreshNextChain(), 2400).start();   // ≈25 DS req/min (hot set)
    CDX.Net.Conn.poller('live:fng', () => loadFearGreed(), 300000).start();
    CDX.Net.Conn.poller('pls:whales', () => refreshPulseWhales(), 50000, { immediate: true }).start();
    CDX.Net.Conn.poller('pls:holders', () => refreshPulseHolders(), 600000, { immediate: true }).start();
    CDX.Net.Conn.poller('pls:tracked', () => topUpPulse(), 300000).start();
    CDX.Net.Streams.start();
  }
  function start(){
    if (started) return;
    started = true;
    setTimeout(boot, 0);                          // defer until all provider scripts are parsed
  }
  return { start, candles, lastBar, sparkOf, logoOf, pushPrices, requestPairRefresh, cgIds: CG_IDS,
           pulseHead: null, isReady: () => ready };
})();
