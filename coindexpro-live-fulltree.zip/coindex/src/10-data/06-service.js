/* CDX.Data — the data facade. Every page talks to this, never to raw arrays.
   Swap the internals for real REST/WebSocket adapters later without touching UI code. */
CDX.Data = (() => {
  const R = CDX.DataRaw;
  const coins = R.coins, pairs = R.pairs, CHAINS = R.CHAINS;
  const coinById = new Map(coins.map(c => [c.id, c]));
  const pairById = new Map(pairs.map(p => [p.id, p]));
  const OTHER_MCAP = 0, OTHER_VOL = 0;                    // live mode: no synthetic padding
  let fearGreed = 38;

  const byKey = key => !key ? null : (key.startsWith('c:') ? coinById.get(key.slice(2)) : pairById.get(key.slice(2)));
  const label = it => it.sym ? it.sym : it.base + '/' + it.quote;
  const ch24  = it => it.sym ? it.ch24 : it.ch.h24;

  function globals(){
    const tracked = coins.reduce((a,c)=>a+c.mcap,0);
    const totalMcap = tracked + OTHER_MCAP;
    return {
      totalMcap,
      totalVol: coins.reduce((a,c)=>a+c.vol,0) + OTHER_VOL,
      btcDom: coins[0].mcap / totalMcap * 100,
      ethDom: coinById.get('eth').mcap / totalMcap * 100,
      wCh24: coins.reduce((a,c)=>a + c.ch24*c.mcap, 0) / tracked,
      fearGreed,
      nCoins: coins.length, nPairs: pairs.length
    };
  }
  function fuzzySub(hay, q){
    let i = 0;
    for (let j = 0; j < hay.length && i < q.length; j++) if (hay[j] === q[i]) i++;
    return i === q.length;
  }
  function matchScore(sym, name, q){
    if (sym === q) return 100;
    if (sym.startsWith(q)) return 84;
    if (name === q) return 74;
    if (name.startsWith(q)) return 62;
    if (sym.includes(q)) return 50;
    if (name.includes(q)) return 38;
    if (q.length >= 3 && fuzzySub(name, q)) return 20;
    return 0;
  }
  function search(q, limit){
    q = q.toLowerCase().trim();
    if (!q) return [];
    const hits = [];
    /* pasted contract / pool address → direct match across the whole universe */
    if (/^(0x[a-f0-9]{6,}|[1-9a-hj-np-z]{25,})$/i.test(q)){
      for (const p of pairs){
        const ca = (p.ca || '').toLowerCase(), ad = (p.address || '').toLowerCase();
        if (ca.startsWith(q) || ad.startsWith(q) || ca === q || ad === q)
          hits.push({ type:'pair', key:'d:'+p.id, it:p, score: 200 + Math.log10(p.liq + 1) });
      }
      if (hits.length) return hits.sort((a,b)=>b.score-a.score).slice(0, limit || 8);
    }
    for (const c of coins){
      const s = matchScore(c.sym.toLowerCase(), c.name.toLowerCase(), q);
      if (s) hits.push({ type:'coin', key:'c:'+c.id, it:c,
        score: s + 6 + Math.min(8, Math.log10((c.mcap || 1) + 1)) });   // symbol/coin priority
    }
    for (const p of pairs){
      let s = matchScore(p.base.toLowerCase(), (p.name || '').toLowerCase(), q);
      if (!s && (p.base + '/' + p.quote).toLowerCase().includes(q)) s = 44;
      if (!s && CHAINS[p.chain].name.toLowerCase().startsWith(q)) s = 12;
      if (!s) continue;
      if (p.base.toLowerCase() === q) s += 10;                           // exact pair priority
      hits.push({ type:'pair', key:'d:'+p.id, it:p,
        score: s + Math.min(7, Math.log10((p.liq || 1) + 1)) });
    }
    const ranked = hits.sort((a, b) => b.score - a.score);
    return suppressDupes(ranked).slice(0, limit || 8);
  }

  /* Scam/duplicate suppression (Phase 4): many low-liquidity impostor pairs
     reuse a popular symbol. For pair hits sharing a base symbol, keep only the
     deepest-liquidity one in the visible set and demote the rest, so a search
     for "PEPE" surfaces the real market, not a wall of fakes. Coins are never
     suppressed (canonical assets). Pure ranking — nothing is fabricated. */
  function suppressDupes(ranked){
    const bestBySym = new Map();
    for (const h of ranked){
      if (h.type !== 'pair') continue;
      const sym = (h.it.base || '').toLowerCase();
      const liq = h.it.liq || 0;
      const cur = bestBySym.get(sym);
      if (!cur || liq > cur.liq) bestBySym.set(sym, { liq, key: h.key });
    }
    const seenSym = new Set();
    const out = [];
    for (const h of ranked){
      if (h.type === 'pair'){
        const sym = (h.it.base || '').toLowerCase();
        const champ = bestBySym.get(sym);
        if (champ && champ.key !== h.key){
          // a deeper-liquidity pair for this symbol exists → demote impostor
          if (seenSym.has(sym)) continue;       // already showed the champ + one demoted note
          if ((h.it.liq || 0) < (champ.liq || 0) * 0.05){ continue; }  // <5% of champ liq → hide as likely impostor
        }
        seenSym.add(sym);
      }
      out.push(h);
    }
    return out;
  }
  function pairsForToken(coin){
    const sym = coin.sym;
    return pairs.filter(p => p.base === sym || p.quote === sym ||
      (sym === 'PLS' && (p.base === 'WPLS' || p.quote === 'WPLS')) ||
      (sym === 'ETH' && (p.base === 'WETH' || p.quote === 'WETH')) ||
      (sym === 'BNB' && p.quote === 'WBNB') || (sym === 'AVAX' && p.quote === 'WAVAX') ||
      (sym === 'SOL' && p.quote === 'SOL'));
  }
  /* ---- live data engine (providers) — simulation removed in Phase 5 ---- */
  function reindex(){
    coinById.clear(); coins.forEach(c => coinById.set(c.id, c));
    pairById.clear(); pairs.forEach(p => pairById.set(p.id, p));
  }
  function setFearGreed(v){ if (v >= 0 && v <= 100) fearGreed = v; }
  let timer = null;
  function startLive(){
    if (timer) return;
    timer = true;
    CDX.LiveData.start();
  }
  return { coins, pairs, CHAINS, CHAIN_ORDER: R.CHAIN_ORDER, LOGOS: R.LOGOS,
           byKey, label, ch24, globals, search, pairsForToken, startLive, reindex, setFearGreed };
})();
