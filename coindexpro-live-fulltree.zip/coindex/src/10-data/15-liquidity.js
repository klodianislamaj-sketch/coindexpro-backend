/* CDX.Liq — liquidity intelligence engine.
   Samples pooled liquidity across the live universe, detects LP adds/removals from
   pool deltas, links removals→adds into migrations, scores pool-death signals,
   measures concentration, and nets cross-chain liquidity flow.
   Scores: Liquidity Pressure (capital strain, higher = draining) and
   Liquidity Stability (depth quality + variance + retention). */
CDX.Liq = (() => {
  const R = () => CDX.DataRaw;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const HOUR = 36e5;
  const series = new Map();   // pairId → [{ ts, liq, vol }]
  const peak = new Map();     // pairId → session max liq
  const events = [];          // { ts, pairId, type:'add'|'remove', delta, pct }
  const migrations = [];      // { ts, sym, fromId, toId, usd }
  let lastSample = 0;

  function detect(p, prev, cur){
    const delta = cur.liq - prev.liq;
    const ref = Math.max(prev.liq, 1);
    const pulse = p.chain === 'pulsechain';
    if (Math.abs(delta) < Math.max(ref * (pulse ? 0.025 : 0.03), pulse ? 2500 : 5000)) return;
    const ev = { ts: cur.ts, pairId: p.id, type: delta > 0 ? 'add' : 'remove',
                 delta, pct: delta / ref * 100 };
    events.unshift(ev);
    if (events.length > 240) events.length = 240;
    if (ev.type === 'add'){                      // migration: matching removal of same base elsewhere
      const cut = ev.ts - 15 * 60e3;
      const rem = events.find(e => e.type === 'remove' && e.ts >= cut && e.pairId !== p.id &&
        (() => { const q = CDX.Data.byKey('d:' + e.pairId); return q && q.base === p.base; })());
      if (rem){
        migrations.unshift({ ts: ev.ts, sym: p.base, fromId: rem.pairId, toId: p.id,
                             usd: Math.min(Math.abs(rem.delta), ev.delta) });
        if (migrations.length > 60) migrations.length = 60;
      }
    }
    CDX.Bus.emit('liq:event', ev);
  }
  function snapshot(){
    for (const p of CDX.Data.pairs){
      let arr = series.get(p.id);
      if (!arr) series.set(p.id, arr = []);
      const cur = { ts: Date.now(), liq: p.liq, vol: p.vol };
      const prev = arr[arr.length - 1];
      arr.push(cur);
      if (arr.length > 160) arr.shift();
      peak.set(p.id, Math.max(peak.get(p.id) || 0, p.liq));
      if (prev) detect(p, prev, cur);
    }
  }
  CDX.Bus.on('pairs:pruned', kept => {
    for (const id of series.keys()) if (!kept.has(id)){ series.delete(id); peak.delete(id); }
  });
  CDX.Bus.on('data:ready', snapshot);
  CDX.Bus.on('tick', () => { if (Date.now() - lastSample > 45000){ lastSample = Date.now(); snapshot(); } });

  const seriesFor = pairId => series.get(pairId) || [];
  const at = (arr, agoMs) => arr.find(s => Date.now() - s.ts <= agoMs) || arr[0];
  function windowDelta(p, ms){
    const arr = seriesFor(p.id);
    if (arr.length < 2) return 0;
    const old = at(arr, ms);
    return old && old.liq ? (p.liq - old.liq) / old.liq * 100 : 0;
  }
  const eventsFor = (pairId, ms) => events.filter(e => e.pairId === pairId && Date.now() - e.ts <= ms);

  /* ---- Liquidity Pressure Score: higher = capital draining / strain ---- */
  function pressure(p){
    const net = windowDelta(p, HOUR);
    const evs = eventsFor(p.id, 2 * HOUR);
    const removeUsd = evs.filter(e => e.type === 'remove').reduce((a, e) => a + Math.abs(e.delta), 0);
    const m = p.flowMeasured;
    const sellRatio = m && m.buyVol + m.sellVol > 0 ? m.sellVol / (m.buyVol + m.sellVol)
                    : (p.buys + p.sells ? p.sells / (p.buys + p.sells) : 0.5);
    const cut = Date.now() - 6 * HOUR;
    let whaleSell = 0;
    for (const t of R().WHALE_TRADES) if (t.pairId === p.id && t.ts >= cut && t.side === 'sell') whaleSell += t.usd;
    const parts = {
      drain: clamp(-net * 3, 0, 40),
      removals: clamp(removeUsd / Math.max(p.liq, 1) * 120, 0, 25),
      sellFlow: clamp((sellRatio - 0.5) * 70, 0, 20),
      whaleExits: clamp(whaleSell / Math.max(p.liq, 1) * 140, 0, 15)
    };
    return { score: Math.round(clamp(parts.drain + parts.removals + parts.sellFlow + parts.whaleExits, 0, 100)),
             parts, net, removeUsd };
  }
  /* ---- Liquidity Stability Score: depth quality + low variance + retention ---- */
  function stability(p){
    const arr = seriesFor(p.id);
    let varScore = 22;                                    // neutral until enough samples
    if (arr.length >= 5){
      const vals = arr.map(s => s.liq);
      const mean = vals.reduce((a, b) => a + b, 0) / vals.length;
      const cv = mean ? Math.sqrt(vals.reduce((a, v) => a + (v - mean) ** 2, 0) / vals.length) / mean : 1;
      varScore = clamp(45 - cv * 700, 0, 45);
    }
    const depth = p.liq > 1e6 ? 20 : p.liq > 250e3 ? 14 : p.liq > 75e3 ? 8 : p.liq > 25e3 ? 3 : 0;
    const age = p.ageH > 24 * 30 ? 10 : p.ageH > 24 * 7 ? 6 : p.ageH > 72 ? 3 : 0;
    const retention = clamp(p.liq / Math.max(peak.get(p.id) || p.liq, 1) * 15, 0, 15);
    const calm = clamp(10 - eventsFor(p.id, 2 * HOUR).length * 2.5, 0, 10);
    return { score: Math.round(clamp(varScore + depth + age + retention + calm, 0, 100)),
             parts: { variance: Math.round(varScore), depth, age, retention: Math.round(retention), calm } };
  }
  /* ---- pool death signals ---- */
  function deathSignals(n){
    return CDX.Data.pairs
      .filter(p => p.ageH > 48)
      .map(p => {
        const pk = peak.get(p.id) || p.liq;
        const drawdown = pk ? (1 - p.liq / pk) * 100 : 0;
        const turnover = p.vol / Math.max(p.liq, 1);
        const pr = pressure(p), st = stability(p);
        const flags = [];
        if (drawdown > 35) flags.push('liquidity bleeding −' + drawdown.toFixed(0) + '%');
        if (turnover < 0.05) flags.push('volume flatlined');
        if (p.buys + p.sells < 25) flags.push('no flow');
        if (p.liq < 15e3) flags.push('sub-viable depth');
        if (pr.score > 60) flags.push('heavy outflow pressure');
        const score = Math.round(clamp(drawdown * 0.8 + (turnover < 0.05 ? 20 : 0)
          + (p.liq < 15e3 ? 18 : 0) + pr.score * 0.25 + (100 - st.score) * 0.15, 0, 100));
        return { p, score, flags, drawdown, pr, st };
      })
      .filter(x => x.score >= 30 && x.flags.length)
      .sort((a, b) => b.score - a.score).slice(0, n || 6);
  }
  /* ---- concentration: per chain and per token ---- */
  function concentration(){
    return CDX.Data.CHAIN_ORDER.map(id => {
      const pools = CDX.Data.pairs.filter(p => p.chain === id);
      const total = pools.reduce((a, p) => a + p.liq, 0);
      if (!total || !pools.length) return null;
      const sorted = [...pools].sort((a, b) => b.liq - a.liq);
      const hhi = pools.reduce((a, p) => a + (p.liq / total) ** 2, 0);
      return { id, chain: CDX.Data.CHAINS[id], total, pools: pools.length,
               topPair: sorted[0], topShare: sorted[0].liq / total * 100, hhi };
    }).filter(Boolean).sort((a, b) => b.hhi - a.hhi);
  }
  /* ---- cross-chain liquidity flow (event-netted, 2h window) ---- */
  function chainFlow(){
    const cut = Date.now() - 2 * HOUR;
    const m = new Map();
    for (const id of CDX.Data.CHAIN_ORDER) m.set(id, { id, chain: CDX.Data.CHAINS[id], add: 0, remove: 0, net: 0 });
    for (const e of events){
      if (e.ts < cut) continue;
      const p = CDX.Data.byKey('d:' + e.pairId);
      if (!p) continue;
      const row = m.get(p.chain);
      e.type === 'add' ? row.add += e.delta : row.remove += Math.abs(e.delta);
      row.net += e.delta;
    }
    return [...m.values()].sort((a, b) => b.net - a.net);
  }
  return { pressure, stability, deathSignals, concentration, chainFlow, seriesFor,
           hasFlow: () => events.length > 0,
           events: n => events.slice(0, n || 20), migrations: n => migrations.slice(0, n || 8) };
})();
