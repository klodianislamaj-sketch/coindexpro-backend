/* CDX.Social — social intelligence engine.
   Real community metrics per asset via CoinGecko community data (X followers,
   Telegram members, Reddit posts/comments/active accounts, community vote
   sentiment) on a rate-limited rotation, plus real crowd attention from trending
   searches and outlet-mention tracking from the news stream. Session snapshots
   yield mention/engagement velocity and spike events. Discord exposes no public
   keyless API and is explicitly excluded from scoring. */
CDX.Social = (() => {
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const HOUR = 36e5;
  const data = new Map();     // coinId → { ts, m }
  const hist = new Map();     // coinId → [{ ts, m }] (≤24)
  const spikes = [];          // { ts, coinId, channel, pct, from, to }
  let trendingRows = [], rotation = [], cursor = 0, started = false;

  const idFromCg = (() => { const m = {}; return () => {
    if (!Object.keys(m).length) for (const [id, cg] of Object.entries(CDX.LiveData.cgIds)) m[cg] = id;
    return m; }; })();

  function detectSpikes(coinId, prev, cur){
    const CH = [['twitter', 0.4, 'X followers'], ['telegram', 0.8, 'Telegram members'],
                ['redditActive48h', 18, 'Reddit active accounts'], ['redditSubs', 0.5, 'Reddit subscribers']];
    for (const [k, thr, label] of CH){
      if (prev.m[k] == null || cur.m[k] == null || !prev.m[k]) continue;
      const pct = (cur.m[k] - prev.m[k]) / prev.m[k] * 100;
      if (pct >= thr){
        spikes.unshift({ ts: cur.ts, coinId, channel: label, pct, from: prev.m[k], to: cur.m[k] });
        if (spikes.length > 40) spikes.length = 40;
        CDX.Bus.emit('social:spike', spikes[0]);
      }
    }
  }
  async function fetchNext(){
    if (!rotation.length){
      const pulseFirst = ['pls', 'plsx', 'hex', 'inc'];
      rotation = pulseFirst.concat(CDX.Data.coins.map(c => c.id)
        .filter(id => !pulseFirst.includes(id) && !['usdt', 'usdc', 'wbtc'].includes(id)));
    }
    const id = rotation[cursor++ % rotation.length];
    const cgId = CDX.LiveData.cgIds[id];
    if (!cgId) return;
    const m = await CDX.Net.Cache.swr('soc:' + id,
      () => CDX.Providers.coingecko.coinSocial(cgId), { ttl: 25 * 60e3, stale: 3 * HOUR });
    const cur = { ts: Date.now(), m };
    const prev = data.get(id);
    data.set(id, cur);
    let h = hist.get(id);
    if (!h) hist.set(id, h = []);
    if (!h.length || h[h.length - 1].ts !== cur.ts) h.push(cur);
    if (h.length > 24) h.shift();
    if (prev && prev.ts !== cur.ts) detectSpikes(id, prev, cur);
  }
  async function fetchTrending(){
    const rows = await CDX.Net.Cache.swr('soc:trending',
      () => CDX.Providers.coingecko.trending(), { ttl: 270e3, stale: HOUR });
    const map = idFromCg();
    trendingRows = rows.map(r => ({ ...r, id: map[r.cgId] || null }));
  }
  function start(){
    if (started) return;
    started = true;
    CDX.Net.Conn.poller('soc:detail', fetchNext, 30000, { immediate: true }).start();
    CDX.Net.Conn.poller('soc:trending', fetchTrending, 300000, { immediate: true }).start();
  }
  CDX.Bus.on('data:ready', start);

  /* ---- velocity: per-hour channel deltas across session snapshots ---- */
  function velocity(id){
    const h = hist.get(id);
    if (!h || h.length < 2) return null;
    const a = h[0], b = h[h.length - 1];
    const hrs = Math.max(0.2, (b.ts - a.ts) / HOUR);
    const d = k => a.m[k] != null && b.m[k] != null
      ? { abs: (b.m[k] - a.m[k]) / hrs, pct: a.m[k] ? (b.m[k] - a.m[k]) / a.m[k] * 100 / hrs : 0 } : null;
    return { twitter: d('twitter'), telegram: d('telegram'),
             redditActive: d('redditActive48h'), redditSubs: d('redditSubs'), hours: hrs };
  }
  const mentionVelocity = id => {
    const e = data.get(id);
    const reddit = e && e.m.redditPosts48h != null
      ? (e.m.redditPosts48h + (e.m.redditComments48h || 0)) / 48 : null;   // per hour
    const news = CDX.News.all().filter(n => n.tag === 'c:' + id && Date.now() - n.ts < 6 * HOUR).length;
    return { redditPerHr: reddit, news6h: news };
  };
  const trendingRank = id => { const t = trendingRows.find(r => r.id === id); return t ? t.rank : null; };

  /* ---- Social Momentum Score ---- */
  function momentum(id){
    const e = data.get(id);
    const m = e ? e.m : {};
    const v = velocity(id);
    const mv = mentionVelocity(id);
    const rank = trendingRank(id);
    const parts = {
      attention: rank != null ? clamp(27 - rank * 3, 8, 25) : 0,
      sentiment: m.upPct != null ? clamp((m.upPct - 50) * 1.1, 0, 20) : 0,
      mentions: clamp((mv.redditPerHr != null ? Math.log10(mv.redditPerHr + 1) * 9 : 0), 0, 15),
      engagement: v ? clamp(((v.twitter && v.twitter.pct) || 0) * 26 + ((v.telegram && v.telegram.pct) || 0) * 26
                          + ((v.redditActive && v.redditActive.pct) || 0) * 6, 0, 25) : 0,
      news: clamp(mv.news6h * 8, 0, 15)
    };
    const channels = ['twitter', 'telegram', 'redditActive48h', 'upPct'].filter(k => m[k] != null).length;
    return { score: Math.round(clamp(parts.attention + parts.sentiment + parts.mentions + parts.engagement + parts.news, 0, 100)),
             parts, coverage: channels, m, v, mv, rank };
  }
  const covered = () => [...data.keys()];
  const leaders = n => covered().map(id => ({ id, c: CDX.Data.byKey('c:' + id), s: momentum(id) }))
    .filter(x => x.c).sort((a, b) => b.s.score - a.s.score).slice(0, n || 8);
  const channelMovers = (k, n) => covered()
    .map(id => ({ id, c: CDX.Data.byKey('c:' + id), v: velocity(id) }))
    .filter(x => x.c && x.v && x.v[k] && x.v[k].abs !== 0)
    .sort((a, b) => b.v[k].pct - a.v[k].pct).slice(0, n || 5);
  /* ---- influencer / outlet tracking from the news stream ---- */
  function influencers(n){
    const cut = Date.now() - 24 * HOUR;
    const m = new Map();
    for (const item of CDX.News.all()){
      if (item.ts < cut) continue;
      let e = m.get(item.src);
      if (!e) m.set(item.src, e = { src: item.src, mentions: 0, bull: 0, bear: 0, tags: new Map(), lastTs: 0 });
      e.mentions++;
      if (item.kind === 'bull') e.bull++;
      if (item.kind === 'bear') e.bear++;
      e.lastTs = Math.max(e.lastTs, item.ts);
      if (item.tag) e.tags.set(item.tag, (e.tags.get(item.tag) || 0) + 1);
    }
    return [...m.values()].map(e => ({ ...e,
      topTags: [...e.tags.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3).map(x => x[0]) }))
      .sort((a, b) => b.mentions - a.mentions).slice(0, n || 6);
  }
  return { momentum, velocity, mentionVelocity, leaders, channelMovers, influencers,
           spikes: n => spikes.slice(0, n || 12), trending: () => trendingRows,
           metricsFor: id => data.get(id) || null, coverage: () => data.size };
})();
