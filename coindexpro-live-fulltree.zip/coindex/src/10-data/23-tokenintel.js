/* CDX.TokenIntel — token profile + new-pair intelligence (Phase 10).
   Pulls only from real sources: the normalized Asset layer (price/liquidity/
   fdv/holders/addresses/freshness), the existing Risk engine (heuristic, so
   labeled), and observed trades. Any field without a real source resolves to
   { available:false } so the UI renders "Unavailable" — never invented. */
CDX.TokenIntel = (() => {
  /* ---- 10.4 · token profile ---- */
  function profile(pairId){
    const p = CDX.Data.byKey('d:' + pairId);
    if (!p) return { available: false, reason: 'unknown pair' };
    const a = CDX.Asset.resolve('d:' + pairId);
    const fresh = CDX.Asset.freshness(a);

    // liquidity depth — real from pair
    const liquidity = a.liquidity != null ? { available: true, usd: a.liquidity } : { available: false };

    // contract age — real from ageH
    const contractAge = (typeof p.ageH === 'number' && p.ageH >= 0)
      ? { available: true, hours: p.ageH, label: CDX.Fmt.age(p.ageH) }
      : { available: false };

    // holder concentration / top wallet % — only if the Risk engine read it (pulsechain via Blockscout)
    let holders = { available: false, reason: 'holder snapshot not available for this chain' };
    let topWallet = { available: false };
    try {
      if (CDX.Risk && typeof CDX.Risk.holderStats === 'function'){
        const hs = CDX.Risk.holderStats(p);
        if (hs && hs.available){ holders = hs; if (hs.topPct != null) topWallet = { available: true, pct: hs.topPct }; }
      }
    } catch(e){}

    // token risk — heuristic, clearly labeled
    let risk = { available: false };
    try {
      if (CDX.Risk && typeof CDX.Risk.quick === 'function'){
        const r = CDX.Risk.quick(p);
        if (r && typeof r.risk === 'number') risk = { available: true, heuristic: true,
          riskScore: r.risk, safetyScore: r.safety, vectors: r.vectors || null };
      }
    } catch(e){}

    // LP lock — only if a real reader exists; otherwise unavailable (never guessed)
    const lpLock = { available: false, reason: 'LP lock status requires a lock-contract reader (not wired)' };

    return {
      available: true, pair: { base: p.base, quote: p.quote, chain: p.chain, dex: p.dex },
      price: a.price, freshness: fresh, source: a.source,
      liquidity, contractAge, holders, topWallet, risk, lpLock
    };
  }

  /* ---- 10.5 · new pair engine ---- */
  function newPairs(opts){
    const o = opts || {};
    const maxAge = o.maxAgeH || 24;
    const pairs = (CDX.Data.pairs || []).filter(p => typeof p.ageH === 'number' && p.ageH <= maxAge && p.liq > 0);
    const raw = (CDX.WhaleFlow.raw && CDX.WhaleFlow.raw()) || [];
    return pairs.map(p => {
      // early whale entries — real, from the trade buffer on this pair
      const earlyWhales = raw.filter(t => t.pairId === p.id).length;
      // first-hour volatility — real if we have the 5m/1h change fields
      const vol1h = (p.ch && typeof p.ch.h1 === 'number') ? Math.abs(p.ch.h1) : null;
      return {
        id: p.id, base: p.base, quote: p.quote, chain: p.chain, dex: p.dex,
        ageH: p.ageH, liquidity: p.liq, volume24h: p.vol,
        earlyWhaleEntries: earlyWhales,
        firstHourVolatilityPct: vol1h,           // null → "Unavailable"
        liquidityInjection: p.liq                  // current LP as observed
      };
    }).sort((a, b) => a.ageH - b.ageH).slice(0, o.limit || 40);
  }

  return { profile, newPairs };
})();
