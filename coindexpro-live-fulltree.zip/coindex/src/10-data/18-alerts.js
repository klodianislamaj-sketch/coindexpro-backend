/* CDX.Alerts — alert engine.
   Nine rule types evaluated against live telemetry streams (ticks, whale prints,
   LP events, PulseChain heads, periodic sweeps) with per-target cooldowns.
   Delivery: in-app toast, Browser Notifications, user webhook (JSON POST),
   Telegram Bot API, and email via a user-supplied relay endpoint. */
CDX.Alerts = (() => {
  const S = () => CDX.Store.state;
  const F = CDX.Fmt;
  const log = [];                       // session log (≤100)
  const cooldowns = new Map();          // ruleId(+target) → ts
  const pctBase = new Map();            // ruleId → baseline price
  let knownPairs = null, lastSweep = 0, lastTickEval = 0;
  const q = CDX.Net.Queue.create({ name: 'alerts', rps: 0.8, burst: 3, minGap: 400 });

  const rules = type => S().alerts.filter(r => r.enabled && (!type || r.type === type));
  const onCooldown = key => Date.now() - (cooldowns.get(key) || 0) < 1;
  function ready(rule, target){
    const key = rule.id + (target ? ':' + target : '');
    if (Date.now() - (cooldowns.get(key) || 0) < (rule.cooldownMs || 600e3)) return false;
    cooldowns.set(key, Date.now());
    if (cooldowns.size > 600){
      const cut = Date.now() - 36e5;
      for (const [k, ts] of cooldowns) if (ts < cut) cooldowns.delete(k);
    }
    return true;
  }
  const label = key => { const it = CDX.Data.byKey(key); return it ? CDX.Data.label(it) : key; };

  /* ---------- delivery ---------- */
  function deliver(rule, title, body, key){
    const ev = { ts: Date.now(), ruleId: rule.id, type: rule.type, title, body, key: key || rule.params.key || null };
    log.unshift(ev);
    if (log.length > 100) log.length = 100;
    rule.fireCount = (rule.fireCount || 0) + 1;
    rule.lastFired = ev.ts;
    CDX.Store.persist();
    CDX.Bus.emit('alert:fired', ev);
    CDX.UI.toast('🔔 ' + title + ' — ' + body, 'warn');
    const ch = S().alertChannels, has = c => (rule.channels || []).includes(c);
    if (has('browser') && ch.browser && typeof Notification !== 'undefined' && Notification.permission === 'granted'){
      try { new Notification('CoinDex Pro · ' + title, { body, tag: rule.id }); } catch(e){}
    }
    if (has('webhook') && ch.webhookUrl){
      q.run(() => fetch(ch.webhookUrl, { method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ source: 'coindex-pro', title, body, type: rule.type, rule: rule.name, ts: ev.ts, key: ev.key })
      })).catch(() => {});
    }
    if (has('telegram') && ch.tgToken && ch.tgChat){
      q.run(() => fetch(`https://api.telegram.org/bot${ch.tgToken}/sendMessage?chat_id=${encodeURIComponent(ch.tgChat)}&text=${encodeURIComponent('🔔 ' + title + '\n' + body)}`)).catch(() => {});
    }
    if (has('email') && ch.emailEndpoint && ch.emailTo){
      q.run(() => fetch(ch.emailEndpoint, { method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ to: ch.emailTo, subject: 'CoinDex Pro alert: ' + title, text: body, ts: ev.ts })
      })).catch(() => {});
    }
  }
  async function test(channel){
    const fake = { id: 'test', type: 'test', name: 'Channel test', params: {}, channels: [channel], cooldownMs: 0 };
    deliver(fake, 'Test alert', 'Delivery channel "' + channel + '" is wired correctly.', null);
  }

  /* ---------- evaluators ---------- */
  function evalPriceVolume(){
    for (const r of rules('price')){
      const it = CDX.Data.byKey(r.params.key);
      if (!it || !it.price) continue;
      const p = it.price;
      if (r.params.op === 'above' && p >= r.params.value && ready(r))
        deliver(r, label(r.params.key) + ' above ' + F.price(r.params.value), 'Now ' + F.price(p), r.params.key);
      else if (r.params.op === 'below' && p <= r.params.value && ready(r))
        deliver(r, label(r.params.key) + ' below ' + F.price(r.params.value), 'Now ' + F.price(p), r.params.key);
      else if (r.params.op === 'pctMove'){
        if (!pctBase.has(r.id)) pctBase.set(r.id, p);
        const base = pctBase.get(r.id);
        const move = (p / base - 1) * 100;
        if (Math.abs(move) >= r.params.value && ready(r)){
          deliver(r, label(r.params.key) + ' moved ' + (move >= 0 ? '+' : '') + move.toFixed(1) + '%',
                  F.price(base) + ' → ' + F.price(p), r.params.key);
          pctBase.set(r.id, p);
        }
      }
    }
    for (const r of rules('volume')){
      const it = CDX.Data.byKey(r.params.key);
      if (!it) continue;
      const turnover = it.liq ? it.vol / it.liq : null;
      if (r.params.op === 'volAbove' && it.vol >= r.params.value && ready(r))
        deliver(r, label(r.params.key) + ' volume ' + F.usd(it.vol), 'crossed ' + F.usd(r.params.value) + ' / 24h', r.params.key);
      else if (r.params.op === 'turnoverAbove' && turnover != null && turnover >= r.params.value && ready(r))
        deliver(r, label(r.params.key) + ' turnover ' + turnover.toFixed(1) + '×', 'vol/liq crossed ' + r.params.value + '×', r.params.key);
    }
  }
  function evalLiquidity(ev){
    for (const r of rules('liquidity')){
      const p = CDX.Data.byKey('d:' + r.params.pairId);
      if (!p) continue;
      if (ev && ev.pairId === r.params.pairId && r.params.op === 'changePct'
          && Math.abs(ev.pct) >= r.params.value && ready(r, ev.ts))
        deliver(r, label('d:' + p.id) + ' LP ' + (ev.delta >= 0 ? 'add' : 'pull') + ' ' + ev.pct.toFixed(1) + '%',
                (ev.delta >= 0 ? '+' : '−') + F.usd(Math.abs(ev.delta)) + ' · pool ' + F.usd(p.liq), 'd:' + p.id);
      if (!ev){
        if (r.params.op === 'below' && p.liq <= r.params.value && ready(r))
          deliver(r, label('d:' + p.id) + ' liquidity below ' + F.usd(r.params.value), 'Now ' + F.usd(p.liq), 'd:' + p.id);
        if (r.params.op === 'above' && p.liq >= r.params.value && ready(r))
          deliver(r, label('d:' + p.id) + ' liquidity above ' + F.usd(r.params.value), 'Now ' + F.usd(p.liq), 'd:' + p.id);
      }
    }
  }
  function evalWhale(t){
    const p = CDX.Data.byKey('d:' + t.pairId);
    for (const r of rules('whale')){
      const pr = r.params;
      if (t.usd < (pr.minUsd || 0)) continue;
      if (pr.side && pr.side !== 'any' && t.side !== pr.side) continue;
      if (pr.chain && pr.chain !== 'any' && (!p || p.chain !== pr.chain)) continue;
      if (ready(r, t.tx || t.id))
        deliver(r, 'Whale ' + t.side.toUpperCase() + ' ' + F.usd(t.usd),
                (p ? p.base + '/' + p.quote + ' · ' + CDX.Data.CHAINS[p.chain].name : t.pairId), p ? 'd:' + p.id : null);
    }
    for (const r of rules('wallet')){
      if ((r.params.addr || '').toLowerCase() !== (t.wallet || '').toLowerCase()) continue;
      if (r.params.side && r.params.side !== 'any' && t.side !== r.params.side) continue;
      const w = CDX.DataRaw.walletByAddr.get(t.wallet);
      if (ready(r, t.tx || t.id))
        deliver(r, (w ? w.label : t.wallet.slice(0, 8) + '…') + ' ' + t.side.toUpperCase() + ' ' + F.usd(t.usd),
                p ? p.base + '/' + p.quote : t.pairId, p ? 'd:' + p.id : null);
    }
  }
  function evalSweep(){
    for (const r of rules('risk')){
      const targets = r.params.pairId ? [CDX.Data.byKey('d:' + r.params.pairId)].filter(Boolean)
        : CDX.Data.pairs.filter(p => r.params.chain === 'any' || p.chain === (r.params.chain || 'pulsechain'));
      for (const p of targets){
        const q2 = CDX.Risk.quick(p);
        if (q2.risk >= r.params.value && ready(r, p.id))
          deliver(r, label('d:' + p.id) + ' risk ' + q2.risk + '/100',
                  q2.vectors.filter(v => v.level === 'high').map(v => v.label).join(' · ') || 'composite threshold crossed', 'd:' + p.id);
      }
    }
    for (const r of rules('narrative')){
      const n = CDX.Intel.allNarratives().find(x => x.id === r.params.id);
      if (!n) continue;
      const v = r.params.metric === 'heat' ? n.heat : n.flow.netFlow;
      const hit = r.params.op === 'above' ? v >= r.params.value : v <= r.params.value;
      if (hit && ready(r))
        deliver(r, n.name + ' ' + (r.params.metric === 'heat' ? 'heat ' + v : 'net flow ' + (v >= 0 ? '+' : '−') + F.usd(Math.abs(v))),
                r.params.metric === 'heat' ? 'crossed ' + r.params.value : 'threshold ' + F.usd(Math.abs(r.params.value)), null);
    }
    for (const r of rules('pulsechain')){
      const pr = r.params;
      const h = CDX.LiveData.pulseHead;
      if (pr.kind === 'gasAbove' && h && h.gasGwei != null && h.gasGwei >= pr.value && ready(r))
        deliver(r, 'PulseChain base fee ' + h.gasGwei.toFixed(2) + ' gwei', 'crossed ' + pr.value + ' gwei at block #' + F.num(h.height), null);
      if (pr.kind === 'blockStall' && h && Date.now() - h.ts > pr.value * 60e3 && ready(r))
        deliver(r, 'PulseChain blocks stalled', 'No new head for ' + Math.round((Date.now() - h.ts) / 60e3) + ' min (last #' + F.num(h.height) + ')', null);
      if (pr.kind === 'trackedMove'){
        for (const p of CDX.Data.pairs){
          if (p.chain !== 'pulsechain' || Math.abs(p.ch.h1) < pr.value) continue;
          if (ready(r, p.id))
            deliver(r, p.base + '/' + p.quote + ' ' + F.pctAuto(p.ch.h1) + ' (1h)',
                    'PulseChain tracked move ≥ ±' + pr.value + '%', 'd:' + p.id);
        }
      }
    }
  }
  function evalNewPairs(){
    const ids = new Set(CDX.Data.pairs.map(p => p.id));
    if (!knownPairs){ knownPairs = ids; return; }
    for (const p of CDX.Data.pairs){
      if (knownPairs.has(p.id)) continue;
      for (const r of rules('newpair')){
        if (r.params.chain !== 'any' && p.chain !== r.params.chain) continue;
        if (p.liq < (r.params.minLiq || 0)) continue;
        if (ready(r, p.id))
          deliver(r, 'New pair: ' + p.base + '/' + p.quote, CDX.Data.CHAINS[p.chain].name + ' · ' + p.dex
                  + ' · Liq ' + F.usd(p.liq) + ' · ' + F.age(p.ageH) + ' old', 'd:' + p.id);
      }
    }
    knownPairs = ids;
  }
  /* ---------- wiring ---------- */
  CDX.Bus.on('data:ready', () => { knownPairs = new Set(CDX.Data.pairs.map(p => p.id)); });
  CDX.Bus.on('tick', () => {
    if (Date.now() - lastTickEval < 5000) return;
    lastTickEval = Date.now();
    try { evalPriceVolume(); evalNewPairs(); } catch(e){ console.warn('[alerts]', e); }
    if (Date.now() - lastSweep > 30000){
      lastSweep = Date.now();
      try { evalLiquidity(null); evalSweep(); } catch(e){ console.warn('[alerts]', e); }
    }
  });
  CDX.Bus.on('whale:new', t => { try { evalWhale(t); } catch(e){} });
  CDX.Bus.on('liq:event', ev => { try { evalLiquidity(ev); } catch(e){} });
  CDX.Bus.on('pls:block', () => {});   // heads consumed via sweep state
  return { log: n => log.slice(0, n || 30), test,
           TYPES: ['price','volume','liquidity','whale','wallet','risk','narrative','newpair','pulsechain'] };
})();
