/* CDX.WalletIntel — wallet intelligence engine.
   Reconstructs per-wallet performance from the live print ledger (FIFO lot matching
   against current prices): PnL (realized + unrealized), win rate, hold times, sizing,
   rotation, token preference, behavior archetypes, smart-money clusters, mirror
   (copy-trade) returns. Registry stats remain the long-horizon profile; everything
   here is session-observed from real prints. */
CDX.WalletIntel = (() => {
  const R = () => CDX.DataRaw;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const HOUR = 36e5;
  const ledgerFor = addr => R().WHALE_TRADES.filter(t => t.wallet === addr).sort((a, b) => a.ts - b.ts);
  const activeAddrs = () => [...new Set(R().WHALE_TRADES.map(t => t.wallet))].filter(Boolean);

  /* ---- FIFO reconstruction → full wallet analytics ---- */
  function analyze(addr){
    const trades = ledgerFor(addr);
    if (!trades.length) return null;
    const byPair = new Map();   // pairId → { lots:[{amt,price,ts}], realized, vol }
    let realized = 0, winUsd = 0, closedUsd = 0, holdWeighted = 0, holdUsd = 0;
    let buys = 0, sells = 0, volume = 0;
    let sellUsdTotal = 0, matchedSellUsd = 0, unmatchedSellUsd = 0;   // PnL coverage accounting
    let exitWins = 0, exits = 0;                                       // per-exit (round-trip) outcomes
    const DUST = 50;                                                   // chunks under $50 don't move win rate
    const sizes = [];
    const order = [];           // rotation path: first-touch sequence
    const transitions = new Map();   // 'A→B' → { from, to, usd, n } rotation edges
    let prevPair = null;
    for (const t of trades){
      if (!(t.price > 0) || !(t.usd > 0)) continue;
      let e = byPair.get(t.pairId);
      if (!e){ byPair.set(t.pairId, e = { lots: [], realized: 0, vol: 0, revisits: 0 }); order.push(t.pairId); }
      else if (prevPair && prevPair !== t.pairId && order[order.length - 1] !== t.pairId) e.revisits++;
      if (prevPair && prevPair !== t.pairId){
        const k = prevPair + '→' + t.pairId;
        const ed = transitions.get(k) || { from: prevPair, to: t.pairId, usd: 0, n: 0 };
        ed.usd += t.usd; ed.n++;
        transitions.set(k, ed);
      }
      prevPair = t.pairId;
      const amt = t.usd / t.price;
      e.vol += t.usd; volume += t.usd; sizes.push(t.usd);
      if (t.side === 'buy'){ buys++; e.lots.push({ amt, price: t.price, ts: t.ts }); continue; }
      sells++;
      sellUsdTotal += t.usd;
      let rem = amt, exitPnl = 0, exitUsd = 0;
      while (rem > 1e-12 && e.lots.length){
        const lot = e.lots[0];
        const take = Math.min(lot.amt, rem);
        const pnl = (t.price - lot.price) * take;
        const usd = lot.price * take;
        realized += pnl; e.realized += pnl;
        exitPnl += pnl; exitUsd += usd;
        closedUsd += usd;
        matchedSellUsd += t.price * take;
        if (usd >= DUST){ if (pnl > 0) winUsd += usd; }
        else closedUsd -= usd;                                         // dust excluded from the win base
        holdWeighted += (t.ts - lot.ts) * usd; holdUsd += usd;
        lot.amt -= take; rem -= take;
        if (lot.amt <= 1e-12) e.lots.shift();
      }
      if (rem > 1e-12) unmatchedSellUsd += rem * t.price;              // entry predates the ledger — never guessed
      if (exitUsd >= DUST){ exits++; if (exitPnl > 0) exitWins++; }
    }
    /* open positions marked to live prices */
    const positions = [];
    let unrealized = 0, openValue = 0, openAgeW = 0, openCostW = 0;
    for (const [pairId, e] of byPair){
      const amt = e.lots.reduce((a, l) => a + l.amt, 0);
      if (amt <= 1e-12) continue;
      const cost = e.lots.reduce((a, l) => a + l.amt * l.price, 0);
      const p = CDX.Data.byKey('d:' + pairId);
      const cur = p ? p.price : e.lots[e.lots.length - 1].price;
      const value = amt * cur, uPnl = value - cost;
      unrealized += uPnl; openValue += value;
      for (const l of e.lots){ openAgeW += (Date.now() - l.ts) * l.amt * l.price; openCostW += l.amt * l.price; }
      positions.push({ pairId, p, amount: amt, avgPrice: cost / amt, value, uPnl, marked: !!p,
                       uPnlPct: cost ? uPnl / cost * 100 : 0, since: e.lots[0].ts });
    }
    positions.sort((a, b) => b.value - a.value);
    positions.forEach(pos => pos.uShare = unrealized !== 0 ? pos.uPnl / Math.abs(unrealized) * 100 : 0);
    const realizedByPair = [...byPair.entries()]
      .filter(([, e]) => e.realized !== 0)
      .map(([pairId, e]) => ({ pairId, p: CDX.Data.byKey('d:' + pairId), realized: e.realized, vol: e.vol }))
      .sort((a, b) => b.realized - a.realized);
    const avgSize = sizes.reduce((a, b) => a + b, 0) / sizes.length;
    const span = Math.max(0.2, (trades[trades.length - 1].ts - trades[0].ts) / HOUR);
    const usdWin = closedUsd > 0 ? winUsd / closedUsd * 100 : null;
    const exitWin = exits ? exitWins / exits * 100 : null;
    const avgHoldMin = holdUsd ? holdWeighted / holdUsd / 60e3 : null;
    const openAgeMin = openCostW ? openAgeW / openCostW / 60e3 : null;
    return {
      addr, trades: trades.length, buys, sells, volume, avgSize,
      maxSize: Math.max(...sizes), sizeRatio: Math.max(...sizes) / avgSize,
      realized, unrealized, totalPnl: realized + unrealized,
      realizedByPair,
      winRate: usdWin != null && exitWin != null ? usdWin * 0.6 + exitWin * 0.4 : (usdWin ?? exitWin),
      winRateUsd: usdWin, winRateExits: exitWin, exits,
      coverage: sellUsdTotal > 0 ? matchedSellUsd / sellUsdTotal * 100 : 100,
      unmatchedSellUsd,
      avgHoldMin, openAgeMin,
      effHoldMin: avgHoldMin != null && openAgeMin != null
        ? (avgHoldMin * holdUsd + openAgeMin * openCostW) / (holdUsd + openCostW) / 1
        : (avgHoldMin ?? openAgeMin),
      positions, openValue,
      concentration: openValue ? (positions[0] ? positions[0].value / openValue * 100 : 0) : 0,
      rotationPath: order, rotationRate: order.length / trades.length,
      transitions: [...transitions.values()].sort((a, b) => b.usd - a.usd).slice(0, 5),
      revisits: [...byPair.values()].reduce((a, e) => a + e.revisits, 0),
      tradesPerHr: trades.length / span,
      lastActive: trades[trades.length - 1].ts, firstSeen: trades[0].ts
    };
  }
  /* ---- token preference: volume share by symbol / chain / narrative ---- */
  function preference(addr){
    const bySym = new Map(), byChain = new Map(), byNarr = new Map();
    let total = 0;
    for (const t of ledgerFor(addr)){
      const p = CDX.Data.byKey('d:' + t.pairId);
      if (!p) continue;
      total += t.usd;
      bySym.set(p.base, (bySym.get(p.base) || 0) + t.usd);
      byChain.set(p.chain, (byChain.get(p.chain) || 0) + t.usd);
      for (const tag of (p.tags || [])) byNarr.set(tag, (byNarr.get(tag) || 0) + t.usd);
    }
    const top = m => [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3)
      .map(([k, v]) => ({ k, v, pct: total ? v / total * 100 : 0 }));
    return { syms: top(bySym), chains: top(byChain), narratives: top(byNarr), total };
  }
  /* ---- mirror (copy-trade) return: equal follow of every observed buy ---- */
  function mirror(addr){
    const buysL = ledgerFor(addr).filter(t => t.side === 'buy' && t.price > 0);
    if (!buysL.length) return null;
    let wSum = 0, w = 0, best = null;
    const entries = buysL.map(t => {
      const p = CDX.Data.byKey('d:' + t.pairId);
      const cur = p ? p.price : t.price;
      const ret = (cur / t.price - 1) * 100;
      wSum += ret * t.usd; w += t.usd;
      if (!best || ret > best.ret) best = { t, ret };
      return { t, p, ret };
    }).sort((a, b) => b.t.ts - a.t.ts);
    return { ret: wSum / w, n: buysL.length, entries, best };
  }
  /* ---- behavior model: trait scores + archetype ---- */
  function behavior(a){
    if (!a) return null;
    const sellShare = a.trades ? a.sells / a.trades : 0;
    const aggression = clamp(a.tradesPerHr * 18 + sellShare * 30 + a.rotationRate * 14, 0, 100);
    const hold = a.effHoldMin != null ? a.effHoldMin : a.avgHoldMin;
    const patience = hold != null ? clamp(hold / 90 * 70 + 10, 0, 100)
                                  : clamp((Date.now() - a.firstSeen) / HOUR * 8, 0, 100);
    const conviction = clamp(a.concentration * 0.55 + Math.log10(a.avgSize + 1) * 8
      + (a.sizeRatio < 3 ? 12 : 0), 0, 100);                                   // consistent sizing = conviction
    const m = mirror(a.addr);
    const timing = m ? clamp(50 + m.ret * 2.2 * Math.min(1, m.n / 3), 0, 100) : 50;   // n-weighted
    const youngShare = ledgerFor(a.addr).filter(t => {
      const p = CDX.Data.byKey('d:' + t.pairId);
      return p && p.ageH <= 48;
    }).length / a.trades;
    let archetype = 'Position Trader';
    if (youngShare > 0.5) archetype = 'Launch Sniper';
    else if (a.rotationRate > 0.55 && a.trades >= 4) archetype = 'Rotator';
    else if (sellShare > 0.62) archetype = 'Distributor';
    else if (hold != null && hold < 45 && a.tradesPerHr > 0.8) archetype = 'Scalper';
    else if (a.buys / Math.max(1, a.trades) > 0.66) archetype = 'Accumulator';
    return { archetype, traits: [['Aggression', Math.round(aggression)], ['Patience', Math.round(patience)],
             ['Conviction', Math.round(conviction)], ['Timing', Math.round(timing)]] };
  }
  /* ---- smart money clusters: union-find over shared-pair activity ---- */
  function clusters(minWallets){
    const byPairW = new Map();      // pairId → Map(wallet → [ts...])
    for (const t of R().WHALE_TRADES){
      if (!t.wallet || t.wallet === 'cexflow-binance-spot') continue;
      let m = byPairW.get(t.pairId);
      if (!m) byPairW.set(t.pairId, m = new Map());
      if (!m.has(t.wallet)) m.set(t.wallet, []);
      m.get(t.wallet).push(t.ts);
    }
    /* precision edges: two wallets connect only on ≥2 shared pools, or one pool with
       prints landing within 45 min of each other; pools touched by >6 wallets are too
       common to be evidence and never form edges */
    const shared = new Map();       // 'a|b' → { pools, sync }
    for (const [, m] of byPairW){
      const ws = [...m.keys()];
      if (ws.length < 2 || ws.length > 6) continue;
      for (let i = 0; i < ws.length; i++) for (let j = i + 1; j < ws.length; j++){
        const k = ws[i] < ws[j] ? ws[i] + '|' + ws[j] : ws[j] + '|' + ws[i];
        const e = shared.get(k) || { pools: 0, sync: 0 };
        e.pools++;
        const A = m.get(ws[i]), B = m.get(ws[j]);
        if (A.some(ta => B.some(tb => Math.abs(ta - tb) <= 45 * 60e3))) e.sync++;
        shared.set(k, e);
      }
    }
    const parent = new Map();
    const find = x => { while (parent.get(x) !== x) x = parent.get(x); return x; };
    const union = (a, b) => { parent.set(find(a), find(b)); };
    const all = new Set();
    for (const [k, e] of shared){
      if (e.pools < 2 && e.sync < 1) continue;
      const [a, b] = k.split('|');
      for (const w of [a, b]){ all.add(w); if (!parent.has(w)) parent.set(w, w); }
      union(a, b);
    }
    const groups = new Map();
    for (const w of all){
      const r = find(w);
      if (!groups.has(r)) groups.set(r, new Set());
      groups.get(r).add(w);
    }
    return [...groups.values()].filter(g => g.size >= (minWallets || 2)).map(g => {
      const wallets = [...g];
      let cohesion = 0, edges = 0;
      for (const [k, e] of shared){
        const [a, b] = k.split('|');
        if (g.has(a) && g.has(b)){ cohesion += e.pools + e.sync; edges++; }
      }
      const pairs = new Set(), flows = { buy: 0, sell: 0 };
      let lastTs = 0;
      for (const t of R().WHALE_TRADES){
        if (!g.has(t.wallet)) continue;
        pairs.add(t.pairId);
        t.side === 'buy' ? flows.buy += t.usd : flows.sell += t.usd;
        lastTs = Math.max(lastTs, t.ts);
      }
      return { wallets, pairs: [...pairs], net: flows.buy - flows.sell,
               cohesion: edges ? +(cohesion / edges).toFixed(1) : 0,
               buyUsd: flows.buy, sellUsd: flows.sell, lastTs };
    }).sort((a, b) => Math.abs(b.net) - Math.abs(a.net));
  }
  /* ---- leaderboard rows: observed analytics + registry profile ---- */
  function leaderboard(){
    return activeAddrs()
      .filter(addr => addr !== 'cexflow-binance-spot')
      .map(addr => {
        const a = analyze(addr);
        if (!a) return null;
        const w = R().walletByAddr.get(addr) || null;
        const covAdj = (a.coverage / 100) * 0.5 + 0.5;                        // unmatched sells discount PnL trust
        const recency = Math.exp(-(Date.now() - a.lastActive) / (12 * HOUR));
        const m = mirror(addr);
        const rankScore = a.totalPnl * covAdj
          + (a.winRate != null ? (a.winRate - 50) * a.volume / 100 * 0.004 : 0)
          + (m ? m.ret * 120 : 0)
          + recency * 250;
        return { addr, a, w, b: behavior(a), m,
                 rankScore,
                 label: w ? w.label : addr.slice(0, 6) + '…' + addr.slice(-4),
                 type: w ? w.type : 'Unlabeled', score: w ? w.score : 50 };
      }).filter(Boolean);
  }
  const topPerformers = n => leaderboard()
    .filter(r => r.m && r.m.n >= 2)
    .sort((a, b) => b.m.ret - a.m.ret).slice(0, n || 3);
  /* copy-trade signal feed: latest qualified smart buys with live Δ since entry */
  function signalFeed(n){
    const qualified = new Set(leaderboard().filter(r => r.score >= 65 || (r.m && r.m.ret > 0)).map(r => r.addr));
    return R().WHALE_TRADES
      .filter(t => t.side === 'buy' && qualified.has(t.wallet) && t.price > 0)
      .slice(0, n || 10)
      .map(t => {
        const p = CDX.Data.byKey('d:' + t.pairId);
        return { t, p, ret: p ? (p.price / t.price - 1) * 100 : 0 };
      });
  }
  return { analyze, preference, mirror, behavior, clusters, leaderboard, topPerformers, signalFeed, ledgerFor };
})();
