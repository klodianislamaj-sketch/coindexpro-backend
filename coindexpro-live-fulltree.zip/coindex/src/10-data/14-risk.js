/* CDX.Risk — token & pair risk intelligence.
   Quick vectors derive synchronously from live pair telemetry (every chain).
   Deep vectors (PulseChain) add on-chain evidence: holder/LP concentration via
   Blockscout, owner() via RPC, trade-tape wash/honeypot analysis via real prints.
   Risk Score: weighted exposure (higher = worse). Safety Score: accumulated
   positive on-chain evidence — unknown is never treated as safe. */
CDX.Risk = (() => {
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const BURN = ['0x0000000000000000000000000000000000000000', '0x000000000000000000000000000000000000dead'];
  const LV = { ok: 0, low: 25, med: 60, high: 100, unknown: 40 };
  const W = { honeypot: 21, rug: 18, lp: 13, owner: 9, holderConc: 9, whaleConc: 8, lowLiq: 7, wash: 6, tax: 5, fakeVol: 4 };
  const V = (id, label, level, detail) => ({ id, label, level, detail });

  /* ---- session sell-execution evidence: rolling sell counter advancing = sells succeed ---- */
  const sell0 = new Map();   // pairId → { ts, sells }
  function sellEvidence(p){
    let v = sell0.get(p.id);
    if (!v){ sell0.set(p.id, v = { ts: Date.now(), sells: p.sells }); return null; }
    if (Date.now() - v.ts < 120e3) return null;
    return p.sells > v.sells;   // true = sells observed executing this session
  }
  /* ---- quick vectors: telemetry only, all chains ---- */
  function quickVectors(p){
    const turnover = p.vol / Math.max(p.liq, 1);
    const tx = p.buys + p.sells;
    const sellRatio = tx ? p.sells / tx : 0.5;
    const m = p.flowMeasured;
    const out = [];

    let hp = 'low', hpD = `${p.sells} sells / ${p.buys} buys observed`;
    if (p.buys >= 10 && p.sells === 0){ hp = 'high'; hpD = 'zero sells against ' + p.buys + ' buys'; }
    else if (p.buys > 30 && sellRatio < 0.05){ hp = 'med'; hpD = 'sell flow nearly absent'; }
    else if (m && m.buyVol > 5e3 && m.sellVol === 0){ hp = 'med'; hpD = 'no sell volume in measured prints'; }
    const se = sellEvidence(p);
    if (se === true && hp !== 'low'){ hp = hp === 'high' ? 'med' : 'low'; hpD += ' · sells executing live this session'; }
    else if (se === false && p.buys - (sell0.get(p.id) || {}).sells > 8 && hp === 'low'){ hp = 'med'; hpD = 'no sell has executed this session despite fresh buys'; }
    out.push(V('honeypot', 'Honeypot risk', hp, hpD + ' · heuristic'));

    const liqLvl = p.liq < 25e3 ? 'high' : p.liq < 100e3 ? 'med' : p.liq < 400e3 ? 'low' : 'ok';
    out.push(V('lowLiq', 'Low liquidity', liqLvl, F('usd', p.liq) + ' pooled'));

    const fl = p.fdv / Math.max(p.liq, 1);
    out.push(V('rug', 'Rug exposure', p.ageH < 48 && p.liq < 60e3 ? 'high' : fl > 80 ? 'med' : fl > 30 ? 'low' : 'ok',
      `FDV ${fl.toFixed(0)}× liquidity · ${CDX.Fmt.age(p.ageH)} old`));

    let wash = 'ok', washD = 'flow looks organic';
    if (turnover > 6 && tx > 200 && Math.abs(p.buys - p.sells) / tx < 0.04){ wash = 'med'; washD = 'near-perfect buy/sell symmetry at high churn'; }
    if (turnover > 14 && (p.holders != null && p.holders < 300)){ wash = 'high'; washD = 'extreme churn over a tiny holder base'; }
    out.push(V('wash', 'Wash trading', wash, washD));

    out.push(V('fakeVol', 'Fake volume', turnover > 25 ? 'high' : turnover > 10 ? 'med' : 'ok',
      turnover.toFixed(1) + '× daily turnover of pooled liquidity'));

    /* whale-print pressure from the live ledger */
    const cut = Date.now() - 6 * 36e5;
    let wb = 0, ws = 0;
    for (const t of CDX.DataRaw.WHALE_TRADES){
      if (t.pairId !== p.id || t.ts < cut) continue;
      t.side === 'buy' ? wb += t.usd : ws += t.usd;
    }
    const wTot = wb + ws;
    out.push(V('whaleConc', 'Whale concentration', wTot > p.liq * 0.25 ? 'med' : wTot > 0 ? 'low' : 'ok',
      wTot ? `${F('usd', wTot)} whale prints vs ${F('usd', p.liq)} liq` : 'no large prints in window'));

    out.push(V('holderConc', 'Holder concentration',
      p.holders == null ? 'unknown' : p.holders < 150 ? 'high' : p.holders < 800 ? 'med' : 'ok',
      p.holders != null ? CDX.Fmt.num(p.holders) + ' holders' : 'no on-chain holder data'));
    out.push(V('tax', 'Tax trap risk', 'unknown', 'buy/sell execution symmetry not yet measured'));
    out.push(V('lp', 'LP unlock risk', 'unknown', 'LP ownership not yet read'));
    out.push(V('owner', 'Contract owner risk', 'unknown', 'owner() not yet read'));
    return out;
  }
  function F(kind, v){ return CDX.Fmt[kind](v); }

  /* ---- scoring ---- */
  function score(vectors, p){
    let risk = 0, wSum = 0;
    for (const v of vectors){
      const w = W[v.id] || 6;
      const eff = v.level === 'unknown' ? w * 0.5 : w;
      risk += LV[v.level] * eff;
      wSum += w;
    }
    risk = clamp(risk / wSum, 0, 100);
    const get = id => vectors.find(v => v.id === id);
    /* rug probability model: additive logit over the live evidence set */
    (() => {
      const rug = get('rug'), lp = get('lp'), ow = get('owner'), hc = get('holderConc');
      let prob = 5;
      prob += lp ? (lp.burned ? -10 : { high: 30, med: 15, low: 5, ok: -6, unknown: 8 }[lp.level] || 0) : 0;
      prob += ow ? (ow.renounced ? -8 : { med: 15, low: 3, ok: -6, unknown: 6 }[ow.level] || 0) : 0;
      prob += p.ageH < 48 ? 15 : p.ageH < 24 * 7 ? 8 : p.ageH > 24 * 60 ? -6 : 0;
      const st = CDX.Liq.stability(p);
      prob += (1 - st.parts.retention / 15) * 14;                       // bleeding from session peak
      prob += hc ? { high: 12, med: 6 }[hc.level] || 0 : 0;
      prob += p.fdv / Math.max(p.liq, 1) > 80 ? 8 : 0;
      prob = Math.round(clamp(prob, 1, 95));
      if (rug){
        rug.prob = prob;
        rug.level = prob >= 55 ? 'high' : prob >= 30 ? 'med' : prob >= 12 ? 'low' : 'ok';
        rug.detail = `rug probability ≈ ${prob}% · ` + rug.detail;
      }
    })();
    let safety = 0;
    const lp = get('lp'), ow = get('owner'), hc = get('holderConc');
    if (lp && lp.burned) safety += 20; else if (lp && lp.level === 'ok') safety += 12;
    if (ow && ow.renounced) safety += 14; else if (ow && ow.level === 'ok') safety += 8;
    if (p.ageH > 24 * 30) safety += 10; else if (p.ageH > 24 * 7) safety += 5;
    safety += p.liq > 1e6 ? 20 : p.liq > 250e3 ? 14 : p.liq > 75e3 ? 6 : 0;
    if (p.holders > 2000) safety += 12; else if (p.holders > 800) safety += 7;
    if (hc && hc.top10 != null && hc.top10 < 40) safety += 12;
    if (get('wash').level === 'ok') safety += 8;
    const tax = get('tax');
    if (tax && tax.level === 'ok') safety += 6;
    if (p.sells > 5 && get('honeypot').level === 'low') safety += 8;
    return { risk: Math.round(risk), safety: Math.round(clamp(safety, 0, 100)) };
  }
  function quick(p){
    const vectors = quickVectors(p);
    return { ...score(vectors, p), vectors, deep: false };
  }

  /* ---- deep vectors: PulseChain on-chain evidence (cached) ---- */
  async function ownerOf(addr){
    try {
      const res = await CDX.Providers.pulsechain.rpc('eth_call', [{ to: addr, data: '0x8da5cb5b' }, 'latest']);
      if (!res || res === '0x' || res.length < 42) return { state: 'none' };
      const owner = '0x' + res.slice(-40);
      return BURN.includes(owner.toLowerCase()) ? { state: 'renounced', owner } : { state: 'active', owner };
    } catch(e){ return { state: 'none' }; }
  }
  async function deepAnalyze(p){
    if (p.chain !== 'pulsechain') return quick(p);
    return CDX.Net.Cache.swr('risk:' + p.id, async () => {
      const tokenAddr = p.ca && p.ca.toLowerCase() !== p.address.toLowerCase() ? p.ca : null;
      const [hold, lp, owner, tape] = await Promise.all([
        tokenAddr ? CDX.Providers.pulsex.holdersBreakdown(tokenAddr, 10).catch(() => null) : null,
        CDX.Providers.pulsex.holdersBreakdown(p.address, 10).catch(() => null),
        tokenAddr ? ownerOf(tokenAddr) : { state: 'none' },
        CDX.Providers.pulsex.poolTrades(p.address, 0).catch(() => [])
      ]);
      const vectors = quickVectors(p);
      const set = (id, level, detail, extra) => {
        const v = vectors.find(x => x.id === id);
        if (v){ v.level = level; v.detail = detail; Object.assign(v, extra || {}); }
      };
      if (hold){
        set('holderConc', hold.topPct > 70 ? 'high' : hold.topPct > 45 ? 'med' : hold.topPct > 25 ? 'low' : 'ok',
          `top 10 hold ${hold.topPct.toFixed(1)}% (${hold.contractPct.toFixed(0)}% in contracts)`, { top10: hold.topPct });
        const eoas = hold.top.filter(h => !h.isContract);
        const top3Eoa = eoas.slice(0, 3).reduce((a, h) => a + h.pct, 0);
        const hhi = hold.top.reduce((a, h) => a + (h.pct / 100) ** 2, 0) * 1e4;
        if (top3Eoa > 0) set('whaleConc',
          top3Eoa > 35 || hhi > 1200 ? 'high' : top3Eoa > 18 || hhi > 600 ? 'med' : top3Eoa > 8 ? 'low' : 'ok',
          `top-3 EOAs hold ${top3Eoa.toFixed(1)}% · holder HHI ${hhi.toFixed(0)}`);
      }
      if (lp && lp.top.length){
        /* aggregate the top-5 LP positions: burned vs locked vs EOA-removable share */
        let burnedPct = 0, lockedPct = 0, eoaPct = 0;
        for (const h of lp.top.slice(0, 5)){
          const isBurn = BURN.includes((h.addr || '').toLowerCase());
          const isLock = h.isContract || /lock|vault|timelock|burn/i.test(h.label || '');
          if (isBurn) burnedPct += h.pct;
          else if (isLock) lockedPct += h.pct;
          else eoaPct += h.pct;
        }
        const burned = burnedPct >= 50;
        const lvl = burned || burnedPct + lockedPct >= 70 ? 'ok'
                  : eoaPct >= 50 ? 'high' : eoaPct >= 25 ? 'med' : 'low';
        set('lp', lvl,
          `LP top-5: ${burnedPct.toFixed(0)}% burned · ${lockedPct.toFixed(0)}% in contracts/lockers · ${eoaPct.toFixed(0)}% EOA-removable`,
          { burned, burnedPct, lockedPct, eoaPct });
      }
      if (owner.state === 'renounced') set('owner', 'ok', 'ownership renounced (burn address)', { renounced: true });
      else if (owner.state === 'active') set('owner', 'med', 'owner active: ' + owner.owner.slice(0, 8) + '…');
      else set('owner', 'low', 'no owner() — non-ownable or proxied');
      if (tape.length >= 12){
        const buyersSet = new Set(tape.filter(t => t.side === 'buy').map(t => t.wallet));
        const sellers = new Set(tape.filter(t => t.side === 'sell').map(t => t.wallet));
        if (!sellers.size) set('honeypot', 'high', `0 distinct sellers across ${tape.length} on-chain prints`);
        else if (buyersSet.size >= 8 && sellers.size / buyersSet.size < 0.15)
          set('honeypot', 'med', `seller diversity ${sellers.size}/${buyersSet.size} — exits concentrated in few wallets`);
        else set('honeypot', 'low', `${sellers.size} distinct sellers executing on-chain`);
        /* wash: round-tripping wallets + two-wallet ping-pong alternation */
        const sides = new Map();
        for (const t of tape){
          const e = sides.get(t.wallet) || { b: 0, s: 0, usd: 0 };
          t.side === 'buy' ? e.b++ : e.s++;
          e.usd += t.usd;
          sides.set(t.wallet, e);
        }
        const washUsd = [...sides.values()].filter(e => Math.min(e.b, e.s) >= 2).reduce((a, e) => a + e.usd, 0);
        const total = tape.reduce((a, t) => a + t.usd, 0) || 1;
        let pingPong = 0;
        const seq = [...tape].sort((a, b) => a.ts - b.ts);
        for (let i = 2; i < seq.length; i++)
          if (seq[i].wallet === seq[i - 2].wallet && seq[i].wallet !== seq[i - 1].wallet
              && seq[i].side !== seq[i - 1].side && seq[i].ts - seq[i - 2].ts < 20 * 60e3) pingPong++;
        const ppShare = pingPong / Math.max(seq.length - 2, 1) * 100;
        const share = washUsd / total * 100;
        if (share > 45 || ppShare > 40) set('wash', 'high',
          `${share.toFixed(0)}% round-trip volume · ${ppShare.toFixed(0)}% two-wallet ping-pong pattern`);
        else if (share > 20 || ppShare > 22) set('wash', 'med',
          `${share.toFixed(0)}% round-trips · ${ppShare.toFixed(0)}% alternation`);
        else set('wash', 'ok', `round-trip ${share.toFixed(0)}% · ping-pong ${ppShare.toFixed(0)}% · organic`);
        /* fake volume: bot-uniform print sizing */
        const sizes = tape.map(t => t.usd).filter(u => u > 0);
        if (sizes.length >= 15){
          const mean = sizes.reduce((a, b) => a + b, 0) / sizes.length;
          const cv = Math.sqrt(sizes.reduce((a, v) => a + (v - mean) ** 2, 0) / sizes.length) / mean;
          const fv = vectors.find(x => x.id === 'fakeVol');
          if (cv < 0.22) set('fakeVol', 'high', `print sizes are bot-uniform (CV ${cv.toFixed(2)}) across ${sizes.length} trades`);
          else if (cv < 0.4 && fv.level !== 'high') set('fakeVol', 'med', `low size dispersion (CV ${cv.toFixed(2)})`);
          else if (fv.level === 'ok') fv.detail += ` · size CV ${cv.toFixed(2)} organic`;
        }
        /* tax trap: systematic buy/sell execution-price asymmetry beyond spread */
        const vwap = side => {
          const rows = tape.filter(t => t.side === side && t.price > 0);
          const u = rows.reduce((a, t) => a + t.usd, 0);
          return u > 0 ? rows.reduce((a, t) => a + t.price * t.usd, 0) / u : null;
        };
        const bV = vwap('buy'), sV = vwap('sell');
        if (bV != null && sV != null && tape.length >= 16){
          const gap = (bV - sV) / ((bV + sV) / 2) * 100;
          set('tax', gap > 9 ? 'high' : gap > 4.5 ? 'med' : gap > 2 ? 'low' : 'ok',
            gap > 2 ? `buy VWAP prints ${gap.toFixed(1)}% above sell VWAP — transfer-tax / asymmetric execution signature`
                    : `execution symmetric (Δ ${gap.toFixed(1)}%) — no tax signature in the tape`);
        }
      }
      const rug = vectors.find(x => x.id === 'rug');
      const lpV = vectors.find(x => x.id === 'lp'), owV = vectors.find(x => x.id === 'owner');
      if (lpV.level === 'high' && owV.level === 'med'){ rug.level = 'high'; rug.detail = 'removable LP + active owner — full rug surface'; }
      else if (lpV.burned && owV.renounced && rug.level !== 'ok'){ rug.level = 'low'; rug.detail = 'LP burned + ownership renounced'; }
      return { ...score(vectors, p), vectors, deep: true };
    }, { ttl: 600e3, stale: 1800e3 });
  }
  /* ---- token-level aggregation ---- */
  function forToken(c){
    const ps = CDX.Data.pairsForToken(c);
    if (!ps.length){
      const major = c.mcap > 1e9;
      return { risk: major ? 8 : 28, safety: major ? 88 : 55, deep: false, pair: null,
               vectors: [V('lowLiq', 'Venue coverage', major ? 'ok' : 'low',
                 major ? 'top-cap asset · deep CEX/DEX liquidity' : 'no tracked pools — telemetry limited')] };
    }
    let wRisk = 0, wSum = 0, minSafety = 100, worst = null;
    for (const p of ps){
      const q = quick(p);
      wRisk += q.risk * p.liq; wSum += p.liq;
      minSafety = Math.min(minSafety, q.safety);
      if (!worst || q.risk > worst.q.risk) worst = { p, q };
    }
    return { risk: Math.round(wRisk / Math.max(wSum, 1)), safety: minSafety,
             deep: false, pair: worst.p, vectors: worst.q.vectors };
  }

  /* ---- shared display helpers ---- */
  const COLORS = { ok: '#2DD480', low: '#8B94A7', med: '#F5C04E', high: '#FF5C5C', unknown: '#5B8CFF' };
  const chip = (r) => `<span class="inline-flex items-center gap-1.5 text-[10px] num font-bold rounded px-1.5 py-0.5 border"
      style="color:${r.risk >= 60 ? '#FF5C5C' : r.risk >= 35 ? '#F5C04E' : '#2DD480'};border-color:currentColor" title="Risk ${r.risk} · Safety ${r.safety}">
      R ${r.risk}</span><span class="inline-flex items-center text-[10px] num font-bold rounded px-1.5 py-0.5 border ml-1"
      style="color:${r.safety >= 60 ? '#2DD480' : r.safety >= 35 ? '#F5C04E' : '#FF5C5C'};border-color:currentColor">S ${r.safety}</span>`;
  const vectorRow = v => `<div class="flex items-start gap-2 py-1.5 border-b border-line/40 last:border-0">
      <span class="mt-1 w-2 h-2 rounded-full shrink-0" style="background:${COLORS[v.level]}"></span>
      <div class="min-w-0 flex-1"><div class="flex items-center justify-between gap-2">
        <span class="text-[12px] text-slate-200">${v.label}</span>
        <span class="text-[9px] font-bold uppercase tracking-wider" style="color:${COLORS[v.level]}">${v.level}</span></div>
      <div class="text-[10px] text-mut leading-snug">${v.detail}</div></div></div>`;
  const gauges = r => `<div class="grid grid-cols-2 gap-2.5 mb-3">
      ${[['RISK SCORE', r.risk, r.risk >= 60 ? '#FF5C5C' : r.risk >= 35 ? '#F5C04E' : '#2DD480'],
         ['SAFETY SCORE', r.safety, r.safety >= 60 ? '#2DD480' : r.safety >= 35 ? '#F5C04E' : '#FF5C5C']]
        .map(([l, v, col]) => `<div class="bg-panel2 border border-line rounded-lg p-3 text-center">
          <div class="num font-disp font-bold text-2xl" style="color:${col}">${v}</div>
          <div class="text-[9px] uppercase tracking-wider text-mut mt-0.5">${l}</div>
          <div class="h-1 bg-line rounded-full mt-1.5 overflow-hidden"><div class="h-full rounded-full" style="width:${v}%;background:${col}"></div></div></div>`).join('')}</div>`;
  return { quick, deepAnalyze, forToken, ui: { chip, vectorRow, gauges, COLORS } };
})();
