/* CDX data — logo CDN map with graceful fallback to initials badge. */
(() => {
const __CL = (slug)=>`https://cryptologos.cc/logos/${slug}-logo.png?v=040`;
CDX.DataRaw.LOGOS = {
  BTC:__CL('bitcoin-btc'), ETH:__CL('ethereum-eth'), WETH:__CL('ethereum-eth'),
  USDT:__CL('tether-usdt'), XRP:__CL('xrp-xrp'), SOL:__CL('solana-sol'),
  BNB:__CL('bnb-bnb'), WBNB:__CL('bnb-bnb'), USDC:__CL('usd-coin-usdc'),
  DOGE:__CL('dogecoin-doge'), ADA:__CL('cardano-ada'), TRX:__CL('tron-trx'),
  AVAX:__CL('avalanche-avax'), WAVAX:__CL('avalanche-avax'), TON:__CL('toncoin-ton'),
  LINK:__CL('chainlink-link'), SHIB:__CL('shiba-inu-shib'), DOT:__CL('polkadot-new-dot'),
  WBTC:__CL('wrapped-bitcoin-wbtc'), LTC:__CL('litecoin-ltc'), UNI:__CL('uniswap-uni'),
  NEAR:__CL('near-protocol-near'), PEPE:__CL('pepe-pepe'), APT:__CL('aptos-apt'),
  ICP:__CL('internet-computer-icp'), ARB:__CL('arbitrum-arb'),
  POL:__CL('polygon-ecosystem-token-pol'), OP:__CL('optimism-ethereum-op'),
  HEX:__CL('hex-hex'), WIF:__CL('dogwifhat-wif'), BONK:__CL('bonk-bonk'),
  PLS:__CL('pulsechain-pls'), WPLS:__CL('pulsechain-pls'), PLSX:__CL('pulsex-plsx'),
  pDAI:__CL('multi-collateral-dai-dai'), GMX:__CL('gmx-gmx'), CAKE:__CL('pancakeswap-cake'),
  FLOKI:__CL('floki-inu-floki'), JUP:__CL('jupiter-ag-jup'), PYTH:__CL('pyth-network-pyth'),
  AERO:__CL('aerodrome-finance-aero'), VELO:__CL('velodrome-finance-velo'),
  JOE:__CL('trader-joe-joe'), MOG:__CL('mog-coin-mog'), SPX:__CL('spx6900-spx'),
  POPCAT:__CL('popcat-popcat'), BRETT:__CL('based-brett-brett'),
  DEGEN:__CL('degen-base-degen'), TOSHI:__CL('toshi-toshi')
};


CDX.DataRaw.CL = __CL;
})();
