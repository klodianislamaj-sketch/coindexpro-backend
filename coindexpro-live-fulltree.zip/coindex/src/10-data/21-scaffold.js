/* CDX.Scaffold — typed interfaces for subsystems whose REAL data source is not
   yet wired. Every method returns an explicit unavailable/scaffold result so
   the UI shows "Unavailable" or a clearly-labeled scaffold — never invented
   numbers. These define the contracts so a real adapter can drop in later. */
CDX.Scaffold = (() => {
  const NA = (reason, extra) => Object.assign({ available: false, scaffold: true, reason }, extra || {});

  /* ---- Phase 11.8 · Flow tracker ----
     Stablecoin flow IS partially observable via existing capital engine; expose
     a pass-through when present, scaffold otherwise. Exchange/bridge flows need
     a labeled-address indexer we don't have → scaffold. */
  const flow = {
    stablecoin(){
      if (CDX.Capital && typeof CDX.Capital.stablecoins === 'function'){
        try { const d = CDX.Capital.stablecoins(); if (d) return { available: true, source: 'capital-engine', data: d }; } catch(e){}
      }
      return NA('stablecoin flow source not available');
    },
    exchange(){ return NA('exchange-labeled wallet set not wired (needs CEX address registry)'); },
    bridge(){ return NA('bridge flow requires cross-chain message indexer (not wired)'); }
  };

  /* ---- Phase 12 · Social connectors (scaffold only, explicitly requested) ----
     No credentials, no live API → every connector reports unconfigured. The
     shape is ready for a real adapter (configure() + fetch()). */
  function socialConnector(name){
    return {
      name, configured: false,
      configure(){ return NA(name + ' connector requires API credentials'); },
      fetch(){ return NA(name + ' connector not configured — no fabricated social data'); }
    };
  }
  const social = {
    x:        socialConnector('X'),
    telegram: socialConnector('Telegram'),
    discord:  socialConnector('Discord'),
    reddit:   socialConnector('Reddit'),
    all(){ return [this.x, this.telegram, this.discord, this.reddit]; }
  };

  /* ---- Phase 14.14 · Historical storage adapter interface ----
     Defines read/write/range contract. Default in-memory adapter is honest:
     it only returns what was actually written this session; no synthetic history. */
  function memoryStore(){
    const m = new Map();
    return {
      kind: 'memory',
      put(key, ts, value){ if (!m.has(key)) m.set(key, []); m.get(key).push({ ts, value }); },
      range(key, fromTs, toTs){
        const arr = m.get(key) || [];
        return arr.filter(r => r.ts >= (fromTs || 0) && r.ts <= (toTs || Infinity));
      },
      latest(key){ const arr = m.get(key) || []; return arr.length ? arr[arr.length - 1] : null; },
      keys(){ return [...m.keys()]; },
      available: true, note: 'Session-only memory store — not durable history.'
    };
  }
  const storage = { memory: memoryStore, adapter: memoryStore() };

  /* ---- Phase 14.15 · Event replay architecture (scaffold only) ----
     Records real bus events into the storage adapter; replay re-emits them.
     Off by default; purely a mechanism, no fabricated events. */
  const replay = (() => {
    let recording = false, off = [];
    const TRACK = ['whaleflow:new', 'liq:event', 'news:changed'];
    function start(){
      if (recording) return; recording = true;
      for (const ev of TRACK) off.push(CDX.Bus.on(ev, payload =>
        storage.adapter.put('replay:' + ev, Date.now(), payload)));
    }
    function stop(){ off.forEach(u => u()); off = []; recording = false; }
    function dump(ev){ return storage.adapter.range('replay:' + ev); }
    return { start, stop, dump, recording: () => recording, tracked: TRACK };
  })();

  /* ---- Phase 14.13 / Priority 7 · Onchain infra adapters (scaffold) ----
     Abstract provider interface so real backends can drop in. Each adapter
     reports unconfigured until wired with a real endpoint/key. No fabrication. */
  function adapterIface(name, needs){
    return { name, configured: false, needs,
      configure(cfg){ if (cfg && cfg.endpoint){ this.configured = true; this.endpoint = cfg.endpoint; return { available: true }; }
                      return NA(name + ' requires ' + needs); },
      query(){ return this.configured ? NA(name + ' configured but no live call implemented yet')
                                      : NA(name + ' not configured — ' + needs); } };
  }
  const onchain = {
    archiveNode:  adapterIface('Archive node', 'archive RPC endpoint'),
    fullNode:     adapterIface('Full node', 'full-node RPC endpoint'),
    indexer:      adapterIface('Indexer', 'indexer API (e.g. subgraph)'),
    paidApi:      adapterIface('Paid market API', 'API key'),
    labeledWallets: adapterIface('Labeled wallet DB', 'labeled-address dataset'),
    holderDb:     adapterIface('Holder DB', 'holder-snapshot source'),
    lockDb:       adapterIface('LP lock DB', 'lock-contract registry'),
    bridgeDb:     adapterIface('Bridge DB', 'cross-chain message indexer'),
    all(){ return [this.archiveNode, this.fullNode, this.indexer, this.paidApi,
                   this.labeledWallets, this.holderDb, this.lockDb, this.bridgeDb]; }
  };

  /* ---- Phase 10 / Priority 4 · Historical intelligence (REAL, session-bounded) ----
     Records real observed values into the memory store and derives baselines
     ONLY from what was actually recorded. No synthetic history: before enough
     real samples exist, baselines return { available:false }. */
  const history = (() => {
    let started = false, off = [];
    function start(){
      if (started) return; started = true;
      // price snapshots on tick (sampled) + whale trades + liq events — all real
      let n = 0;
      off.push(CDX.Bus.on('tick', () => {
        if (++n % 6 !== 0) return;                 // ~ every 24s
        for (const p of (CDX.Data.pairs || []).slice(0, 60)){
          if (p.price > 0) storage.adapter.put('px:' + p.id, Date.now(), p.price);
        }
      }));
      off.push(CDX.Bus.on('whaleflow:new', t => storage.adapter.put('wt:' + (t.wallet||'').toLowerCase(), t.ts, { usd: t.usd, side: t.side, base: t.base })));
      off.push(CDX.Bus.on('liq:event', e => storage.adapter.put('liq:' + e.pairId, Date.now(), e.delta)));
    }
    // volatility baseline from recorded real prices (stdev of returns)
    function volatilityBaseline(pairId){
      const rows = storage.adapter.range('px:' + pairId);
      if (rows.length < 5) return { available: false, reason: 'insufficient real samples', samples: rows.length };
      const px = rows.map(r => r.value);
      const rets = []; for (let i = 1; i < px.length; i++) if (px[i-1] > 0) rets.push((px[i] - px[i-1]) / px[i-1]);
      const mean = rets.reduce((a, x) => a + x, 0) / rets.length;
      const variance = rets.reduce((a, x) => a + (x - mean) ** 2, 0) / rets.length;
      return { available: true, samples: rows.length, volatility: Math.sqrt(variance),
               note: 'Derived from session-recorded real prices only.' };
    }
    // wallet evolution from recorded real trades
    function walletEvolution(addr){
      const rows = storage.adapter.range('wt:' + (addr||'').toLowerCase());
      if (!rows.length) return { available: false, reason: 'no recorded trades for wallet' };
      return { available: true, recordedTrades: rows.length,
               firstSeen: rows[0].ts, lastSeen: rows[rows.length-1].ts,
               note: 'Observed activity recorded this session only.' };
    }
    return { start, volatilityBaseline, walletEvolution };
  })();

  return { flow, social, storage, replay, onchain, history, NA };
})();
