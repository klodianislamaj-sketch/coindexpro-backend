/* CDX.Backend — INSTITUTIONAL BACKEND ABSTRACTION LAYER (preparation pass).
   These are interface/adapter contracts only. Nothing here fabricates data: an
   unconfigured adapter returns { available:false, reason } and a configured one
   returns { available:true } from configure() but does NOT invent results until
   a real driver is attached. The point is a stable surface the app can call
   today (degrading to "Unavailable") and a real backend can fulfil tomorrow.

   The ONE genuinely-live subsystem here is the Provider Trust Engine, which
   computes real weights from telemetry the app already collects. */
CDX.Backend = (() => {
  const NA = (reason, extra) => Object.assign({ available: false, reason }, extra || {});

  /* generic adapter factory: configure(cfg) attaches a real driver; until then
     every capability reports unconfigured. Methods never fabricate. */
  function makeAdapter(name, capabilities, needs){
    const self = { name, needs, configured: false, driver: null };
    self.configure = (cfg) => {
      if (cfg && (cfg.driver || cfg.endpoint || cfg.connectionString)){
        self.configured = true; self.driver = cfg.driver || null;
        self.endpoint = cfg.endpoint || cfg.connectionString || null;
        return { available: true, name };
      }
      return NA(name + ' requires ' + needs);
    };
    self.status = () => ({ name, configured: self.configured, capabilities, needs });
    // each capability becomes a method that delegates to the driver if present,
    // else returns unconfigured — never a fake value
    for (const cap of capabilities){
      self[cap] = (...args) => {
        if (!self.configured) return NA(name + '.' + cap + ' not configured — ' + needs);
        if (self.driver && typeof self.driver[cap] === 'function'){
          try { return self.driver[cap](...args); } catch(e){ return NA(name + '.' + cap + ' driver error', { error: String(e) }); }
        }
        return NA(name + '.' + cap + ' configured but driver does not implement it yet');
      };
    }
    return self;
  }

  /* ──────────────── 1 · CHAIN INDEXER ──────────────── */
  const indexer = makeAdapter('ChainIndexer',
    ['blocks', 'swaps', 'lpEvents', 'transfers', 'holderSnapshots', 'contractCreations'],
    'an indexer/node endpoint (e.g. subgraph, archive RPC, or custom indexer)');

  /* ──────────────── 2 · HISTORICAL DB ADAPTERS ──────────────── */
  const db = {
    timescale:  makeAdapter('TimescaleDB',  ['query', 'insert', 'range', 'aggregate', 'retention'], 'a TimescaleDB connection string'),
    postgres:   makeAdapter('PostgreSQL',   ['query', 'insert', 'range', 'aggregate'], 'a PostgreSQL connection string'),
    clickhouse: makeAdapter('ClickHouse',   ['query', 'insert', 'range', 'aggregate', 'materializedView'], 'a ClickHouse endpoint'),
    /* the app picks one as the active history backend; default none → memory store handles session */
    active: null,
    use(name){ if (this[name]){ this.active = this[name]; return { available: true, active: name }; } return NA('unknown db adapter ' + name); }
  };

  /* ──────────────── 3 · WALLET LABEL ENGINE ──────────────── */
  const labels = (() => {
    const adapter = makeAdapter('WalletLabels',
      ['entity', 'exchange', 'dev', 'insider', 'vc', 'bulk'],
      'a labeled-address dataset (e.g. Arkham/Nansen export or curated registry)');
    // honest lookup: returns the label ONLY if a real source is attached, else unlabeled
    function lookup(address){
      if (!adapter.configured) return { address, labeled: false, reason: 'no label source configured' };
      const r = adapter.entity(address);
      return (r && r.available === false) ? { address, labeled: false } : r;
    }
    return { adapter, lookup, configure: adapter.configure, status: adapter.status };
  })();

  /* ──────────────── 4 · CONTRACT ANALYZER ──────────────── */
  const contract = makeAdapter('ContractAnalyzer',
    ['bytecodeScan', 'ownershipDetect', 'mintDetect', 'blacklistDetect', 'taxDetect', 'hiddenAdminDetect'],
    'a bytecode/source analysis backend (e.g. GoPlus, custom static analyzer, or RPC + ABI)');

  /* ──────────────── 5 · PROVIDER TRUST ENGINE (LIVE — real telemetry) ──────────────── */
  const providerTrust = (() => {
    // accumulates real per-provider observations during the session
    const obs = new Map();   // provider → { calls, fails, stale, outliers, mismatches }
    const rec = name => { if (!obs.has(name)) obs.set(name, { calls: 0, fails: 0, stale: 0, outliers: 0, mismatches: 0 }); return obs.get(name); };
    function note(provider, kind){ const o = rec(provider); if (kind in o) o[kind]++; o.calls++; }
    function report(){
      // fold in global consensus + cache telemetry the app already tracks
      const cons = (CDX.Asset && CDX.Asset.consensusStats) ? CDX.Asset.consensusStats() : { rejectedOutliers: 0, disagreements: 0 };
      const cache = (CDX.Net.Cache && CDX.Net.Cache.stats) ? CDX.Net.Cache.stats() : null;
      const rows = [...obs.entries()].map(([provider, o]) => {
        const uptime = o.calls ? 1 - o.fails / o.calls : null;
        const staleRate = o.calls ? o.stale / o.calls : null;
        const outlierRate = o.calls ? o.outliers / o.calls : null;
        // confidence weight: high uptime, low stale/outlier → higher weight
        const weight = uptime == null ? null :
          Math.max(0, Math.min(1, uptime - (staleRate || 0) * 0.5 - (outlierRate || 0) * 0.7));
        return { provider, calls: o.calls, uptime, staleRate, outlierRate, mismatches: o.mismatches, weight };
      });
      return { providers: rows, global: { rejectedOutliers: cons.rejectedOutliers, disagreements: cons.disagreements,
               cacheHitRate: cache ? cache.hitRate : null }, live: true };
    }
    return { note, report };
  })();

  /* ──────────────── 6 · TOKEN REGISTRY ENGINE ──────────────── */
  const registry = (() => {
    const adapter = makeAdapter('TokenRegistry',
      ['official', 'socials', 'website', 'aliases', 'scamClones', 'chainDuplicates'],
      'a curated token registry (official contracts, socials, alias map)');
    // real-now helper: detect chain duplicates from the LIVE universe (no external source needed)
    function liveDuplicates(){
      const bySym = new Map();
      for (const p of (CDX.Data.pairs || [])){
        const k = (p.base || '').toUpperCase();
        if (!bySym.has(k)) bySym.set(k, []);
        bySym.get(k).push({ chain: p.chain, ca: p.ca, liq: p.liq });
      }
      const dupes = [];
      for (const [sym, list] of bySym){
        const chains = new Set(list.map(x => x.chain));
        if (chains.size > 1) dupes.push({ symbol: sym, chains: [...chains], instances: list.length });
      }
      return dupes.sort((a, b) => b.instances - a.instances);
    }
    return { adapter, liveDuplicates, configure: adapter.configure, status: adapter.status };
  })();

  /* ──────────────── 7 · PERSISTENT HISTORY ADAPTERS ──────────────── */
  const persistentHistory = makeAdapter('PersistentHistory',
    ['prices', 'liquidity', 'whaleTrades', 'trustScores', 'sectorFlows', 'writeBatch', 'readRange'],
    'a durable time-series store (delegates to the active DB adapter once configured)');

  /* ──────────────── 8 · REPLAY SYSTEM ──────────────── */
  const replay = (() => {
    // extends the session recorder; replay is real over whatever was recorded
    function lifecycle(pairId){
      const store = CDX.Scaffold && CDX.Scaffold.storage && CDX.Scaffold.storage.adapter;
      if (!store) return NA('no history store available');
      const px = store.range('px:' + pairId);
      if (!px.length) return NA('no recorded history for this token yet (session-bounded)');
      return { available: true, kind: 'token-lifecycle', samples: px.length, series: px,
               note: 'Replays session-recorded real data only.' };
    }
    function whaleReplay(addr){
      const store = CDX.Scaffold && CDX.Scaffold.storage && CDX.Scaffold.storage.adapter;
      if (!store) return NA('no history store available');
      const wt = store.range('wt:' + (addr || '').toLowerCase());
      return wt.length ? { available: true, kind: 'whale-replay', events: wt } : NA('no recorded whale activity for wallet');
    }
    function liquidityReplay(pairId){
      const store = CDX.Scaffold && CDX.Scaffold.storage && CDX.Scaffold.storage.adapter;
      if (!store) return NA('no history store available');
      const lq = store.range('liq:' + pairId);
      return lq.length ? { available: true, kind: 'liquidity-replay', events: lq } : NA('no recorded liquidity events for pair');
    }
    return { lifecycle, whaleReplay, liquidityReplay };
  })();

  /* ──────────────── 9 · PORTFOLIO ENGINE V2 ──────────────── */
  const portfolioV2 = (() => {
    const sync = makeAdapter('WalletSync',
      ['connect', 'positions', 'transactions'],
      'a read-only wallet connection (RPC balance reads or indexer)');
    /* cost-basis + PnL contract. Compute is REAL given real transactions, but
       returns unavailable until a wallet is actually synced — never fabricates
       a number. */
    function costBasis(positions){
      if (!sync.configured) return NA('wallet not synced — cannot compute cost basis without real transactions');
      if (!Array.isArray(positions) || !positions.length) return NA('no positions provided');
      // pure function: given REAL fills, compute average cost basis
      return positions.map(pos => {
        const fills = pos.fills || [];
        const bought = fills.filter(f => f.side === 'buy');
        const qty = bought.reduce((a, f) => a + f.qty, 0);
        const cost = bought.reduce((a, f) => a + f.qty * f.price, 0);
        return { token: pos.token, qty, avgCost: qty ? cost / qty : null, available: qty > 0 };
      });
    }
    function pnl(position, livePrice){
      if (!sync.configured) return NA('wallet not synced');
      if (position == null || !Number.isFinite(livePrice)) return NA('insufficient data');
      const cb = position.avgCost;
      if (cb == null) return NA('no cost basis');
      const unrealized = (livePrice - cb) * (position.qty || 0);
      const realized = position.realized != null ? position.realized : null;   // only if real fills recorded
      return { available: true, unrealizedPnl: unrealized, realizedPnl: realized,
               note: realized == null ? 'realized PnL requires recorded sell fills' : undefined };
    }
    return { sync, costBasis, pnl, configure: sync.configure, status: sync.status };
  })();

  /* registry of every backend subsystem for the status/integrity pages */
  function subsystems(){
    return [
      indexer.status(), db.timescale.status(), db.postgres.status(), db.clickhouse.status(),
      labels.status(), contract.status(), registry.status(), persistentHistory.status(),
      portfolioV2.status()
    ];
  }

  return { indexer, db, labels, contract, providerTrust, registry,
           persistentHistory, replay, portfolioV2, subsystems, makeAdapter, NA };
})();
