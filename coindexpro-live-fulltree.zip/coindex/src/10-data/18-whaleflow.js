/* CDX.WhaleFlow — REAL on-chain whale swap feed.
   Polls the live tracked-pool universe for large swaps via GeckoTerminal's
   per-pool /trades endpoint (and PulseX's GT-backed poolTrades for PulseChain).
   Each row is a verifiable on-chain trade: wallet (tx_from_address), tx hash,
   token, side, base amount, USD value, timestamp. No PnL, no win-rate, no
   smart-money labels, no synthetic wallets — only what the chain reports.

   Bounded by design: GeckoTerminal trades are per-pool, so this scans the
   pools the app already tracks (deepest-liquidity pairs per chain), not a
   global firehose. Threshold filtering is applied at fetch and at display. */
CDX.WhaleFlow = (() => {
  const MAX = 400;                 // ring-buffer cap of recent whale prints
  const SCAN_POOLS = 14;           // top pools (by liq) scanned per cycle
  const FETCH_MIN = 10000;         // hard floor: never fetch trades under $10k
  let trades = [];                 // [{ ts, wallet, tx, pairId, base, quote, chain, side, usd, price }]
  const seen = new Set();          // tx-hash dedupe
  let lastScan = 0;
  let started = false;

  const explorerTx = (chain, tx) => {
    const m = { ethereum:'https://etherscan.io/tx/', bnb:'https://bscscan.com/tx/',
      base:'https://basescan.org/tx/', arbitrum:'https://arbiscan.io/tx/',
      optimism:'https://optimistic.etherscan.io/tx/', polygon:'https://polygonscan.com/tx/',
      avalanche:'https://snowtrace.io/tx/', pulsechain:'https://scan.pulsechain.com/tx/',
      solana:'https://solscan.io/tx/' };
    return (m[chain] || '') + tx;
  };
  const explorerAddr = (chain, addr) => {
    const m = { ethereum:'https://etherscan.io/address/', bnb:'https://bscscan.com/address/',
      base:'https://basescan.org/address/', arbitrum:'https://arbiscan.io/address/',
      optimism:'https://optimistic.etherscan.io/address/', polygon:'https://polygonscan.com/address/',
      avalanche:'https://snowtrace.io/address/', pulsechain:'https://scan.pulsechain.com/address/',
      solana:'https://solscan.io/account/' };
    return (m[chain] || '') + addr;
  };

  /* fetch one pool's large trades via the real on-chain source */
  async function fetchPool(p){
    try {
      const rows = p.chain === 'pulsechain'
        ? await CDX.Providers.pulsex.poolTrades(p.address, FETCH_MIN)
        : await CDX.Providers.geckoterminal.trades(p.chain, p.address, FETCH_MIN);
      let added = 0;
      for (const t of rows){
        if (!t.tx || seen.has(t.tx) || t.usd < FETCH_MIN || !t.wallet) continue;
        seen.add(t.tx);
        const row = { ts: t.ts, wallet: t.wallet, tx: t.tx, pairId: p.id,
                      base: p.base, quote: p.quote, chain: p.chain,
                      side: t.side, usd: t.usd, price: t.price,
                      amount: t.price > 0 ? t.usd / t.price : 0 };
        trades.unshift(row);
        added++;
        CDX.Bus.emit('whaleflow:new', row);
      }
      if (trades.length > MAX){ trades.length = MAX; }
      if (seen.size > MAX * 3){ seen.clear(); trades.forEach(t => seen.add(t.tx)); }
      return added;
    } catch(e){ return 0; }
  }

  /* one scan cycle: deepest-liquidity tracked pools across chains */
  async function scan(){
    const pools = CDX.Data.pairs
      .filter(p => p.address && p.liq > 0 && CDX.Providers.geckoterminal.NET[p.chain])
      .sort((a, b) => (b.liq || 0) - (a.liq || 0))
      .slice(0, SCAN_POOLS);
    let added = 0;
    for (const p of pools){ added += await fetchPool(p); }
    trades.sort((a, b) => b.ts - a.ts);
    if (added) CDX.Bus.emit('whaleflow:updated', added);
    return added;
  }

  function start(){
    if (started) return;
    started = true;
    CDX.Net.Conn.routePoller('whaleflow:scan', async () => {
      if (Date.now() - lastScan < 25000) return;
      lastScan = Date.now();
      await scan();
    }, 30000, { immediate: true }).start();
  }

  /* public reads — filter by minimum USD threshold */
  function feed(minUsd, opts){
    const o = opts || {};
    let rows = trades.filter(t => t.usd >= (minUsd || 0));
    if (o.side) rows = rows.filter(t => t.side === o.side);
    if (o.chain) rows = rows.filter(t => t.chain === o.chain);
    return o.limit ? rows.slice(0, o.limit) : rows;
  }
  function stats(minUsd){
    const rows = feed(minUsd || 0);
    let bv = 0, sv = 0;
    const wallets = new Set();
    for (const t of rows){ t.side === 'buy' ? bv += t.usd : sv += t.usd; wallets.add(t.wallet); }
    return { buyVol: bv, sellVol: sv, net: bv - sv, count: rows.length, wallets: wallets.size };
  }

  /* ---- V2 GROUNDWORK (Phase 3) — typed structure only, NO fabricated data ----
     These expose the SHAPE that wallet-intelligence V2 will fill from a real
     indexer (holdings, in/out flow, concentration, realized/unrealized PnL).
     Until a verifiable source is wired, every method returns an explicit
     "unavailable" result so the UI shows Unavailable, never invented numbers.
     What IS real today: aggregate per-wallet swap activity derived from the
     live trade buffer (counts and gross USD by side) — computed, not guessed. */
  function walletActivity(addr){
    if (!addr) return { available: false, reason: 'no address' };
    const a = addr.toLowerCase();
    const mine = trades.filter(t => (t.wallet || '').toLowerCase() === a);
    if (!mine.length) return { available: false, reason: 'no observed trades in buffer', wallet: addr };
    let buyUsd = 0, sellUsd = 0;
    for (const t of mine){ t.side === 'buy' ? buyUsd += t.usd : sellUsd += t.usd; }
    return {
      available: true, wallet: addr,
      observedTrades: mine.length,
      grossBuyUsd: buyUsd, grossSellUsd: sellUsd, netUsd: buyUsd - sellUsd,
      firstSeen: Math.min(...mine.map(t => t.ts)), lastSeen: Math.max(...mine.map(t => t.ts)),
      note: 'Derived from live trade buffer only — not full wallet history.'
    };
  }
  /* V2 placeholders — return unavailable until a real holdings/balance source exists */
  const _unavailable = reason => ({ available: false, reason });
  function holdings(){ return _unavailable('wallet holdings require a balance indexer (not yet wired)'); }
  function flows(){ return _unavailable('wallet in/out flows require full tx history (not yet wired)'); }
  function concentration(){ return _unavailable('token concentration requires holder snapshot (not yet wired)'); }
  function pnl(){ return _unavailable('realized/unrealized PnL requires cost-basis tracking (not yet wired)'); }

  /* compact embeddable row for other live pages (real trade only) */
  function miniRow(t){
    const F = CDX.Fmt;
    const sideCls = t.side === 'buy' ? 'text-up' : 'text-down';
    const short = a => a ? a.slice(0,6)+'…'+a.slice(-4) : '—';
    return `<div class="flex items-center gap-2 px-4 py-2 border-b border-line/40 last:border-0 text-xs">
      <span class="num font-bold ${sideCls} w-9">${t.side==='buy'?'BUY':'SELL'}</span>
      <span class="font-medium text-slate-200">${F.esc(t.base)}</span>
      <a href="${explorerTx(t.chain,t.tx)}" target="_blank" rel="noopener" class="num text-mut hover:text-acc ml-1">${short(t.wallet)} ↗</a>
      <span class="num font-semibold ${sideCls} ml-auto">${F.usd(t.usd)}</span>
      <span class="num text-mut text-[10px] whitespace-nowrap">${F.rel(t.ts)}</span></div>`;
  }

  return { start, scan, feed, stats, explorerTx, explorerAddr, miniRow,
           raw: () => trades.slice(),
           walletActivity, holdings, flows, concentration, pnl,
           THRESHOLDS: [10000, 50000, 100000, 500000] };
})();
