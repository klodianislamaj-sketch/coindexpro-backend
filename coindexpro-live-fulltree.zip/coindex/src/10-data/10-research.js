/* CDX.Research — Phase 4 intelligence: sentiment, catalysts, commentary, related assets. */
CDX.Research = (() => {
  const F = CDX.Fmt;
  const DAY = 864e5;
  const CATALYSTS = [
    { inDays: 1,  title: 'FOMC rate decision + press conference', kind: 'macro',   impact: 'high', tag: 'c:btc' },
    { inDays: 3,  title: 'Tokenized SpaceX shares go live on Solana', kind: 'listing', impact: 'high', tag: 'c:sol' },
    { inDays: 5,  title: 'Jupiter buyback expansion governance vote closes', kind: 'event', impact: 'med', tag: 'd:d-jup-usdc' },
    { inDays: 6,  title: 'ARB quarterly unlock — 92.6M tokens vest', kind: 'unlock', impact: 'med', tag: 'c:arb' },
    { inDays: 8,  title: 'Large HEX stake-ladder expiry wave begins', kind: 'event', impact: 'med', tag: 'c:hex' },
    { inDays: 9,  title: 'APT foundation + investor unlock', kind: 'unlock', impact: 'med', tag: 'c:apt' },
    { inDays: 11, title: 'PulseX V2 fee-switch parameter vote', kind: 'event', impact: 'med', tag: 'c:plsx' },
    { inDays: 12, title: 'OP grants-cycle unlock', kind: 'unlock', impact: 'low', tag: 'c:op' },
    { inDays: 15, title: 'US CPI print (May data)', kind: 'macro', impact: 'high', tag: 'c:btc' },
    { inDays: 18, title: 'Base network throughput upgrade (mainnet)', kind: 'upgrade', impact: 'med', tag: 'd:d-brett-weth' },
    { inDays: 24, title: 'CME crypto index futures — first monthly expiry', kind: 'macro', impact: 'med', tag: 'c:btc' },
    { inDays: 29, title: 'Ethereum core devs: next hard-fork scope freeze', kind: 'upgrade', impact: 'med', tag: 'c:eth' }
  ];
  const catalysts = () => CATALYSTS.map(c => ({ ...c, ts: Date.now() + c.inDays * DAY }));

  function newsScore(items){
    if (!items.length) return 50;
    const s = items.reduce((a,n) => a + (n.kind === 'bull' ? 1 : n.kind === 'bear' ? -1 : 0), 0);
    return Math.max(2, Math.min(98, Math.round(50 + s / items.length * 42)));
  }
  function marketSentiment(){
    const g = CDX.Data.globals();
    const news = newsScore(CDX.News.all());
    const flows = CDX.Intel.allChains().map(s => s.flow.momentum);
    const flow = flows.reduce((a,b)=>a+b,0) / flows.length;
    const value = Math.round(g.fearGreed * 0.4 + news * 0.3 + flow * 0.3);
    const label = value >= 70 ? 'Risk-On' : value >= 55 ? 'Constructive' : value >= 45 ? 'Neutral' : value >= 30 ? 'Defensive' : 'Risk-Off';
    return { value, label, parts: { fearGreed: g.fearGreed, news, flow: Math.round(flow) } };
  }
  function assetSentiment(key){
    const items = CDX.News.all().filter(n => n.tag === key);
    return { score: newsScore(items), n: items.length };
  }
  function narrativeSentiment(){
    return CDX.Intel.allNarratives().map(n => {
      const items = CDX.News.all().filter(x => {
        const it = CDX.Data.byKey(x.tag);
        return it && (it.tags || []).includes(n.id);
      });
      return { ...n, news: newsScore(items), nItems: items.length };
    });
  }
  function related(key, n){
    const base = CDX.Data.byKey(key);
    if (!base) return [];
    const bTags = base.tags || [], bChain = base.chain, bSize = base.sym ? base.mcap : base.fdv;
    const all = [
      ...CDX.Data.coins.map(c => ({ key: 'c:' + c.id, it: c })),
      ...CDX.Data.pairs.map(p => ({ key: 'd:' + p.id, it: p }))
    ].filter(x => x.key !== key);
    return all.map(x => {
      const tags = x.it.tags || [];
      const shared = tags.filter(t => bTags.includes(t)).length;
      const size = x.it.sym ? x.it.mcap : x.it.fdv;
      const prox = 1 / (1 + Math.abs(Math.log10((size || 1) / (bSize || 1))));
      const score = shared * 3 + (x.it.chain === bChain ? 2 : 0) + prox * 2;
      return { ...x, score, shared };
    }).filter(x => x.score > 1.2).sort((a,b) => b.score - a.score).slice(0, n || 8);
  }
  const pick = a => a[Math.floor(Math.random() * a.length)];
  function commentary(){
    const g = CDX.Data.globals();
    const sent = marketSentiment();
    const ns = [...CDX.Intel.allNarratives()].sort((a,b)=>b.flow.netFlow-a.flow.netFlow);
    const inN = ns[0], outN = ns[ns.length-1];
    const pls = CDX.Intel.chainStats('pulsechain');
    const btc = CDX.Data.coins[0];
    return [
      { tag: 'Macro Read', color: '#5B8CFF', body: pick([
        `Composite sentiment sits at <b class="text-white">${sent.value}/100 (${sent.label})</b> with Fear & Greed at ${sent.parts.fearGreed}. BTC dominance ${g.btcDom.toFixed(1)}% and a cap-weighted 24h move of ${F.pct(g.wCh24)} read as ${g.wCh24 > 0 ? 'a relief bid into event risk — chase carefully' : 'positioning being trimmed into event risk rather than panic'}. Total cap ${F.usd(g.totalMcap)}.`,
        `The tape is ${sent.value >= 50 ? 'leaning constructive' : 'defensive'}: news flow scores ${sent.parts.news}/100 against an average chain momentum of ${sent.parts.flow}. BTC at ${F.price(btc.price)} (${F.pct(btc.ch24)} 24h) remains the swing factor — alts follow with higher beta in both directions.`]) },
      { tag: 'Rotation Read', color: '#2DD480', body: pick([
        `Net DEX flow favors <b style="color:${inN.color}">${inN.name}</b> (+${F.usd(Math.max(0, inN.flow.netFlow)).slice(1)}) while <b style="color:${outN.color}">${outN.name}</b> bleeds (−${F.usd(Math.abs(Math.min(0, outN.flow.netFlow))).slice(1)}). Heat scores back the move: ${inN.name} at ${inN.heat} vs ${outN.name} at ${outN.heat}. Rotation, not expansion — size accordingly.`,
        `Capital is rotating rather than entering: ${inN.name} shows accumulation at ${inN.flow.accumulation} while ${outN.name} distribution reads ${outN.flow.distribution}. Watch whether inflow breadth widens past the top two narratives before calling it a regime change.`]) },
      { tag: 'PulseChain Read', color: '#FF0080', body: pick([
        `PulseX volume runs ${F.usd(pls.dexVol)} on ${F.usd(pls.liq)} pooled liquidity (momentum ${pls.flow.momentum}). ${pls.flow.netFlow >= 0 ? 'Buy-side transactions lead — breadth across pairs, not a single-pair squeeze.' : 'Sell-side leads; WPLS pools are the tell — stabilization there usually precedes ecosystem bounces.'} New deploys: ${pls.newTokens}/24h.`,
        `Pulse ecosystem reads ${pls.flow.accumulation >= 50 ? 'accumulative under the surface despite headline weakness' : 'distributive — rallies are being sold until churn cools'}. ${F.num(pls.flow.buyTx)} buys vs ${F.num(pls.flow.sellTx)} sells across tracked PulseX pairs.`]) }
    ];
  }
  return { catalysts, marketSentiment, assetSentiment, narrativeSentiment, related, commentary, newsScore };
})();
