/* CDX data — supported chains. PulseChain is first-class. */
CDX.DataRaw = CDX.DataRaw || {};
CDX.DataRaw.CHAINS = {
  pulsechain:{ name:'PulseChain', short:'PLS', color:'#FF0080' },
  ethereum:  { name:'Ethereum',   short:'ETH', color:'#627EEA' },
  solana:    { name:'Solana',     short:'SOL', color:'#14F195' },
  base:      { name:'Base',       short:'BASE',color:'#0052FF' },
  arbitrum:  { name:'Arbitrum',   short:'ARB', color:'#2D9CDB' },
  bnb:       { name:'BSC',        short:'BSC', color:'#F0B90B' },
  avalanche: { name:'Avalanche',  short:'AVAX',color:'#E84142' },
  optimism:  { name:'Optimism',   short:'OP',  color:'#FF0420' },
  polygon:   { name:'Polygon',    short:'POL', color:'#8247E5' },
  sui:       { name:'Sui',        short:'SUI', color:'#4DA2FF' },
  ton:       { name:'TON',        short:'TON', color:'#0098EA' },
  linea:     { name:'Linea',      short:'LIN', color:'#61DFFF' },
  sonic:     { name:'Sonic',      short:'S',   color:'#C8CCD4' }
};
CDX.DataRaw.CHAIN_ORDER = ['pulsechain','ethereum','solana','base','arbitrum','bnb','avalanche','optimism','polygon','sui','ton','linea','sonic'];
