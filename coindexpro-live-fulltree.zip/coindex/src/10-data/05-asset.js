/* CDX.Asset — NORMALIZED DATA LAYER (Phase 1 keystone).
   Single source of truth for asset shape. Every page should resolve assets
   through here instead of reading raw provider/seed fields, so validation,
   fallback-source marking and freshness are applied uniformly.

   Unified shape (exactly as specified):
     { price, volume24h, liquidity, marketCap, fdv, holders,
       pairAddress, tokenAddress, chain, timestamp,
       // provenance / integrity (added, non-breaking):
       symbol, name, source, stale, valid }

   Validation rejects: null, undefined, NaN, Infinity, negative liquidity,
   invalid timestamps, malformed addresses. Invalid numerics resolve to null
   so the UI renders "Unavailable" (via Fmt) rather than a fabricated value. */
CDX.Asset = (() => {
  const STALE_MS = 90 * 1000;          // data older than this is flagged stale
  const HARD_STALE_MS = 10 * 60 * 1000; // beyond this, treated as unusable-as-live

  /* ---- field validators ---- */
  const num = v => (typeof v === 'number' && Number.isFinite(v)) ? v : null;
  const posNum = v => { const n = num(v); return (n != null && n >= 0) ? n : null; };
  const price = v => { const n = num(v); return (n != null && n > 0) ? n : null; };   // 0 price is invalid for a live asset
  const liquidity = v => { const n = num(v); return (n != null && n >= 0) ? n : null; }; // negative liq rejected
  const ts = v => { const n = num(v); return (n != null && n > 1e12 && n <= Date.now() + 60000) ? n
                                       : (n != null && n > 1e9 && n < 1e12 ? n * 1000 : null); }; // accept s or ms; reject future/garbage
  const EVM = /^0x[a-fA-F0-9]{40}$/;
  const SOL = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
  const addr = (v, chain) => {
    if (typeof v !== 'string' || !v) return null;
    if (chain === 'solana') return SOL.test(v) ? v : null;
    return EVM.test(v) ? v.toLowerCase() : null;
  };

  /* ---- core normalizer: takes a live coin or pair object → unified asset ---- */
  function fromPair(p, meta){
    if (!p) return null;
    const liq = liquidity(p.liq);
    const out = {
      price:        price(p.price),
      volume24h:    posNum(p.vol),
      liquidity:    liq,
      marketCap:    posNum(p.mcap ?? p.fdv),     // pairs carry fdv; mcap if present
      fdv:          posNum(p.fdv),
      holders:      posNum(p.holders),
      pairAddress:  addr(p.address, p.chain),
      tokenAddress: addr(p.ca, p.chain),
      chain:        p.chain || null,
      timestamp:    meta && meta.ts ? ts(meta.ts) : Date.now(),
      symbol:       p.base || null,
      name:         p.name || null,
      source:       (meta && meta.source) || 'live',
      stale:        false, valid: true
    };
    return finalize(out, meta);
  }

  function fromCoin(c, meta){
    if (!c) return null;
    const out = {
      price:        price(c.price),
      volume24h:    posNum(c.vol),
      liquidity:    null,                        // coins aren't pool-scoped
      marketCap:    posNum(c.mcap),
      fdv:          posNum(c.fdv),
      holders:      posNum(c.holders),
      pairAddress:  null,
      tokenAddress: addr(c.ca, c.chain),
      chain:        c.chain || null,
      timestamp:    meta && meta.ts ? ts(meta.ts) : Date.now(),
      symbol:       c.sym || null,
      name:         c.name || null,
      source:       (meta && meta.source) || 'live',
      stale:        false, valid: true
    };
    return finalize(out, meta);
  }

  /* freshness + overall validity stamp */
  function finalize(a, meta){
    const age = a.timestamp ? Date.now() - a.timestamp : Infinity;
    a.stale = age > STALE_MS;
    a.hardStale = age > HARD_STALE_MS;
    // an asset with no usable price is not valid-as-live
    a.valid = a.price != null && !a.hardStale;
    if (meta && meta.cacheKey){
      const cacheAge = CDX.Net.Cache.ageOf(meta.cacheKey);
      if (Number.isFinite(cacheAge)){
        a.cacheAgeMs = cacheAge;
        if (cacheAge > STALE_MS) a.stale = true;
      }
    }
    return a;
  }

  /* ---- public resolve: by store key ('c:id' | 'd:id') or raw object ---- */
  function resolve(keyOrObj, meta){
    if (!keyOrObj) return null;
    if (typeof keyOrObj === 'string'){
      const it = CDX.Data.byKey(keyOrObj);
      if (!it) return null;
      return keyOrObj.startsWith('c:') ? fromCoin(it, meta) : fromPair(it, meta);
    }
    // raw object: disambiguate by shape
    return keyOrObj.sym ? fromCoin(keyOrObj, meta) : fromPair(keyOrObj, meta);
  }

  /* ---- fallback hierarchy (Phase 1.2): DexScreener → GeckoTerminal → CoinGecko → cache.
     Returns the first source that yields a VALID asset, tagged with its source and
     freshness. Never fabricates; if all fail, returns a structurally-valid object
     with null numerics (renders "Unavailable") and source:'unavailable'. */
  async function resolveLive(chain, address){
    const ca = addr(address, chain);
    if (!ca) return unavailable(chain, address);
    const key = 'asset:' + chain + ':' + ca;

    // 1 · DexScreener (primary)
    try {
      const rows = await CDX.Net.Cache.swr(key + ':ds',
        () => CDX.Providers.dexscreener.pairs(chain, [ca]), { ttl: 30e3, stale: 600e3 });
      const best = pickDeepest(rows);
      if (best){ const a = fromPair(best, { source: 'dexscreener', ts: Date.now(), cacheKey: key + ':ds' }); if (a.valid) return a; }
    } catch(e){}

    // 2 · GeckoTerminal (fallback)
    try {
      const gt = await CDX.Net.Cache.swr(key + ':gt',
        () => CDX.Providers.geckoterminal.topPools(chain, 1), { ttl: 45e3, stale: 600e3 });
      const hit = (gt || []).find(p => (p.ca || '').toLowerCase() === ca || (p.address || '').toLowerCase() === ca);
      if (hit){ const a = fromPair(hit, { source: 'geckoterminal', ts: Date.now(), cacheKey: key + ':gt' }); if (a.valid) return a; }
    } catch(e){}

    // 3 · CoinGecko (fallback, symbol/contract-resolved upstream) — best-effort
    try {
      const cg = await CDX.Net.Cache.swr(key + ':cg',
        () => CDX.Providers.coingecko.byContract && CDX.Providers.coingecko.byContract(chain, ca),
        { ttl: 60e3, stale: 900e3 });
      if (cg){ const a = fromCoin(cg, { source: 'coingecko', ts: Date.now(), cacheKey: key + ':cg' }); if (a.valid) return a; }
    } catch(e){}

    // 4 · cached last-valid (any of the above keys)
    for (const suf of [':ds', ':gt', ':cg']){
      const cached = CDX.Net.Cache.get(key + suf);
      if (cached){
        const best = Array.isArray(cached) ? pickDeepest(cached) : cached;
        if (best){ const a = (best.sym ? fromCoin : fromPair)(best, { source: 'cache', ts: null, cacheKey: key + suf }); a.stale = true; if (a.price != null) return a; }
      }
    }
    return unavailable(chain, address);
  }

  function pickDeepest(rows){
    if (!Array.isArray(rows) || !rows.length) return null;
    return rows.filter(r => r && r.price > 0)
               .sort((a, b) => (b.liq || 0) - (a.liq || 0))[0] || null;
  }

  /* ════ PRIORITY 2 · DATA INTEGRITY ENFORCEMENT ════
     Reject obviously-bad data. Each check returns a reason string when it
     rejects, or null when the value passes. Pure functions, no side effects. */
  const integrity = {
    // impossible single-tick price move vs last accepted price (>10x or <1/10x in one refresh)
    impossibleMove(prev, next){
      if (prev == null || next == null || prev <= 0 || next <= 0) return null;
      const r = next / prev;
      return (r > 10 || r < 0.1) ? `price moved ${r.toFixed(1)}x vs last accepted` : null;
    },
    // suspicious liquidity jump (>20x up in one refresh is almost always bad data)
    suspiciousLiqJump(prev, next){
      if (prev == null || next == null || prev <= 0) return null;
      return (next / prev > 20) ? `liquidity jumped ${(next/prev).toFixed(0)}x` : null;
    },
    // timestamp drift: data timestamp far in the future or absurdly old
    timestampDrift(tsv){
      const t = ts(tsv);
      if (t == null) return 'invalid timestamp';
      if (t > Date.now() + 120000) return 'timestamp in the future';
      return null;
    },
    // chain mismatch: claimed chain doesn't match the address format
    chainMismatch(chain, address){
      if (!address) return null;
      const isEvm = EVM.test(address), isSol = SOL.test(address);
      if (chain === 'solana' && !isSol) return 'solana chain with non-solana address';
      if (chain !== 'solana' && !isEvm) return 'evm chain with non-evm address';
      return null;
    }
  };

  // last-accepted price per asset key, for move/jump checks (in-memory, session)
  const lastAccepted = new Map();
  function gateUpdate(key, candidate){
    const rejects = [];
    const prev = lastAccepted.get(key);
    if (prev){
      const im = integrity.impossibleMove(prev.price, candidate.price); if (im) rejects.push(im);
      const lj = integrity.suspiciousLiqJump(prev.liquidity, candidate.liquidity); if (lj) rejects.push(lj);
    }
    const td = integrity.timestampDrift(candidate.timestamp); if (td) rejects.push(td);
    const cm = integrity.chainMismatch(candidate.chain, candidate.tokenAddress || candidate.pairAddress); if (cm) rejects.push(cm);
    if (rejects.length) return { accepted: false, rejects };
    lastAccepted.set(key, { price: candidate.price, liquidity: candidate.liquidity });
    return { accepted: true, rejects: [] };
  }

  /* ════ PRIORITY 3 · MULTI-SOURCE CONSENSUS ENGINE ════
     Gather candidate prices from all available providers, cross-check them, and
     assign a confidence. Rules:
       • 2+ sources within tolerance → accept (high confidence)
       • a single extreme outlier → reject the outlier
       • all disagree → mark low confidence (return median, flagged)
       • no usable source → unavailable
     Tolerance is relative (default 5%). Never fabricates a value. */
  const _rejectedOutliers = { count: 0 };
  const _disagreements = { count: 0 };
  function consensus(candidates, opts){
    const tol = (opts && opts.tolerance) || 0.05;
    const valid = candidates.filter(c => c && Number.isFinite(c.price) && c.price > 0);
    if (!valid.length) return { price: null, confidence: 'unavailable', sources: [], agreeing: 0 };
    if (valid.length === 1) return { price: valid[0].price, confidence: 'single-source',
      sources: valid.map(v => v.source), agreeing: 1 };

    // cluster by relative agreement
    const prices = valid.map(v => v.price).sort((a, b) => a - b);
    const median = prices[Math.floor(prices.length / 2)];
    const agree = valid.filter(v => Math.abs(v.price - median) / median <= tol);
    const outliers = valid.filter(v => Math.abs(v.price - median) / median > tol);

    if (agree.length >= 2){
      if (outliers.length){ _rejectedOutliers.count += outliers.length;
        if (CDX.Backend && CDX.Backend.providerTrust) for (const o of outliers) try { CDX.Backend.providerTrust.note(o.source, 'outliers'); } catch(e){} }
      const avg = agree.reduce((a, v) => a + v.price, 0) / agree.length;
      return { price: avg, confidence: 'high', sources: agree.map(v => v.source),
        agreeing: agree.length, rejected: outliers.map(v => v.source) };
    }
    // all disagree
    _disagreements.count++;
    if (CDX.Backend && CDX.Backend.providerTrust) for (const v of valid) try { CDX.Backend.providerTrust.note(v.source, 'mismatches'); } catch(e){}
    return { price: median, confidence: 'low', sources: valid.map(v => v.source),
      agreeing: 0, note: 'sources disagree — showing median, low confidence' };
  }

  function consensusStats(){ return { rejectedOutliers: _rejectedOutliers.count, disagreements: _disagreements.count }; }

  function unavailable(chain, address){
    return { price: null, volume24h: null, liquidity: null, marketCap: null, fdv: null,
             holders: null, pairAddress: null, tokenAddress: null, chain: chain || null,
             timestamp: null, symbol: null, name: null, source: 'unavailable',
             stale: true, hardStale: true, valid: false };
  }

  /* freshness label for UI badges */
  function freshness(a){
    if (!a || !a.valid) return { label: 'Unavailable', cls: 'text-mut' };
    if (a.source === 'cache') return { label: 'Cached', cls: 'text-gold' };
    if (a.stale) return { label: 'Stale', cls: 'text-gold' };
    return { label: 'Live', cls: 'text-up' };
  }

  return { resolve, resolveLive, freshness, fromPair, fromCoin,
           validators: { num, posNum, price, liquidity, ts, addr },
           integrity, gateUpdate, consensus, consensusStats,
           STALE_MS, HARD_STALE_MS };
})();
