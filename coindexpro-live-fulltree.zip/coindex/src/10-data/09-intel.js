/* CDX.Intel — Phase 2 intelligence layer: chain, flow, whale and narrative analytics.
   Pure derivations over CDX.Data; recomputed on demand so live ticks stay cheap. */
CDX.Intel = (() => {
  const R = CDX.DataRaw, F = CDX.Fmt;
  const clamp = v => Math.max(1, Math.min(99, Math.round(v)));

  /* per-chain synthetic baselines (TVL multiplier on tracked liq, 24h active wallets, new tokens/24h) */
  const BASE = {
    ethereum:  { tvlX: 18, wallets: 418e3, newTok: 320 },
    solana:    { tvlX: 9,  wallets: 1.24e6, newTok: 1240 },
    base:      { tvlX: 8,  wallets: 540e3, newTok: 860 },
    pulsechain:{ tvlX: 6,  wallets: 38.4e3, newTok: 145 },
    arbitrum:  { tvlX: 10, wallets: 196e3, newTok: 95 },
    bnb:       { tvlX: 9,  wallets: 612e3, newTok: 410 },
    avalanche: { tvlX: 7,  wallets: 64e3,  newTok: 40 },
    optimism:  { tvlX: 8,  wallets: 88e3,  newTok: 35 },
    polygon:   { tvlX: 7,  wallets: 142e3, newTok: 60 }
  };

  function flowFor(ps){
    let buyVol = 0, sellVol = 0, buyTx = 0, sellTx = 0, chW = 0, wsum = 0, heat = 0;
    for (const p of ps){
      const m = p.flowMeasured;
      const r = m && Date.now() - (m.ts || 0) < 600e3 && (m.buyVol + m.sellVol) > 0
        ? m.buyVol / (m.buyVol + m.sellVol)
        : p.buys / (p.buys + p.sells);
      buyVol += p.vol * r; sellVol += p.vol * (1 - r);
      buyTx += p.buys; sellTx += p.sells;
      chW += p.ch.h24 * p.vol; wsum += p.vol;
      heat += p.vol / Math.max(p.liq, 1);
    }
    const net = buyVol - sellVol;
    const total = buyVol + sellVol || 1;
    const ch = wsum ? chW / wsum : 0;
    const momentum = clamp(50 + ch * 1.4 + (net / total) * 38 + Math.min(12, heat));
    const accumulation = clamp((buyTx / ((buyTx + sellTx) || 1)) * 72 + (net > 0 ? 24 + Math.min(14, net / total * 60) : 8));
    const distribution = clamp(100 - accumulation + (ch < 0 ? 9 : -9));
    return { buyVol, sellVol, buyTx, sellTx, netFlow: net, momentum, accumulation, distribution };
  }

  function chainPairs(id){ return CDX.Data.pairs.filter(p => p.chain === id); }
  /* Overlay live DEX pair price onto an ecosystem coin so the Chains page
     never renders frozen seed values. Matches the coin's symbol to the
     deepest-liquidity live pair where it is the BASE token (DexScreener
     priceUsd is already USD, so WPLS-quoted pairs are fine). PLS maps to
     WPLS. Falls back to the coin's own value if no live pair is found. */
  function livePriceFor(coin, pairs){
    const sym = coin.sym === 'PLS' ? 'WPLS' : coin.sym;
    let best = null;
    for (const p of pairs){
      if (p.base !== sym) continue;
      if (!(p.price > 0)) continue;
      if (!best || (p.liq || 0) > (best.liq || 0)) best = p;
    }
    if (!best) return coin;
    const ch24 = best.ch && typeof best.ch.h24 === 'number' ? best.ch.h24 : coin.ch24;
    return Object.assign({}, coin, { price: best.price, ch24,
      mcap: coin.supply > 0 ? coin.supply * best.price : coin.mcap, _live: true });
  }

  function chainStats(id){
    const ps = chainPairs(id);
    let cs = CDX.Data.coins.filter(c => c.chain === id);
    if (id === 'pulsechain') cs = cs.map(c => livePriceFor(c, ps));
    const liq = ps.reduce((a,p)=>a+p.liq,0), vol = ps.reduce((a,p)=>a+p.vol,0);
    const b = BASE[id] || { tvlX: 7, wallets: 25e3, newTok: 20 };
    return {
      id, chain: CDX.Data.CHAINS[id],
      mcap: cs.reduce((a,c)=>a+c.mcap,0) + liq * 8,
      tvl: liq * b.tvlX,
      dexVol: vol, liq,
      activeWallets: Math.round(b.wallets * (1 + (vol / (liq || 1)) * 0.04)),
      activePairs: ps.length,
      newTokens: b.newTok + ps.filter(p => p.ageH <= 24).length,
      flow: flowFor(ps),
      coins: cs, pairs: ps
    };
  }
  const allChains = () => CDX.Data.CHAIN_ORDER.map(chainStats);

  /* ---- narratives ---- */
  function narrative(id){
    const meta = R.NARRATIVES[id];
    if (!meta) return null;
    const coins = CDX.Data.coins.filter(c => c.tags.includes(id));
    const pairs = CDX.Data.pairs.filter(p => p.tags.includes(id));
    const mcap = coins.reduce((a,c)=>a+c.mcap,0);
    const wCh24 = mcap ? coins.reduce((a,c)=>a + c.ch24*c.mcap, 0) / mcap : 0;
    const wCh7d = mcap ? coins.reduce((a,c)=>a + c.ch7d*c.mcap, 0) / mcap : 0;
    const flow = flowFor(pairs);
    const heat = clamp(46 + wCh24 * 2 + (flow.momentum - 50) * 0.55 + Math.min(10, pairs.length * 0.4));
    return { ...meta, coins, pairs, mcap, wCh24, wCh7d,
      vol: coins.reduce((a,c)=>a+c.vol,0) + pairs.reduce((a,p)=>a+p.vol,0) * 0.2,
      flow, heat };
  }
  const allNarratives = () => R.NARRATIVE_ORDER.map(narrative);

  /* ---- whales ---- */
  function whaleTrades(filter){
    let t = R.WHALE_TRADES;
    if (filter && filter.chain) t = t.filter(x => CDX.Data.byKey('d:'+x.pairId)?.chain === filter.chain);
    if (filter && filter.wallet) t = t.filter(x => x.wallet === filter.wallet);
    if (filter && filter.side) t = t.filter(x => x.side === filter.side);
    return t;
  }
  const wallets = () => [...R.WALLETS].sort((a,b) => b.score - a.score);
  const wallet = addr => R.walletByAddr.get(addr);
  function walletHoldings(w){
    const rnd = F.mulberry32(F.seedOf(w.addr.slice(2, 12)));
    const universe = [
      ...CDX.Data.coins.filter(c => w.chains.includes(c.chain) || (c.id==='btc'&&w.type==='Fund')).map(c => ({ key:'c:'+c.id, it:c })),
      ...CDX.Data.pairs.filter(p => w.chains.includes(p.chain)).map(p => ({ key:'d:'+p.id, it:p }))
    ];
    const n = Math.min(universe.length, 3 + Math.floor(rnd()*4));
    const picks = [];
    const pool = [...universe];
    for (let i = 0; i < n && pool.length; i++) picks.push(pool.splice(Math.floor(rnd()*pool.length), 1)[0]);
    return picks.map(x => {
      const usd = 18e3 * Math.exp(rnd() * 4.2) * (w.type === 'Fund' ? 2.4 : 1);
      return { ...x, usd, amount: usd / x.it.price };
    }).sort((a,b) => b.usd - a.usd);
  }
  function scoreBreakdown(w){
    const rnd = F.mulberry32(F.seedOf(w.addr.slice(4, 16)));
    const around = (c, spread) => clamp(c + (rnd()-0.5) * spread);
    return [
      ['Entry timing',  around(w.score, 18)],
      ['Position sizing', around(w.score, 14)],
      ['Exit quality',  around(w.score - 4, 20)],
      ['Consistency',   clamp(w.winRate + 12)]
    ];
  }

  /* ---- whale live engine ---- */
  let tickN = 0;
  CDX.Bus.on('tick', () => {
    if (++tickN % 3 !== 0 || Math.random() > 0.65) return;
    const t = R.mkWhaleTrade();
    if (!t) return;
    R.WHALE_TRADES.unshift(t);
    if (R.WHALE_TRADES.length > 60) R.WHALE_TRADES.pop();
    CDX.Bus.emit('whale:new', t);
  });

  return { flowFor, chainStats, allChains, chainPairs, narrative, allNarratives,
           whaleTrades, wallets, wallet, walletHoldings, scoreBreakdown };
})();
