/* CDX data — live news pool built from real June 2026 market themes. */
CDX.DataRaw.NEWS_POOL = [
 {src:'The Block', tag:'c:btc',  kind:'bear', h:'Bitcoin holds near $62.6K after hotter-than-expected PPI print; traders eye this week\'s Fed meeting'},
 {src:'CoinDesk',  tag:'c:sol',  kind:'bull', h:'Eligible SpaceX shares launch tokenized on Solana, enabling 24/7 trading of pre-IPO equity'},
 {src:'Reuters',   tag:'c:btc',  kind:'neut', h:'CME Group launches crypto index futures tracking Bitcoin, Solana and XRP'},
 {src:'DL News',   tag:'c:usdt', kind:'neut', h:'Tether spearheads $1.4B funding round for Neura Robotics, extending payments push into AI hardware'},
 {src:'The Block', tag:'c:btc',  kind:'bear', h:'Spot Bitcoin ETFs log third straight day of outflows as institutions de-risk into the FOMC'},
 {src:'Bitcoin.com',tag:'c:sol', kind:'neut', h:'Japanese gaming firm Enish sells Bitcoin treasury at a loss, shifts to Solana staking'},
 {src:'CoinDex Wire',tag:'d:d-pcock-wpls', kind:'bull', h:'PulseX meme rotation: PCOCK does $1M+ volume as PulseChain degens hunt the next runner'},
 {src:'CoinDex Wire',tag:'c:hex', kind:'bear', h:'HEX slides 12% as PulseChain ecosystem retraces; PLS down 21% on the week'},
 {src:'CoinDesk',  tag:'c:doge', kind:'neut', h:'Dogecoin steadies above $0.084 as the meme sector finds a floor'},
 {src:'DL News',   tag:'c:hype', kind:'neut', h:'Hyperliquid holds #10 by market cap despite perp volume cooling from Q1 records'},
 {src:'The Block', tag:'c:btc',  kind:'neut', h:'Analysts flag $61K as the key BTC support after Sunday\'s 2026 lows'},
 {src:'Reuters',   tag:'c:xrp',  kind:'bear', h:'XRP slips under $1.12 as post-futures-launch momentum fades'},
 {src:'CoinDex Wire',tag:'d:d-brett-weth', kind:'bull', h:'Base memecoin volume jumps 18% week-over-week; BRETT and TOSHI lead the flow'},
 {src:'The Block', tag:'c:eth',  kind:'bear', h:'Layer-2 fees hit yearly lows, squeezing Ethereum validator revenue'},
 {src:'DL News',   tag:'c:usdt', kind:'bull', h:'Stablecoin float hits a record — USDT supply tops $178B as dry powder builds'},
 {src:'CoinDex Wire',tag:'d:d-honk-sol', kind:'bull', h:'New Solana pair HONK prints $2.8M volume in its first six hours'},
 {src:'Bitcoin.com',tag:'c:btc', kind:'bull', h:'US Tiger Research sets long-term Bitcoin valuation range at $227K–$378K'},
 {src:'CoinDex Wire',tag:'c:plsx', kind:'neut', h:'PulseX V2 keeps majority share of PulseChain DEX volume as V1 pools wind down'}
];
