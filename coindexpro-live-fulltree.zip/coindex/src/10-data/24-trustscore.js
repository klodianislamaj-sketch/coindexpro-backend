/* CDX.TrustScore — explainable 0–100 token trust (Priority 5).
   Built ONLY from real, available inputs. Every contributing factor is returned
   with its own sub-score and a plain-language reason, so the score is never a
   black box. Inputs without a real source are EXCLUDED (not guessed), and the
   result reports how many factors were actually available — a score derived
   from few factors is explicitly marked low-confidence.

   Real inputs used today: contract age (ageH), liquidity depth + stability,
   whale participation (observed trades), and the heuristic risk engine
   (honeypot/rug/tax — labeled heuristic). Inputs NOT available are listed as
   such: holder concentration (most chains), LP lock, dev-wallet activity,
   mint controls — these need indexer/contract readers not yet wired. */
CDX.TrustScore = (() => {
  function score(pairId){
    const p = CDX.Data.byKey('d:' + pairId);
    if (!p) return { available: false, reason: 'unknown pair' };

    const factors = [];   // { key, label, points, max, reason, available }
    const add = (key, label, points, max, reason, available = true) =>
      factors.push({ key, label, points: available ? points : null, max, reason, available });

    // 1 · contract age (real: ageH) — older = more trust, capped
    if (typeof p.ageH === 'number' && p.ageH >= 0){
      const pts = Math.min(20, Math.round(p.ageH / 720 * 20));   // ~30d → full 20
      add('age', 'Contract age', pts, 20,
        `${CDX.Fmt.age(p.ageH)} old${p.ageH < 48 ? ' — very new, higher risk' : ''}`);
    } else add('age', 'Contract age', 0, 20, 'age unavailable', false);

    // 2 · liquidity depth (real) — deeper = harder to rug/manipulate
    if (typeof p.liq === 'number' && p.liq >= 0){
      const pts = p.liq >= 1e6 ? 25 : p.liq >= 250e3 ? 18 : p.liq >= 50e3 ? 10 : p.liq >= 10e3 ? 4 : 0;
      add('liq', 'Liquidity depth', pts, 25, `${CDX.Fmt.usd(p.liq)} pooled`);
    } else add('liq', 'Liquidity depth', 0, 25, 'liquidity unavailable', false);

    // 3 · whale participation (real: observed trades on this pair)
    try {
      const raw = (CDX.WhaleFlow.raw && CDX.WhaleFlow.raw()) || [];
      const onPair = raw.filter(t => t.pairId === p.id);
      const pts = onPair.length >= 5 ? 15 : onPair.length >= 1 ? 8 : 0;
      add('whales', 'Whale participation', pts, 15,
        onPair.length ? `${onPair.length} large trades observed` : 'no large trades observed yet');
    } catch(e){ add('whales', 'Whale participation', 0, 15, 'trade buffer unavailable', false); }

    // 4 · heuristic risk engine (real, labeled heuristic) — inverse of risk
    try {
      if (CDX.Risk && typeof CDX.Risk.quick === 'function'){
        const r = CDX.Risk.quick(p);
        if (r && typeof r.safety === 'number'){
          const pts = Math.round(r.safety / 100 * 25);
          add('risk', 'Risk heuristics', pts, 25,
            `safety ${r.safety}/100 (heuristic: honeypot/rug/tax signals)`);
        } else add('risk', 'Risk heuristics', 0, 25, 'risk engine returned no score', false);
      } else add('risk', 'Risk heuristics', 0, 25, 'risk engine unavailable', false);
    } catch(e){ add('risk', 'Risk heuristics', 0, 25, 'risk engine error', false); }

    // 5 · liquidity stability (real if we have a liquidity engine series)
    try {
      if (CDX.Liq && typeof CDX.Liq.seriesFor === 'function'){
        const series = CDX.Liq.seriesFor(p.id);
        if (series && series.length >= 2){
          const first = series[0].liq, last = series[series.length - 1].liq;
          const drop = first > 0 ? (first - last) / first : 0;
          const pts = drop > 0.5 ? 0 : drop > 0.2 ? 5 : 10;
          add('stability', 'Liquidity stability', pts, 10,
            drop > 0.2 ? `liquidity fell ${(drop*100).toFixed(0)}% in session` : 'liquidity stable in session');
        } else add('stability', 'Liquidity stability', 0, 10, 'insufficient snapshots yet', false);
      } else add('stability', 'Liquidity stability', 0, 10, 'liquidity engine unavailable', false);
    } catch(e){ add('stability', 'Liquidity stability', 0, 10, 'stability check error', false); }

    // factors with NO real source — listed as unavailable, never scored
    add('holders', 'Holder concentration', 0, 0, 'holder snapshot not available for this chain', false);
    add('lplock', 'LP lock', 0, 0, 'lock-contract reader not wired', false);
    add('devwallet', 'Dev wallet activity', 0, 0, 'dev-wallet labeling not available', false);
    add('mint', 'Mint controls', 0, 0, 'mint-authority reader not wired', false);

    const scored = factors.filter(f => f.available && f.max > 0);
    const earned = scored.reduce((a, f) => a + (f.points || 0), 0);
    const possible = scored.reduce((a, f) => a + f.max, 0);
    const trust = possible > 0 ? Math.round(earned / possible * 100) : null;
    const coverage = scored.length;   // how many real factors contributed

    return {
      available: trust != null,
      trust,                          // 0–100 or null
      confidence: coverage >= 4 ? 'high' : coverage >= 2 ? 'medium' : 'low',
      factorsAvailable: coverage,
      factorsTotal: factors.filter(f => f.max > 0).length,
      factors,                        // full explainable breakdown
      heuristic: true,
      note: 'Trust is derived only from available real signals; missing factors are excluded, not assumed.'
    };
  }

  return { score };
})();
