/* CDX.SmartMoney — OBSERVABLE-ONLY market intelligence (Phase 9).
   Every number here is DERIVED from CDX.WhaleFlow.raw() — the buffer of real
   on-chain swaps (wallet, tx, side, usd, ts, chain, pair). Nothing is
   estimated, modeled, or fabricated. Explicitly NOT computed: win rate, PnL,
   net worth, or anything requiring full wallet history we do not have.

   Hard honesty boundary: this only "sees" trades large enough to enter the
   whale buffer, over the session window. It is a lens on observed activity,
   not a complete account of any wallet — surfaced as such in the UI. */
CDX.SmartMoney = (() => {
  const sectorsOf = pairId => {
    const p = CDX.Data.byKey('d:' + pairId);
    return (p && p.tags) ? p.tags : [];
  };

  /* ---- 9.1 · per-wallet observed behavior ---- */
  function wallets(opts){
    const o = opts || {};
    const raw = (CDX.WhaleFlow.raw && CDX.WhaleFlow.raw()) || [];
    const byWallet = new Map();
    for (const t of raw){
      if (!t.wallet) continue;
      const w = t.wallet.toLowerCase();
      let m = byWallet.get(w);
      if (!m) byWallet.set(w, m = { wallet: t.wallet, trades: 0, buys: 0, sells: 0,
        grossUsd: 0, chains: new Set(), sectors: new Set(), tokens: new Map(),
        firstSeen: t.ts, lastSeen: t.ts });
      m.trades++; t.side === 'buy' ? m.buys++ : m.sells++;
      m.grossUsd += t.usd;
      if (t.chain) m.chains.add(t.chain);
      for (const s of sectorsOf(t.pairId)) m.sectors.add(s);
      m.tokens.set(t.base, (m.tokens.get(t.base) || 0) + 1);
      m.firstSeen = Math.min(m.firstSeen, t.ts);
      m.lastSeen = Math.max(m.lastSeen, t.ts);
    }
    const rows = [...byWallet.values()].map(m => {
      // repeated entries/exits = tokens this wallet bought/sold more than once
      const repeatTokens = [...m.tokens.values()].filter(n => n >= 2).length;
      // conviction (observed): repeated buys drive it; capped, transparent formula
      const conviction = Math.min(100, m.buys * 6 + repeatTokens * 10 +
        (m.chains.size - 1) * 4 + Math.min(20, Math.log10(m.grossUsd + 1) * 4));
      return {
        wallet: m.wallet, trades: m.trades, buys: m.buys, sells: m.sells,
        avgTradeUsd: m.trades ? m.grossUsd / m.trades : 0,
        grossUsd: m.grossUsd,
        chains: [...m.chains], sectors: [...m.sectors],
        repeatTokens, conviction: Math.round(conviction),
        firstSeen: m.firstSeen, lastSeen: m.lastSeen,
        observedOnly: true
      };
    });
    rows.sort((a, b) => b.conviction - a.conviction);
    const min = o.minTrades || 2;
    return rows.filter(r => r.trades >= min).slice(0, o.limit || 50);
  }

  /* ---- 9.2 · whale clusters from real co-trading overlap ---- */
  function clusters(opts){
    const o = opts || {};
    const raw = (CDX.WhaleFlow.raw && CDX.WhaleFlow.raw()) || [];
    // group buys/sells by token, find wallets that act together on the same token
    const byToken = new Map();
    for (const t of raw){
      if (!t.wallet) continue;
      let g = byToken.get(t.base);
      if (!g) byToken.set(t.base, g = { buyers: new Set(), sellers: new Set() });
      (t.side === 'buy' ? g.buyers : g.sellers).add(t.wallet.toLowerCase());
    }
    // build pairwise co-occurrence across tokens (real overlap only)
    const pairCount = new Map();   // "a|b" → shared token count
    const walletTokens = new Map();
    for (const t of raw){ if (!t.wallet) continue; const w = t.wallet.toLowerCase();
      if (!walletTokens.has(w)) walletTokens.set(w, new Set()); walletTokens.get(w).add(t.base); }
    const ws = [...walletTokens.keys()];
    for (let i = 0; i < ws.length; i++){
      for (let j = i + 1; j < ws.length; j++){
        const a = walletTokens.get(ws[i]), b = walletTokens.get(ws[j]);
        let shared = 0; for (const tk of a) if (b.has(tk)) shared++;
        if (shared >= 2) pairCount.set(ws[i] + '|' + ws[j], shared);
      }
    }
    const rows = [...pairCount.entries()].map(([k, shared]) => {
      const [a, b] = k.split('|');
      return { wallets: [a, b], sharedTokens: shared,
               strength: Math.min(100, shared * 18), observedOnly: true };
    }).sort((x, y) => y.sharedTokens - x.sharedTokens);
    return rows.slice(0, o.limit || 30);
  }

  /* ---- 9.3 · sector flow from token classification + real trade flow ---- */
  function sectors(){
    const raw = (CDX.WhaleFlow.raw && CDX.WhaleFlow.raw()) || [];
    const bySector = new Map();
    for (const t of raw){
      for (const s of sectorsOf(t.pairId)){
        let m = bySector.get(s);
        if (!m) bySector.set(s, m = { sector: s, inflow: 0, outflow: 0, volume: 0, trades: 0 });
        t.side === 'buy' ? m.inflow += t.usd : m.outflow += t.usd;
        m.volume += t.usd; m.trades++;
      }
    }
    return [...bySector.values()].map(m => ({ ...m, net: m.inflow - m.outflow }))
      .sort((a, b) => b.volume - a.volume);
  }

  return { wallets, clusters, sectors, observable: true };
})();
