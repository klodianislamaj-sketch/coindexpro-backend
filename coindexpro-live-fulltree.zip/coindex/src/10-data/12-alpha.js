/* CDX.Alpha — alpha discovery engine.
   Derives detection signals and Alpha / Conviction / Risk scores from the live
   universe: pair telemetry, whale prints, smart-money registry, holder snapshots,
   liquidity baselines, news velocity, narrative/chain flows. No synthetic inputs. */
CDX.Alpha = (() => {
  const R = () => CDX.DataRaw;
  const now = () => Date.now();
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const HOUR = 36e5;

  /* ---- telemetry: liquidity baselines + holder/price/tx history (sampled) ---- */
  const base = new Map();      // pairId → { liq0, ts0 }
  const firstSeen = new Map(); // pairId → session detection ts (earlier-than-age detection)
  const samples = new Map();
  CDX.Bus.on('pairs:pruned', kept => {
    for (const id of samples.keys()) if (!kept.has(id)) samples.delete(id);
  });   // pairId → [{ ts, liq, vol, holders }]
  let lastSample = 0;
  function snapshot(){
    for (const p of CDX.Data.pairs){
      if (!base.has(p.id)){ base.set(p.id, { liq0: p.liq, ts0: now() }); firstSeen.set(p.id, now()); }
      let arr = samples.get(p.id);
      if (!arr) samples.set(p.id, arr = []);
      arr.push({ ts: now(), liq: p.liq, vol: p.vol, holders: p.holders ?? null,
                 price: p.price, tx: p.buys + p.sells, buys: p.buys, sells: p.sells });
      if (arr.length > 60) arr.shift();
    }
  }
  CDX.Bus.on('data:ready', snapshot);
  CDX.Bus.on('tick', () => { if (now() - lastSample > 20000){ lastSample = now(); snapshot(); } });

  /* ---- 1/2 · early pairs + fresh liquidity ---- */
  const isEarly = p => p.ageH <= 24 * 7 && p.liq > 12e3;
  function liqGrowth(p){
    const b = base.get(p.id);
    const arr = samples.get(p.id) || [];
    const old = arr.find(s => now() - s.ts > 30 * 60e3) || arr[0];
    const ref = Math.min(b ? b.liq0 : p.liq, old ? old.liq : p.liq) || p.liq;
    return ref > 0 ? (p.liq - ref) / ref * 100 : 0;
  }
  /* ---- 3/4 · smart money entries + wallet clusters (whale print window) ---- */
  function whaleWindow(hours){
    const cut = now() - (hours || 6) * HOUR;
    return R().WHALE_TRADES.filter(t => t.ts >= cut);
  }
  const smartQ = new Map();   // addr → { ts, w } (observed-performance qualification, 5-min memo)
  const smartWallet = addr => {
    if (!addr || addr === 'cexflow-binance-spot') return 0;
    let q = smartQ.get(addr);
    if (!q || now() - q.ts > 300e3){
      const reg = R().walletByAddr.get(addr);
      let w = reg && (reg.type === 'Smart Money' || reg.score >= 72) ? 1 : 0;
      const m = CDX.WalletIntel.mirror(addr);
      const a = m && m.n >= 2 ? CDX.WalletIntel.analyze(addr) : null;
      if (m && m.n >= 2 && m.ret > 4) w = Math.max(w, 1.5);                       // proven entries
      if (a && a.winRate != null && a.winRate >= 60 && a.trades >= 4) w = Math.max(w, 1.3);
      smartQ.set(addr, q = { ts: now(), w });
    }
    return q.w;
  };
  function pairFlows(hours){
    const m = new Map();   // pairId → { buyUsd, sellUsd, buyers:Set, sellers:Set, smartBuyUsd, smartBuyers:Set, lastTs }
    for (const t of whaleWindow(hours)){
      let e = m.get(t.pairId);
      if (!e) m.set(t.pairId, e = { buyUsd: 0, sellUsd: 0, buyers: new Set(), sellers: new Set(),
                                    smartBuyUsd: 0, smartBuyers: new Set(), lastTs: 0 });
      const rec = Math.exp(-(now() - t.ts) / (3 * HOUR));                       // recency weighting
      if (t.side === 'buy'){
        e.buyUsd += t.usd; e.buyers.add(t.wallet);
        const q = smartWallet(t.wallet);
        if (q){ e.smartBuyUsd += t.usd * q * (0.5 + rec); e.smartBuyers.add(t.wallet); }
      } else { e.sellUsd += t.usd; e.sellers.add(t.wallet); }
      e.lastTs = Math.max(e.lastTs, t.ts);
    }
    return m;
  }
  /* ---- buy pressure model: live tx-delta imbalance > cumulative ratios ---- */
  function txDeltas(p, ms){
    const arr = samples.get(p.id) || [];
    if (arr.length < 2) return null;
    const old = arr.find(s => now() - s.ts <= (ms || 30 * 60e3)) || arr[0];
    const last = arr[arr.length - 1];
    const db = Math.max(0, last.buys - old.buys), ds = Math.max(0, last.sells - old.sells);
    const mins = Math.max(0.5, (last.ts - old.ts) / 60e3);
    return { db, ds, perMin: (db + ds) / mins, mins };
  }
  function buyPressure(p, flow){
    const d = txDeltas(p);
    const m = p.flowMeasured;
    const fresh = m && m.ts && now() - m.ts < 12 * 60e3;
    const measured = m && m.buyVol + m.sellVol > 0 ? m.buyVol / (m.buyVol + m.sellVol) : null;
    const tx = p.buys + p.sells;
    const cumulative = tx ? p.buys / tx : 0.5;
    const live = d && d.db + d.ds >= 4 ? d.db / (d.db + d.ds) : null;
    const whaleNet = flow ? (flow.buyUsd - flow.sellUsd) / Math.max(flow.buyUsd + flow.sellUsd, 1) : 0;
    const share = live != null ? live * 0.5 + (measured != null ? measured : cumulative) * (fresh ? 0.35 : 0.25) + cumulative * (live != null ? 0.15 : 0.25)
                : measured != null ? measured * (fresh ? 0.65 : 0.5) + cumulative * (fresh ? 0.35 : 0.5)
                : cumulative;
    return clamp(share * 70 + whaleNet * 18 + (d ? Math.min(d.perMin, 8) * 1.5 : 0), 0, 100);
  }
  /* ---- contract freshness: exponential decay + session-detection bonus ---- */
  function freshScore(p){
    const ageDecay = Math.exp(-p.ageH / 96) * 80;                                 // ≤4d sweet spot
    const fs = firstSeen.get(p.id);
    const sessionNew = fs && now() - fs < 45 * 60e3 && p.ageH <= 48 ? 20 : 0;     // surfaced this session
    return clamp(ageDecay + sessionNew, 0, 100);
  }
  /* ---- liquidity lock scoring: deep on-chain evidence when available, stability proxy otherwise ---- */
  const lockInfo = new Map();   // pairId → { ts, score, label }
  async function enrichLocks(){
    const pulse = CDX.Data.pairs.filter(p => p.chain === 'pulsechain' && p.liq > 8e3 && p.ageH <= 24 * 14)
      .sort((a, b) => b.vol - a.vol).slice(0, 3);
    for (const p of pulse){
      const cur = lockInfo.get(p.id);
      if (cur && now() - cur.ts < 15 * 60e3) continue;
      try {
        const r = await CDX.Risk.deepAnalyze(p);
        const lp = r.vectors.find(v => v.id === 'lp');
        const score = lp ? (lp.burned ? 100 : lp.level === 'low' ? 70 : lp.level === 'med' ? 35 : lp.level === 'high' ? 8 : 40) : 40;
        lockInfo.set(p.id, { ts: now(), score, label: lp ? lp.detail : 'unknown', deep: true });
      } catch(e){}
    }
  }
  CDX.Bus.on('data:ready', () => CDX.Net.Conn.poller('alpha:locks', enrichLocks, 60000, { immediate: true }).start());
  function lockScore(p){
    const li = lockInfo.get(p.id);
    if (li) return li.score;
    const st = CDX.Liq.stability(p);                                              // proxy: retention + calm + age
    return clamp(st.parts.retention / 15 * 40 + st.parts.calm / 10 * 25 + st.parts.age / 10 * 20 + (p.liq > 100e3 ? 15 : 0), 0, 100);
  }
  /* ---- wallet cluster scoring: co-trading clusters touching this pool ---- */
  let clusterCache = { ts: 0, cs: [] };
  function clusterScore(p){
    if (now() - clusterCache.ts > 60e3) clusterCache = { ts: now(), cs: CDX.WalletIntel.clusters(2) };
    let score = 0;
    for (const c of clusterCache.cs){
      if (!c.pairs.includes(p.id)) continue;
      score += c.wallets.length * 14 * (c.net >= 0 ? 1 : 0.35);
    }
    return clamp(score, 0, 100);
  }
  /* ---- momentum acceleration: short-window return + second derivative + tx accel ---- */
  function accel(p){
    const arr = samples.get(p.id) || [];
    if (arr.length < 4) return { score: 0, dPct: 0 };
    const at = ms => arr.find(s => now() - s.ts <= ms) || arr[0];
    const last = arr[arr.length - 1];
    const r = (a, b) => a && b && b.price > 0 ? (a.price / b.price - 1) * 100 : 0;
    const r10 = r(last, at(10 * 60e3));
    const r20 = r(at(10 * 60e3), at(20 * 60e3));
    const d = txDeltas(p, 10 * 60e3), dPrev = txDeltas(p, 20 * 60e3);
    const txAccel = d && dPrev && dPrev.perMin > 0 ? d.perMin / dPrev.perMin : 1;
    return { score: clamp(50 + (r10 - r20) * 7 + r10 * 3 + (txAccel - 1) * 14, 0, 100), dPct: r10 - r20 };
  }
  /* ---- 5 · social/news velocity ---- */
  function socialVelocity(key){
    const items = CDX.News.all().filter(n => n.tag === key);
    const recent = items.filter(n => now() - n.ts < 2 * HOUR);
    const bull = recent.filter(n => n.kind === 'bull').length;
    return recent.length * 2 + bull;
  }
  /* ---- 6 · holder growth ---- */
  function holderGrowth(p){
    const arr = (samples.get(p.id) || []).filter(s => s.holders != null);
    if (arr.length < 2 || p.holders == null) return null;
    const first = arr[0], last = arr[arr.length - 1];
    const dh = (last.ts - first.ts) / HOUR;
    if (dh < 0.05 || !first.holders) return null;
    const delta = last.holders - first.holders;
    return { delta, perHr: delta / dh, pct: delta / first.holders * 100 };
  }
  /* ---- 7 · contract deployment tracking ---- */
  function deployments(){
    return CDX.Data.CHAIN_ORDER.map(id => {
      const s = CDX.Intel.chainStats(id);
      const fresh = CDX.Data.pairs.filter(p => p.chain === id && p.ageH <= 24);
      return { id, chain: s.chain, newTokens: s.newTokens, freshPairs: fresh.length,
               freshLiq: fresh.reduce((a, p) => a + p.liq, 0) };
    }).sort((a, b) => b.newTokens - a.newTokens);
  }
  /* ---- 8 · trending momentum engine ---- */
  function momentum(p){
    const raw = (p.ch.m5 || 0) * 3 + (p.ch.h1 || 0) * 1.5 + (p.ch.h6 || 0) * 0.5;
    const confirm = clamp(Math.sqrt(p.vol / Math.max(p.liq, 1)), 0.4, 2);
    const a = accel(p);
    return clamp((50 + raw * confirm) * 0.72 + a.score * 0.28, 0, 100);
  }
  /* ---- 9 · viral detection ---- */
  function viralScore(p){
    if (p.ageH > 24 * 21 || p.liq < 20e3) return 0;
    const turnover = p.vol / Math.max(p.liq, 1);
    const tx = p.buys + p.sells;
    const buyDom = tx ? p.buys / tx : 0.5;
    return clamp(turnover * 13 + Math.log10(tx + 1) * 9 + buyDom * 26 + socialVelocity('d:' + p.id) * 4, 0, 100);
  }
  /* ---- 10 · rotation detection ---- */
  function rotation(){
    const ns = [...CDX.Intel.allNarratives()].sort((a, b) => b.flow.netFlow - a.flow.netFlow);
    const cs = [...CDX.Intel.allChains()].sort((a, b) => b.flow.netFlow - a.flow.netFlow);
    return { inN: ns[0], outN: ns[ns.length - 1], inC: cs[0], outC: cs[cs.length - 1] };
  }

  /* ---- scores ---- */
  function scoresFor(p, flows){
    const f = (flows || pairFlows(6)).get ? (flows || pairFlows(6)).get(p.id) : null;
    const e = f || { buyUsd: 0, sellUsd: 0, buyers: new Set(), sellers: new Set(), smartBuyUsd: 0, smartBuyers: new Set() };
    const turnover = p.vol / Math.max(p.liq, 1);
    const tx = p.buys + p.sells;
    const buyDom = tx ? p.buys / tx : 0.5;
    const hg = holderGrowth(p);
    const social = socialVelocity('d:' + p.id);
    const mom = momentum(p);
    const m = p.flowMeasured;
    const mRatio = m && m.buyVol + m.sellVol > 0 ? m.buyVol / (m.buyVol + m.sellVol) : null;

    const earliness = freshScore(p);
    const traction = clamp(turnover * 25, 0, 100);
    const smart = clamp(e.smartBuyers.size * 24 + e.smartBuyUsd / 5e3, 0, 100);
    const cluster = clamp((e.buyers.size - e.sellers.size) * 12 + clusterScore(p) * 0.5, 0, 100);
    const pressure = buyPressure(p, e);
    const lock = lockScore(p);
    const spanH = (() => { const arr = (samples.get(p.id) || []).filter(s2 => s2.holders != null);
      return arr.length > 1 ? (arr[arr.length - 1].ts - arr[0].ts) / HOUR : 0; })();
    const conf = clamp(spanH / 0.5, 0.25, 1);                                     // ≥30min span = full confidence
    const holders = hg ? clamp((Math.log10(Math.abs(hg.perHr) + 1) * 34 * Math.sign(hg.perHr) + hg.pct * 6) * conf, 0, 100) : 0;
    const soc = clamp(social * 18, 0, 100);
    const alpha = clamp(
      earliness * 0.16 + traction * 0.16 + mom * 0.16 + smart * 0.15 + pressure * 0.12
      + cluster * 0.09 + holders * 0.09 + lock * 0.04 + soc * 0.03, 0, 100);

    const conviction = clamp(
      Math.log10(Math.max(p.liq, 10)) * 8
      + pressure * 0.3
      + (mRatio != null ? (mRatio - 0.5) * 24 : 0)
      + e.smartBuyers.size * 8
      + lock * 0.12
      + (p.holders > 1000 ? 9 : p.holders > 200 ? 4 : 0)
      + (Math.sign(p.ch.h1) === Math.sign(p.ch.h24) && p.ch.h24 !== 0 ? 7 : 0), 0, 100);

    const risk = clamp(
      (p.liq < 50e3 ? 26 : p.liq < 250e3 ? 13 : 0)
      + (p.ageH < 24 ? 22 : p.ageH < 72 ? 11 : 0)
      + clamp(turnover * 3.2, 0, 22)
      + (p.fdv / Math.max(p.liq, 1) > 80 ? 15 : p.fdv / Math.max(p.liq, 1) > 30 ? 8 : 0)
      + clamp(Math.abs(p.ch.m5 || 0), 0, 10)
      + (p.holders == null ? 5 : p.holders < 200 ? 9 : 0), 0, 100);

    return { alpha: Math.round(alpha), conviction: Math.round(conviction), risk: Math.round(risk),
             momentum: Math.round(mom),
             parts: { earliness, traction, momentum: mom, smart, cluster, holders, social: soc, pressure, lock },
             flow: e, turnover, buyDom, hg, social, viral: viralScore(p) };
  }
  function ranked(filter, sorter, n){
    const flows = pairFlows(6);
    return CDX.Data.pairs
      .map(p => ({ p, s: scoresFor(p, flows) }))
      .filter(filter)
      .sort(sorter)
      .slice(0, n || 8);
  }
  /* ---- display feeds ---- */
  const gemRank = x => x.s.alpha * 0.62 + x.s.conviction * 0.24 + (100 - x.s.risk) * 0.14;
  const earlyGems = n => ranked(x => isEarly(x.p) && x.s.alpha >= 28,
    (a, b) => gemRank(b) - gemRank(a), n);
  const freshLiquidity = n => CDX.Data.pairs
    .map(p => ({ p, growth: liqGrowth(p) }))
    .filter(x => x.growth > 8 && x.p.liq > 15e3)
    .sort((a, b) => b.growth - a.growth).slice(0, n || 6);
  const smartMoney = n => ranked(x => x.s.flow.smartBuyers.size > 0,
    (a, b) => (b.s.flow.smartBuyUsd * (1 + b.s.flow.smartBuyers.size * 0.25))
            - (a.s.flow.smartBuyUsd * (1 + a.s.flow.smartBuyers.size * 0.25)), n);
  const whaleAccumulation = n => ranked(x => x.s.flow.buyUsd + x.s.flow.sellUsd > 0,
    (a, b) => (b.s.flow.buyUsd - b.s.flow.sellUsd) - (a.s.flow.buyUsd - a.s.flow.sellUsd), n);
  const viralTokens = n => ranked(x => x.s.viral >= 35,
    (a, b) => b.s.viral - a.s.viral, n);
  const freshLaunches = n => ranked(x => x.p.ageH <= 96,
    (a, b) => a.p.ageH - b.p.ageH, n || 10);
  const holderMovers = n => CDX.Data.pairs
    .map(p => ({ p, hg: holderGrowth(p) }))
    .filter(x => x.hg && x.hg.delta !== 0)
    .sort((a, b) => b.hg.perHr - a.hg.perHr).slice(0, n || 6);

  return { scoresFor, momentum, viralScore, socialVelocity, holderGrowth, liqGrowth, rotation, deployments,
           buyPressure, lockScore, clusterScore, accel, freshScore,
           earlyGems, freshLiquidity, smartMoney, whaleAccumulation, viralTokens, freshLaunches, holderMovers };
})();
