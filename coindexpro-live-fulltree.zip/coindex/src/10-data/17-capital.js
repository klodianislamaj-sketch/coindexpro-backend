/* CDX.Capital — capital flow engine.
   Stablecoin flows: live USDT/USDC market-cap & supply deltas (issuance proxy) plus
   stable-quoted pair flow split by measured prints or txn ratio. Exchange flows: real
   Binance spot taker prints from the live ledger. Chain/sector rotation: volume-flow,
   liquidity-event flow and session acceleration. Whale rotation: window-vs-window
   deployment shares + wallet path transitions. All inputs are live telemetry. */
CDX.Capital = (() => {
  const R = () => CDX.DataRaw;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const HOUR = 36e5;
  const STABLES = new Set(['USDT', 'USDC', 'DAI', 'PDAI', 'USDC.E', 'USDL', 'FUSD']);
  const CEX = 'cexflow-binance-spot';
  const series = { stable: [], narr: new Map(), chain: new Map() };   // session snapshots
  let lastSnap = 0;

  function snapshot(){
    const u = CDX.Data.byKey('c:usdt'), c = CDX.Data.byKey('c:usdc');
    if (u && c) series.stable.push({ ts: Date.now(), mcap: u.mcap + c.mcap, supply: (u.supply || 0) + (c.supply || 0) });
    if (series.stable.length > 180) series.stable.shift();
    for (const n of CDX.Intel.allNarratives()){
      let arr = series.narr.get(n.id);
      if (!arr) series.narr.set(n.id, arr = []);
      arr.push({ ts: Date.now(), net: n.flow.netFlow });
      if (arr.length > 180) arr.shift();
    }
    for (const s of CDX.Intel.allChains()){
      let arr = series.chain.get(s.id);
      if (!arr) series.chain.set(s.id, arr = []);
      arr.push({ ts: Date.now(), net: s.flow.netFlow });
      if (arr.length > 180) arr.shift();
    }
  }
  CDX.Bus.on('data:ready', snapshot);
  CDX.Bus.on('tick', () => { if (Date.now() - lastSnap > 60000){ lastSnap = Date.now(); snapshot(); } });
  const accelOf = (arr, ms) => {
    if (!arr || arr.length < 2) return 0;
    const old = arr.find(s => Date.now() - s.ts <= ms) || arr[0];
    return arr[arr.length - 1].net - old.net;
  };

  /* ---- stablecoin in/outflows ---- */
  function stableFlow(){
    const u = CDX.Data.byKey('c:usdt'), c = CDX.Data.byKey('c:usdc');
    const arr = series.stable;
    const old = arr.find(s => Date.now() - s.ts <= HOUR) || arr[0];
    const now = arr[arr.length - 1];
    const issuance = old && now ? now.mcap - old.mcap : 0;
    const issuancePct = old && old.mcap ? issuance / old.mcap * 100 : 0;
    /* stable-quoted pairs: buys = stables → risk (outflow from stables) */
    const byChain = new Map();
    let inflow = 0, outflow = 0;
    for (const p of CDX.Data.pairs){
      if (!STABLES.has((p.quote || '').toUpperCase())) continue;
      const m = p.flowMeasured;
      const r = m && m.buyVol + m.sellVol > 0 ? m.buyVol / (m.buyVol + m.sellVol)
              : (p.buys + p.sells ? p.buys / (p.buys + p.sells) : 0.5);
      const toRisk = p.vol * r, toStable = p.vol * (1 - r);
      outflow += toRisk; inflow += toStable;
      let e = byChain.get(p.chain);
      if (!e) byChain.set(p.chain, e = { chain: p.chain, toRisk: 0, toStable: 0, pairs: 0 });
      e.toRisk += toRisk; e.toStable += toStable; e.pairs++;
    }
    return { coins: [u, c].filter(Boolean), issuance, issuancePct,
             toRisk: outflow, toStable: inflow, net: outflow - inflow,
             byChain: [...byChain.values()].sort((a, b) => (b.toRisk + b.toStable) - (a.toRisk + a.toStable)) };
  }
  /* ---- exchange taker flow (real Binance spot prints ≥$250K) ---- */
  function exchangeFlow(hours){
    const cut = Date.now() - (hours || 6) * HOUR;
    let buy = 0, sell = 0, prints = 0, biggest = null;
    const recent = [];
    for (const t of R().WHALE_TRADES){
      if (t.wallet !== CEX || t.ts < cut) continue;
      prints++;
      t.side === 'buy' ? buy += t.usd : sell += t.usd;
      if (!biggest || t.usd > biggest.usd) biggest = t;
      if (recent.length < 8) recent.push(t);
    }
    return { buy, sell, net: buy - sell, prints, biggest, recent };
  }
  /* ---- chain rotation: volume flow + liquidity-event flow + acceleration ---- */
  function chainRotation(){
    const liq = new Map(CDX.Liq.chainFlow().map(r => [r.id, r]));
    const rows = CDX.Intel.allChains().map(s => {
      const lf = liq.get(s.id) || { net: 0, add: 0, remove: 0 };
      const accel = accelOf(series.chain.get(s.id), 30 * 60e3);
      return { id: s.id, chain: s.chain, volNet: s.flow.netFlow, liqNet: lf.net,
               accel, momentum: s.flow.momentum,
               composite: s.flow.netFlow + lf.net * 3 + accel * 2 };
    }).sort((a, b) => b.composite - a.composite);
    return { rows, into: rows[0], outOf: rows[rows.length - 1] };
  }
  /* ---- sector rotation with phase classification ---- */
  function sectorRotation(){
    return CDX.Intel.allNarratives().map(n => {
      const accel = accelOf(series.narr.get(n.id), 30 * 60e3);
      const phase = n.flow.netFlow >= 0
        ? (accel >= 0 ? 'inflow accelerating' : 'inflow cooling')
        : (accel <= 0 ? 'outflow accelerating' : 'outflow slowing');
      return { ...n, accel, phase };
    }).sort((a, b) => b.flow.netFlow - a.flow.netFlow);
  }
  /* ---- whale rotation: deployment share shift + path transitions ---- */
  function whaleRotation(){
    const nowW = { cut: Date.now() - 3 * HOUR, narr: new Map(), chain: new Map(), total: 0 };
    const prevW = { lo: Date.now() - 6 * HOUR, hi: Date.now() - 3 * HOUR, narr: new Map(), chain: new Map(), total: 0 };
    for (const t of R().WHALE_TRADES){
      if (t.side !== 'buy') continue;
      const p = CDX.Data.byKey('d:' + t.pairId);
      if (!p) continue;
      const tag = (p.tags || [])[0] || 'other';
      const b = t.ts >= nowW.cut ? nowW : (t.ts >= prevW.lo && t.ts < prevW.hi ? prevW : null);
      if (!b) continue;
      b.narr.set(tag, (b.narr.get(tag) || 0) + t.usd);
      b.chain.set(p.chain, (b.chain.get(p.chain) || 0) + t.usd);
      b.total += t.usd;
    }
    const shift = (cur, prev, total, ptotal) => {
      const keys = new Set([...cur.keys(), ...prev.keys()]);
      return [...keys].map(k => {
        const nowPct = total ? (cur.get(k) || 0) / total * 100 : 0;
        const prevPct = ptotal ? (prev.get(k) || 0) / ptotal * 100 : 0;
        return { k, nowPct, prevPct, d: nowPct - prevPct, usd: cur.get(k) || 0 };
      }).sort((a, b) => b.d - a.d);
    };
    /* wallet path transitions → narrative edges */
    const edges = new Map();
    const byWallet = new Map();
    for (const t of [...R().WHALE_TRADES].sort((a, b) => a.ts - b.ts)){
      if (!t.wallet || t.wallet === CEX) continue;
      const p = CDX.Data.byKey('d:' + t.pairId);
      if (!p) continue;
      const tag = (p.tags || [])[0] || 'other';
      const last = byWallet.get(t.wallet);
      if (last && last !== tag){
        const key = last + '→' + tag;
        if (!edges.has(key)) edges.set(key, { from: last, to: tag, wallets: new Set() });
        edges.get(key).wallets.add(t.wallet);
      }
      byWallet.set(t.wallet, tag);
    }
    return { narr: shift(nowW.narr, prevW.narr, nowW.total, prevW.total),
             chain: shift(nowW.chain, prevW.chain, nowW.total, prevW.total),
             nowTotal: nowW.total, prevTotal: prevW.total,
             edges: [...edges.values()].sort((a, b) => b.wallets.size - a.wallets.size).slice(0, 5) };
  }
  /* ---- capital bias: risk-on composite ---- */
  function bias(){
    const sf = stableFlow();
    const ex = exchangeFlow(6);
    const cut = Date.now() - 6 * HOUR;
    let wb = 0, ws = 0;
    for (const t of R().WHALE_TRADES){
      if (t.ts < cut || t.wallet === CEX) continue;
      t.side === 'buy' ? wb += t.usd : ws += t.usd;
    }
    const ratio = (a, b) => a + b > 0 ? (a - b) / (a + b) : 0;
    const parts = {
      issuance: clamp(sf.issuancePct * 35, -20, 20),
      stablePairs: ratio(sf.toRisk, sf.toStable) * 30,
      exchange: ratio(ex.buy, ex.sell) * 30,
      whales: ratio(wb, ws) * 20
    };
    const score = clamp(parts.issuance + parts.stablePairs + parts.exchange + parts.whales, -100, 100);
    return { score, riskOn: Math.round(50 + score / 2), parts,
             label: score > 25 ? 'Risk-On' : score > 8 ? 'Leaning Risk-On' : score > -8 ? 'Balanced' : score > -25 ? 'Leaning Risk-Off' : 'Risk-Off' };
  }
  return { stableFlow, exchangeFlow, chainRotation, sectorRotation, whaleRotation, bias };
})();
