/* CDX.Quant — institutional analytics engine.
   Series math runs on real CoinGecko 7d hourly sparklines (returns, vol, Sharpe,
   beta, correlation, drawdowns, VaR) and real OHLC candles power the strategy
   backtester (SMA cross, RSI reversion, breakout vs buy & hold, fees included).
   Portfolio analytics are value-weighted over live holdings. */
CDX.Quant = (() => {
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const ANN_H = Math.sqrt(24 * 365);
  const retsOf = c => {
    const s = c && c.spark7d;
    if (!s || s.length < 20) return null;
    const r = [];
    for (let i = 1; i < s.length; i++) if (s[i - 1] > 0) r.push(s[i] / s[i - 1] - 1);
    return r;
  };
  const tail = (arr, n) => arr.slice(arr.length - n);
  const mean = a => a.reduce((x, y) => x + y, 0) / a.length;
  const std = a => { const m = mean(a); return Math.sqrt(a.reduce((x, v) => x + (v - m) ** 2, 0) / a.length); };
  function align(list){
    const rs = list.map(retsOf);
    if (rs.some(r => !r)) return null;
    const n = Math.min(...rs.map(r => r.length));
    return rs.map(r => tail(r, n));
  }
  const corr = (a, b) => {
    const ma = mean(a), mb = mean(b);
    let num = 0, da = 0, db = 0;
    for (let i = 0; i < a.length; i++){ num += (a[i] - ma) * (b[i] - mb); da += (a[i] - ma) ** 2; db += (b[i] - mb) ** 2; }
    return da && db ? num / Math.sqrt(da * db) : 0;
  };
  const betaOf = (a, b) => { const mb = mean(b);
    let cov = 0, varB = 0;
    for (let i = 0; i < a.length; i++){ cov += (a[i] - mean(a)) * (b[i] - mb); varB += (b[i] - mb) ** 2; }
    return varB ? cov / varB : 0;
  };
  function ddOf(rets){
    let eq = 1, peak = 1, maxDD = 0, cur = 0, underBars = 0, longest = 0;
    const curve = [1];
    for (const r of rets){
      eq *= 1 + r;
      curve.push(eq);
      if (eq > peak){ peak = eq; underBars = 0; }
      else { underBars++; longest = Math.max(longest, underBars); }
      const dd = (peak - eq) / peak;
      maxDD = Math.max(maxDD, dd);
      cur = dd;
    }
    return { maxDD: maxDD * 100, currentDD: cur * 100, underHours: longest, curve };
  }
  function seriesStats(rets){
    if (!rets || rets.length < 10) return null;
    const m = mean(rets), s = std(rets);
    const sorted = [...rets].sort((a, b) => a - b);
    return { vol: s * ANN_H * 100, sharpe: s ? m / s * ANN_H : 0,
             ret7d: (rets.reduce((e, r) => e * (1 + r), 1) - 1) * 100,
             var95: Math.abs(sorted[Math.floor(sorted.length * 0.05)] || 0) * Math.sqrt(24) * 100,
             dd: ddOf(rets) };
  }
  const volWindows = c => {
    const r = retsOf(c);
    if (!r) return null;
    const w = h => { const x = tail(r, Math.min(h, r.length)); return std(x) * ANN_H * 100; };
    return { h24: w(24), h72: w(72), d7: w(r.length) };
  };

  /* ---- portfolio ---- */
  function coinHoldings(){
    return CDX.Store.state.holdings
      .map(h => ({ h, it: CDX.Data.byKey(h.key) }))
      .filter(x => x.it && x.it.sym && retsOf(x.it))
      .map(x => ({ ...x, value: x.it.price * x.h.amount }));
  }
  function portfolioSeries(){
    const hs = coinHoldings();
    if (!hs.length) return null;
    const aligned = align(hs.map(x => x.it));
    if (!aligned) return null;
    const total = hs.reduce((a, x) => a + x.value, 0) || 1;
    const w = hs.map(x => x.value / total);
    const n = aligned[0].length;
    const rets = [];
    for (let i = 0; i < n; i++) rets.push(aligned.reduce((a, r, j) => a + r[i] * w[j], 0));
    return { rets, holdings: hs, weights: w };
  }
  function portfolioAnalytics(){
    const ps = portfolioSeries();
    const all = CDX.Store.state.holdings.map(h => ({ h, it: CDX.Data.byKey(h.key) })).filter(x => x.it);
    const totalAll = all.reduce((a, x) => a + x.it.price * x.h.amount, 0);
    if (!ps) return { totalAll, covered: 0, stats: null, beta: null };
    const stats = seriesStats(ps.rets);
    const btc = CDX.Data.byKey('c:btc');
    let beta = null;
    const btcR = retsOf(btc);
    if (btcR){ const n = Math.min(ps.rets.length, btcR.length); beta = betaOf(tail(ps.rets, n), tail(btcR, n)); }
    const covered = ps.holdings.reduce((a, x) => a + x.value, 0);
    return { totalAll, covered, coveredPct: totalAll ? covered / totalAll * 100 : 0, stats, beta, ps };
  }
  /* ---- attribution: contribution = weight × return ---- */
  function attribution(horizon){
    const all = CDX.Store.state.holdings.map(h => ({ h, it: CDX.Data.byKey(h.key) })).filter(x => x.it);
    const total = all.reduce((a, x) => a + x.it.price * x.h.amount, 0) || 1;
    const rows = all.map(x => {
      const ch = horizon === '7d' && x.it.ch7d != null ? x.it.ch7d : CDX.Data.ch24(x.it);
      const wPct = x.it.price * x.h.amount / total * 100;
      return { it: x.it, key: x.h.key, w: wPct, ch, contrib: wPct * ch / 100 };
    }).sort((a, b) => b.contrib - a.contrib);
    const byGroup = kind => {
      const m = new Map();
      for (const r of rows){
        const g = kind === 'chain' ? (CDX.Data.CHAINS[r.it.chain] ? CDX.Data.CHAINS[r.it.chain].name : 'Other')
                : ((r.it.tags && r.it.tags[0]) ? CDX.DataRaw.NARRATIVES[r.it.tags[0]].name : 'Other');
        m.set(g, (m.get(g) || 0) + r.contrib);
      }
      return [...m.entries()].sort((a, b) => b[1] - a[1]);
    };
    return { rows, total: rows.reduce((a, r) => a + r.contrib, 0), byNarrative: byGroup('narr'), byChain: byGroup('chain') };
  }
  /* ---- matrices, betas, factors ---- */
  function matrixAssets(){
    const set = new Map();
    for (const x of coinHoldings()) set.set(x.it.id, x.it);
    for (const id of ['btc','eth','sol','pls','plsx','hex']){
      const c = CDX.Data.byKey('c:' + id);
      if (c && retsOf(c)) set.set(id, c);
    }
    return [...set.values()].slice(0, 8);
  }
  function corrMatrix(){
    const assets = matrixAssets();
    const aligned = align(assets);
    if (!aligned) return null;
    const m = assets.map((_, i) => assets.map((_, j) => corr(aligned[i], aligned[j])));
    return { assets, m };
  }
  const volMatrix = () => matrixAssets().map(c => ({ c, v: volWindows(c) })).filter(x => x.v);
  function betas(){
    const btcR = retsOf(CDX.Data.byKey('c:btc'));
    if (!btcR) return [];
    return matrixAssets().filter(c => c.id !== 'btc').map(c => {
      const r = retsOf(c);
      const n = Math.min(r.length, btcR.length);
      return { c, beta: betaOf(tail(r, n), tail(btcR, n)) };
    }).sort((a, b) => b.beta - a.beta);
  }
  function factorReturns(){
    const eq = ids => {
      const rs = ids.map(id => retsOf(CDX.Data.byKey('c:' + id))).filter(Boolean);
      if (!rs.length) return null;
      const n = Math.min(...rs.map(r => r.length));
      const out = [];
      for (let i = 0; i < n; i++) out.push(rs.reduce((a, r) => a + tail(r, n)[i], 0) / rs.length);
      return out;
    };
    return {
      'Market (BTC)': retsOf(CDX.Data.byKey('c:btc')),
      'Alt L1 (ETH/SOL)': eq(['eth', 'sol']),
      'Meme': eq(['doge', 'pepe', 'bonk', 'wif', 'shib']),
      'PulseChain': eq(['pls', 'plsx', 'hex'])
    };
  }
  function factorExposure(){
    const ps = portfolioSeries();
    if (!ps) return [];
    const fr = factorReturns();
    return Object.entries(fr).filter(([, r]) => r).map(([name, r]) => {
      const n = Math.min(ps.rets.length, r.length);
      return { name, beta: betaOf(tail(ps.rets, n), tail(r, n)) };
    });
  }
  /* ---- backtester (real OHLC) ---- */
  const sma = (a, n, i) => { if (i + 1 < n) return null; let s = 0; for (let j = i - n + 1; j <= i; j++) s += a[j]; return s / n; };
  function rsi(closes, n, i){
    if (i < n) return null;
    let g = 0, l = 0;
    for (let j = i - n + 1; j <= i; j++){
      const d = closes[j] - closes[j - 1];
      d >= 0 ? g += d : l -= d;
    }
    if (!l) return 100;
    return 100 - 100 / (1 + (g / n) / (l / n));
  }
  async function backtest(key, tf, strat, params){
    const item = CDX.Data.byKey(key);
    const s = await CDX.LiveData.candles(key, tf, item);
    const cs = s.candles;
    if (!cs || cs.length < 40) throw new Error('not enough history');
    const closes = cs.map(c => c.close), highs = cs.map(c => c.high), lows = cs.map(c => c.low);
    const FEE = 0.003;
    let pos = 0, eq = 1, bh0 = closes[0];
    const eqC = [], bhC = [], trades = [];
    let entryPx = 0, wins = 0;
    const warm = Math.max(params.slow || 0, params.entry || 0, 15) + 1;
    for (let i = 1; i < cs.length; i++){
      if (pos) eq *= closes[i] / closes[i - 1];
      let want = pos;
      if (i >= warm){
        if (strat === 'smacross'){
          const f = sma(closes, params.fast, i), sl = sma(closes, params.slow, i);
          if (f != null && sl != null) want = f > sl ? 1 : 0;
        } else if (strat === 'rsi'){
          const r = rsi(closes, 14, i);
          if (r != null){ if (r <= params.buy) want = 1; else if (r >= params.sell) want = 0; }
        } else if (strat === 'breakout'){
          const hi = Math.max(...highs.slice(i - params.entry, i));
          const lo = Math.min(...lows.slice(i - Math.min(params.exit, i), i));
          if (!pos && closes[i] > hi) want = 1;
          if (pos && closes[i] < lo) want = 0;
        }
      }
      if (want !== pos){
        eq *= 1 - FEE;
        if (want){ entryPx = closes[i]; }
        else { trades.push({ entry: entryPx, exit: closes[i] }); if (closes[i] > entryPx) wins++; }
        pos = want;
      }
      eqC.push(eq);
      bhC.push(closes[i] / bh0);
    }
    if (pos){ trades.push({ entry: entryPx, exit: closes[closes.length - 1], open: true }); if (closes[closes.length - 1] > entryPx) wins++; }
    const rets = [];
    for (let i = 1; i < eqC.length; i++) rets.push(eqC[i] / eqC[i - 1] - 1);
    const ann = tf === '1D' ? Math.sqrt(91) : Math.sqrt(6 * 365);
    const dd = ddOf(rets);
    return { eqC, bhC, bars: cs.length,
             ret: (eq - 1) * 100, bhRet: (closes[closes.length - 1] / bh0 - 1) * 100,
             sharpe: std(rets) ? mean(rets) / std(rets) * ann : 0,
             maxDD: dd.maxDD, trades: trades.length, winRate: trades.length ? wins / trades.length * 100 : 0 };
  }
  return { portfolioAnalytics, attribution, corrMatrix, volMatrix, betas, factorExposure,
           seriesStats, volWindows, retsOf, ddOf, backtest };
})();
