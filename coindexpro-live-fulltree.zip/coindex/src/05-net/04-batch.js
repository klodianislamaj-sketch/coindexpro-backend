/* CDX.Net.Batch — coalesce per-key requests inside a window into one provider call. */
CDX.Net.Batch = (() => {
  function create(cfg){
    const windowMs = cfg.windowMs || 100, max = cfg.max || 30, exec = cfg.exec;
    let pending = new Map();    // key → [{res, rej}]
    let timer = null;
    async function flush(){
      timer = null;
      const batch = pending;
      pending = new Map();
      const keys = [...batch.keys()];
      for (let i = 0; i < keys.length; i += max){
        const chunk = keys.slice(i, i + max);
        try {
          const out = await exec(chunk);                       // Map|object key → value
          for (const k of chunk){
            const v = out instanceof Map ? out.get(k) : out[k];
            batch.get(k).forEach(w => w.res(v));
          }
        } catch(e){ for (const k of chunk) batch.get(k).forEach(w => w.rej(e)); }
      }
    }
    return {
      add(key){
        return new Promise((res, rej) => {
          if (!pending.has(key)) pending.set(key, []);
          pending.get(key).push({ res, rej });
          if (!timer) timer = setTimeout(flush, windowMs);
        });
      }
    };
  }
  return { create };
})();
