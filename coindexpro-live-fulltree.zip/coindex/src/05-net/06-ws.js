/* CDX.Net.WS — managed sockets: exponential reconnect with jitter, max attempts,
   automatic polling-fallback signal, resume on connectivity restore. */
CDX.Net.WS = (() => {
  function connect(name, url, cfg){
    const c = Object.assign({ maxRetries: 7, baseDelay: 1200 }, cfg);
    const h = { ws: null, attempts: 0, closed: false, alive: false, timer: null, offOnline: null };
    function open(){
      if (h.closed) return;
      let ws;
      try { ws = new WebSocket(url); } catch(e){ return fail(); }
      h.ws = ws;
      ws.onopen = () => {
        h.attempts = 0; h.alive = true;
        CDX.Bus.emit('ws:up', { name });
        if (c.onOpen) try { c.onOpen(ws); } catch(e){ console.warn('[ws]', name, e); }
      };
      ws.onmessage = ev => { if (c.onMessage) try { c.onMessage(ev.data); } catch(e){ console.warn('[ws]', name, e); } };
      ws.onerror = () => {};
      ws.onclose = () => { h.alive = false; if (!h.closed) fail(); };
    }
    function fail(){
      if (h.closed) return;
      CDX.Bus.emit('ws:down', { name });
      if (h.attempts >= c.maxRetries){
        CDX.Bus.emit('ws:fallback', { name });                 // polling takes over
        if (h.offOnline) h.offOnline();
        h.offOnline = CDX.Bus.on('net:online', () => { if (h.offOnline){ h.offOnline(); h.offOnline = null; } if (!h.closed){ h.attempts = 0; open(); } });
        return;
      }
      const delay = Math.min(30000, c.baseDelay * Math.pow(2, h.attempts++)) + Math.random() * 400;
      clearTimeout(h.timer);
      h.timer = setTimeout(open, delay);
    }
    open();
    return {
      send(data){ if (h.alive) h.ws.send(typeof data === 'string' ? data : JSON.stringify(data)); },
      close(){
        h.closed = true;
        clearTimeout(h.timer);
        if (h.offOnline){ h.offOnline(); h.offOnline = null; }
        if (h.ws){ h.ws.onopen = h.ws.onmessage = h.ws.onclose = h.ws.onerror = null; try { h.ws.close(); } catch(e){} }
        h.ws = null;
      },
      alive: () => h.alive
    };
  }
  return { connect };
})();
