/* CDX.Net.Queue — per-endpoint token-bucket rate limiting, min-gap throttling,
   429 cooldowns, burst protection, FIFO with priority. */
CDX.Net.Queue = (() => {
  const registry = new Map();
  function create(cfg){
    const q = {
      name: cfg.name, rps: cfg.rps || 1, burst: cfg.burst || 2, minGap: cfg.minGap || 0,
      tokens: cfg.burst || 2, lastRun: 0, lastRefill: Date.now(), coolUntil: 0,
      jobs: [], pumping: false
    };
    function refill(){
      const now = Date.now();
      q.tokens = Math.min(q.burst, q.tokens + (now - q.lastRefill) / 1000 * q.rps);
      q.lastRefill = now;
    }
    async function pump(){
      if (q.pumping) return;
      q.pumping = true;
      while (q.jobs.length){
        refill();
        const now = Date.now();
        const wait = Math.max(q.coolUntil - now, q.lastRun + q.minGap - now,
                              q.tokens >= 1 ? 0 : (1 - q.tokens) / q.rps * 1000);
        if (wait > 0) await new Promise(r => setTimeout(r, wait));
        refill();
        const job = q.jobs.shift();
        q.tokens -= 1;
        q.lastRun = Date.now();
        try { job.res(await job.fn()); } catch(e){ job.rej(e); }
      }
      q.pumping = false;
    }
    q.run = (fn, opts) => new Promise((res, rej) => {
      const job = { fn, res, rej };
      (opts && opts.priority) ? q.jobs.unshift(job) : q.jobs.push(job);
      pump();
    });
    q.cooldown = ms => { q.coolUntil = Math.max(q.coolUntil, Date.now() + ms); };
    registry.set(q.name, q);
    return q;
  }
  return { create, get: name => registry.get(name), all: () => [...registry.values()] };
})();
