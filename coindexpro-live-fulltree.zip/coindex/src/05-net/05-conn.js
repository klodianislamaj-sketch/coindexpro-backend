/* CDX.Net.Conn — offline detection, stale/reconnect banners, visibility-aware
   polling lifecycle with route-bound pollers and reconnect resume. */
CDX.Net.Conn = (() => {
  const state = { online: navigator.onLine !== false, degraded: false, lastOk: Date.now(), failStreak: 0 };
  const pollers = new Map();   // name → { fn, interval, timer, running, routeBound, lastRun }
  let bannerEl = null, restoreTimer = null;

  /* ---- banners ---- */
  function banner(kind){
    if (!bannerEl){
      bannerEl = document.createElement('div');
      bannerEl.id = 'netBanner';
      bannerEl.className = 'fixed left-1/2 -translate-x-1/2 top-[4.2rem] z-[60] hidden text-xs font-medium rounded-lg px-3.5 py-2 border shadow-xl shadow-black/40';
      document.body.appendChild(bannerEl);
    }
    clearTimeout(restoreTimer);
    if (!kind){ bannerEl.classList.add('hidden'); return; }
    const cfg = {
      offline:   ['You are offline — showing cached data', 'bg-[#1a0f12] border-down/50 text-down'],
      degraded:  ['Live feeds unstable — retrying with backoff', 'bg-[#1a1610] border-gold/50 text-gold'],
      stale:     ['Data is stale — reconnecting to providers', 'bg-[#1a1610] border-gold/50 text-gold'],
      restored:  ['Live feeds restored', 'bg-[#0f1a14] border-up/50 text-up']
    }[kind];
    bannerEl.textContent = cfg[0];
    bannerEl.className = 'fixed left-1/2 -translate-x-1/2 top-[4.2rem] z-[60] text-xs font-medium rounded-lg px-3.5 py-2 border shadow-xl shadow-black/40 ' + cfg[1];
    if (kind === 'restored') restoreTimer = setTimeout(() => banner(null), 2600);
  }

  /* ---- polling lifecycle ---- */
  function schedule(p){
    clearTimeout(p.timer);
    p.timer = setTimeout(async () => {
      if (!p.running) return;
      if (!document.hidden && state.online){
        p.lastRun = Date.now();
        try { await p.fn(); } catch(e){ console.warn('[poll]', p.name, e.message); }
      }
      if (p.running) schedule(p);
    }, p.interval);
  }
  function poller(name, fn, interval, opts){
    const p = { name, fn, interval, timer: null, running: false,
                routeBound: !!(opts && opts.routeBound), lastRun: 0 };
    pollers.set(name, p);
    p.start = () => {
      if (p.running) return p;
      p.running = true;
      if (opts && opts.immediate && !document.hidden && state.online){
        p.lastRun = Date.now();
        Promise.resolve(p.fn()).catch(e => console.warn('[poll]', name, e.message));
      }
      schedule(p);
      return p;
    };
    p.stop = () => { p.running = false; clearTimeout(p.timer); };
    return p;
  }
  const routePoller = (name, fn, interval, opts) =>
    poller(name, fn, interval, Object.assign({}, opts, { routeBound: true }));
  function kick(){
    for (const p of pollers.values()){
      if (!p.running) continue;
      clearTimeout(p.timer);
      Promise.resolve(p.fn()).catch(e => console.warn('[poll]', p.name, e.message));
      p.lastRun = Date.now();
      schedule(p);
    }
  }

  /* ---- detection wiring ---- */
  function init(){
    window.addEventListener('online', () => {
      state.online = true;
      banner('restored');
      CDX.Bus.emit('net:online');
      kick();
    });
    window.addEventListener('offline', () => {
      state.online = false;
      banner('offline');
      CDX.Bus.emit('net:offline');
    });
    document.addEventListener('visibilitychange', () => {
      CDX.Bus.emit(document.hidden ? 'net:hidden' : 'net:visible');
      if (!document.hidden && state.online) kick();           // resume on visibility restore
    });
    CDX.Bus.on('route:changed', () => {                        // pause route-bound pollers on destroy
      for (const p of pollers.values()) if (p.routeBound) p.stop();
    });
    CDX.Bus.on('net:reqok', () => {
      state.lastOk = Date.now();
      state.failStreak = 0;
      if (state.degraded){ state.degraded = false; banner(state.online ? 'restored' : 'offline'); }
    });
    CDX.Bus.on('net:reqfail', () => {
      if (++state.failStreak >= 4 && !state.degraded){
        state.degraded = true;
        if (state.online) banner('degraded');
      }
    });
    setInterval(() => {                                        // staleness watchdog
      if (state.online && !state.degraded && Date.now() - state.lastOk > 150e3) banner('stale');
    }, 15000);
    if (!state.online) banner('offline');
  }
  return { init, poller, routePoller, kick, banner, state };
})();
