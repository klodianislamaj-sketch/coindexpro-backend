/* CDX.Net.Cache — in-memory TTL cache, stale-while-revalidate, in-flight dedupe. */
CDX.Net = CDX.Net || {};
CDX.Net.Cache = (() => {
  const store = new Map();      // key → { v, ts }
  const inflight = new Map();   // key → Promise
  const CAP = 200;
  const _stats = { hits: 0, misses: 0 };   // for status-page hit-rate
  function set(key, v){
    if (store.size >= CAP) store.delete(store.keys().next().value);
    store.delete(key);
    store.set(key, { v, ts: Date.now() });
    return v;
  }
  const get = key => { const e = store.get(key); return e && e.v; };
  const ageOf = key => { const e = store.get(key); return e ? Date.now() - e.ts : Infinity; };
  function dedupe(key, fn){
    if (inflight.has(key)) return inflight.get(key);
    const p = Promise.resolve().then(fn).finally(() => inflight.delete(key));
    inflight.set(key, p);
    return p;
  }
  /* swr: fresh → return; stale-but-usable → return stale, revalidate in background;
     missing/expired → await fetch */
  async function swr(key, fetcher, opts){
    const ttl = (opts && opts.ttl) || 60e3;
    const stale = (opts && opts.stale) || ttl * 10;
    const age = ageOf(key);
    if (age < ttl){ _stats.hits++; return get(key); }
    if (age < stale){
      _stats.hits++;
      dedupe(key, fetcher).then(v => set(key, v)).catch(() => {});
      return get(key);
    }
    _stats.misses++;
    // expired: fetch fresh, but if it fails (e.g. rate-limited) fall back to last
    // cached value when we have one — never break the UI on a transient error.
    try {
      const v = await dedupe(key, fetcher);
      return set(key, v);
    } catch(e){
      if (store.has(key)) return get(key);   // serve last valid data
      throw e;                                // nothing cached → let caller handle
    }
  }
  const invalidate = key => store.delete(key);
  const stats = () => { const t = _stats.hits + _stats.misses;
    return { hits: _stats.hits, misses: _stats.misses, size: store.size,
             hitRate: t ? _stats.hits / t : null }; };
  return { get, set, swr, dedupe, invalidate, ageOf, stats };
})();
