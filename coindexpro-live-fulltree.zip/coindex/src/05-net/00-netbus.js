/* Bus augmentation — streams with last-value replay, scoped/route-bound subscriptions,
   listener-leak guard. Original Bus.on/emit contracts unchanged. */
(() => {
  const rawOn = CDX.Bus.on.bind(CDX.Bus);
  const counts = new Map();
  const warned = new Set();
  CDX.Bus.on = (evt, fn) => {
    counts.set(evt, (counts.get(evt) || 0) + 1);
    if (counts.get(evt) > 80 && !warned.has(evt)){
      warned.add(evt);
      console.warn('[bus] possible listener leak on "' + evt + '" (' + counts.get(evt) + ' subscribers)');
    }
    const off = rawOn(evt, fn);
    let dead = false;
    return () => {
      if (dead) return;
      dead = true;
      counts.set(evt, Math.max(0, (counts.get(evt) || 1) - 1));
      off();
    };
  };
  /* stream: subscription with last-value replay */
  const lastVal = new Map();
  const rawEmit = CDX.Bus.emit.bind(CDX.Bus);
  CDX.Bus.emit = (evt, payload) => { lastVal.set(evt, payload); rawEmit(evt, payload); };
  CDX.Bus.stream = evt => ({
    last: () => lastVal.get(evt),
    subscribe(fn){
      if (lastVal.has(evt)){ try { fn(lastVal.get(evt)); } catch(e){ console.error('[bus:stream]', evt, e); } }
      return CDX.Bus.on(evt, fn);
    }
  });
  /* scope: grouped subscriptions with single dispose */
  CDX.Bus.scope = () => {
    const offs = [];
    return {
      on(evt, fn){ const off = CDX.Bus.on(evt, fn); offs.push(off); return off; },
      dispose(){ offs.splice(0).forEach(off => off()); }
    };
  };
  /* route-bound subscription: auto-disposed on next navigation */
  CDX.Bus.onRoute = (evt, fn) => {
    const off = CDX.Bus.on(evt, fn);
    const offRoute = rawOn('route:changed', () => { off(); offRoute(); });
    return off;
  };
})();
