/* CDX.Net.http — fetch with timeout, exponential backoff + jitter, max retries,
   429 endpoint cooldowns, connectivity reporting, graceful failure. */
CDX.Net.http = (() => {
  class HttpError extends Error {
    constructor(msg, status, retryable){ super(msg); this.status = status; this.retryable = retryable; }
  }
  async function once(url, opts){
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), opts.timeout || 12000);
    try {
      const res = await fetch(url, {
        method: opts.method || 'GET',
        headers: Object.assign({ accept: 'application/json' }, opts.headers || {}),
        body: opts.body ? JSON.stringify(opts.body) : undefined,
        signal: ctl.signal
      });
      if (res.status === 429) throw new HttpError('rate limited', 429, true);
      if (res.status >= 500) throw new HttpError('server ' + res.status, res.status, true);
      if (!res.ok) throw new HttpError('http ' + res.status, res.status, false);
      return await res.json();
    } catch(e){
      if (e.name === 'AbortError') throw new HttpError('timeout', 0, true);
      if (e instanceof HttpError) throw e;
      throw new HttpError(e.message || 'network', 0, true);   // network/CORS
    } finally { clearTimeout(t); }
  }
  async function json(url, opts){
    const o = opts || {};
    const retries = o.retries == null ? 2 : o.retries;
    const base = o.backoff || 700;
    let attempt = 0;
    for (;;){
      try {
        const exec = () => once(url, o);
        const out = o.queue ? await o.queue.run(exec, { priority: o.priority }) : await exec();
        CDX.Bus.emit('net:reqok', { url });
        return out;
      } catch(e){
        if (e.status === 429 && o.queue) o.queue.cooldown(20000 + attempt * 15000);
        if (!e.retryable || attempt >= retries){
          CDX.Bus.emit('net:reqfail', { url, error: e.message, status: e.status });
          throw e;
        }
        const delay = base * Math.pow(2, attempt) + Math.random() * 300;
        await new Promise(r => setTimeout(r, delay));
        attempt++;
      }
    }
  }
  return { json, HttpError };
})();
