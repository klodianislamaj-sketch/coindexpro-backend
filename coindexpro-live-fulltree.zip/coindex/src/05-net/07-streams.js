/* CDX.Net.Streams — real WebSocket feeds with throttled flushes:
   Binance miniTicker → live coin prices · aggTrade → live whale prints ·
   PulseChain newHeads → live chain heartbeat. Polling continues as fallback. */
CDX.Net.Streams = (() => {
  const BINANCE = {
    btc:'btcusdt', eth:'ethusdt', sol:'solusdt', xrp:'xrpusdt', bnb:'bnbusdt', doge:'dogeusdt',
    ada:'adausdt', trx:'trxusdt', avax:'avaxusdt', ltc:'ltcusdt', ton:'tonusdt', dot:'dotusdt',
    shib:'shibusdt', uni:'uniusdt', near:'nearusdt', icp:'icpusdt', apt:'aptusdt', pepe:'pepeusdt',
    arb:'arbusdt', pol:'polusdt', op:'opusdt', link:'linkusdt', bonk:'bonkusdt', wif:'wifusdt'
  };
  const TRADE_STREAMS = ['btc','eth','sol','bnb','xrp','doge','pepe','link'];
  const WHALE_USD = 150000;
  const bySym = {};
  Object.keys(BINANCE).forEach(id => bySym[BINANCE[id]] = id);
  let buffer = new Map(), flushTimer = null, started = false;

  function flush(){
    flushTimer = null;
    const updates = [...buffer.values()];
    buffer = new Map();
    if (updates.length) CDX.LiveData.pushPrices(updates);
  }
  function onMiniTicker(d){
    const id = bySym[(d.s || '').toLowerCase()];
    if (!id) return;
    const price = +d.c, open = +d.o;
    if (!price) return;
    buffer.set(id, { id, price, ch24: open ? (price - open) / open * 100 : null });
    if (!flushTimer) flushTimer = setTimeout(flush, 1500);
  }
  function onAggTrade(d){
    const id = bySym[(d.s || '').toLowerCase()];
    if (!id) return;
    const usd = (+d.p) * (+d.q);
    if (usd < WHALE_USD) return;
    const coin = CDX.Data.coins.find(c => c.id === id);
    const pool = coin && CDX.Data.pairsForToken(coin)[0];
    if (!pool) return;
    const t = { id: 'cex' + d.a, ts: d.T || Date.now(), wallet: 'cexflow-binance-spot',
                pairId: pool.id, side: d.m ? 'sell' : 'buy', usd, price: +d.p, tx: 'binance spot' };
    CDX.DataRaw.WHALE_TRADES.unshift(t);
    if (CDX.DataRaw.WHALE_TRADES.length > 60) CDX.DataRaw.WHALE_TRADES.pop();
    CDX.Bus.emit('whale:new', t);
  }
  function start(){
    if (started) return;
    started = true;
    const streams = Object.values(BINANCE).map(s => s + '@miniTicker')
      .concat(TRADE_STREAMS.map(id => BINANCE[id] + '@aggTrade'));
    CDX.Net.WS.connect('binance', 'wss://stream.binance.com:9443/stream?streams=' + streams.join('/'), {
      onMessage: raw => {
        let j; try { j = JSON.parse(raw); } catch(e){ return; }
        const d = j.data || j;
        if (!d || !d.e) return;
        if (d.e === '24hrMiniTicker') onMiniTicker(d);
        else if (d.e === 'aggTrade') onAggTrade(d);
      }
    });
    let lastHeadAt = 0;
    const onHead = head => {
      lastHeadAt = Date.now();
      CDX.LiveData.pulseHead = head;
      CDX.Bus.emit('pls:block', head);
    };
    CDX.Providers.pulsechain.subscribeHeads(onHead);
    CDX.Net.Conn.poller('pls:headwatch', async () => {
      if (Date.now() - lastHeadAt < 180e3) return;       // stream healthy
      onHead(await CDX.Providers.pulsechain.head());
    }, 90000).start();
  }
  return { start };
})();
