/* Page: Home — global intelligence overview. Route: #/ */
CDX.Pages = CDX.Pages || {};
CDX.Pages.home = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI;
  let subs = [], root = null;

  function statsHtml(){
    const g = CDX.Data.globals();
    const fgLabel = g.fearGreed>=75?'Extreme Greed':g.fearGreed>=55?'Greed':g.fearGreed>=45?'Neutral':g.fearGreed>=25?'Fear':'Extreme Fear';
    const fgColor = g.fearGreed>=55?'#2DD480':g.fearGreed>=45?'#F5C04E':'#FF5C5C';
    return U.statCard('Total Market Cap', F.usd(g.totalMcap), `<span class="${F.cls(g.wCh24)}">${F.pct(g.wCh24)}</span> 24h`)
      + U.statCard('24h Volume', F.usd(g.totalVol), 'spot + DEX')
      + U.statCard('BTC Dominance', g.btcDom.toFixed(1)+'%', `ETH ${g.ethDom.toFixed(1)}%`)
      + U.statCard('Coins / Pairs', `${g.nCoins} / ${g.nPairs}`, `${CDX.Data.CHAIN_ORDER.length} chains tracked`)
      + U.statCard('Fear & Greed', `<span style="color:${fgColor}">${g.fearGreed}</span>`, `<span style="color:${fgColor}">${fgLabel}</span>`, { pct: g.fearGreed, color: fgColor });
  }
  function moverRow(c, i){
    return `<a href="#/token/${c.id}" class="row-hov flex items-center gap-2.5 px-3.5 py-[7px] border-b border-line/50 last:border-0">
      <span class="text-mut text-[10px] w-4 num">${i+1}</span>${U.logo(c.sym, c.color, 5)}
      <div class="min-w-0"><div class="text-[12.5px] font-medium text-white leading-tight">${F.esc(c.sym)} <span class="num text-[9.5px] ${F.cls(c.ch1h)} font-normal">${F.pct(c.ch1h)} 1h</span></div>
      <div class="text-[10px] text-mut truncate leading-tight">${F.esc(c.name)} · MC ${F.usd(c.mcap)}</div></div>
      <span class="ml-auto hidden sm:block">${U.sparkline('hm'+c.id, c.ch7d, 64, 20)}</span>
      <div class="text-right w-[88px] shrink-0">
        <div class="num text-[12.5px] text-slate-200 leading-tight" data-live="hp:${c.id}">${F.price(c.price)}</div>
        <div class="num text-[11px] ${F.cls(c.ch24)} leading-tight">${F.pct(c.ch24)}</div></div></a>`;
  }
  function pairRow(p, i){
    return `<a href="#/pair/${p.id}" class="row-hov flex items-center gap-2.5 px-3.5 py-[7px] border-b border-line/50 last:border-0">
      <span class="text-mut text-[10px] w-4 num">${i+1}</span>${U.logo(p.base, CDX.Data.CHAINS[p.chain].color, 5)}
      <div class="min-w-0"><div class="text-[12.5px] font-medium text-white leading-tight">${F.esc(p.base)}<span class="text-mut font-normal">/${F.esc(p.quote)}</span> <span class="text-[9px] text-mut font-normal">${F.esc(p.dex)}</span></div>
      <div class="text-[10px] text-mut leading-tight flex items-center gap-1">${U.chainBadge(p.chain)} <span class="num">Liq ${F.usd(p.liq)} · <span class="text-up">${F.num(p.buys)}</span>/<span class="text-down">${F.num(p.sells)}</span></span></div></div>
      <div class="ml-auto text-right shrink-0">
        <div class="num text-[12.5px] text-slate-200 leading-tight" data-live="hd:${p.id}">${F.price(p.price)}</div>
        <div class="num text-[10.5px] text-mut leading-tight">V ${F.usd(p.vol)} · <span class="${F.cls(p.ch.h24)}">${F.pctAuto(p.ch.h24)}</span></div></div></a>`;
  }
  function newsRow(n){
    const it = CDX.Data.byKey(n.tag);
    const dot = n.kind==='bull' ? 'bg-up' : n.kind==='bear' ? 'bg-down' : 'bg-acc';
    const href = it ? (it.sym ? '#/token/'+it.id : '#/pair/'+it.id) : '#/news';
    return `<a href="${href}" class="row-hov flex items-start gap-2.5 px-3.5 py-2 border-b border-line/50 last:border-0">
      <span class="mt-1.5 w-1.5 h-1.5 rounded-full ${dot} shrink-0"></span>
      <div class="min-w-0 flex-1"><div class="text-[12.5px] text-slate-200 leading-snug">${n.h}</div>
      <div class="flex items-center gap-2 text-[10px] text-mut mt-0.5"><span class="font-medium text-slate-400">${n.src}</span> · <span>${F.rel(n.ts)}</span>
      ${it?`<span class="ml-1 text-[10px] border border-line rounded px-1.5 py-px text-slate-300">${F.esc(CDX.Data.label(it))} <span class="num ${F.cls(CDX.Data.ch24(it))}">${F.pctAuto(CDX.Data.ch24(it))}</span></span>`:''}</div></div></a>`;
  }
  function chainStrip(){
    /* single grouping pass over pairs (was 13 filter+reduce passes) */
    const agg = new Map();
    for (const p of CDX.Data.pairs){
      let e = agg.get(p.chain);
      if (!e) agg.set(p.chain, e = { vol: 0, liq: 0, n: 0 });
      e.vol += p.vol; e.liq += p.liq; e.n++;
    }
    return CDX.Data.CHAIN_ORDER.map(id => {
      const e = agg.get(id) || { vol: 0, liq: 0, n: 0 };
      if (!e.n && id !== 'pulsechain') return '';
      const pls = id === 'pulsechain';
      return `<a href="#/dex?chain=${id}" class="shrink-0 rounded-lg border px-3 py-2 ${pls ? 'border-pls/50 pls-ring bg-gradient-to-r from-pls/10 to-plx/10' : 'border-line bg-panel hover:border-acc/40'} transition-colors">
        <div class="mb-1">${U.chainBadge(id, true)}</div>
        <div class="text-[10px] text-mut num leading-tight">L ${F.usd(e.liq)} · V ${F.usd(e.vol)} · ${e.n}p</div></a>`;
    }).join('');
  }
  function render(){
    /* movers: volume-qualified, conviction-weighted (|Δ| × turnover), stables excluded */
    const score = c => Math.abs(c.ch24) * Math.min(3, Math.sqrt(c.vol / Math.max(c.mcap, 1) * 100));
    const gainers = [...CDX.Data.coins]
      .filter(c => !['usdt','usdc'].includes(c.id) && c.ch24 > 0 && c.vol > 1e6)
      .sort((a, b) => score(b) - score(a)).slice(0, 9);
    const seenBase = new Set();
    const hot = [...CDX.Data.pairs]
      .filter(p => p.liq > 25e3)
      .sort((a, b) => b.vol - a.vol)
      .filter(p => { const k = p.chain + ':' + p.base; if (seenBase.has(k)) return false; seenBase.add(k); return true; })
      .slice(0, 9);
    root.innerHTML = `
      <div class="space-y-4">
        <div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-2.5">${statsHtml()}</div>
        <div class="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">${chainStrip()}</div>
        <div class="grid lg:grid-cols-3 gap-3">
          <div class="bg-panel border border-line rounded-xl overflow-hidden">
            <div class="flex items-center justify-between px-4 py-3 border-b border-line">
              <h3 class="font-disp font-semibold text-white">Top Movers <span class="text-mut text-[10px] font-body font-normal">volume-qualified</span></h3>
              <a class="text-xs text-acc hover:underline" href="#/markets?f=gainers">View all →</a></div>
            ${gainers.map(moverRow).join('')}</div>
          <div class="bg-panel border border-line rounded-xl overflow-hidden">
            <div class="flex items-center justify-between px-4 py-3 border-b border-line">
              <h3 class="font-disp font-semibold text-white">Hot DEX Pairs</h3>
              <a class="text-xs text-acc hover:underline" href="#/dex">Open screener →</a></div>
            ${hot.map(pairRow).join('')}</div>
          <div class="bg-panel border border-line rounded-xl overflow-hidden">
            <div class="flex items-center justify-between px-4 py-3 border-b border-line">
              <h3 class="font-disp font-semibold text-white flex items-center gap-2">Live News <span class="w-1.5 h-1.5 rounded-full bg-down live-dot"></span></h3>
              <a class="text-xs text-acc hover:underline" href="#/news">All news →</a></div>
            <div id="homeNews">${CDX.News.latest(8).map(newsRow).join('')}</div></div>
        </div>
      </div>`;
  }
  return {
    mount(el){
      root = el; render();
      subs.push(CDX.Bus.on('tick', changed => {
        for (const { key, dir } of changed){
          const id = key.slice(2);
          const node = root.querySelector(`[data-live="${key.startsWith('c:')?'hp':'hd'}:${id}"]`);
          if (node) D.liveSet(node, F.price(CDX.Data.byKey(key).price), dir);
        }
      }));
      subs.push(CDX.Bus.on('news:changed', () => {
        const host = D.$('#homeNews', root);
        if (host) host.innerHTML = CDX.News.latest(8).map(newsRow).join('');
      }));
    },
    unmount(){ subs.forEach(u => u()); subs = []; root = null; }
  };
})();
