/* Page: Capital Flow Engine — three dashboards. Route: #/flows/:view (capital|rotation|migration) */
CDX.Pages.flows = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI, C = CDX.Capital, L = CDX.Liq, V = CDX.Viz;
  let subs = [], root = null, undelegate = null, view = 'capital';
  const VIEWS = [['capital','Capital Flow'],['rotation','Rotation'],['migration','Liquidity Migration']];
  const money = v => (v >= 0 ? '+' : '−') + F.usd(Math.abs(v));
  const panel = (title, sub, body) => `<div class="bg-panel border border-line rounded-xl overflow-hidden">
    <div class="px-4 py-3 border-b border-line"><h3 class="font-disp font-semibold text-white">${title}</h3>
    <div class="text-[10px] text-mut">${sub}</div></div>
    ${body || '<div class="px-4 py-8 text-center text-sm text-mut">Signals build as the session runs.</div>'}</div>`;
  const splitBar = (a, b) => { const t = a + b || 1;
    return `<div class="h-2 rounded-full overflow-hidden flex bg-line"><div class="bg-up" style="width:${(a/t*100).toFixed(0)}%"></div><div class="bg-down flex-1"></div></div>`; };
  const bar = (v, color) => `<div class="h-1.5 bg-line rounded-full overflow-hidden"><div class="h-full rounded-full" style="width:${Math.min(100, Math.abs(v))}%;background:${color}"></div></div>`;

  /* ================= CAPITAL ================= */
  function vCapital(){
    const b = C.bias(), sf = C.stableFlow(), ex1 = C.exchangeFlow(1), ex6 = C.exchangeFlow(6);
    const gaugeCol = b.riskOn >= 58 ? '#2DD480' : b.riskOn >= 42 ? '#F5C04E' : '#FF5C5C';
    return `<div class="grid lg:grid-cols-2 xl:grid-cols-3 gap-4">
      <div class="bg-panel border border-line rounded-xl p-4 text-center">
        <h3 class="font-disp font-semibold text-white mb-1">Capital Flow Bias</h3>
        ${V.gauge(b.riskOn, b.label, gaugeCol)}
        <div class="grid grid-cols-4 gap-1.5 mt-2 text-center">${[['Issuance', b.parts.issuance], ['Stables→Risk', b.parts.stablePairs], ['CEX Takers', b.parts.exchange], ['Whales', b.parts.whales]]
          .map(([l, v]) => `<div class="bg-panel2 border border-line rounded-lg py-1.5">
            <div class="num text-xs ${v >= 0 ? 'text-up' : 'text-down'}">${v >= 0 ? '+' : ''}${v.toFixed(0)}</div>
            <div class="text-[8px] uppercase tracking-wider text-mut">${l}</div></div>`).join('')}</div></div>
      ${panel('Stablecoin Flows', 'live USDT + USDC float · issuance Δ1h is the dry-powder proxy', `
        <div class="p-4 space-y-3">
          ${sf.coins.map(s => `<div class="flex items-center gap-2.5 text-[12px]">${U.logo(s.sym, s.color, 5)}
            <span class="text-white font-medium">${F.esc(s.sym)}</span>
            <span class="num text-mut">float ${F.usd(s.mcap)}</span>
            <span class="ml-auto num ${s.ch24 >= 0 ? 'text-up' : 'text-down'}">${F.pct(s.ch24, 2)} px</span></div>`).join('')}
          <div class="bg-panel2 border border-line rounded-lg px-3 py-2 flex items-center justify-between">
            <span class="text-[10px] uppercase tracking-wider text-mut">Net issuance · 1h</span>
            <span class="num font-semibold ${sf.issuance >= 0 ? 'text-up' : 'text-down'}">${money(sf.issuance)} (${sf.issuancePct >= 0 ? '+' : ''}${sf.issuancePct.toFixed(3)}%)</span></div>
          <div><div class="flex justify-between text-[10px] uppercase tracking-wider text-mut mb-1">
            <span>Stables → Risk (inflow)</span><span>Risk → Stables (outflow)</span></div>
            ${splitBar(sf.toRisk, sf.toStable)}
            <div class="flex justify-between text-[11px] num mt-1"><span class="text-up">${F.usd(sf.toRisk)}</span><span class="text-down">${F.usd(sf.toStable)}</span></div>
            <div class="text-center num text-[11px] mt-0.5 ${sf.net >= 0 ? 'text-up' : 'text-down'}">net ${money(sf.net)} into risk</div></div></div>`)}
      ${panel('Stable-Pair Flow by Chain', 'stable-quoted pools · measured prints preferred', sf.byChain.slice(0, 7).map(e => `
        <div class="row-hov px-4 py-2 border-b border-line/40 last:border-0" data-go="/chain/${e.chain}" style="cursor:pointer">
          <div class="flex items-center gap-2 text-[12px] mb-1">${U.chainBadge(e.chain)}
            <span class="text-[10px] text-mut">${e.pairs} stable pools</span>
            <span class="ml-auto num ${e.toRisk - e.toStable >= 0 ? 'text-up' : 'text-down'}">${money(e.toRisk - e.toStable)}</span></div>
          ${splitBar(e.toRisk, e.toStable)}</div>`).join(''))}
      ${panel('Exchange Taker Flow', 'real Binance spot prints ≥ $250K · buy = bid lifted', `
        <div class="p-4 space-y-3">
          ${[['1h', ex1], ['6h', ex6]].map(([l, e]) => `<div>
            <div class="flex justify-between text-[10px] uppercase tracking-wider text-mut mb-1">
              <span>${l} · ${e.prints} prints</span>
              <span class="num normal-case ${e.net >= 0 ? 'text-up' : 'text-down'}">net ${money(e.net)}</span></div>
            ${splitBar(e.buy, e.sell)}
            <div class="flex justify-between text-[11px] num mt-1"><span class="text-up">buy ${F.usd(e.buy)}</span><span class="text-down">sell ${F.usd(e.sell)}</span></div></div>`).join('')}
          ${ex6.biggest ? `<div class="text-[10px] text-mut">Largest: <span class="num ${ex6.biggest.side === 'buy' ? 'text-up' : 'text-down'}">${ex6.biggest.side.toUpperCase()} ${F.usd(ex6.biggest.usd)}</span> · ${F.rel(ex6.biggest.ts)}</div>` : ''}</div>`)}
      ${panel('Exchange Prints', 'latest spot takers', (ex6.recent || []).map(t => {
        const p = CDX.Data.byKey('d:' + t.pairId);
        return `<div class="row-hov flex items-center gap-3 px-4 py-2 border-b border-line/40 last:border-0" ${p ? `data-go="/pair/${p.id}" style="cursor:pointer"` : ''}>
          <span class="num text-[10px] text-mut w-12">${F.rel(t.ts)}</span>
          <span class="num text-[10px] font-bold w-9 ${t.side === 'buy' ? 'text-up' : 'text-down'}">${t.side.toUpperCase()}</span>
          <span class="text-sm text-white font-medium">${p ? F.esc(p.base) : '—'}</span>
          <span class="ml-auto num text-sm text-slate-200">${F.usd(t.usd)}</span></div>`;
      }).join(''))}
    </div>`;
  }
  /* ================= ROTATION ================= */
  function vRotation(){
    const cr = C.chainRotation(), sr = C.sectorRotation(), wr = C.whaleRotation();
    const PHASE = { 'inflow accelerating': 'text-up border-up/40 bg-up/10', 'inflow cooling': 'text-gold border-gold/40 bg-gold/10',
                    'outflow accelerating': 'text-down border-down/40 bg-down/10', 'outflow slowing': 'text-acc border-acc/40 bg-acc/10' };
    return `<div class="ai-card rounded-xl px-4 py-3 text-sm text-mut mb-4">
        Chain rotation: <a href="#/chain/${cr.outOf.id}" class="text-down hover:underline">${cr.outOf.chain.name}</a> →
        <a href="#/chain/${cr.into.id}" class="text-up hover:underline">${cr.into.chain.name}</a> ·
        whale deployment 3h: ${wr.nowTotal ? F.usd(wr.nowTotal) : '—'} vs prior ${wr.prevTotal ? F.usd(wr.prevTotal) : '—'}</div>
      <div class="grid lg:grid-cols-2 xl:grid-cols-3 gap-4">
      ${panel('Chain Rotation', 'volume flow + liquidity-event flow + 30min acceleration', cr.rows.map(r => `
        <div class="row-hov px-4 py-2 border-b border-line/40 last:border-0" data-go="/chain/${r.id}" style="cursor:pointer">
          <div class="flex items-center gap-2 text-[12px]">${U.chainBadge(r.id)}
            <span class="num text-[10px] ${r.accel >= 0 ? 'text-up' : 'text-down'}">${r.accel >= 0 ? '⬆ accel' : '⬇ decel'}</span>
            <span class="ml-auto num text-[10px] text-mut">vol ${money(r.volNet)} · liq ${money(r.liqNet)}</span></div>
          ${bar(Math.min(100, Math.abs(r.composite) / 5e5 * 100), r.composite >= 0 ? '#2DD480' : '#FF5C5C')}</div>`).join(''))}
      ${panel('Sector Rotation', 'narrative flows with phase classification', sr.map(n => `
        <div class="row-hov px-4 py-2 border-b border-line/40 last:border-0" data-go="/narrative/${n.id}" style="cursor:pointer">
          <div class="flex items-center gap-2 text-[12px] flex-wrap">
            <span class="font-medium" style="color:${n.color}">${n.name}</span>
            <span class="text-[9px] uppercase tracking-wider border rounded px-1.5 py-0.5 ${PHASE[n.phase]}">${n.phase}</span>
            <span class="ml-auto num ${n.flow.netFlow >= 0 ? 'text-up' : 'text-down'}">${money(n.flow.netFlow)}</span></div>
          <div class="flex items-center gap-2 text-[10px] text-mut num mt-0.5">
            <span>heat ${n.heat}</span><span>wΔ24h ${F.pct(n.wCh24)}</span>
            <span class="ml-auto ${n.accel >= 0 ? 'text-up' : 'text-down'}">accel ${money(n.accel)}/30m</span></div></div>`).join(''))}
      ${panel('Whale Rotation', 'buy-deployment share: last 3h vs prior 3h', `
        ${wr.narr.slice(0, 6).map(x => {
          const n = CDX.DataRaw.NARRATIVES[x.k];
          return `<div class="px-4 py-2 border-b border-line/40 last:border-0">
            <div class="flex items-center gap-2 text-[12px]">
              <span class="font-medium" style="color:${n ? n.color : '#8B94A7'}">${n ? n.name : x.k}</span>
              <span class="ml-auto num ${x.d >= 0 ? 'text-up' : 'text-down'}">${x.d >= 0 ? '+' : ''}${x.d.toFixed(1)}pp</span></div>
            <div class="flex items-center gap-2 text-[10px] text-mut num"><span>${x.prevPct.toFixed(0)}% →</span>
              <div class="flex-1">${bar(x.nowPct, x.d >= 0 ? '#2DD480' : '#FF5C5C')}</div>
              <span>${x.nowPct.toFixed(0)}% · ${F.usd(x.usd)}</span></div></div>`; }).join('')}
        ${wr.edges.length ? `<div class="px-4 py-2.5"><div class="text-[10px] uppercase tracking-wider text-mut mb-1.5">Wallet path transitions</div>
          <div class="flex flex-col gap-1">${wr.edges.map(e => {
            const a = CDX.DataRaw.NARRATIVES[e.from], b2 = CDX.DataRaw.NARRATIVES[e.to];
            return `<div class="text-[11px]"><span style="color:${a ? a.color : '#8B94A7'}">${a ? a.name : e.from}</span>
              <span class="text-mut">→</span> <span style="color:${b2 ? b2.color : '#8B94A7'}">${b2 ? b2.name : e.to}</span>
              <span class="num text-mut">· ${e.wallets.size} wallet${e.wallets.size > 1 ? 's' : ''}</span></div>`; }).join('')}</div></div>` : ''}`)}
      </div>`;
  }
  /* ================= MIGRATION ================= */
  function vMigration(){
    const ms = L.migrations(8), evs = L.events(10), cf = L.chainFlow(), max = Math.max(...cf.map(r => Math.abs(r.net)), 1);
    return `<div class="grid lg:grid-cols-2 xl:grid-cols-3 gap-4">
      ${panel('Liquidity Migrations', 'pool → pool capital moves (same token, 15min link window)', ms.map(m => {
        const from = CDX.Data.byKey('d:' + m.fromId), to = CDX.Data.byKey('d:' + m.toId);
        if (!from || !to) return '';
        return `<div class="px-4 py-2.5 border-b border-line/40 last:border-0">
          <div class="flex items-center gap-2 text-[12px]"><span class="font-medium text-white">${F.esc(m.sym)}</span>
            <span class="num text-gold">≈${F.usd(m.usd)}</span><span class="ml-auto num text-[10px] text-mut">${F.rel(m.ts)}</span></div>
          <div class="flex items-center gap-1.5 text-[11px] mt-1 flex-wrap">
            <a href="#/pair/${from.id}" class="border border-down/40 text-down rounded px-1.5 py-0.5">${F.esc(from.dex)} · ${CDX.Data.CHAINS[from.chain].name}</a>
            <span class="text-mut">→</span>
            <a href="#/pair/${to.id}" class="border border-up/40 text-up rounded px-1.5 py-0.5">${F.esc(to.dex)} · ${CDX.Data.CHAINS[to.chain].name}</a></div></div>`;
      }).join(''))}
      ${panel('LP Events <span class="w-1.5 h-1.5 rounded-full bg-down live-dot inline-block ml-1"></span>', 'live adds & pulls feeding migration detection', evs.map(e => {
        const p = CDX.Data.byKey('d:' + e.pairId);
        if (!p) return '';
        return `<div class="row-hov flex items-center gap-3 px-4 py-2 border-b border-line/40 last:border-0" data-go="/pair/${p.id}" style="cursor:pointer">
          <span class="num text-[10px] text-mut w-12">${F.rel(e.ts)}</span>
          <span class="num text-[10px] font-bold w-14 ${e.type === 'add' ? 'text-up' : 'text-down'}">${e.type === 'add' ? '＋ADD' : '−PULL'}</span>
          <span class="text-sm text-white font-medium">${F.esc(p.base)}<span class="text-mut font-normal">/${F.esc(p.quote)}</span></span>
          ${U.chainBadge(p.chain)}
          <span class="ml-auto num text-sm ${e.delta >= 0 ? 'text-up' : 'text-down'}">${money(e.delta)}</span></div>`;
      }).join(''))}
      ${panel('Cross-Chain Liquidity Flow', 'event-netted · 2h window', cf.map(r => `
        <div class="row-hov flex items-center gap-3 px-4 py-2 border-b border-line/40 last:border-0" data-go="/chain/${r.id}" style="cursor:pointer">
          ${U.chainBadge(r.id)}
          <div class="flex-1">${bar(Math.abs(r.net) / max * 100, r.net >= 0 ? '#2DD480' : '#FF5C5C')}</div>
          <span class="num text-xs w-20 text-right ${r.net >= 0 ? 'text-up' : 'text-down'}">${money(r.net)}</span></div>`).join(''))}
      ${panel('Migration Death Watch', 'pools bleeding into the rotation', L.deathSignals(5).map(({ p, score, drawdown }) => `
        <div class="row-hov flex items-center gap-3 px-4 py-2 border-b border-line/40 last:border-0" data-go="/pair/${p.id}" style="cursor:pointer">
          ${U.logo(p.base, CDX.Data.CHAINS[p.chain].color, 5)}
          <div><div class="text-sm font-medium text-white leading-tight">${F.esc(p.base)}/${F.esc(p.quote)}</div>
          <div class="text-[10px] text-mut">−${drawdown.toFixed(0)}% from session peak · ${F.usd(p.liq)} left</div></div>
          <span class="ml-auto num font-disp font-bold ${score >= 60 ? 'text-down' : 'text-gold'}">☠ ${score}</span></div>`).join(''))}
    </div>`;
  }
  const RENDER = { capital: vCapital, rotation: vRotation, migration: vMigration };
  function paint(){
    D.$('#flTabs', root).innerHTML = VIEWS.map(([id, label]) =>
      `<a href="#/flows/${id}" class="text-xs rounded-lg px-3 py-1.5 border transition-colors ${id === view ? 'bg-acc/15 border-acc/50 text-white' : 'bg-panel border-line text-mut hover:text-white'}">${label}</a>`).join('');
    D.$('#flBody', root).innerHTML = RENDER[view]();
  }
  return {
    mount(el, ctx){
      view = RENDER[ctx.params.view] ? ctx.params.view : 'capital';
      root = el;
      root.innerHTML = `<div class="space-y-4">
        <div class="flex items-center gap-3 flex-wrap">
          <h2 class="font-disp font-semibold text-white text-lg">Capital Flow Engine</h2>
          <div class="flex gap-1.5 flex-wrap" id="flTabs"></div>
          <span class="ml-auto flex items-center gap-1.5 text-[11px] text-mut"><span class="w-2 h-2 rounded-full bg-down live-dot"></span> live flows</span></div>
        <div id="flBody"></div></div>`;
      paint();
      undelegate = D.delegate(root, { '[data-go]': t => CDX.Router.go(t.dataset.go) });
      let n = 0;
      subs.push(CDX.Bus.on('tick', () => { if (++n % 5 === 0) paint(); }));
      subs.push(CDX.Bus.on('liq:event', () => { if (view === 'migration') paint(); }));
      subs.push(CDX.Bus.on('whale:new', () => { if (view !== 'migration') paint(); }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; root=null; }
  };
})();
