/* Page: Chain Intelligence overview. Route: #/chains */
CDX.Pages.chains = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI, I = CDX.Intel;
  let subs = [], root = null, undelegate = null;
  function render(){
    const stats = I.allChains();
    const totTvl = stats.reduce((a,s)=>a+s.tvl,0), totVol = stats.reduce((a,s)=>a+s.dexVol,0);
    const topMom = [...stats].sort((a,b)=>b.flow.momentum-a.flow.momentum)[0];
    const topNew = [...stats].sort((a,b)=>b.newTokens-a.newTokens)[0];
    root.innerHTML = `<div class="space-y-5">
      <h2 class="font-disp font-semibold text-white text-lg">Chain Intelligence</h2>
      <div class="grid grid-cols-2 xl:grid-cols-4 gap-3">
        ${U.statCard('Tracked TVL', F.usd(totTvl), CDX.Data.CHAIN_ORDER.length + ' chains')}
        ${U.statCard('DEX Volume 24h', F.usd(totVol), 'tracked pairs')}
        ${U.statCard('Top Momentum', topMom.chain.name, `score <span class="text-acc num">${topMom.flow.momentum}</span>`)}
        ${U.statCard('Most New Tokens', topNew.chain.name, `<span class="num">${F.num(topNew.newTokens)}</span> / 24h`)}
      </div>
      <div class="bg-panel border border-line rounded-xl overflow-hidden"><div class="overflow-x-auto">
      <table class="w-full text-sm" style="min-width:1100px">
        <thead class="bg-panel2 text-mut text-[11px] uppercase tracking-wider"><tr class="border-b border-line">
          <th class="px-3 py-2.5 text-left">Chain</th><th class="px-3 py-2.5 text-right">Market Cap</th>
          <th class="px-3 py-2.5 text-right">TVL</th><th class="px-3 py-2.5 text-right">DEX Vol 24h</th>
          <th class="px-3 py-2.5 text-right">Active Wallets</th><th class="px-3 py-2.5 text-right">Pairs</th>
          <th class="px-3 py-2.5 text-right">New Tokens 24h</th><th class="px-3 py-2.5 text-right">Net Flow</th>
          <th class="px-3 py-2.5 text-left" style="width:170px">Momentum</th></tr></thead>
        <tbody class="divide-y divide-line/60">${stats.map(s => `
          <tr class="row-hov" data-go="/chain/${s.id}">
            <td class="px-3 py-3">${U.chainBadge(s.id, true)}</td>
            <td class="px-3 py-3 text-right num text-slate-300">${F.usd(s.mcap)}</td>
            <td class="px-3 py-3 text-right num text-slate-300">${F.usd(s.tvl)}</td>
            <td class="px-3 py-3 text-right num text-white">${F.usd(s.dexVol)}</td>
            <td class="px-3 py-3 text-right num text-slate-300">${F.num(s.activeWallets)}</td>
            <td class="px-3 py-3 text-right num text-mut">${s.activePairs}</td>
            <td class="px-3 py-3 text-right num ${s.newTokens > 300 ? 'text-gold' : 'text-slate-300'}">${F.num(s.newTokens)}</td>
            <td class="px-3 py-3 text-right num ${s.flow.netFlow>=0?'text-up':'text-down'}">${(s.flow.netFlow>=0?'+':'−')+F.usd(Math.abs(s.flow.netFlow)).slice(1)}</td>
            <td class="px-3 py-3">${CDX.IntelUI.heatChip(s.flow.momentum)}</td></tr>`).join('')}
        </tbody></table></div></div></div>`;
  }
  return {
    mount(el){ root = el; render();
      undelegate = D.delegate(root, { '[data-go]': t => CDX.Router.go(t.dataset.go) });
      let n = 0;
      subs.push(CDX.Bus.on('tick', () => { if (++n % 4 === 0) render(); }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; root=null; }
  };
})();
