/* Page: Smart Money — surfaces the observable-only SmartMoney engine.
   Premium-gated (CDX.Premium). Every value is derived from real observed trades
   via CDX.SmartMoney; nothing is fabricated. No PnL, no win rate, no labels. */
CDX.Pages.smartMoney = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI;
  let root = null, timer = null, tab = 'wallets';
  const short = a => a ? a.slice(0, 6) + '…' + a.slice(-4) : '—';

  function gateNotice(){
    return `<div class="max-w-xl mx-auto mt-10 bg-panel border border-line rounded-xl p-6 text-center">
      <div class="text-2xl mb-2">✦</div>
      <h2 class="font-disp font-bold text-white text-lg">Smart Money is a Premium feature</h2>
      <p class="text-sm text-mut mt-2">Observable-only wallet intelligence derived from real on-chain trades — conviction scoring, co-trading clusters and sector flow. No fabricated PnL or labels.</p>
      <div class="mt-4 inline-flex items-center gap-2 text-[11px] text-mut border border-line rounded-lg px-3 py-1.5">Current tier: <span class="text-white num">${CDX.Premium ? CDX.Premium.getTier() : 'free'}</span></div>
    </div>`;
  }

  function walletRows(){
    const ws = CDX.SmartMoney.wallets({ minTrades: 2, limit: 40 });
    if (!ws.length) return empty('No wallets with 2+ observed trades yet. Scanning live pools…');
    return ws.map(w => `<tr class="row-hov border-b border-line/40 last:border-0">
      <td class="px-3 py-2.5 num text-[11px]"><a href="${CDX.WhaleFlow.explorerAddr(w.chains[0]||'ethereum', w.wallet)}" target="_blank" rel="noopener" class="text-slate-300 hover:text-acc">${short(w.wallet)} ↗</a></td>
      <td class="px-3 py-2.5"><div class="flex items-center gap-2"><div class="flex-1 max-w-[80px]">${CDX.TrustUI.bar(w.conviction, w.conviction>=60?'#2DD480':w.conviction>=30?'#F5C04E':'#FF5C5C')}</div><span class="num text-xs text-slate-300">${w.conviction}</span></div></td>
      <td class="px-3 py-2.5 text-right num text-xs text-slate-300">${w.trades} <span class="text-mut">(${w.buys}b/${w.sells}s)</span></td>
      <td class="px-3 py-2.5 text-right num text-xs text-mut">${w.repeatTokens}</td>
      <td class="px-3 py-2.5 text-right num text-xs text-slate-300">${F.usd(w.avgTradeUsd)}</td>
      <td class="px-3 py-2.5 text-right text-[10px] text-mut">${w.chains.map(c => U.chainBadge(c)).join(' ')}</td>
      <td class="px-3 py-2.5 text-right text-[10px] text-mut">${w.sectors.slice(0,3).join(', ') || '—'}</td></tr>`).join('');
  }

  function clusterRows(){
    const cs = CDX.SmartMoney.clusters({ limit: 25 });
    if (!cs.length) return empty('No co-trading clusters detected yet — needs ≥2 shared tokens between wallets.');
    return cs.map(c => `<tr class="row-hov border-b border-line/40 last:border-0">
      <td class="px-3 py-2.5 num text-[11px] text-slate-300">${short(c.wallets[0])}</td>
      <td class="px-3 py-2.5 num text-[11px] text-slate-300">${short(c.wallets[1])}</td>
      <td class="px-3 py-2.5 text-right num text-xs text-white">${c.sharedTokens}</td>
      <td class="px-3 py-2.5"><div class="max-w-[120px]">${CDX.TrustUI.bar(c.strength, '#5B8CFF')}</div></td></tr>`).join('');
  }

  function sectorRows(){
    const ss = CDX.SmartMoney.sectors();
    if (!ss.length) return empty('No sector flow observed yet.');
    return ss.map(s => `<tr class="row-hov border-b border-line/40 last:border-0">
      <td class="px-3 py-2.5 text-sm text-slate-200 capitalize">${F.esc(s.sector)}</td>
      <td class="px-3 py-2.5 text-right num text-xs text-up">${F.usd(s.inflow)}</td>
      <td class="px-3 py-2.5 text-right num text-xs text-down">${F.usd(s.outflow)}</td>
      <td class="px-3 py-2.5 text-right num text-xs ${s.net>=0?'text-up':'text-down'}">${(s.net>=0?'+':'−')+F.usd(Math.abs(s.net)).slice(1)}</td>
      <td class="px-3 py-2.5 text-right num text-xs text-mut">${F.usd(s.volume)}</td></tr>`).join('');
  }

  const empty = msg => `<tr><td colspan="7" class="px-4 py-8 text-center text-sm text-mut">${msg}</td></tr>`;

  function table(){
    if (tab === 'wallets') return `<table class="w-full text-left"><thead><tr class="text-[10px] uppercase tracking-wide text-mut border-b border-line">
      <th class="px-3 py-2">Wallet</th><th class="px-3 py-2">Conviction</th><th class="px-3 py-2 text-right">Trades</th>
      <th class="px-3 py-2 text-right">Repeat tokens</th><th class="px-3 py-2 text-right">Avg size</th>
      <th class="px-3 py-2 text-right">Chains</th><th class="px-3 py-2 text-right">Sectors</th></tr></thead><tbody>${walletRows()}</tbody></table>`;
    if (tab === 'clusters') return `<table class="w-full text-left"><thead><tr class="text-[10px] uppercase tracking-wide text-mut border-b border-line">
      <th class="px-3 py-2">Wallet A</th><th class="px-3 py-2">Wallet B</th><th class="px-3 py-2 text-right">Shared tokens</th><th class="px-3 py-2">Strength</th></tr></thead><tbody>${clusterRows()}</tbody></table>`;
    return `<table class="w-full text-left"><thead><tr class="text-[10px] uppercase tracking-wide text-mut border-b border-line">
      <th class="px-3 py-2">Sector</th><th class="px-3 py-2 text-right">Inflow</th><th class="px-3 py-2 text-right">Outflow</th>
      <th class="px-3 py-2 text-right">Net</th><th class="px-3 py-2 text-right">Volume</th></tr></thead><tbody>${sectorRows()}</tbody></table>`;
  }

  function paint(){ const h = root && D.$('#smBody', root); if (h) h.innerHTML = table(); }

  function render(){
    root.innerHTML = `<div class="max-w-5xl mx-auto px-3 sm:px-4 py-4 space-y-4">
      <div class="flex items-center gap-2 flex-wrap">
        <h1 class="font-disp text-xl font-bold text-white">Smart Money</h1>
        <span class="text-[10px] num border border-acc/40 text-acc rounded px-1.5 py-0.5">observed-only</span>
        <span class="text-[10px] num border border-line text-mut rounded px-1.5 py-0.5">no PnL · no labels</span></div>
      <p class="text-[12px] text-mut">Derived entirely from real on-chain trades observed this session. Conviction is a transparent function of repeated buys, repeat tokens, multi-chain activity and size — not a prediction.</p>
      <div class="flex gap-2">${[['wallets','Wallets'],['clusters','Clusters'],['sectors','Sector flow']].map(([id,l])=>`<button data-smtab="${id}" class="px-3 py-1.5 rounded-lg text-xs border ${tab===id?'border-acc text-acc bg-acc/10':'border-line text-slate-300 hover:border-acc/40'}">${l}</button>`).join('')}</div>
      <div class="bg-panel border border-line rounded-xl overflow-x-auto" id="smBody">${table()}</div>
      <p class="text-[10px] text-mut text-center">Bounded to the live whale buffer (large trades, this session). Not a complete account of any wallet.</p></div>`;
    undelegate = D.delegate(root, { '[data-smtab]': t => { tab = t.dataset.smtab; render(); } });
  }
  let undelegate = null;

  return {
    mount(el){
      root = el;
      if (CDX.Premium && !CDX.Premium.gate('smartMoney')){ root.innerHTML = gateNotice(); return; }
      if (CDX.WhaleFlow && CDX.WhaleFlow.start) try { CDX.WhaleFlow.start(); } catch(e){}
      render();
      timer = setInterval(paint, 5000);
    },
    unmount(){ if (timer) clearInterval(timer); timer = null; if (undelegate) undelegate(); undelegate = null; root = null; }
  };
})();
