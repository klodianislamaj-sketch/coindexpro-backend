/* Page: Deploy Smoke Test — hidden at #/smoke (not in nav).
   Runs live self-checks against real runtime state and reports PASS/FAIL per
   subsystem. Intended to be opened immediately after deploy. Read-only; it
   never mutates data, only inspects what the app has actually loaded. */
CDX.Pages.smoke = (() => {
  const D = CDX.Dom, F = CDX.Fmt, A = CDX.Asset;
  let root = null, timer = null;

  /* each check returns { name, pass, detail } — pass=null means "still warming up" */
  function checks(){
    const out = [];
    const pairs = CDX.Data.pairs || [];
    const coins = CDX.Data.coins || [];

    // 1 · PRICES — at least some pairs have a valid live price via the normalized layer
    const priced = pairs.filter(p => { const a = A.resolve('d:' + p.id); return a && a.valid && a.price != null; });
    out.push({ name: 'Prices', pass: priced.length > 0,
      detail: `${priced.length}/${pairs.length} pairs resolve to a valid live price` });

    // 2 · NO STALE-SEED LEAK — WPLS/INC/PLSX should not sit exactly on seed values
    const seedWatch = [['WPLS', 0.0000065], ['INC', 0.1482], ['PLSX', 0.000005542]];
    const leaks = seedWatch.filter(([sym, seed]) => {
      const p = pairs.find(x => x.base === sym && x.price > 0);
      return p && Math.abs(p.price - seed) < seed * 1e-6;   // still pinned to seed
    }).map(x => x[0]);
    out.push({ name: 'No stale-seed leak', pass: leaks.length === 0,
      detail: leaks.length ? `still on seed: ${leaks.join(', ')} (may be pre-hydration)` : 'WPLS/INC/PLSX moved off seed' });

    // 3 · CHARTS — chart component + sanitizer present and callable
    out.push({ name: 'Charts', pass: !!(CDX.Chart && typeof CDX.Chart.create === 'function'),
      detail: CDX.Chart ? 'chart engine present' : 'chart engine missing' });

    // 4 · WHALES — engine present + (warming) feed reachable
    const wfOk = !!(CDX.WhaleFlow && typeof CDX.WhaleFlow.feed === 'function');
    const wfN = wfOk ? CDX.WhaleFlow.feed(10000, { limit: 50 }).length : 0;
    out.push({ name: 'Whales', pass: wfOk ? true : false,
      detail: wfOk ? `engine live · ${wfN} prints buffered${wfN === 0 ? ' (warming)' : ''}` : 'whale engine missing' });

    // 5 · LIQUIDITY — engine present + correct empty-vs-flow state
    const liqOk = !!(CDX.Liq && typeof CDX.Liq.hasFlow === 'function');
    out.push({ name: 'Liquidity', pass: liqOk,
      detail: liqOk ? (CDX.Liq.hasFlow() ? 'flow events present' : 'building state (no events yet) — correct') : 'liquidity engine missing' });

    // 6 · NEWS — feed produces items, single route
    const newsN = (CDX.News && CDX.News.all && CDX.News.all().length) || 0;
    out.push({ name: 'News', pass: newsN > 0, detail: `${newsN} headlines in feed` });

    // 7 · CHAINS — every active chain has at least one priced pair
    const order = CDX.Data.CHAIN_ORDER || [];
    const dead = order.filter(id => !pairs.some(p => p.chain === id && p.price > 0));
    out.push({ name: 'Chains', pass: dead.length < order.length,
      detail: dead.length ? `${order.length - dead.length}/${order.length} chains priced (${dead.join(',')} warming)` : `all ${order.length} chains priced` });

    // 8 · NORMALIZED LAYER — Asset.resolve returns the unified shape
    const sample = pairs[0] ? A.resolve('d:' + pairs[0].id) : null;
    const shapeOk = sample && ['price','volume24h','liquidity','marketCap','fdv','holders',
      'pairAddress','tokenAddress','chain','timestamp','source','stale','valid']
      .every(k => k in sample);
    out.push({ name: 'Normalized layer', pass: !!shapeOk,
      detail: shapeOk ? 'Asset.resolve returns unified object' : 'unified shape not resolving' });

    return out;
  }

  function row(c){
    const state = c.pass === null ? ['bg-gold', 'text-gold', 'WARMING']
                : c.pass ? ['bg-up', 'text-up', 'PASS'] : ['bg-down', 'text-down', 'FAIL'];
    return `<div class="flex items-center gap-3 px-4 py-2.5 border-b border-line/40 last:border-0">
      <span class="w-2 h-2 rounded-full ${state[0]} shrink-0"></span>
      <span class="font-medium text-slate-200 text-sm w-40">${F.esc(c.name)}</span>
      <span class="num text-[10px] ${state[1]} uppercase tracking-wide w-16">${state[2]}</span>
      <span class="text-[11px] text-mut flex-1">${F.esc(c.detail)}</span></div>`;
  }

  function paint(){
    if (!root) return;
    const cs = checks();
    const passed = cs.filter(c => c.pass === true).length;
    const failed = cs.filter(c => c.pass === false).length;
    const verdict = failed === 0 ? ['SAFE', 'text-up', 'bg-up/10 border-up/40']
                                 : ['CHECK FAILURES', 'text-down', 'bg-down/10 border-down/40'];
    const hdr = D.$('#smVerdict', root), body = D.$('#smBody', root);
    if (hdr) hdr.innerHTML = `<div class="rounded-xl border ${verdict[2]} px-4 py-3 flex items-center gap-3">
      <span class="font-disp font-bold text-lg ${verdict[1]}">${verdict[0]}</span>
      <span class="num text-sm text-slate-300">${passed} pass · ${failed} fail</span>
      <span class="ml-auto text-[10px] text-mut">re-runs every 4s</span></div>`;
    if (body) body.innerHTML = cs.map(row).join('');
  }

  return {
    mount(el){
      root = el;
      root.innerHTML = `<div class="max-w-3xl mx-auto px-3 sm:px-4 py-4 space-y-4">
        <div><h1 class="font-disp text-xl font-bold text-white">Deploy Smoke Test</h1>
        <p class="text-[12px] text-mut">Live self-checks across prices, charts, whales, liquidity, news, chains and the normalized layer. Open right after deploy. WARMING is expected for the first ~30s.</p></div>
        <div id="smVerdict"></div>
        <div class="bg-panel border border-line rounded-xl overflow-hidden" id="smBody"></div></div>`;
      paint();
      timer = setInterval(paint, 4000);
    },
    unmount(){ if (timer) clearInterval(timer); timer = null; root = null; }
  };
})();
