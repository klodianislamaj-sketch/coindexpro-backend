/* Page: Research Suite — news intelligence, sentiment, catalysts, commentary, related assets, notes.
   Route: #/research */
CDX.Pages.research = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI, R = CDX.Research, S = CDX.Store, V = CDX.Viz;
  let subs = [], root = null, undelegate = null;
  let newsFilter = 'all', relKey = 'c:pls', editing = null;

  /* ---- news intelligence ---- */
  function newsRow(n){
    const it = CDX.Data.byKey(n.tag);
    const dot = n.kind === 'bull' ? 'bg-up' : n.kind === 'bear' ? 'bg-down' : 'bg-acc';
    return `<div class="row-hov flex items-start gap-3 px-4 py-3 border-b border-line/50 last:border-0" ${it ? `data-go="${it.sym ? '/token/' + it.id : '/pair/' + it.id}"` : ''}>
      <span class="mt-1.5 w-1.5 h-1.5 rounded-full ${dot} shrink-0"></span>
      <div class="min-w-0 flex-1"><div class="text-sm text-slate-200 leading-snug">${n.h}</div>
      <div class="flex items-center gap-2 text-[11px] text-mut mt-1">
        <span class="font-medium text-slate-400">${n.src}</span> · <span>${F.rel(n.ts)}</span>
        ${it ? `<span class="ml-1 text-[10px] border border-line rounded px-1.5 py-px text-slate-300">${F.esc(CDX.Data.label(it))} <span class="num ${F.cls(CDX.Data.ch24(it))}">${F.pctAuto(CDX.Data.ch24(it))}</span></span>` : ''}</div></div></div>`;
  }
  function newsPanel(){
    const items = CDX.News.all().filter(n => newsFilter === 'all' || n.kind === newsFilter);
    const all = CDX.News.all();
    const counts = { bull: all.filter(n=>n.kind==='bull').length, bear: all.filter(n=>n.kind==='bear').length, neut: all.filter(n=>n.kind==='neut').length };
    return `<div class="flex items-center gap-1.5 px-4 py-2.5 border-b border-line">
        ${[['all','All ' + all.length],['bull',`<span class="text-up">▲ ${counts.bull}</span>`],['bear',`<span class="text-down">▼ ${counts.bear}</span>`],['neut','◆ ' + counts.neut]]
          .map(([id, label]) => `<button data-nf="${id}" class="text-xs rounded-lg px-2.5 py-1 border ${newsFilter === id ? 'bg-acc/15 border-acc/50 text-white' : 'bg-panel2 border-line text-mut hover:text-white'}">${label}</button>`).join('')}
        <span class="ml-auto text-[10px] text-mut">news score <span class="num text-white">${R.newsScore(all)}</span>/100</span></div>
      <div class="max-h-[460px] overflow-y-auto" id="rsNews">${items.map(newsRow).join('')}</div>`;
  }
  /* ---- sentiment ---- */
  function sentimentPanel(){
    const m = R.marketSentiment();
    const color = m.value >= 55 ? '#2DD480' : m.value >= 45 ? '#F5C04E' : '#FF5C5C';
    const ns = R.narrativeSentiment().sort((a,b)=>b.news-a.news);
    return `${V.gauge(m.value, m.label, color)}
      <div class="grid grid-cols-3 gap-2 mt-2 mb-4 text-center">
        ${[['Fear & Greed', m.parts.fearGreed], ['News Flow', m.parts.news], ['Chain Momentum', m.parts.flow]]
          .map(([l, v]) => `<div class="bg-panel2 border border-line rounded-lg py-2">
            <div class="num text-white font-medium">${v}</div><div class="text-[9px] uppercase tracking-wider text-mut">${l}</div></div>`).join('')}</div>
      <div class="space-y-1.5">${ns.map(n => `<div class="flex items-center gap-2 text-[12px] row-hov rounded px-1.5 py-1" data-go="/narrative/${n.id}">
        <span class="font-medium" style="color:${n.color}">${n.name}</span>
        <span class="text-[10px] text-mut">${n.nItems} stories</span>
        <span class="ml-auto">${CDX.IntelUI.heatChip(n.news)}</span></div>`).join('')}</div>`;
  }
  /* ---- catalysts ---- */
  function catalystsPanel(){
    const IMPACT = { high: ['HIGH', 'down'], med: ['MED', 'gold'], low: ['LOW', 'acc'] };
    const KIND = { macro: '🏛', unlock: '🔓', upgrade: '⚙️', listing: '📈', event: '📅' };
    return R.catalysts().map(c => {
      const it = CDX.Data.byKey(c.tag);
      const d = new Date(c.ts);
      return `<div class="row-hov flex items-start gap-3 px-4 py-2.5 border-b border-line/50 last:border-0" ${it ? `data-go="${it.sym ? '/token/' + it.id : '/pair/' + it.id}"` : ''}>
        <div class="text-center shrink-0 w-11 bg-panel2 border border-line rounded-lg py-1">
          <div class="text-[9px] uppercase text-mut">${d.toLocaleString('en-US',{month:'short'})}</div>
          <div class="num text-white font-semibold text-sm leading-none">${d.getDate()}</div></div>
        <div class="min-w-0 flex-1"><div class="text-sm text-slate-200 leading-snug">${KIND[c.kind] || ''} ${c.title}</div>
          <div class="flex items-center gap-2 mt-1 text-[11px] text-mut">
            <span>in ${c.inDays}d</span>${U.badge(IMPACT[c.impact][0] + ' IMPACT', IMPACT[c.impact][1])}
            ${it ? `<span class="text-slate-300">${F.esc(CDX.Data.label(it))}</span>` : ''}</div></div></div>`;
    }).join('');
  }
  /* ---- commentary ---- */
  function commentaryPanel(){
    return R.commentary().map(c => `<div class="ai-card rounded-xl p-4">
      <div class="text-[10px] uppercase tracking-wider font-semibold mb-1.5" style="color:${c.color}">${c.tag}</div>
      <p class="text-[12.5px] leading-relaxed text-mut">${c.body}</p></div>`).join('');
  }
  /* ---- related assets ---- */
  function relatedPanel(){
    const base = CDX.Data.byKey(relKey);
    const rel = R.related(relKey, 8);
    return `<div class="flex items-center gap-2 px-4 py-2.5 border-b border-line">
        <span class="text-[11px] text-mut shrink-0">Related to</span>
        <span class="text-sm font-medium text-white">${base ? F.esc(CDX.Data.label(base)) : '—'}</span>
        <div class="relative ml-auto w-44">
          <input data-relq placeholder="Change asset…" autocomplete="off" class="w-full bg-panel2 border border-line rounded-lg px-2.5 py-1 text-xs placeholder:text-mut/70 focus:border-acc/60 focus:outline-none">
          <div data-relres class="hidden absolute top-full mt-1 right-0 w-60 bg-panel border border-line rounded-xl shadow-2xl shadow-black/60 overflow-hidden z-30"></div></div></div>
      ${rel.map(x => {
        const isCoin = !!x.it.sym;
        return `<div class="row-hov flex items-center gap-3 px-4 py-2.5 border-b border-line/50 last:border-0" data-go="${isCoin ? '/token/' + x.it.id : '/pair/' + x.it.id}">
          ${U.logo(isCoin ? x.it.sym : x.it.base, isCoin ? x.it.color : CDX.Data.CHAINS[x.it.chain].color, 6)}
          <span class="text-sm font-medium text-white">${F.esc(CDX.Data.label(x.it))}</span>
          ${(x.it.tags || []).slice(0, 2).map(t => `<span class="text-[9px] border rounded px-1 py-px" style="color:${CDX.DataRaw.NARRATIVES[t].color};border-color:${CDX.DataRaw.NARRATIVES[t].color}55">${CDX.DataRaw.NARRATIVES[t].name}</span>`).join('')}
          <span class="ml-auto flex items-center gap-3">
            <span class="num text-[10px] text-mut">match ${(x.score * 12).toFixed(0)}</span>
            <span class="num text-sm ${F.cls(CDX.Data.ch24(x.it))}">${F.pctAuto(CDX.Data.ch24(x.it))}</span></span></div>`;
      }).join('') || '<div class="px-4 py-6 text-sm text-mut">No strong correlations found.</div>'}`;
  }
  /* ---- research notes ---- */
  function notesPanel(){
    if (editing){
      const linked = editing.tag ? CDX.Data.byKey(editing.tag) : null;
      return `<div class="p-4 space-y-2.5">
        <input data-nt-title value="${F.esc(editing.title || '')}" placeholder="Note title…" class="w-full bg-panel2 border border-line rounded-lg px-3 py-2 text-sm text-white focus:border-acc/60 focus:outline-none">
        <div class="relative">
          <input data-nt-asset value="${linked ? F.esc(CDX.Data.label(linked)) : ''}" placeholder="Link an asset (optional)…" autocomplete="off" class="w-full bg-panel2 border border-line rounded-lg px-3 py-2 text-xs text-white focus:border-acc/60 focus:outline-none">
          <div data-nt-res class="hidden absolute top-full mt-1 left-0 right-0 bg-panel border border-line rounded-xl shadow-2xl shadow-black/60 overflow-hidden z-30"></div></div>
        <textarea data-nt-body rows="6" placeholder="Thesis, levels, invalidation, catalysts…" class="w-full bg-panel2 border border-line rounded-lg px-3 py-2 text-sm text-slate-200 focus:border-acc/60 focus:outline-none">${F.esc(editing.body || '')}</textarea>
        <div class="flex gap-2">
          <button data-nt-save class="text-xs bg-acc/15 border border-acc/50 text-white rounded-lg px-3 py-1.5 hover:bg-acc/25">Save note</button>
          <button data-nt-cancel class="text-xs bg-panel border border-line text-mut rounded-lg px-3 py-1.5 hover:text-white">Cancel</button>
          ${editing.id ? '<button data-nt-del class="ml-auto text-xs text-mut hover:text-down">Delete</button>' : ''}</div></div>`;
    }
    const notes = S.state.notes;
    return `<div class="px-4 py-2.5 border-b border-line">
        <button data-nt-new class="text-xs bg-acc/15 border border-acc/50 text-white rounded-lg px-3 py-1.5 hover:bg-acc/25">+ New note</button></div>
      ${notes.length ? notes.map(n => {
        const it = n.tag ? CDX.Data.byKey(n.tag) : null;
        return `<div class="row-hov px-4 py-3 border-b border-line/50 last:border-0" data-nt-edit="${n.id}" style="cursor:pointer">
          <div class="flex items-center gap-2">
            <span class="text-sm font-medium text-white">${F.esc(n.title || 'Untitled')}</span>
            ${it ? `<span class="text-[10px] border border-line rounded px-1.5 py-px text-slate-300">${F.esc(CDX.Data.label(it))}</span>` : ''}
            <span class="ml-auto text-[10px] text-mut">${F.rel(n.updated)}</span></div>
          <div class="text-[12px] text-mut mt-1 line-clamp-2">${F.esc((n.body || '').slice(0, 180))}</div></div>`;
      }).join('') : '<div class="px-4 py-8 text-center text-sm text-mut">No notes yet. Document a thesis before you trade it.</div>'}`;
  }
  const card = (title, body, extra) => `<div class="bg-panel border border-line rounded-xl overflow-hidden">
    <div class="flex items-center justify-between px-4 py-3 border-b border-line">
      <h3 class="font-disp font-semibold text-white">${title}</h3>${extra || ''}</div>${body}</div>`;

  function render(){
    root.innerHTML = `<div class="space-y-4">
      <div class="flex items-center gap-3 flex-wrap">
        <h2 class="font-disp font-semibold text-white text-lg">Research Suite</h2>
        <span class="flex items-center gap-1.5 text-[11px] text-mut"><span class="w-2 h-2 rounded-full bg-down live-dot"></span> live intelligence</span>
        <button data-refresh class="ml-auto text-xs flex items-center gap-1.5 bg-panel border border-line hover:border-acc/50 rounded-lg px-3 py-1.5 text-mut hover:text-white transition-colors">↻ Refresh commentary</button></div>
      <div class="grid lg:grid-cols-3 gap-4">
        <div class="bg-panel border border-line rounded-xl p-4">
          <h3 class="font-disp font-semibold text-white mb-1">Market Sentiment</h3>
          <div id="rsSent">${sentimentPanel()}</div></div>
        <div class="lg:col-span-2 space-y-4">
          <div class="grid sm:grid-cols-3 gap-3" id="rsComment">${commentaryPanel()}</div>
          ${card('Catalyst Calendar <span class="text-mut text-xs font-body font-normal">next 30 days</span>', `<div class="max-h-[330px] overflow-y-auto">${catalystsPanel()}</div>`)}</div></div>
      <div class="grid lg:grid-cols-3 gap-4">
        <div class="lg:col-span-1">${card('News Intelligence <span class="w-1.5 h-1.5 rounded-full bg-down live-dot inline-block ml-1"></span>', `<div id="rsNewsWrap">${newsPanel()}</div>`)}</div>
        <div class="lg:col-span-1">${card('Related Assets', `<div id="rsRel">${relatedPanel()}</div>`)}</div>
        <div class="lg:col-span-1">${card('Research Notes <span class="text-mut text-xs font-body font-normal">private · saved locally</span>', `<div id="rsNotes">${notesPanel()}</div>`)}</div></div></div>`;
    bindTypeaheads();
  }
  function bindTypeaheads(){
    const rq = root.querySelector('[data-relq]'), rres = root.querySelector('[data-relres]');
    if (rq) rq.addEventListener('input', () => {
      const v = rq.value.trim();
      if (!v){ rres.classList.add('hidden'); return; }
      rres.innerHTML = CDX.Data.search(v, 6).map(h => `<button data-relpick="${h.key}" class="w-full text-left px-3 py-2 hover:bg-panel2 text-xs text-white">${F.esc(CDX.Data.label(h.it))} <span class="text-mut">${F.esc(h.it.name)}</span></button>`).join('');
      rres.classList.remove('hidden');
    });
    if (rq) rq.addEventListener('blur', () => setTimeout(() => rres.classList.add('hidden'), 160));
    const nq = root.querySelector('[data-nt-asset]'), nres = root.querySelector('[data-nt-res]');
    if (nq) nq.addEventListener('input', () => {
      const v = nq.value.trim();
      if (!v){ nres.classList.add('hidden'); editing.tag = null; return; }
      nres.innerHTML = CDX.Data.search(v, 6).map(h => `<button data-ntpick="${h.key}" class="w-full text-left px-3 py-2 hover:bg-panel2 text-xs text-white">${F.esc(CDX.Data.label(h.it))}</button>`).join('');
      nres.classList.remove('hidden');
    });
    if (nq) nq.addEventListener('blur', () => setTimeout(() => nres.classList.add('hidden'), 160));
  }
  function repaint(sel, html){ const el = D.$(sel, root); if (el) el.innerHTML = html; }
  return {
    mount(el){
      root = el; render();
      undelegate = D.delegate(root, {
        '[data-nf]': t => { newsFilter = t.dataset.nf; repaint('#rsNewsWrap', newsPanel()); },
        '[data-refresh]': () => { repaint('#rsComment', commentaryPanel()); U.toast('Commentary refreshed', 'up'); },
        '[data-relpick]': t => { relKey = t.dataset.relpick; repaint('#rsRel', relatedPanel()); bindTypeaheads(); },
        '[data-nt-new]': () => { editing = { title: '', body: '', tag: null }; repaint('#rsNotes', notesPanel()); bindTypeaheads(); },
        '[data-nt-edit]': t => { editing = { ...S.state.notes.find(n => n.id === t.dataset.ntEdit) }; repaint('#rsNotes', notesPanel()); bindTypeaheads(); },
        '[data-ntpick]': t => { editing.tag = t.dataset.ntpick; const q = root.querySelector('[data-nt-asset]'); q.value = CDX.Data.label(CDX.Data.byKey(editing.tag)); root.querySelector('[data-nt-res]').classList.add('hidden'); },
        '[data-nt-save]': () => {
          editing.title = root.querySelector('[data-nt-title]').value.trim();
          editing.body  = root.querySelector('[data-nt-body]').value;
          if (!editing.title && !editing.body){ U.toast('Write something first.', 'warn'); return; }
          S.saveNote(editing); editing = null; repaint('#rsNotes', notesPanel()); U.toast('Note saved', 'up');
        },
        '[data-nt-cancel]': () => { editing = null; repaint('#rsNotes', notesPanel()); },
        '[data-nt-del]': () => { S.deleteNote(editing.id); editing = null; repaint('#rsNotes', notesPanel()); U.toast('Note deleted'); },
        '[data-go]': t => CDX.Router.go(t.dataset.go)
      });
      subs.push(CDX.Bus.on('news:changed', () => { if (!editing){ repaint('#rsNewsWrap', newsPanel()); } }));
      let n = 0;
      subs.push(CDX.Bus.on('tick', () => { if (++n % 6 === 0 && !editing){ repaint('#rsSent', sentimentPanel()); } }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; root=null; editing=null; }
  };
})();
