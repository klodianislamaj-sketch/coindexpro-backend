/* Page: Narrative Intelligence overview. Route: #/narratives */
CDX.Pages.narratives = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI, I = CDX.Intel, IU = CDX.IntelUI;
  let subs = [], root = null, undelegate = null;
  function card(n){
    const top = [...n.coins].sort((a,b)=>b.mcap-a.mcap).slice(0,3);
    const pls = n.id === 'pulsechain';
    return `<div class="rounded-xl border ${pls?'border-pls/50 pls-ring bg-gradient-to-br from-pls/10 to-plx/10':'border-line bg-panel hover:border-acc/40'} p-4 cursor-pointer transition-colors" data-go="/narrative/${n.id}">
      <div class="flex items-center justify-between mb-2">
        <span class="font-disp font-semibold text-white" style="color:${pls?'':n.color}">${n.name}</span>
        <span class="flex items-center -space-x-1.5">${top.map(c=>U.logo(c.sym, c.color, 6)).join('')}</span></div>
      <div class="grid grid-cols-2 gap-x-3 gap-y-1.5 text-[12px] mb-3">
        <div class="text-mut">Market Cap</div><div class="num text-right text-slate-200">${F.usd(n.mcap)}</div>
        <div class="text-mut">24h</div><div class="num text-right ${F.cls(n.wCh24)}">${F.pct(n.wCh24)}</div>
        <div class="text-mut">7d</div><div class="num text-right ${F.cls(n.wCh7d)}">${F.pct(n.wCh7d)}</div>
        <div class="text-mut">Volume</div><div class="num text-right text-slate-200">${F.usd(n.vol)}</div>
        <div class="text-mut">Assets</div><div class="num text-right text-slate-200">${n.coins.length} + ${n.pairs.length} pairs</div>
        <div class="text-mut">Net Flow</div><div class="num text-right ${n.flow.netFlow>=0?'text-up':'text-down'}">${(n.flow.netFlow>=0?'+':'−')+F.usd(Math.abs(n.flow.netFlow)).slice(1)}</div></div>
      <div class="flex items-center justify-between">
        <span class="text-[10px] uppercase tracking-wider text-mut">Narrative Heat</span>
        <span>${IU.heatChip(n.heat)}</span></div></div>`;
  }
  function render(){
    const ns = I.allNarratives();
    const hottest = [...ns].sort((a,b)=>b.heat-a.heat)[0];
    const flows = [...ns].sort((a,b)=>b.flow.netFlow-a.flow.netFlow);
    root.innerHTML = `<div class="space-y-5">
      <h2 class="font-disp font-semibold text-white text-lg">Narrative Intelligence</h2>
      <div class="grid grid-cols-2 xl:grid-cols-4 gap-3">
        ${U.statCard('Hottest Narrative', hottest.name, `heat <span class="num text-acc">${hottest.heat}</span>`)}
        ${U.statCard('Strongest Inflow', flows[0].name, `<span class="num text-up">+${F.usd(Math.max(0,flows[0].flow.netFlow)).slice(1)}</span> net`)}
        ${U.statCard('Heaviest Outflow', flows[flows.length-1].name, `<span class="num text-down">−${F.usd(Math.abs(Math.min(0,flows[flows.length-1].flow.netFlow))).slice(1)}</span> net`)}
        ${U.statCard('Narratives Tracked', ns.length, 'across ' + CDX.Data.CHAIN_ORDER.length + ' chains')}
      </div>
      <div class="grid sm:grid-cols-2 xl:grid-cols-3 gap-4" id="narrGrid">${ns.map(card).join('')}</div></div>`;
  }
  return {
    mount(el){ root = el; render();
      undelegate = D.delegate(root, { '[data-go]': t => CDX.Router.go(t.dataset.go) });
      let n = 0;
      subs.push(CDX.Bus.on('tick', () => { if (++n % 5 === 0) render(); }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; root=null; }
  };
})();
