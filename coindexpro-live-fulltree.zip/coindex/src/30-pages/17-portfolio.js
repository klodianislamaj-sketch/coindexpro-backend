/* Page: Portfolio — holdings, PnL, allocation, performance, watchlist integration. Route: #/portfolio */
CDX.Pages.portfolio = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI, S = CDX.Store, V = CDX.Viz;
  let subs = [], root = null, undelegate = null, chart = null, series = null, ro = null;
  let range = 90;
  const PALETTE = ['#5B8CFF','#FF0080','#2DD480','#F5C04E','#9B5CFF','#FF7849','#2D9CDB','#FF5C5C','#14F195','#F0B90B'];

  const rows = () => S.state.holdings.map(h => {
    const it = CDX.Data.byKey(h.key);
    if (!it) return null;
    const value = it.price * h.amount, cost = h.avg * h.amount, ch = CDX.Data.ch24(it);
    return { ...h, it, value, cost, pnl: value - cost, pnlPct: cost ? (value - cost) / cost * 100 : 0,
             ch24: ch, day: value - value / (1 + ch / 100) };
  }).filter(Boolean);
  const totalOf = rs => rs.reduce((a,r)=>a+r.value,0);
  const money = (v, signed) => (signed ? (v >= 0 ? '+' : '−') : '') + '$' + Math.abs(v).toLocaleString('en-US',{minimumFractionDigits:2, maximumFractionDigits:2});

  /* deterministic relative performance path, rescaled to live total */
  const relPath = (() => {
    const rnd = F.mulberry32(4242);
    const pts = []; let v = 0.74;
    for (let i = 0; i < 90; i++){ v *= 1 + (rnd() - 0.455) * 0.04; pts.push(v); }
    const last = pts[89];
    return pts.map(p => p / last);                      // ends at 1.0
  })();
  function perfData(total){
    const day0 = Math.floor(Date.now() / 864e5) * 86400;
    return relPath.slice(90 - range).map((m, i) => ({ time: day0 - (range - 1 - i) * 86400, value: +(m * total).toFixed(2) }));
  }
  function mountChart(total){
    const host = D.$('#pfChart', root);
    if (typeof LightweightCharts === 'undefined'){ host.innerHTML = '<div class="h-full grid place-items-center text-mut text-sm">Chart engine unavailable.</div>'; return; }
    chart = LightweightCharts.createChart(host, {
      width: host.clientWidth, height: 250,
      layout: { background: { color: 'transparent' }, textColor: '#8B94A7', fontFamily: "'JetBrains Mono',monospace", fontSize: 10 },
      grid: { vertLines: { color: '#161B27' }, horzLines: { color: '#161B27' } },
      rightPriceScale: { borderColor: '#1F2633' },
      timeScale: { borderColor: '#1F2633' }
    });
    series = chart.addAreaSeries({ lineColor: '#5B8CFF', topColor: 'rgba(91,140,255,.25)', bottomColor: 'rgba(91,140,255,0)',
      lineWidth: 2, priceFormat: { type: 'price', precision: 2, minMove: 0.01 } });
    series.setData(perfData(total));
    chart.timeScale().fitContent();
    ro = new ResizeObserver(() => chart && chart.applyOptions({ width: host.clientWidth }));
    ro.observe(host);
  }
  function allocation(rs, by){
    const groups = new Map();
    for (const r of rs){
      const k = by === 'chain' ? (CDX.Data.CHAINS[r.it.chain] ? CDX.Data.CHAINS[r.it.chain].name : 'Other')
              : by === 'narrative' ? ((r.it.tags && r.it.tags[0]) ? CDX.DataRaw.NARRATIVES[r.it.tags[0]].name : 'Other')
              : CDX.Data.label(r.it);
      groups.set(k, (groups.get(k) || 0) + r.value);
    }
    return [...groups.entries()].sort((a,b)=>b[1]-a[1])
      .map(([label, value], i) => ({ label, value, color: PALETTE[i % PALETTE.length] }));
  }
  function holdingRow(r){
    return `<tr class="row-hov" data-go="${r.it.sym ? '/token/' + r.it.id : '/pair/' + r.it.id}">
      <td class="px-4 py-3"><div class="flex items-center gap-2.5">${U.logo(r.it.sym || r.it.base, r.it.color || CDX.Data.CHAINS[r.it.chain].color)}
        <div><div class="font-medium text-white">${F.esc(CDX.Data.label(r.it))}</div>
        <div class="text-[11px] text-mut">${F.esc(r.it.name)}</div></div></div></td>
      <td class="px-4 py-3 text-right num text-slate-300">${F.num(r.amount)}</td>
      <td class="px-4 py-3 text-right num text-mut">${F.price(r.avg)}</td>
      <td class="px-4 py-3 text-right num text-white" data-live="pf:${r.key}">${F.price(r.it.price)}</td>
      <td class="px-4 py-3 text-right num text-white">${F.usd(r.value)}</td>
      <td class="px-4 py-3 text-right num ${r.pnl >= 0 ? 'text-up' : 'text-down'}">${money(r.pnl, 1)}<span class="text-[11px] opacity-80"> (${F.pct(r.pnlPct, 1)})</span></td>
      <td class="px-4 py-3 text-right num text-mut" data-w="${r.key}"></td>
      <td class="px-4 py-3 text-right whitespace-nowrap">
        <button data-trade="buy:${r.key}" class="text-xs bg-up/15 text-up border border-up/40 rounded px-2 py-1 hover:bg-up/25">Buy</button>
        <button data-trade="sell:${r.key}" class="text-xs bg-down/15 text-down border border-down/40 rounded px-2 py-1 hover:bg-down/25 ml-1">Sell</button>
        <button data-rmh="${r.key}" class="text-xs text-mut hover:text-down ml-1 px-1" title="Remove position">✕</button></td></tr>`;
  }
  function watchPanel(rs){
    const held = new Set(rs.map(r => r.key));
    const list = S.state.lists.find(l => l.id === S.state.activeList);
    const cand = list.keys.filter(k => !held.has(k)).map(k => ({ k, it: CDX.Data.byKey(k) })).filter(x => x.it).slice(0, 8);
    if (!cand.length) return '<div class="px-4 py-6 text-sm text-mut">Everything on your active watchlist is already held — or the list is empty.</div>';
    return cand.map(({k, it}) => `<div class="flex items-center gap-3 px-4 py-2.5 border-b border-line/50 last:border-0">
      ${U.logo(it.sym || it.base, it.color || CDX.Data.CHAINS[it.chain].color, 6)}
      <span class="text-sm font-medium text-white" data-go="${it.sym ? '/token/' + it.id : '/pair/' + it.id}" style="cursor:pointer">${F.esc(CDX.Data.label(it))}</span>
      <span class="num text-xs ${F.cls(CDX.Data.ch24(it))}">${F.pctAuto(CDX.Data.ch24(it))}</span>
      <span class="ml-auto flex items-center gap-2">
        <span class="num text-xs text-slate-300">${F.price(it.price)}</span>
        <button data-trade="buy:${k}" class="text-xs bg-acc/15 border border-acc/50 text-white rounded px-2 py-1 hover:bg-acc/25">+ Add</button></span></div>`).join('');
  }
  function tradeModal(side, key){
    const it = CDX.Data.byKey(key); if (!it) return;
    const h = S.state.holdings.find(x => x.key === key);
    const held = h ? h.amount : 0;
    const m = D.el('div', 'fixed inset-0 z-[75] modal-bg', `
      <div class="min-h-full flex items-center justify-center p-4" data-tm-bg>
        <div class="bg-panel border border-line rounded-2xl w-full max-w-sm shadow-2xl shadow-black/60 p-5">
          <div class="flex items-center justify-between mb-4">
            <div class="flex items-center gap-2">${U.logo(it.sym || it.base, it.color || CDX.Data.CHAINS[it.chain].color)}
              <div><div class="font-disp font-semibold text-white">${F.esc(CDX.Data.label(it))}</div>
              <div class="text-[11px] text-mut num">${F.price(it.price)}</div></div></div>
            <button data-tm-x class="text-mut hover:text-white">✕</button></div>
          <label class="block text-[11px] uppercase tracking-wider text-mut mb-1">Amount (${F.esc(it.sym || it.base)})</label>
          <input data-tm-amt type="number" min="0" step="any" placeholder="0.00" class="w-full bg-panel2 border border-line rounded-lg px-3 py-2 num text-white focus:border-acc/60 focus:outline-none mb-1">
          ${side === 'sell' ? `<div class="text-[11px] text-mut mb-2">Held: <button data-tm-max class="text-acc hover:underline num">${F.num(held)}</button></div>` : '<div class="mb-2"></div>'}
          <div class="flex justify-between text-sm bg-panel2 border border-line rounded-lg px-3 py-2 mb-4">
            <span class="text-mut">Estimated total</span><span class="num text-white" data-tm-total>$0.00</span></div>
          <button data-tm-go class="w-full rounded-lg py-2.5 font-medium text-white ${side === 'buy' ? 'bg-up/80 hover:bg-up' : 'bg-down/80 hover:bg-down'} transition-colors">
            Confirm ${side === 'buy' ? 'Buy' : 'Sell'} · simulated</button></div></div>`);
    document.body.appendChild(m);
    const amt = m.querySelector('[data-tm-amt]');
    amt.focus();
    amt.addEventListener('input', () => m.querySelector('[data-tm-total]').textContent = F.usd((+amt.value || 0) * it.price));
    const unsubRoute = CDX.Bus.on('route:changed', () => close());
    const close = () => { unsubRoute(); m.remove(); };
    m.addEventListener('click', e => {
      if (e.target.closest('[data-tm-x]') || e.target.dataset.tmBg != null) close();
      if (e.target.closest('[data-tm-max]')){ amt.value = held; amt.dispatchEvent(new Event('input')); }
      if (e.target.closest('[data-tm-go]')){
        const res = S.trade(key, side, +amt.value, it.price);
        res.ok ? (U.toast(`${side === 'buy' ? 'Bought' : 'Sold'} ${F.num(res.amount)} ${CDX.Data.label(it)} @ ${F.price(it.price)}`, side === 'buy' ? 'up' : 'down'), close())
               : U.toast(res.msg, 'warn');
      }
    });
  }
  function render(){
    if (chart){ chart.remove(); chart = null; series = null; }
    if (ro){ ro.disconnect(); ro = null; }
    const rs = rows();
    const total = totalOf(rs);
    const pnl = rs.reduce((a,r)=>a+r.pnl,0), day = rs.reduce((a,r)=>a+r.day,0), cost = rs.reduce((a,r)=>a+r.cost,0);
    const best = [...rs].sort((a,b)=>b.pnlPct-a.pnlPct)[0];
    const alloc = allocation(rs, 'asset');
    root.innerHTML = `<div class="space-y-5">
      <div class="flex flex-wrap items-end gap-x-8 gap-y-3">
        <div><div class="text-xs uppercase tracking-wider text-mut mb-1">Total Portfolio Value</div>
          <div class="font-disp font-bold text-white text-4xl num" id="pfTotal">${money(total)}</div></div>
        <div><div class="text-xs uppercase tracking-wider text-mut mb-1">24h P&L</div>
          <div class="font-disp font-semibold text-2xl num ${day >= 0 ? 'text-up' : 'text-down'}">${money(day, 1)} (${F.pct(total - day ? day / (total - day) * 100 : 0)})</div></div>
        <div><div class="text-xs uppercase tracking-wider text-mut mb-1">Total P&L</div>
          <div class="font-disp font-semibold text-2xl num ${pnl >= 0 ? 'text-up' : 'text-down'}">${money(pnl, 1)} (${F.pct(cost ? pnl / cost * 100 : 0)})</div></div>
        ${best ? `<div><div class="text-xs uppercase tracking-wider text-mut mb-1">Best Position</div>
          <div class="font-disp font-semibold text-2xl">${F.esc(CDX.Data.label(best.it))} <span class="num text-base ${best.pnlPct>=0?'text-up':'text-down'}">${F.pct(best.pnlPct,1)}</span></div></div>` : ''}
      </div>
      <div class="grid lg:grid-cols-5 gap-4">
        <div class="lg:col-span-3 bg-panel border border-line rounded-xl p-4">
          <div class="flex items-center justify-between mb-2">
            <h3 class="font-disp font-semibold text-white">Performance</h3>
            <div class="flex items-center bg-panel2 border border-line rounded-lg p-0.5 text-xs">
              ${[30, 90].map(d => `<button data-range="${d}" class="px-2.5 py-1 rounded-md ${range === d ? 'seg-active' : 'text-mut hover:text-white'}">${d}D</button>`).join('')}</div></div>
          <div id="pfChart" class="w-full" style="height:250px"></div></div>
        <div class="lg:col-span-2 bg-panel border border-line rounded-xl p-4">
          <div class="flex items-center justify-between mb-2">
            <h3 class="font-disp font-semibold text-white">Allocation</h3>
            <div class="flex items-center bg-panel2 border border-line rounded-lg p-0.5 text-xs">
              ${['asset','chain','narrative'].map(b => `<button data-alloc="${b}" class="px-2 py-1 rounded-md ${(S.state.prefs.allocBy || 'asset') === b ? 'seg-active' : 'text-mut hover:text-white'}">${b[0].toUpperCase()+b.slice(1)}</button>`).join('')}</div></div>
          <div id="pfAlloc"></div></div></div>
      <div class="grid lg:grid-cols-3 gap-4">
        <div class="lg:col-span-2 bg-panel border border-line rounded-xl overflow-hidden">
          <div class="px-4 py-3 border-b border-line font-disp font-semibold text-white">Holdings</div>
          <div class="overflow-x-auto"><table class="w-full text-sm" style="min-width:940px">
            <thead class="bg-panel2 text-mut text-[11px] uppercase tracking-wider"><tr class="border-b border-line">
              <th class="px-4 py-2.5 text-left">Asset</th><th class="px-4 py-2.5 text-right">Amount</th>
              <th class="px-4 py-2.5 text-right">Avg Buy</th><th class="px-4 py-2.5 text-right">Price</th>
              <th class="px-4 py-2.5 text-right">Value</th><th class="px-4 py-2.5 text-right">P&L</th>
              <th class="px-4 py-2.5 text-right">Weight</th><th class="px-4 py-2.5 text-right">Trade</th></tr></thead>
            <tbody class="divide-y divide-line/60">${rs.length ? rs.map(holdingRow).join('') : '<tr><td colspan="8" class="px-6 py-10 text-center text-mut text-sm">No holdings — add from your watchlist or any asset page.</td></tr>'}</tbody></table></div></div>
        <div class="bg-panel border border-line rounded-xl overflow-hidden">
          <div class="flex items-center justify-between px-4 py-3 border-b border-line">
            <h3 class="font-disp font-semibold text-white">From Your Watchlist</h3>
            <a href="#/watchlist" class="text-xs text-acc hover:underline">Manage →</a></div>
          ${watchPanel(rs)}</div></div></div>`;
    rs.forEach(r => { const c = root.querySelector(`[data-w="${r.key}"]`); if (c) c.textContent = total ? (r.value / total * 100).toFixed(1) + '%' : '—'; });
    paintAlloc(rs);
    mountChart(total);
  }
  function paintAlloc(rs){
    const by = S.state.prefs.allocBy || 'asset';
    const items = allocation(rs, by);
    D.$('#pfAlloc', root).innerHTML = items.length
      ? V.donut(items, 180, [F.usd(totalOf(rs)), 'total value']) + `<div class="space-y-1.5 mt-3">${V.legend(items)}</div>`
      : '<div class="py-10 text-center text-mut text-sm">Nothing to allocate yet.</div>';
  }
  return {
    mount(el){
      root = el; render();
      undelegate = D.delegate(root, {
        '[data-trade]': t => { const [side, ...k] = t.dataset.trade.split(':'); tradeModal(side, k.join(':')); },
        '[data-rmh]': t => { S.removeHolding(t.dataset.rmh); U.toast('Position removed'); },
        '[data-range]': t => { range = +t.dataset.range; render(); },
        '[data-alloc]': t => { S.setPref('allocBy', t.dataset.alloc); render(); },
        '[data-go]': t => CDX.Router.go(t.dataset.go)
      });
      subs.push(CDX.Bus.on('holdings:changed', render));
      subs.push(CDX.Bus.on('tick', changed => {
        const rs = rows();
        const total = totalOf(rs);
        const tEl = D.$('#pfTotal', root);
        if (tEl) tEl.textContent = money(total);
        if (series){ const d = perfData(total); series.update(d[d.length - 1]); }
        for (const { key, dir } of changed){
          const node = root.querySelector(`[data-live="pf:${key}"]`);
          if (node) D.liveSet(node, F.price(CDX.Data.byKey(key).price), dir);
        }
      }));
    },
    unmount(){
      subs.forEach(u=>u()); subs = [];
      if (undelegate) undelegate(); undelegate = null;
      if (ro) ro.disconnect(); ro = null;
      if (chart){ chart.remove(); chart = null; series = null; }
      root = null;
    }
  };
})();
