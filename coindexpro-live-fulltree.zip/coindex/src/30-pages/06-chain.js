/* Page: single chain intelligence. Route: #/chain/:name */
CDX.Pages.chain = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI, I = CDX.Intel, IU = CDX.IntelUI;
  let subs = [], root = null, undelegate = null, chainId = null;

  function pairRows(ps){
    const sorted = [...ps].sort((a,b)=>b.vol-a.vol).slice(0, 10);
    return sorted.map(p => `<div class="row-hov flex items-center gap-3 px-4 py-2.5 border-b border-line/50 last:border-0" data-go="/pair/${p.id}">
      ${U.logo(p.base, CDX.Data.CHAINS[p.chain].color, 6)}
      <span class="text-sm font-medium text-white">${F.esc(p.base)}<span class="text-mut font-normal">/${F.esc(p.quote)}</span></span>
      <span class="text-[11px] text-mut">${F.esc(p.dex)}</span>
      <span class="ml-auto flex items-center gap-3">
        <span class="num text-xs text-mut">Liq ${F.usd(p.liq)}</span>
        <span class="num text-xs text-slate-300">Vol ${F.usd(p.vol)}</span>
        <span class="num text-sm ${F.cls(p.ch.h24)}">${F.pctAuto(p.ch.h24)}</span></span></div>`).join('');
  }
  function coinRows(cs){
    if (!cs.length) return '<div class="px-4 py-5 text-sm text-mut">No tracked native assets.</div>';
    return cs.map(c => `<div class="row-hov flex items-center gap-3 px-4 py-2.5 border-b border-line/50 last:border-0" data-go="/token/${c.id}">
      ${U.logo(c.sym, c.color, 6)}<span class="text-sm font-medium text-white">${F.esc(c.sym)}</span>
      <span class="text-[11px] text-mut truncate">${F.esc(c.name)}</span>
      <span class="ml-auto flex items-center gap-3">
        <span class="num text-xs text-mut">MC ${F.usd(c.mcap)}</span>
        <span class="num text-sm text-slate-200">${F.price(c.price)}</span>
        <span class="num text-sm ${F.cls(c.ch24)}">${F.pct(c.ch24)}</span></span></div>`).join('');
  }
  function render(){
    const s = I.chainStats(chainId);
    CDX.WhaleFlow.start(); const whales = CDX.WhaleFlow.feed(10000, { chain: chainId, limit: 8 });
    const pls = chainId === 'pulsechain';
    root.innerHTML = `<div class="space-y-5">
      <div class="flex items-center gap-3 flex-wrap ${pls ? 'rounded-xl border border-pls/50 pls-ring bg-gradient-to-r from-pls/10 to-plx/10 px-4 py-3' : ''}">
        ${U.chainBadge(chainId, true)}
        <h1 class="font-disp font-bold text-white text-2xl">${F.esc(s.chain.name)} Intelligence</h1>
        <a href="#/dex?chain=${chainId}" class="ml-auto text-xs text-acc hover:underline">Open in DEX Screener →</a></div>
      <div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
        ${U.statCard('Market Cap', F.usd(s.mcap), 'ecosystem')}
        ${U.statCard('TVL', F.usd(s.tvl), 'total value locked')}
        ${U.statCard('DEX Volume', F.usd(s.dexVol), '24h tracked')}
        ${U.statCard('Active Wallets', F.num(s.activeWallets), '24h')}
        ${U.statCard('Active Pairs', s.activePairs, 'tracked')}
        ${U.statCard('New Tokens', F.num(s.newTokens), '24h deploys')}
      </div>
      <div class="grid lg:grid-cols-2 gap-4">
        ${IU.flowPanel(s.flow, s.chain.name + ' Flow')}
        <div class="bg-panel border border-line rounded-xl overflow-hidden">
          <div class="flex items-center justify-between px-4 py-3 border-b border-line">
            <h3 class="font-disp font-semibold text-white">Whale Activity</h3>
            </div>
          <div id="chWhales">${whales.length ? whales.map(CDX.WhaleFlow.miniRow).join('') : '<div class="px-4 py-6 text-sm text-mut">Scanning live pools for large prints…</div>'}</div>
        </div></div>
      <div class="grid lg:grid-cols-2 gap-4">
        <div class="bg-panel border border-line rounded-xl overflow-hidden">
          <div class="px-4 py-3 border-b border-line font-disp font-semibold text-white">Top Pairs by Volume</div>
          ${pairRows(s.pairs)}</div>
        <div class="bg-panel border border-line rounded-xl overflow-hidden">
          <div class="px-4 py-3 border-b border-line font-disp font-semibold text-white">Native Assets</div>
          ${coinRows(s.coins)}</div>
      </div></div>`;
  }
  return {
    mount(el, ctx){
      chainId = ctx.params.name;
      root = el;
      if (!CDX.Data.CHAINS[chainId]){ root.innerHTML = '<div class="py-20 text-center text-mut">Unknown chain.</div>'; return; }
      render();
      undelegate = D.delegate(root, { '[data-go]': t => CDX.Router.go(t.dataset.go) });
      subs.push(CDX.Bus.on('whale:new', () => {
        const host = D.$('#chWhales', root);
        if (host) host.innerHTML = CDX.Intel.whaleTrades({ chain: chainId }).slice(0, 8).map(CDX.IntelUI.whaleRow).join('') || host.innerHTML;
      }));
      let n = 0;
      subs.push(CDX.Bus.on('tick', () => { if (++n % 5 === 0) render(); }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; root=null; chainId=null; }
  };
})();
