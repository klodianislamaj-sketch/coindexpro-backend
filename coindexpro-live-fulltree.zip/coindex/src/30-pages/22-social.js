/* Page: Social Intelligence — momentum leaderboard, crowd attention, spikes,
   channel velocity, X sentiment, outlet tracking. Route: #/social */
CDX.Pages.social = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI, S = CDX.Social;
  let subs = [], root = null, undelegate = null;
  const panel = (title, sub, body) => `<div class="bg-panel border border-line rounded-xl overflow-hidden">
    <div class="px-4 py-3 border-b border-line"><h3 class="font-disp font-semibold text-white">${title}</h3>
    <div class="text-[10px] text-mut">${sub}</div></div>
    ${body || '<div class="px-4 py-8 text-center text-sm text-mut">Coverage builds as the rotation completes…</div>'}</div>`;
  const bar = (v, color) => `<div class="h-1.5 bg-line rounded-full overflow-hidden"><div class="h-full rounded-full" style="width:${Math.min(100, v)}%;background:${color}"></div></div>`;
  const pctFmt = v => (v >= 0 ? '+' : '') + v.toFixed(2) + '%/hr';

  function vLeaders(){
    const rows = S.leaders(8);
    if (!rows.length) return '';
    return rows.map(({ id, c, s }, i) => `<div class="row-hov px-4 py-2 border-b border-line/40 last:border-0" data-go="/token/${id}" style="cursor:pointer">
      <div class="flex items-center gap-2.5">
        <span class="text-mut text-xs w-4 num">${i + 1}</span>${U.logo(c.sym, c.color, 6)}
        <div><div class="text-sm font-medium text-white leading-tight">${F.esc(c.sym)}</div>
        <div class="text-[10px] text-mut">${s.rank ? '🔎 trending #' + s.rank + ' · ' : ''}${s.coverage}/4 channels</div></div>
        <span class="ml-auto num font-disp font-bold text-xl ${s.score >= 55 ? 'text-up' : s.score >= 30 ? 'text-gold' : 'text-mut'}">${s.score}</span></div>
      <div class="grid grid-cols-5 gap-1.5 mt-1.5">${[['ATTN', s.parts.attention, 25], ['SENT', s.parts.sentiment, 20], ['MENT', s.parts.mentions, 15], ['ENGM', s.parts.engagement, 25], ['NEWS', s.parts.news, 15]]
        .map(([l, v, max]) => `<div><div class="text-[8px] text-mut text-center">${l}</div>${bar(v / max * 100, '#5B8CFF')}</div>`).join('')}</div></div>`).join('');
  }
  function vTrending(){
    const rows = S.trending();
    if (!rows.length) return '';
    return rows.map(r => `<div class="row-hov flex items-center gap-3 px-4 py-2 border-b border-line/40 last:border-0" ${r.id ? `data-go="/token/${r.id}" style="cursor:pointer"` : ''}>
      <span class="num text-mut text-xs w-5">#${r.rank}</span>
      <div><div class="text-sm font-medium text-white leading-tight">${F.esc(r.sym)}</div>
      <div class="text-[10px] text-mut">${F.esc(r.name)}${r.mcapRank ? ' · cap #' + r.mcapRank : ''}</div></div>
      <span class="ml-auto text-[10px] ${r.id ? 'text-acc' : 'text-mut'}">${r.id ? 'tracked →' : 'off-universe'}</span></div>`).join('');
  }
  function vSpikes(){
    const rows = S.spikes(10);
    if (!rows.length) return '';
    return rows.map(sp => {
      const c = CDX.Data.byKey('c:' + sp.coinId);
      return `<div class="row-hov flex items-center gap-3 px-4 py-2 border-b border-line/40 last:border-0" ${c ? `data-go="/token/${sp.coinId}" style="cursor:pointer"` : ''}>
        <span class="num text-[10px] text-mut w-12 shrink-0">${F.rel(sp.ts)}</span>
        ${c ? U.logo(c.sym, c.color, 5) : ''}
        <div class="min-w-0"><div class="text-sm font-medium text-white leading-tight">${c ? F.esc(c.sym) : sp.coinId}</div>
        <div class="text-[10px] text-mut">${sp.channel}: ${F.num(sp.from)} → ${F.num(sp.to)}</div></div>
        <span class="ml-auto num text-sm font-semibold text-up">⚡ +${sp.pct.toFixed(2)}%</span></div>`;
    }).join('');
  }
  function vChannels(){
    const groups = [['twitter', '𝕏 Followers'], ['telegram', 'Telegram Members'], ['redditActive', 'Reddit Active Accounts']];
    const html = groups.map(([k, label]) => {
      const rows = S.channelMovers(k, 4);
      if (!rows.length) return '';
      return `<div class="px-4 py-2.5 border-b border-line/40 last:border-0">
        <div class="text-[10px] uppercase tracking-wider text-mut mb-1.5">${label} · velocity</div>
        ${rows.map(({ id, c, v }) => `<div class="flex items-center gap-2 py-1 text-[12px]" data-go="/token/${id}" style="cursor:pointer">
          ${U.logo(c.sym, c.color, 4)}<span class="text-slate-200 font-medium">${F.esc(c.sym)}</span>
          <span class="ml-auto num ${v[k].pct >= 0 ? 'text-up' : 'text-down'}">${pctFmt(v[k].pct)}</span>
          <span class="num text-[10px] text-mut w-16 text-right">${v[k].abs >= 0 ? '+' : ''}${F.num(v[k].abs)}/hr</span></div>`).join('')}</div>`;
    }).join('');
    return html || '';
  }
  function vSentiment(){
    const rows = S.leaders(20).filter(x => x.s.m.upPct != null).slice(0, 7);
    if (!rows.length) return '';
    return rows.map(({ id, c, s }) => `<div class="row-hov px-4 py-2 border-b border-line/40 last:border-0" data-go="/token/${id}" style="cursor:pointer">
      <div class="flex items-center gap-2 text-[12px] mb-1">${U.logo(c.sym, c.color, 4)}
        <span class="text-slate-200 font-medium">${F.esc(c.sym)}</span>
        <span class="ml-auto num text-up">${s.m.upPct.toFixed(0)}% 👍</span>
        <span class="num text-down">${(s.m.downPct ?? 100 - s.m.upPct).toFixed(0)}% 👎</span></div>
      <div class="h-1.5 rounded-full overflow-hidden flex bg-line"><div class="bg-up" style="width:${s.m.upPct}%"></div><div class="bg-down flex-1"></div></div>
      <div class="text-[9px] text-mut mt-0.5 num">𝕏 ${s.m.twitter != null ? F.num(s.m.twitter) : '—'} · TG ${s.m.telegram != null ? F.num(s.m.telegram) : '—'} · r/ ${s.m.redditSubs != null ? F.num(s.m.redditSubs) : '—'}</div></div>`).join('');
  }
  function vInfluencers(){
    const rows = S.influencers(6);
    if (!rows.length) return '';
    const max = Math.max(...rows.map(r => r.mentions), 1);
    return rows.map(r => `<div class="px-4 py-2.5 border-b border-line/40 last:border-0">
      <div class="flex items-center gap-2 text-[12px]">
        <span class="text-slate-200 font-medium">${F.esc(r.src)}</span>
        <span class="text-[10px] text-mut">${F.rel(r.lastTs)}</span>
        <span class="ml-auto num text-white">${r.mentions} <span class="text-mut text-[10px]">stories 24h</span></span></div>
      <div class="flex items-center gap-2 mt-1">
        <div class="flex-1">${bar(r.mentions / max * 100, '#9B5CFF')}</div>
        <span class="num text-[10px]"><span class="text-up">▲${r.bull}</span> <span class="text-down">▼${r.bear}</span></span></div>
      <div class="flex items-center gap-1.5 flex-wrap mt-1">${r.topTags.map(t => {
        const it = CDX.Data.byKey(t);
        return it ? `<a href="#${it.sym ? '/token/' + it.id : '/pair/' + it.id}" class="text-[9px] border border-line rounded px-1.5 py-0.5 text-slate-300 hover:border-acc/50">${F.esc(CDX.Data.label(it))}</a>` : '';
      }).join('')}</div></div>`).join('');
  }
  function paint(){
    D.$('#soLead', root).innerHTML = panel('Social Momentum', 'attention · sentiment · mentions · engagement velocity · news', vLeaders());
    D.$('#soTrend', root).innerHTML = panel('Crowd Attention', 'live trending searches (CoinGecko)', vTrending());
    D.$('#soSpikes', root).innerHTML = panel('Social Spikes <span class="w-1.5 h-1.5 rounded-full bg-down live-dot inline-block ml-1"></span>', 'channel jumps between snapshots', vSpikes());
    D.$('#soChan', root).innerHTML = panel('Channel Velocity', 'per-hour growth across covered assets', vChannels());
    D.$('#soSent', root).innerHTML = panel('𝕏 / Community Sentiment', 'vote sentiment + channel sizes per asset', vSentiment());
    D.$('#soInf', root).innerHTML = panel('Influencer & Outlet Tracker', 'newsroom mention share · 24h · bull/bear lean', vInfluencers());
    D.$('#soCov', root).textContent = S.coverage() + ' assets covered';
  }
  return {
    mount(el){
      root = el;
      root.innerHTML = `<div class="space-y-4">
        <div class="flex items-center gap-3 flex-wrap">
          <h2 class="font-disp font-semibold text-white text-lg">Social Intelligence</h2>
          <span class="flex items-center gap-1.5 text-[11px] text-mut"><span class="w-2 h-2 rounded-full bg-down live-dot"></span> <span id="soCov">building coverage…</span></span>
          <span class="ml-auto text-[10px] text-mut">X · Telegram · Reddit via CoinGecko community data — Discord has no public API and is excluded from scoring</span></div>
        <div class="grid lg:grid-cols-2 xl:grid-cols-3 gap-4">
          <div id="soLead"></div><div id="soTrend"></div><div id="soSpikes"></div>
          <div id="soChan"></div><div id="soSent"></div><div id="soInf"></div></div></div>`;
      paint();
      undelegate = D.delegate(root, { '[data-go]': t => CDX.Router.go(t.dataset.go) });
      let n = 0;
      subs.push(CDX.Bus.on('tick', () => { if (++n % 8 === 0) paint(); }));
      subs.push(CDX.Bus.on('social:spike', () => {
        const host = D.$('#soSpikes', root);
        if (host) host.innerHTML = panel('Social Spikes <span class="w-1.5 h-1.5 rounded-full bg-down live-dot inline-block ml-1"></span>', 'channel jumps between snapshots', vSpikes());
      }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; root=null; }
  };
})();
