/* Page: Liquidity Intelligence — LP events, migrations, dying pools, chain flow,
   concentration, pressure/stability scoreboard. Route: #/liquidity */
CDX.Pages.liquidity = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI, L = CDX.Liq;
  let subs = [], root = null, undelegate = null;
  const money = v => (v >= 0 ? '+' : '−') + F.usd(Math.abs(v));
  const panel = (title, sub, body) => `<div class="bg-panel border border-line rounded-xl overflow-hidden">
    <div class="px-4 py-3 border-b border-line"><h3 class="font-disp font-semibold text-white">${title}</h3>
    <div class="text-[10px] text-mut">${sub}</div></div>
    ${body || '<div class="px-4 py-8 text-center text-sm text-mut">Watching pools — signals build as the session runs.</div>'}</div>`;
  const pairCell = p => `<div class="flex items-center gap-2 min-w-0">
    ${U.logo(p.base, CDX.Data.CHAINS[p.chain].color, 5)}
    <div class="min-w-0"><div class="text-sm font-medium text-white leading-tight truncate">${F.esc(p.base)}<span class="text-mut font-normal">/${F.esc(p.quote)}</span></div>
    <div class="text-[10px] text-mut">${U.chainBadge(p.chain)}</div></div></div>`;
  const bar = (v, color) => `<div class="h-1.5 bg-line rounded-full overflow-hidden"><div class="h-full rounded-full" style="width:${v}%;background:${color}"></div></div>`;

  function vEvents(){
    const evs = L.events(14);
    if (!evs.length) return `<div class="px-4 py-8 text-center">
      <div class="inline-flex items-center gap-2 text-sm text-mut">
        <span class="w-2 h-2 rounded-full bg-acc animate-pulse"></span>Building live liquidity flow…</div>
      <div class="text-[11px] text-mut mt-2">LP adds and removals appear here once detected from live pool deltas.</div></div>`;
    return evs.map(e => {
      const p = CDX.Data.byKey('d:' + e.pairId);
      if (!p) return '';
      return `<div class="row-hov flex items-center gap-3 px-4 py-2 border-b border-line/40 last:border-0" data-go="/pair/${p.id}" style="cursor:pointer">
        <span class="num text-[10px] text-mut w-12 shrink-0">${F.rel(e.ts)}</span>
        <span class="num text-[10px] font-bold w-14 ${e.type === 'add' ? 'text-up' : 'text-down'}">${e.type === 'add' ? '＋LP ADD' : '−LP PULL'}</span>
        ${pairCell(p)}
        <span class="ml-auto text-right shrink-0">
          <div class="num text-sm ${e.delta >= 0 ? 'text-up' : 'text-down'}">${money(e.delta)}</div>
          <div class="num text-[10px] text-mut">${e.pct >= 0 ? '+' : ''}${e.pct.toFixed(1)}% · pool ${F.usd(p.liq)}</div></span></div>`;
    }).join('');
  }
  function vMigrations(){
    const ms = L.migrations(6);
    if (!ms.length) return '';
    return ms.map(m => {
      const from = CDX.Data.byKey('d:' + m.fromId), to = CDX.Data.byKey('d:' + m.toId);
      if (!from || !to) return '';
      return `<div class="px-4 py-2.5 border-b border-line/40 last:border-0">
        <div class="flex items-center gap-2 text-[12px] flex-wrap">
          <span class="font-medium text-white">${F.esc(m.sym)}</span>
          <span class="num text-gold">≈${F.usd(m.usd)}</span>
          <span class="num text-[10px] text-mut ml-auto">${F.rel(m.ts)}</span></div>
        <div class="flex items-center gap-1.5 text-[11px] mt-1 flex-wrap">
          <a href="#/pair/${from.id}" class="border border-down/40 text-down rounded px-1.5 py-0.5 hover:bg-down/10">${F.esc(from.dex)} · ${CDX.Data.CHAINS[from.chain].name}</a>
          <span class="text-mut">→</span>
          <a href="#/pair/${to.id}" class="border border-up/40 text-up rounded px-1.5 py-0.5 hover:bg-up/10">${F.esc(to.dex)} · ${CDX.Data.CHAINS[to.chain].name}</a></div></div>`;
    }).join('');
  }
  function vDeath(){
    return L.deathSignals(6).map(({ p, score, flags }) => `
      <div class="row-hov px-4 py-2.5 border-b border-line/40 last:border-0" data-go="/pair/${p.id}" style="cursor:pointer">
        <div class="flex items-center gap-2">${pairCell(p)}
          <span class="ml-auto num font-disp font-bold text-lg ${score >= 60 ? 'text-down' : 'text-gold'}">☠ ${score}</span></div>
        <div class="flex items-center gap-1.5 flex-wrap mt-1.5">${flags.map(f =>
          `<span class="text-[9px] uppercase tracking-wider border border-down/40 text-down bg-down/10 rounded px-1.5 py-0.5">${f}</span>`).join('')}</div></div>`).join('');
  }
  function vChainFlow(){
    if (!L.hasFlow()){
      return `<div class="px-4 py-8 text-center">
        <div class="inline-flex items-center gap-2 text-sm text-mut">
          <span class="w-2 h-2 rounded-full bg-acc animate-pulse"></span>Building live liquidity flow…</div>
        <div class="text-[11px] text-mut mt-2">Net movement appears once pool snapshots are compared. No add/remove events measured yet.</div></div>`;
    }
    const rows = L.chainFlow();
    const max = Math.max(...rows.map(r => Math.abs(r.net)), 1);
    const inC = rows[0], outC = rows[rows.length - 1];
    const signal = inC && outC && outC.net < 0 && inC.net > 0
      ? `<div class="px-4 py-2 text-[11px] text-mut border-b border-line/40">Liquidity rotating <span class="text-down">${outC.chain.name}</span> → <span class="text-up">${inC.chain.name}</span> (2h window)</div>` : '';
    return signal + rows.map(r => `<div class="row-hov flex items-center gap-3 px-4 py-2 border-b border-line/40 last:border-0" data-go="/chain/${r.id}" style="cursor:pointer">
      ${U.chainBadge(r.id)}
      <div class="flex-1">${bar(Math.abs(r.net) / max * 100, r.net >= 0 ? '#2DD480' : '#FF5C5C')}</div>
      <span class="num text-xs w-20 text-right ${r.net >= 0 ? 'text-up' : 'text-down'}">${money(r.net)}</span>
      <span class="num text-[10px] text-mut w-28 text-right hidden sm:inline">＋${F.usd(r.add)} / −${F.usd(r.remove)}</span></div>`).join('');
  }
  function vConcentration(){
    return L.concentration().map(c => `<div class="row-hov px-4 py-2 border-b border-line/40 last:border-0" data-go="/chain/${c.id}" style="cursor:pointer">
      <div class="flex items-center gap-2 text-[12px]">${U.chainBadge(c.id)}
        <span class="text-mut text-[10px]">${c.pools} pools · ${F.usd(c.total)}</span>
        <span class="ml-auto num text-[10px] text-mut">HHI ${(c.hhi * 100).toFixed(0)}</span></div>
      <div class="flex items-center gap-2 mt-1">
        <div class="flex-1">${bar(c.topShare, c.topShare > 60 ? '#F5C04E' : '#5B8CFF')}</div>
        <span class="num text-[10px] text-slate-300 w-32 text-right truncate">top: ${F.esc(c.topPair.base)}/${F.esc(c.topPair.quote)} ${c.topShare.toFixed(0)}%</span></div></div>`).join('');
  }
  function vBoard(){
    const rows = CDX.Data.pairs.filter(p => p.liq > 15e3)
      .map(p => ({ p, pr: L.pressure(p), st: L.stability(p) }))
      .sort((a, b) => b.pr.score - a.pr.score).slice(0, 12);
    return rows.map(({ p, pr, st }) => `<div class="row-hov flex items-center gap-3 px-4 py-2 border-b border-line/40 last:border-0" data-go="/pair/${p.id}" style="cursor:pointer">
      ${pairCell(p)}
      <span class="num text-[10px] text-mut hidden md:inline">Liq ${F.usd(p.liq)} · ${pr.net >= 0 ? '+' : ''}${pr.net.toFixed(1)}% 1h</span>
      <span class="ml-auto flex items-center gap-3 w-64 shrink-0">
        <span class="flex-1"><span class="flex justify-between text-[9px] text-mut"><span>PRESSURE</span><span class="num">${pr.score}</span></span>${bar(pr.score, pr.score >= 55 ? '#FF5C5C' : pr.score >= 30 ? '#F5C04E' : '#2DD480')}</span>
        <span class="flex-1"><span class="flex justify-between text-[9px] text-mut"><span>STABILITY</span><span class="num">${st.score}</span></span>${bar(st.score, st.score >= 60 ? '#2DD480' : st.score >= 35 ? '#F5C04E' : '#FF5C5C')}</span></span></div>`).join('');
  }
  function paint(){
    D.$('#lqEvents', root).innerHTML = panel('LP Adds & Removals <span class="w-1.5 h-1.5 rounded-full bg-down live-dot inline-block ml-1"></span>', 'pool-delta detection · ≥3% or $5K moves', vEvents());
    D.$('#lqMig', root).innerHTML = panel('Liquidity Migrations', 'removal → matching add of the same token elsewhere', vMigrations());
    D.$('#lqDeath', root).innerHTML = panel('Pool Death Signals', 'drawdown · flow collapse · sub-viable depth', vDeath());
    D.$('#lqFlow', root).innerHTML = panel('Cross-Chain Liquidity Flow', 'event-netted liquidity movement · 2h window', vChainFlow());
    D.$('#lqConc', root).innerHTML = panel('Liquidity Concentration', 'top-pool share + HHI per chain', vConcentration());
    D.$('#lqBoard', root).innerHTML = panel('Pressure / Stability Scoreboard', 'pools ranked by outflow pressure · marked to live telemetry', vBoard());
  }
  return {
    mount(el){
      root = el;
      root.innerHTML = `<div class="space-y-4">
        <div class="flex items-center gap-3 flex-wrap">
          <h2 class="font-disp font-semibold text-white text-lg">Liquidity Intelligence</h2>
          <span class="flex items-center gap-1.5 text-[11px] text-mut"><span class="w-2 h-2 rounded-full bg-down live-dot"></span> pool telemetry engine</span></div>
        <div class="grid lg:grid-cols-2 xl:grid-cols-3 gap-4">
          <div id="lqEvents"></div><div id="lqMig"></div><div id="lqDeath"></div>
          <div id="lqFlow"></div><div id="lqConc"></div>
          <div class="bg-panel border border-line rounded-xl p-4">
            <h3 class="font-disp font-semibold text-white mb-2">Score Model</h3>
            <div class="space-y-2 text-[12px] text-mut leading-relaxed">
              <div><span class="num font-bold text-down">PRESSURE</span> — 1h liquidity drain · LP removal weight · sell-flow dominance (measured prints preferred) · whale exits vs depth. Higher = capital leaving.</div>
              <div><span class="num font-bold text-up">STABILITY</span> — liquidity variance (session series) · depth tier · pool age · retention vs session peak · event calm. Higher = dependable depth.</div></div></div>
        </div>
        <div id="lqBoard"></div></div>`;
      paint();
      undelegate = D.delegate(root, { '[data-go]': t => CDX.Router.go(t.dataset.go) });
      let n = 0;
      subs.push(CDX.Bus.on('tick', () => { if (++n % 5 === 0) paint(); }));
      subs.push(CDX.Bus.on('liq:event', () => {
        const host = D.$('#lqEvents', root);
        if (host) host.innerHTML = panel('LP Adds & Removals <span class="w-1.5 h-1.5 rounded-full bg-down live-dot inline-block ml-1"></span>', 'pool-delta detection · ≥3% or $5K moves', vEvents());
      }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; root=null; }
  };
})();
