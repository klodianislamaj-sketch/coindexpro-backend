/* Page: Integrity Monitor — hidden at #/integrity (not in nav).
   Surfaces real data-integrity issues found by scanning the live universe
   through the normalized Asset layer + consensus stats. Read-only. */
CDX.Pages.integrity = (() => {
  const D = CDX.Dom, F = CDX.Fmt, A = CDX.Asset;
  let root = null, timer = null;

  function scan(){
    const pairs = CDX.Data.pairs || [];
    const issues = { invalid: [], stale: [], chainMismatch: [], dupCollision: [], missingChart: [], brokenRoute: [] };

    // duplicate pair collisions: same chain+pairAddress appearing twice
    const seen = new Map();
    for (const p of pairs){
      if (!p.address) continue;
      const k = p.chain + '|' + p.address.toLowerCase();
      if (seen.has(k)) issues.dupCollision.push(`${p.base}/${p.quote} (${k})`);
      else seen.set(k, p.id);
    }

    for (const p of pairs){
      const a = A.resolve('d:' + p.id);
      if (!a){ issues.invalid.push(p.id); continue; }
      if (!a.valid) issues.invalid.push(`${p.base}/${p.quote}: no valid price`);
      else if (a.stale) issues.stale.push(`${p.base}/${p.quote}`);
      // chain mismatch on tokenAddress
      const cm = A.integrity.chainMismatch(p.chain, p.ca || p.address);
      if (cm) issues.chainMismatch.push(`${p.base}/${p.quote}: ${cm}`);
      // broken pair route: id can't round-trip through byKey
      if (!CDX.Data.byKey('d:' + p.id)) issues.brokenRoute.push(p.id);
    }
    return issues;
  }

  function section(title, list, okMsg){
    const n = list.length;
    const head = `<div class="px-4 py-2.5 border-b border-line flex items-center gap-2">
      <span class="w-2 h-2 rounded-full ${n ? 'bg-down' : 'bg-up'} shrink-0"></span>
      <span class="font-disp font-semibold text-white text-sm">${title}</span>
      <span class="num text-[11px] ${n ? 'text-down' : 'text-up'} ml-auto">${n || 'clean'}</span></div>`;
    const body = n
      ? `<div class="px-4 py-2 text-[11px] text-mut num space-y-0.5">${list.slice(0, 20).map(x => `<div>${F.esc(String(x))}</div>`).join('')}${n > 20 ? `<div class="text-down">…+${n - 20} more</div>` : ''}</div>`
      : `<div class="px-4 py-3 text-[11px] text-up">${okMsg}</div>`;
    return `<div class="bg-panel border border-line rounded-xl overflow-hidden">${head}${body}</div>`;
  }

  function paint(){
    if (!root) return;
    const i = scan();
    const cs = A.consensusStats ? A.consensusStats() : { rejectedOutliers: 0, disagreements: 0 };
    const totalIssues = i.invalid.length + i.chainMismatch.length + i.dupCollision.length + i.brokenRoute.length;
    const hdr = D.$('#inHdr', root);
    if (hdr) hdr.innerHTML = `<div class="rounded-xl border ${totalIssues ? 'border-down/40 bg-down/10' : 'border-up/40 bg-up/10'} px-4 py-3 flex items-center gap-3">
      <span class="font-disp font-bold text-lg ${totalIssues ? 'text-down' : 'text-up'}">${totalIssues ? totalIssues + ' ISSUES' : 'CLEAN'}</span>
      <span class="num text-[11px] text-mut ml-auto">${cs.rejectedOutliers} outliers rejected · ${cs.disagreements} source disagreements · ${i.stale.length} stale</span></div>`;
    const body = D.$('#inBody', root);
    if (body) body.innerHTML = [
      section('Failed validations', i.invalid, 'All assets resolve to a valid price.'),
      section('Chain mismatches', i.chainMismatch, 'No chain/address mismatches.'),
      section('Duplicate pair collisions', i.dupCollision, 'No duplicate chain+address collisions.'),
      section('Stale assets', i.stale, 'No stale assets.'),
      section('Broken token routes', i.brokenRoute, 'All pair ids round-trip cleanly.')
    ].join('');
  }

  return {
    mount(el){
      root = el;
      root.innerHTML = `<div class="max-w-3xl mx-auto px-3 sm:px-4 py-4 space-y-3">
        <div><h1 class="font-disp text-xl font-bold text-white">Integrity Monitor</h1>
        <p class="text-[12px] text-mut">Live scan of the asset universe for failed validations, mismatches, collisions and stale data. Read-only.</p></div>
        <div id="inHdr"></div><div id="inBody" class="space-y-3"></div></div>`;
      paint();
      timer = setInterval(paint, 5000);
    },
    unmount(){ if (timer) clearInterval(timer); timer = null; root = null; }
  };
})();
