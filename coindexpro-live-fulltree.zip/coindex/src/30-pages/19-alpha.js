/* Page: Alpha Discovery — early gems, smart money, whale accumulation, viral tokens,
   fresh launches, fresh liquidity, holder growth, deployments. Route: #/alpha */
CDX.Pages.alpha = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI, A = CDX.Alpha;
  let subs = [], root = null, undelegate = null;

  const scoreChip = (label, v, color) =>
    `<span class="inline-flex items-center gap-1 text-[10px] num font-bold rounded px-1.5 py-0.5 border"
       style="color:${color};border-color:${color}55;background:${color}14" title="${label} ${v}/100">${label[0]} ${v}</span>`;
  const triple = s => scoreChip('Alpha', s.alpha, '#5B8CFF') + ' ' + scoreChip('Conviction', s.conviction, '#2DD480')
                    + ' ' + scoreChip('Mom', s.momentum != null ? s.momentum : '·', '#9B5CFF')
                    + ' ' + scoreChip('Risk', s.risk, s.risk >= 60 ? '#FF5C5C' : '#F5C04E');
  const pairCell = (p, sub) => `<div class="flex items-center gap-2.5 min-w-0">
    ${U.logo(p.base, CDX.Data.CHAINS[p.chain].color, 6)}
    <div class="min-w-0"><div class="text-sm font-medium text-white leading-tight truncate">${F.esc(p.base)}<span class="text-mut font-normal">/${F.esc(p.quote)}</span></div>
    <div class="text-[10px] text-mut">${U.chainBadge(p.chain)} ${sub || ''}</div></div></div>`;
  const panel = (title, sub, body) => `<div class="bg-panel border border-line rounded-xl overflow-hidden flex flex-col">
    <div class="px-4 py-3 border-b border-line">
      <h3 class="font-disp font-semibold text-white">${title}</h3>
      <div class="text-[10px] text-mut">${sub}</div></div>
    <div class="flex-1">${body || '<div class="px-4 py-8 text-center text-sm text-mut">No qualifying signals right now.</div>'}</div></div>`;
  const row = (p, html) => `<div class="row-hov flex items-center gap-3 px-4 py-2 border-b border-line/40 last:border-0" data-go="/pair/${p.id}" style="cursor:pointer">${html}</div>`;

  function vGems(){
    return A.earlyGems(8).map(({ p, s }) => row(p,
      pairCell(p, `${F.age(p.ageH)} · Liq ${F.usd(p.liq)}`)
      + `<span class="ml-auto flex items-center gap-2 shrink-0">
          <span class="num text-xs ${F.cls(p.ch.h24)} hidden sm:inline">${F.pctAuto(p.ch.h24)}</span>${triple(s)}</span>`)).join('');
  }
  function vSmart(){
    return A.smartMoney(8).map(({ p, s }) => row(p,
      pairCell(p, `${s.flow.smartBuyers.size} smart wallet${s.flow.smartBuyers.size > 1 ? 's' : ''} in`)
      + `<span class="ml-auto text-right shrink-0">
          <div class="num text-sm text-up">+${F.usd(s.flow.smartBuyUsd)}</div>
          <div class="num text-[10px] text-mut">${F.rel(s.flow.lastTs)} · ${triple(s)}</div></span>`)).join('');
  }
  function vWhale(){
    return A.whaleAccumulation(8).map(({ p, s }) => {
      const net = s.flow.buyUsd - s.flow.sellUsd;
      const tot = s.flow.buyUsd + s.flow.sellUsd || 1;
      return row(p,
        pairCell(p, `${s.flow.buyers.size} buyers · ${s.flow.sellers.size} sellers`)
        + `<span class="ml-auto w-32 shrink-0">
            <div class="num text-xs text-right ${net >= 0 ? 'text-up' : 'text-down'}">${net >= 0 ? '+' : '−'}${F.usd(Math.abs(net))}</div>
            <div class="h-1.5 rounded-full overflow-hidden flex bg-line mt-1">
              <div class="bg-up" style="width:${(s.flow.buyUsd / tot * 100).toFixed(0)}%"></div>
              <div class="bg-down flex-1"></div></div></span>`);
    }).join('');
  }
  function vViral(){
    return A.viralTokens(8).map(({ p, s }) => row(p,
      pairCell(p, `${s.turnover.toFixed(1)}× turnover · ${F.num(p.buys + p.sells)} txns`)
      + `<span class="ml-auto flex items-center gap-2 shrink-0">
          <span class="num text-[10px] text-mut">soc ${s.social}</span>
          <span class="num text-sm font-bold text-gold">🔥 ${Math.round(s.viral)}</span></span>`)).join('');
  }
  function vLaunches(){
    return A.freshLaunches(9).map(({ p, s }) => row(p,
      pairCell(p, `${F.esc(p.dex)} · FDV ${F.usd(p.fdv)}`)
      + `<span class="ml-auto flex items-center gap-2.5 shrink-0">
          <span class="num text-xs ${p.ageH <= 24 ? 'text-up' : 'text-mut'}">${F.age(p.ageH)}</span>
          <span class="num text-xs ${p.liq < 50e3 ? 'text-down' : 'text-mut'}">Liq ${F.usd(p.liq)}</span>
          ${scoreChip('Risk', s.risk, s.risk >= 60 ? '#FF5C5C' : '#F5C04E')}</span>`)).join('');
  }
  function vLiquidity(){
    return A.freshLiquidity(7).map(({ p, growth }) => row(p,
      pairCell(p, `now ${F.usd(p.liq)}`)
      + `<span class="ml-auto num text-sm text-up shrink-0">+${growth.toFixed(1)}% liq</span>`)).join('');
  }
  function vHolders(){
    return A.holderMovers(7).map(({ p, hg }) => row(p,
      pairCell(p, `${F.num(p.holders)} holders`)
      + `<span class="ml-auto text-right shrink-0">
          <div class="num text-sm ${hg.delta >= 0 ? 'text-up' : 'text-down'}">${hg.delta >= 0 ? '+' : ''}${F.num(hg.delta)}</div>
          <div class="num text-[10px] text-mut">${hg.perHr >= 0 ? '+' : ''}${hg.perHr.toFixed(1)}/hr</div></span>`)).join('');
  }
  function vDeploys(){
    const rows = A.deployments().slice(0, 7);
    const max = Math.max(...rows.map(r => r.newTokens), 1);
    return rows.map(r => `<div class="row-hov flex items-center gap-3 px-4 py-2 border-b border-line/40 last:border-0" data-go="/chain/${r.id}" style="cursor:pointer">
      ${U.chainBadge(r.id)}
      <span class="text-[10px] text-mut">${r.freshPairs} fresh pairs · ${F.usd(r.freshLiq)} liq</span>
      <span class="ml-auto flex items-center gap-2 w-36 shrink-0">
        <div class="h-1.5 flex-1 bg-line rounded-full overflow-hidden"><div class="h-full bg-acc rounded-full" style="width:${(r.newTokens / max * 100).toFixed(0)}%"></div></div>
        <span class="num text-xs text-white">${F.num(r.newTokens)}</span></span></div>`).join('');
  }
  function banner(){
    const r = A.rotation();
    return `<div class="ai-card rounded-xl px-4 py-3 flex items-center gap-3 flex-wrap text-sm">
      <span class="text-[10px] uppercase tracking-wider font-semibold text-acc">Rotation</span>
      <span class="text-mut">Capital: <a href="#/narrative/${r.outN.id}" class="font-medium hover:underline" style="color:${r.outN.color}">${r.outN.name}</a>
        <span class="text-down num">−${F.usd(Math.abs(Math.min(0, r.outN.flow.netFlow)))}</span> →
        <a href="#/narrative/${r.inN.id}" class="font-medium hover:underline" style="color:${r.inN.color}">${r.inN.name}</a>
        <span class="text-up num">+${F.usd(Math.max(0, r.inN.flow.netFlow))}</span></span>
      <span class="text-mut hidden md:inline">· Chains: <a href="#/chain/${r.outC.id}" class="text-slate-300 hover:underline">${r.outC.chain.name}</a> →
        <a href="#/chain/${r.inC.id}" class="text-slate-300 hover:underline">${r.inC.chain.name}</a></span>
      <span class="ml-auto flex items-center gap-1.5">${scoreChip('Alpha', '·', '#5B8CFF')}${scoreChip('Conviction', '·', '#2DD480')}${scoreChip('Risk', '·', '#F5C04E')}</span></div>`;
  }
  function paint(){
    D.$('#alBanner', root).innerHTML = banner();
    D.$('#alGems', root).innerHTML = panel('💎 Early Gems', 'young pairs ranked by Alpha Score', vGems());
    D.$('#alSmart', root).innerHTML = panel('🧠 Smart Money Entering', 'tracked high-score wallets buying · 6h window', vSmart());
    D.$('#alWhale', root).innerHTML = panel('🐋 Whale Accumulation', 'net whale print flow · 6h window', vWhale());
    D.$('#alViral', root).innerHTML = panel('🔥 Viral Tokens', 'turnover × transactions × buy dominance × news velocity', vViral());
    D.$('#alLaunch', root).innerHTML = panel('🚀 Fresh Launches', 'youngest pairs first · risk-scored', vLaunches());
    D.$('#alLiq', root).innerHTML = panel('💧 Fresh Liquidity', 'pools growing vs session baseline', vLiquidity());
    D.$('#alHold', root).innerHTML = panel('👥 Holder Growth', 'on-chain holder deltas · PulseChain', vHolders());
    D.$('#alDeploy', root).innerHTML = panel('🏗 Deployments', 'new contracts + fresh pairs by chain · 24h', vDeploys());
  }
  return {
    mount(el){
      root = el;
      root.innerHTML = `<div class="space-y-4">
        <div class="flex items-center gap-3 flex-wrap">
          <h2 class="font-disp font-semibold text-white text-lg">Alpha Discovery</h2>
          <span class="flex items-center gap-1.5 text-[11px] text-mut"><span class="w-2 h-2 rounded-full bg-down live-dot"></span> live signal engine</span></div>
        <div id="alBanner"></div>
        <div class="grid lg:grid-cols-2 xl:grid-cols-3 gap-4">
          <div id="alGems" class="xl:col-span-1"></div><div id="alSmart"></div><div id="alWhale"></div>
          <div id="alViral"></div><div id="alLaunch"></div><div id="alLiq"></div>
          <div id="alHold"></div><div id="alDeploy"></div>
          <div class="bg-panel border border-line rounded-xl p-4">
            <h3 class="font-disp font-semibold text-white mb-2">Score Model</h3>
            <div class="space-y-2 text-[12px] text-mut leading-relaxed">
              <div><span class="num font-bold" style="color:#5B8CFF">ALPHA</span> — contract freshness (decay + session detection) · traction · momentum w/ acceleration · performance-qualified smart money (recency-weighted) · live buy-pressure model (tx deltas + measured prints + whale net) · cluster co-trading · confidence-weighted holder growth · liquidity-lock evidence · news velocity.</div>
              <div><span class="num font-bold" style="color:#9B5CFF">MOMENTUM</span> — multi-TF move confirmed by turnover, blended with 10-min price/tx acceleration (second derivative).</div>
              <div><span class="num font-bold" style="color:#2DD480">CONVICTION</span> — liquidity depth · buy dominance · measured buy volume · smart wallets · holder base · trend alignment.</div>
              <div><span class="num font-bold" style="color:#F5C04E">RISK</span> — thin liquidity · extreme youth · churn · FDV/liquidity stretch · short-TF volatility · unknown holder base.</div></div></div>
        </div></div>`;
      paint();
      undelegate = D.delegate(root, { '[data-go]': t => CDX.Router.go(t.dataset.go) });
      let n = 0;
      subs.push(CDX.Bus.on('tick', () => { if (++n % 5 === 0) paint(); }));
      subs.push(CDX.Bus.on('whale:new', () => {
        D.$('#alSmart', root).innerHTML = panel('🧠 Smart Money Entering', 'tracked high-score wallets buying · 6h window', vSmart());
        D.$('#alWhale', root).innerHTML = panel('🐋 Whale Accumulation', 'net whale print flow · 6h window', vWhale());
      }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; root=null; }
  };
})();
