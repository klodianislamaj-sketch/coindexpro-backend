/* Page: custom watchlists — multiple named lists, active-list ★ binding. Route: #/watchlist */
CDX.Pages.watchlists = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI, S = CDX.Store;
  let subs = [], root = null, undelegate = null, viewing = null;

  function tabsHtml(){
    const active = S.state.activeList;
    return S.state.lists.map(l => `
      <button data-vl="${l.id}" class="text-xs rounded-lg px-3 py-1.5 border transition-colors ${l.id===viewing?'bg-acc/15 border-acc/50 text-white':'bg-panel border-line text-mut hover:text-white'}">
        ${F.esc(l.name)} <span class="opacity-70">${l.keys.length}</span>${l.id===active?' <span class="text-gold">★</span>':''}</button>`).join('')
      + `<button data-newl class="text-xs rounded-lg px-3 py-1.5 border border-dashed border-line text-mut hover:text-acc hover:border-acc/50">+ New list</button>`;
  }
  function rows(l){
    const items = l.keys.map(k => ({ k, it: CDX.Data.byKey(k) })).filter(r => r.it);
    if (!items.length) return `<div class="px-6 py-12 text-center text-mut text-sm">Empty list. Add assets below, or tap ★ anywhere in the app${l.id===S.state.activeList?'':' (after making this the active ★ list)'}.</div>`;
    return `<div class="overflow-x-auto"><table class="w-full text-sm" style="min-width:920px">
      <thead class="bg-panel2 text-mut text-[11px] uppercase tracking-wider"><tr class="border-b border-line">
        <th class="px-4 py-2.5 text-left">Asset</th><th class="px-4 py-2.5 text-left">Type</th>
        <th class="px-4 py-2.5 text-left">Chain</th><th class="px-4 py-2.5 text-right">Price</th>
        <th class="px-4 py-2.5 text-right">24h %</th><th class="px-4 py-2.5 text-right">Volume</th>
        <th class="px-4 py-2.5 text-right">MCap / Liq</th><th class="px-4 py-2.5 w-12"></th></tr></thead>
      <tbody class="divide-y divide-line/60">${items.map(({k, it}) => {
        const isCoin = !!it.sym, ch = CDX.Data.ch24(it);
        return `<tr class="row-hov" data-go="${isCoin?'/token/'+it.id:'/pair/'+it.id}">
          <td class="px-4 py-3"><div class="flex items-center gap-2.5">${U.logo(isCoin?it.sym:it.base, isCoin?it.color:CDX.Data.CHAINS[it.chain].color)}
            <div><div class="font-medium text-white">${F.esc(CDX.Data.label(it))}</div>
            <div class="text-[11px] text-mut">${F.esc(it.name)}</div></div></div></td>
          <td class="px-4 py-3"><span class="text-[10px] uppercase tracking-wider rounded px-1.5 py-0.5 border ${isCoin?'border-acc/40 text-acc bg-acc/10':'border-plx/50 text-fuchsia-300 bg-plx/15'}">${isCoin?'Market':'DEX'}</span></td>
          <td class="px-4 py-3">${U.chainBadge(it.chain)}</td>
          <td class="px-4 py-3 text-right num text-white" data-live="wl:${k}">${F.price(it.price)}</td>
          <td class="px-4 py-3 text-right num ${F.cls(ch)}">${F.pctAuto(ch)}</td>
          <td class="px-4 py-3 text-right num text-slate-300">${F.usd(it.vol)}</td>
          <td class="px-4 py-3 text-right num text-mut">${F.usd(isCoin?it.mcap:it.liq)}</td>
          <td class="px-3 py-3 text-center"><button data-rm="${k}" class="text-mut hover:text-down" title="Remove">✕</button></td></tr>`;
      }).join('')}</tbody></table></div>`;
  }
  function render(){
    if (!S.state.lists.some(l => l.id === viewing)) viewing = S.state.lists[0].id;
    const l = S.state.lists.find(x => x.id === viewing);
    root.innerHTML = `<div class="space-y-4">
      <div class="flex items-center gap-2 flex-wrap">
        <h2 class="font-disp font-semibold text-white text-lg mr-2">Watchlists</h2>
        <div class="flex flex-wrap gap-1.5">${tabsHtml()}</div></div>
      <div class="flex items-center gap-2 flex-wrap">
        ${viewing !== S.state.activeList ? `<button data-mkactive class="text-xs bg-gold/15 border border-gold/50 text-gold rounded-lg px-3 py-1.5 hover:bg-gold/25">★ Make active list</button>` : '<span class="text-xs text-gold">★ Active — stars across the app add here</span>'}
        <button data-ren class="text-xs bg-panel border border-line rounded-lg px-3 py-1.5 text-mut hover:text-white">Rename</button>
        ${viewing !== 'default' ? '<button data-dell class="text-xs bg-panel border border-line rounded-lg px-3 py-1.5 text-mut hover:text-down">Delete list</button>' : ''}
        <div class="relative ml-auto w-64">
          <input data-addq placeholder="Add asset to this list…" autocomplete="off"
            class="w-full bg-panel border border-line rounded-lg px-3 py-1.5 text-xs placeholder:text-mut/70 focus:border-acc/60 focus:outline-none">
          <div data-addres class="hidden absolute top-full mt-1 left-0 right-0 bg-panel border border-line rounded-xl shadow-2xl shadow-black/60 overflow-hidden z-30"></div></div></div>
      <div class="bg-panel border border-line rounded-xl overflow-hidden" id="wlTable">${rows(l)}</div></div>`;
    const q = root.querySelector('[data-addq]'), res = root.querySelector('[data-addres]');
    q.addEventListener('input', () => {
      const v = q.value.trim();
      if (!v){ res.classList.add('hidden'); return; }
      const hits = CDX.Data.search(v, 6);
      res.innerHTML = hits.map(h => `<button data-addkey="${h.key}" class="w-full text-left flex items-center gap-2 px-3 py-2 hover:bg-panel2 text-xs">
        <span class="text-white font-medium">${F.esc(CDX.Data.label(h.it))}</span>
        <span class="text-mut truncate">${F.esc(h.it.name)}</span></button>`).join('') || '<div class="px-3 py-2 text-xs text-mut">No results</div>';
      res.classList.remove('hidden');
    });
    q.addEventListener('blur', () => setTimeout(() => res.classList.add('hidden'), 160));
  }
  return {
    mount(el){
      root = el;
      viewing = S.state.activeList;
      render();
      undelegate = D.delegate(root, {
        '[data-vl]': t => { viewing = t.dataset.vl; render(); },
        '[data-newl]': () => { const name = window.prompt('New watchlist name:'); if (name){ const l = S.createList(name); viewing = l.id; render(); } },
        '[data-mkactive]': () => { S.setActiveList(viewing); render(); U.toast('★ now adds to this list', 'up'); },
        '[data-ren]': () => { const l = S.state.lists.find(x=>x.id===viewing); const name = window.prompt('Rename list:', l.name); if (name){ S.renameList(viewing, name); render(); } },
        '[data-dell]': () => { S.deleteList(viewing); viewing = 'default'; render(); },
        '[data-addkey]': t => { S.addToList(viewing, t.dataset.addkey); render(); },
        '[data-rm]': t => { S.removeFromList(viewing, t.dataset.rm); render(); },
        '[data-go]': t => CDX.Router.go(t.dataset.go)
      });
      subs.push(CDX.Bus.on('tick', changed => {
        for (const { key, dir } of changed){
          const node = root.querySelector(`[data-live="wl:${key}"]`);
          if (node) D.liveSet(node, F.price(CDX.Data.byKey(key).price), dir);
        }
      }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; root=null; }
  };
})();
