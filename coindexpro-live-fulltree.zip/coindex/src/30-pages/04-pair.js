/* Page: Pair detail — live chart, trade tape, liquidity analytics, risk, holders/LP.
   Phase 2 adds: trades stream, liquidity depth, holder intel. Route: #/pair/:id */
CDX.Pages.pair = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI;
  let subs = [], root = null, chart = null, undelegate = null, key = null, tape = [], tapeFilter = 'all';
  const short = a => a && a.length > 12 ? a.slice(0, 6) + '…' + a.slice(-4) : (a || '—');
  const tapeMax = () => Math.max(...tape.slice(0, 30).map(t => t.usd), 1);
  function tapeRow(t, max){
    const amt = t.price > 0 ? t.usd / t.price : null;
    const w = Math.max(4, Math.min(100, t.usd / max * 100));
    return `<div class="relative flex items-center gap-2 px-4 py-1 border-b border-line/30 last:border-0 text-[11.5px] overflow-hidden">
      <div class="absolute inset-y-0 right-0 ${t.side === 'buy' ? 'bg-up/[0.07]' : 'bg-down/[0.07]'}" style="width:${w}%"></div>
      <span class="num text-mut w-12 shrink-0 relative">${F.rel(t.ts)}</span>
      <span class="num font-bold w-8 relative ${t.side === 'buy' ? 'text-up' : 'text-down'}">${t.side === 'buy' ? 'BUY' : 'SELL'}</span>
      <span class="num text-white w-[72px] text-right relative ${t.usd >= 10e3 ? 'font-semibold' : ''}">${F.usd(t.usd)}${t.usd >= 50e3 ? ' 🐋' : ''}</span>
      <span class="num text-mut/80 w-[88px] text-right relative hidden sm:inline">${amt != null ? F.num(amt) : '—'}</span>
      <span class="num text-mut text-right flex-1 relative">${F.price(t.price)}</span>
      ${t.wallet ? `<span class="num text-[10px] text-mut relative shrink-0">${short(t.wallet)}</span>` : ''}</div>`;
  }
  function tapeFiltered(){
    let rows = tape;
    if (tapeFilter === 'buy' || tapeFilter === 'sell') rows = rows.filter(t => t.side === tapeFilter);
    else if (tapeFilter === 'big') rows = rows.filter(t => t.usd >= 1000);
    return rows;
  }
  /* orderflow footer: cumulative delta of the visible tape window */
  function tapeFooter(){
    const rows = tape.slice(0, 30);
    if (!rows.length) return '';
    let b = 0, s = 0;
    rows.forEach(t => t.side === 'buy' ? b += t.usd : s += t.usd);
    const tot = b + s || 1, delta = b - s;
    return `<div class="px-4 py-2 border-t border-line bg-panel2/60">
      <div class="flex justify-between text-[10px] uppercase tracking-wider text-mut mb-1">
        <span>Orderflow · last ${rows.length} prints</span>
        <span class="num normal-case ${delta >= 0 ? 'text-up' : 'text-down'}">Δ ${(delta >= 0 ? '+' : '−') + F.usd(Math.abs(delta))}</span></div>
      <div class="h-2 rounded-full overflow-hidden flex bg-line"><div class="bg-up" style="width:${(b / tot * 100).toFixed(0)}%"></div><div class="bg-down flex-1"></div></div>
      <div class="flex justify-between num text-[10px] mt-0.5"><span class="text-up">${F.usd(b)} taker buy</span><span class="text-down">${F.usd(s)} taker sell</span></div></div>`;
  }
  function renderTape(){
    const host = root && root.querySelector('#pTape');
    if (!host) return;
    const rows = tapeFiltered();
    const max = tapeMax();
    host.innerHTML = (rows.length
      ? rows.slice(0, 30).map(t => tapeRow(t, max)).join('')
      : '<div class="px-4 py-6 text-sm text-mut">Waiting for on-chain prints…</div>') + tapeFooter();
    const fl = root.querySelector('#pTapeF');
    if (fl) fl.querySelectorAll('[data-tf2]').forEach(b =>
      b.className = 'px-1.5 py-0.5 rounded ' + (b.dataset.tf2 === tapeFilter ? 'bg-acc/20 text-white' : 'text-mut hover:text-white'));
  }
  function liqAnalytics(p){
    const tx = p.buys + p.sells;
    const turn = p.vol / Math.max(p.liq, 1);
    const m = p.flowMeasured;
    const mPct = m && m.buyVol + m.sellVol > 0 ? m.buyVol / (m.buyVol + m.sellVol) * 100 : null;
    const rows = [
      ['Pooled Liquidity', F.usd(p.liq)], ['Turnover (Vol/Liq)', turn.toFixed(2) + '×'],
      ['Trades 24h', F.num(tx)], ['Avg Trade Size', tx ? F.usd(p.vol / tx) : '—'],
      ['FDV / Liquidity', p.liq ? (p.fdv / p.liq).toFixed(1) + '×' : '—'],
      ['Liquidity / FDV', p.fdv ? (p.liq / p.fdv * 100).toFixed(2) + '%' : '—'],
      (() => { const v = CDX.Liq.pressure(p).score;
        return ['Liq Pressure', `<span class="${v >= 55 ? 'text-down' : v >= 30 ? 'text-gold' : 'text-up'}">${v}</span>/100`]; })(),
      (() => { const v = CDX.Liq.stability(p).score;
        return ['Liq Stability', `<span class="${v >= 60 ? 'text-up' : v >= 35 ? 'text-gold' : 'text-down'}">${v}</span>/100`]; })()
    ];
    const buyShare = tx ? p.buys / tx * 100 : 50;
    return `<div class="mb-2.5">
      <div class="flex justify-between text-[10px] uppercase tracking-wider text-mut mb-1"><span>Liquidity vs 24h Volume</span><span class="num normal-case">${turn.toFixed(2)}×</span></div>
      <div class="flex items-center gap-1.5">
        <div class="h-2 rounded-full bg-acc/60" style="width:${Math.max(8, Math.min(100, 100 / (1 + turn))).toFixed(0)}%"></div>
        <div class="h-2 rounded-full bg-gold/60 flex-1"></div></div>
      <div class="flex justify-between num text-[10px] text-mut mt-0.5"><span>liq ${F.usd(p.liq)}</span><span>vol ${F.usd(p.vol)}</span></div>
      <div class="flex justify-between text-[10px] uppercase tracking-wider text-mut mb-1 mt-2"><span>Txn buy/sell split</span><span class="num normal-case">${buyShare.toFixed(0)}% buys</span></div>
      <div class="h-2 rounded-full overflow-hidden flex bg-line"><div class="bg-up" style="width:${buyShare.toFixed(0)}%"></div><div class="bg-down flex-1"></div></div></div>
    <div class="grid grid-cols-2 gap-2.5">${rows.map(([l, v]) => `
      <div class="bg-panel2 border border-line rounded-lg px-3 py-2">
        <div class="text-[9px] uppercase tracking-wider text-mut">${l}</div>
        <div class="num text-white text-sm font-medium">${v}</div></div>`).join('')}</div>
      ${mPct != null ? `<div class="mt-3"><div class="text-[10px] uppercase tracking-wider text-mut mb-1">Measured buy/sell volume <span class="normal-case">(recent prints)</span></div>
        <div class="h-2 rounded-full overflow-hidden flex bg-line"><div class="bg-up" style="width:${mPct.toFixed(0)}%"></div><div class="bg-down flex-1"></div></div>
        <div class="flex justify-between text-[11px] mt-1"><span class="text-up num">${F.usd(m.buyVol)}</span><span class="text-down num">${F.usd(m.sellVol)}</span></div></div>` : ''}`;
  }
  function concRows(b, title){
    if (!b || !b.top.length) return '';
    return `<div class="mb-3 last:mb-0">
      <div class="flex justify-between text-[10px] uppercase tracking-wider text-mut mb-1">
        <span>${title}</span><span class="num normal-case">top ${b.top.length} = ${b.topPct.toFixed(1)}%</span></div>
      <div class="h-1.5 bg-line rounded-full overflow-hidden flex mb-2">
        <div class="bg-gold" style="width:${Math.min(100, b.contractPct).toFixed(1)}%" title="contracts"></div>
        <div class="bg-acc" style="width:${Math.min(100, b.eoaPct).toFixed(1)}%" title="wallets"></div></div>
      ${b.top.slice(0, 5).map((h, i) => `<div class="flex items-center gap-2 text-[11px] py-0.5">
        <span class="text-mut w-3">${i + 1}</span>
        <span class="num text-slate-300">${h.label ? F.esc(h.label) : short(h.addr)}</span>
        ${h.isContract ? '<span class="text-[8px] font-bold border border-gold/40 text-gold rounded px-1">CONTRACT</span>' : ''}
        <span class="ml-auto num text-mut">${h.pct.toFixed(2)}%</span></div>`).join('')}</div>`;
  }
  function riskPanelHtml(r){
    return `${CDX.Risk.ui.gauges(r)}
      <div>${r.vectors.map(CDX.Risk.ui.vectorRow).join('')}</div>
      <div class="text-[9px] text-mut mt-2">${r.deep ? 'On-chain evidence: holder & LP registry, owner(), live trade tape.' : 'Telemetry heuristics' + (CDX.Data.byKey(key) && CDX.Data.byKey(key).chain === 'pulsechain' ? ' — reading on-chain evidence…' : ' — on-chain evidence available on PulseChain pairs.')}</div>`;
  }
  async function loadRisk(p){
    const host = root && root.querySelector('#pRisk');
    if (!host) return;
    host.innerHTML = riskPanelHtml(CDX.Risk.quick(p));
    if (p.chain !== 'pulsechain') return;
    try {
      const deep = await CDX.Risk.deepAnalyze(p);
      const h2 = root && root.querySelector('#pRisk');
      if (h2) h2.innerHTML = riskPanelHtml(deep);
    } catch(e){}
  }
  async function loadConcentration(p){
    const host = root && root.querySelector('#pConc');
    if (!host) return;
    try {
      const [holders, lp] = await Promise.all([
        p.ca && p.ca.toLowerCase() !== p.address.toLowerCase() ? CDX.Providers.pulsex.holdersBreakdown(p.ca, 10) : null,
        CDX.Providers.pulsex.holdersBreakdown(p.address, 10)
      ]);
      if (!root) return;
      const html = (holders ? concRows(holders, `Holder concentration · ${F.esc(p.base)}`) : '')
                 + (lp ? concRows(lp, 'LP concentration · pool token') : '');
      host.innerHTML = html || '<div class="text-sm text-mut">Explorer data unavailable.</div>';
      const hc = root.querySelector('#pHolders');
      if (hc && holders && holders.holders != null) hc.textContent = F.num(holders.holders);
    } catch(e){ if (host) host.innerHTML = '<div class="text-sm text-mut">Explorer data unavailable.</div>'; }
  }
  function tfButtons(){
    const cur = chart ? chart.getTf() : CDX.Store.state.prefs.chartTf;
    return CDX.Chart.TFS.map(tf => `<button data-ctf="${tf}" class="px-2.5 py-1 rounded-md ${tf===cur?'seg-active':'text-mut hover:text-white'}">${tf}</button>`).join('');
  }
  return {
    mount(el, ctx){
      const want = (ctx.params.id || '').toLowerCase();
      const p = CDX.Data.pairs.find(x => x.id === ctx.params.id)
             || CDX.Data.pairs.find(x => x.id.toLowerCase() === want);
      root = el;
      if (!p){ root.innerHTML = '<div class="py-20 text-center text-mut">Unknown pair.</div>'; return; }
      key = 'd:' + p.id;
      const buyPct = p.buys / (p.buys + p.sells) * 100;
      root.innerHTML = `<div class="space-y-5">
        <div class="flex items-start gap-3 flex-wrap">
          ${U.logo(p.base, CDX.Data.CHAINS[p.chain].color, 10)}
          <div class="min-w-0 flex-1">
            <div class="flex items-center gap-2 flex-wrap">
              <h1 class="font-disp font-bold text-white text-2xl">${F.esc(p.base)}<span class="text-mut font-normal">/${F.esc(p.quote)}</span></h1>
              ${U.chainBadge(p.chain, true)}
              <span class="text-[10px] text-mut border border-line rounded px-1.5 py-0.5">${F.esc(p.dex)}</span>
              <button data-copy="${p.ca}" class="text-[10px] text-mut hover:text-acc border border-line hover:border-acc/50 rounded px-1.5 py-0.5 num">${p.ca.slice(0,6)}…${p.ca.slice(-4)} ⧉</button>
              <span class="ml-1">${U.star('d:' + p.id)}</span></div>
            <div class="flex items-end gap-3 mt-1.5 flex-wrap">
              <span class="font-disp font-bold text-white text-3xl num" data-live="ppx">${F.price(p.price)}</span>
              <span class="num text-lg font-semibold ${F.cls(p.ch.h24)}" data-live="pch">${F.pctAuto(p.ch.h24)} <span class="text-xs font-normal text-mut">24h</span></span>
              <span class="num text-sm ${F.cls(p.ch.h1)}">${F.pctAuto(p.ch.h1)} <span class="text-mut font-normal">1h</span></span>
              ${CDX.TrustUI ? CDX.TrustUI.sourceChip(CDX.Asset.resolve('d:' + p.id)) : ''}</div></div></div>
        <div class="grid grid-cols-4 gap-2">${['m5','h1','h6','h24'].map(tf=>`
          <div class="bg-panel2 border border-line rounded-lg px-2 py-2 text-center">
            <div class="text-[10px] uppercase text-mut">${{m5:'5m',h1:'1h',h6:'6h',h24:'24h'}[tf]}</div>
            <div class="num text-sm font-medium ${F.cls(p.ch[tf])}">${F.pctAuto(p.ch[tf])}</div></div>`).join('')}</div>
        <div class="bg-panel border border-line rounded-xl p-4">
          <div class="flex items-center justify-between mb-3 flex-wrap gap-2">
            <h3 class="font-disp font-semibold text-white">Price Chart <span class="text-mut text-xs font-body font-normal">TradingView Lightweight · live</span></h3>
            <div class="flex items-center bg-panel2 border border-line rounded-lg p-0.5 text-xs" id="ctfSeg">${tfButtons()}</div></div>
          <div id="tvChart" class="w-full" style="height:420px"></div></div>
        <div class="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-3">
          ${[['Liquidity',F.usd(p.liq)],['Volume 24h',F.usd(p.vol)],['Buys 24h',F.num(p.buys)],['Sells 24h',F.num(p.sells)],['Pair Age',F.age(p.ageH)],['FDV',F.usd(p.fdv)]]
            .map(([l,v])=>`<div class="bg-panel2 border border-line rounded-lg px-3 py-2.5"><div class="text-[10px] uppercase tracking-wider text-mut mb-0.5">${l}</div><div class="num text-white font-medium">${v}</div></div>`).join('')}</div>
        <div class="grid lg:grid-cols-2 xl:grid-cols-4 gap-4">
          <div class="bg-panel border border-line rounded-xl p-4">
            <h3 class="font-disp font-semibold text-white mb-3">Trust Score <span class="text-mut text-xs font-body font-normal">explainable</span></h3>
            <div id="pTrust">${CDX.TrustUI ? CDX.TrustUI.trustPanel(p.id) : ''}</div>
            <div class="mt-3 pt-3 border-t border-line/50">
              <div class="text-[10px] uppercase tracking-wide text-mut mb-1.5">Whale participation <span class="text-[9px] normal-case">· observed-only</span></div>
              <div id="pWhaleP">${CDX.TrustUI ? CDX.TrustUI.whaleParticipation(p.id) : ''}</div></div></div>
          <div class="bg-panel border border-line rounded-xl p-4">
            <h3 class="font-disp font-semibold text-white mb-3">Risk Intelligence</h3>
            <div id="pRisk"><div class="space-y-2"><div class="shimmer h-16"></div><div class="shimmer h-3 w-3/4"></div><div class="shimmer h-3 w-2/3"></div></div></div></div>
          <div class="bg-panel border border-line rounded-xl overflow-hidden flex flex-col">
            <div class="flex items-center justify-between px-4 py-3 border-b border-line">
              <h3 class="font-disp font-semibold text-white">Trade Tape <span class="w-1.5 h-1.5 rounded-full bg-down live-dot inline-block ml-1"></span></h3>
              <span id="pTapeF" class="flex gap-1 text-[10px] num">${[['all','All'],['buy','Buys'],['sell','Sells'],['big','>$1K']].map(([id,l])=>`<button data-tf2="${id}" class="px-1.5 py-0.5 rounded ${id==='all'?'bg-acc/20 text-white':'text-mut hover:text-white'}">${l}</button>`).join('')}</span>
              <span class="text-[10px] text-mut">on-chain prints</span></div>
            <div id="pTape" class="max-h-[380px] overflow-y-auto"><div class="px-4 py-6 text-sm text-mut">Loading prints…</div></div></div>
          <div class="bg-panel border border-line rounded-xl p-4">
            <h3 class="font-disp font-semibold text-white mb-3">Liquidity Analytics</h3>
            ${liqAnalytics(p)}
            <div class="mt-3"><div class="text-[10px] uppercase tracking-wider text-mut mb-1">Txn pressure (24h)</div>
              <div class="h-2 rounded-full overflow-hidden flex bg-line"><div class="bg-up" style="width:${buyPct}%"></div><div class="bg-down flex-1"></div></div>
              <div class="flex justify-between text-[11px] mt-1"><span class="text-up num">${F.num(p.buys)} buys</span><span class="text-down num">${F.num(p.sells)} sells</span></div></div></div>
          ${p.chain === 'pulsechain' ? `<div class="bg-panel border border-line rounded-xl p-4">
            <div class="flex items-center justify-between mb-3">
              <h3 class="font-disp font-semibold text-white">Holders & LP</h3>
              <span class="text-[11px] text-mut">Holders <span class="num text-white" id="pHolders">${p.holders ? F.num(p.holders) : '…'}</span></span></div>
            <div id="pConc"><div class="text-sm text-mut">Reading explorer…</div></div></div>`
          : `<div class="bg-panel border border-line rounded-xl p-4">
            <h3 class="font-disp font-semibold text-white mb-2">Holders & LP</h3>
            <p class="text-sm text-mut leading-relaxed">On-chain holder and LP concentration is available for PulseChain pairs, where explorer data is wired in. Trade tape and liquidity analytics above are live for this chain.</p></div>`}
        </div>
      </div>`;
      chart = CDX.Chart.create(D.$('#tvChart', root), key, p);
      undelegate = D.delegate(root, {
        '[data-tf2]': t => { tapeFilter = t.dataset.tf2; renderTape(); },
        '[data-ctf]': t => { chart.setTf(t.dataset.ctf); D.$('#ctfSeg', root).innerHTML = tfButtons(); }
      });
      tape = [];
      CDX.Net.Conn.routePoller('pair:tape', async () => {
        const fresh = p.chain === 'pulsechain'
          ? await CDX.Providers.pulsex.poolTrades(p.address, 0)
          : await CDX.Providers.geckoterminal.trades(p.chain, p.address, 0);
        const seen = new Set(tape.map(t => t.tx));
        for (const t of fresh) if (!t.tx || !seen.has(t.tx)) tape.push(t);
        tape.sort((a, b) => b.ts - a.ts);
        tape = tape.slice(0, 80);
        renderTape();
      }, 20000, { immediate: true }).start();
      subs.push(CDX.Bus.on('whale:new', t => {
        if (t.pairId !== p.id) return;
        if (!tape.some(x => x.tx === t.tx)) tape.unshift({ ts: t.ts, side: t.side, usd: t.usd, price: t.price, wallet: t.wallet, tx: t.tx });
        renderTape();
      }));
      if (p.chain === 'pulsechain') loadConcentration(p);
      loadRisk(p);
      subs.push(CDX.Bus.on('tick', changed => {
        const hit = changed.find(x => x.key === key);
        if (!hit) return;
        D.liveSet(root.querySelector('[data-live="ppx"]'), F.price(p.price), hit.dir);
        const chNode = root.querySelector('[data-live="pch"]');
        if (chNode){ chNode.innerHTML = `${F.pctAuto(p.ch.h24)} <span class="text-xs font-normal text-mut">24h</span>`; chNode.className = 'num text-lg font-semibold ' + F.cls(p.ch.h24); }
      }));
      subs.push(CDX.Bus.on('whaleflow:updated', () => {
        const wp = root && root.querySelector('#pWhaleP');
        if (wp && CDX.TrustUI) wp.innerHTML = CDX.TrustUI.whaleParticipation(p.id);
      }));
      if (CDX.WhaleFlow && CDX.WhaleFlow.start) try { CDX.WhaleFlow.start(); } catch(e){}
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (chart) chart.destroy(); chart=null; if (undelegate) undelegate(); undelegate=null; root=null; }
  };
})();
