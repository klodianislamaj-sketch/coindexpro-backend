/* Page: PulseChain Hub — flagship ecosystem intelligence. Route: #/pulsechain */
CDX.Pages.pulsechain = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI, I = CDX.Intel, IU = CDX.IntelUI;
  let subs = [], root = null, undelegate = null, holderCa = null, holderSym = null;
  const HOUR = 36e5;
  const money = v => (v >= 0 ? '+' : '−') + F.usd(Math.abs(v));
  const short = a => a && a.length > 12 ? a.slice(0, 6) + '…' + a.slice(-4) : (a || '');
  const pulsePairs = () => CDX.Data.pairs.filter(p => p.chain === 'pulsechain');
  const panel = (title, sub, body, extra) => `<div class="bg-panel border border-line rounded-xl overflow-hidden flex flex-col">
    <div class="flex items-center justify-between px-4 py-3 border-b border-line">
      <div><h3 class="font-disp font-semibold text-white">${title}</h3><div class="text-[10px] text-mut">${sub}</div></div>${extra || ''}</div>
    <div class="flex-1 min-h-0">${body || '<div class="px-4 py-7 text-center text-sm text-mut">Building as live data lands…</div>'}</div></div>`;
  const bar = (v, color) => `<div class="h-1.5 bg-line rounded-full overflow-hidden"><div class="h-full rounded-full" style="width:${Math.min(100, v)}%;background:${color}"></div></div>`;
  /* ---- PulseChain trending engine: turnover × activity × momentum × freshness × velocity ---- */
  const vel0 = new Map();
  function pulseVel(p){
    const n = p.buys + p.sells;
    let v = vel0.get(p.id);
    if (!v) vel0.set(p.id, v = { ts: Date.now(), n });
    const mins = (Date.now() - v.ts) / 60e3;
    return mins >= 1.5 && n >= v.n ? (n - v.n) / mins : n / (24 * 60);
  }
  function pulseTrendScore(p){
    const turn = Math.min(p.vol / Math.max(p.liq, 1), 14);
    const act = Math.log10(p.buys + p.sells + 10);
    const mom = 1 + (Math.min(Math.abs(p.ch.h1 || 0), 50) + Math.min(Math.abs(p.ch.h6 || 0), 60) / 2) / 35;
    const fresh = p.ageH <= 24 ? 1.7 : p.ageH <= 96 ? 1.25 : 1;
    const vel = 1 + Math.min(pulseVel(p), 8) / 9;
    const hg = CDX.Alpha.holderGrowth(p.id);
    const hold = hg && hg.perHr > 0 ? 1 + Math.min(Math.log10(hg.perHr + 1) * 0.35, 0.5) : 1;
    const acc = 1 + (CDX.Alpha.accel(p).score - 50) / 220;
    const floor = p.liq < 4000 ? 0.25 : 1;
    return Math.round(Math.log10(p.vol + 2) * (1 + turn / 4) * act * mom * fresh * vel * hold * acc * floor * 6);
  }
  function vTrending(){
    const rows = pulsePairs().map(p => ({ p, sc: pulseTrendScore(p) }))
      .sort((a, b) => b.sc - a.sc).slice(0, 8);
    const max = Math.max(...rows.map(r => r.sc), 1);
    return rows.map(({ p, sc }, i) => `<div class="row-hov px-4 py-2 border-b border-line/40 last:border-0" data-go="/pair/${p.id}" style="cursor:pointer">
      <div class="flex items-center gap-2 text-[12px]">
        <span class="num text-mut w-4">${i + 1}</span>${U.logo(p.base, '#FF0080', 5)}
        <span class="text-white font-medium">${F.esc(p.base)}<span class="text-mut font-normal">/${F.esc(p.quote)}</span></span>
        <span class="text-[9px] text-mut">${F.esc(p.dex)}</span>
        <span class="ml-auto num font-disp font-bold ${sc >= max * 0.7 ? 'text-gold' : 'text-slate-300'}">${sc}</span></div>
      <div class="flex items-center gap-2 mt-1">
        <div class="flex-1">${bar(sc / max * 100, '#FF0080AA')}</div>
        <span class="num text-[9.5px] text-mut">${pulseVel(p).toFixed(1)} tx/m · ${(p.vol / Math.max(p.liq, 1)).toFixed(1)}× · Mom ${CDX.Alpha.scoresFor(p).momentum} · <span class="${F.cls(p.ch.h1)}">${F.pctAuto(p.ch.h1)}</span> 1h</span></div></div>`).join('');
  }
  /* ---- buy pressure heatmap: size = volume · color = buy-side share ---- */
  function vPressureMap(){
    const items = pulsePairs().filter(p => p.vol > 500).slice(0, 40).map(p => {
      const m = p.flowMeasured;
      const share = m && m.buyVol + m.sellVol > 0 ? m.buyVol / (m.buyVol + m.sellVol)
                  : (p.buys + p.sells ? p.buys / (p.buys + p.sells) : 0.5);
      return { label: p.base, value: p.vol, ch: (share - 0.5) * 16, sub: (share * 100).toFixed(0) + '% buy', go: '/pair/' + p.id };
    });
    return items.length ? `<div id="plsHeat" class="p-2" style="height:230px"></div>
      <div class="px-4 pb-2 flex items-center gap-1.5 text-[9px] text-mut">sell pressure
        ${[-8,-4,-1,1,4,8].map(v => `<span class="w-5 h-2.5 rounded-sm inline-block" style="background:${CDX.Heatmap.colorFor(v, 8)}"></span>`).join('')} buy pressure · size = 24h volume</div>` : '';
  }
  /* ---- whale accumulation: 6h net by pool from the real print ledger ---- */
  function vAccumulation(){
    const cut = Date.now() - 6 * HOUR;
    const byPair = new Map();
    for (const t of CDX.DataRaw.WHALE_TRADES){
      if (t.ts < cut) continue;
      const p = CDX.Data.byKey('d:' + t.pairId);
      if (!p || p.chain !== 'pulsechain') continue;
      const e = byPair.get(t.pairId) || { p, buy: 0, sell: 0, prints: 0, wallets: new Set(), byW: new Map() };
      t.side === 'buy' ? e.buy += t.usd : e.sell += t.usd;
      e.prints++;
      if (t.wallet){ e.wallets.add(t.wallet); if (t.side === 'buy') e.byW.set(t.wallet, (e.byW.get(t.wallet) || 0) + t.usd); }
      byPair.set(t.pairId, e);
    }
    const rows = [...byPair.values()].map(e => ({ ...e, net: e.buy - e.sell }))
      .sort((a, b) => b.net - a.net).slice(0, 7);
    if (!rows.length) return '';
    const max = Math.max(...rows.map(r => Math.abs(r.net)), 1);
    return rows.map(r => {
      const topW = [...r.byW.entries()].sort((a, b) => b[1] - a[1])[0];
      const w = topW ? CDX.DataRaw.walletByAddr.get(topW[0]) : null;
      const tot = r.buy + r.sell || 1;
      return `<div class="row-hov px-4 py-2 border-b border-line/40 last:border-0" data-go="/pair/${r.p.id}" style="cursor:pointer">
      <div class="flex items-center gap-2 text-[12px]">${U.logo(r.p.base, '#FF0080', 5)}
        <span class="text-white font-medium">${F.esc(r.p.base)}</span>
        <span class="num text-[9.5px] text-mut">${r.prints} prints · ${r.wallets.size} wallets</span>
        <span class="ml-auto num font-semibold ${r.net >= 0 ? 'text-up' : 'text-down'}">${money(r.net)}</span></div>
      <div class="h-1.5 rounded-full overflow-hidden flex bg-line mt-1"><div class="bg-up" style="width:${(r.buy / tot * 100).toFixed(0)}%"></div><div class="bg-down flex-1"></div></div>
      ${topW ? `<div class="num text-[9px] text-mut mt-0.5">lead buyer: <span>${w ? F.esc(w.label) : short(topW[0])}</span> · ${F.usd(topW[1])}</div>` : ''}</div>`; }).join('');
  }
  /* ---- holder leaderboard: live Blockscout breakdown per tracked token ---- */
  function holderTokens(){
    const seen = new Map();
    for (const p of pulsePairs()){
      const ca = p.ca && p.ca.startsWith('0x') && p.ca.toLowerCase() !== p.address.toLowerCase() ? p.ca : null;
      if (!ca) continue;
      if (!seen.has(p.base) || seen.get(p.base).liq < p.liq) seen.set(p.base, { sym: p.base, ca, liq: p.liq, fdv: p.fdv });
    }
    return [...seen.values()].sort((a, b) => b.liq - a.liq).slice(0, 8);
  }
  async function loadHolders(){
    const host = root && root.querySelector('#plsHolders');
    if (!host || !holderCa) return;
    host.innerHTML = '<div class="p-4 space-y-2"><div class="shimmer h-4"></div><div class="shimmer h-4 w-5/6"></div><div class="shimmer h-4 w-4/6"></div></div>';
    try {
      const tok = holderTokens().find(t => t.ca === holderCa);
      const b = await CDX.Net.Cache.swr('plsH:' + holderCa,
        () => CDX.Providers.pulsex.holdersBreakdown(holderCa, 10), { ttl: 600e3, stale: 3600e3 });
      const h2 = root && root.querySelector('#plsHolders');
      if (!h2 || !b || !b.top.length){ if (h2) h2.innerHTML = '<div class="px-4 py-6 text-sm text-mut">No holder data exposed for this token.</div>'; return; }
      h2.innerHTML = b.top.map((h, i) => {
        const w = CDX.DataRaw.walletByAddr.get((h.addr || '').toLowerCase()) || CDX.DataRaw.walletByAddr.get(h.addr);
        const usd = tok && tok.fdv ? tok.fdv * h.pct / 100 : null;
        return `<div class="flex items-center gap-2.5 px-4 py-1.5 border-b border-line/40 last:border-0 text-[11.5px]">
          <span class="num text-mut w-4">${i + 1}</span>
          <span class="num text-slate-200">${w ? F.esc(w.label) : F.esc(h.label || short(h.addr))}</span>
          ${h.isContract ? '<span class="text-[8px] border border-acc/40 text-acc rounded px-1">CONTRACT</span>' : ''}
          <span class="ml-auto flex items-center gap-2 w-44">
            <span class="flex-1">${bar(Math.min(h.pct * 2.2, 100), h.isContract ? '#5B8CFF' : '#FF0080')}</span>
            <span class="num text-white w-12 text-right">${h.pct.toFixed(2)}%</span></span>
          ${usd != null ? `<span class="num text-[9.5px] text-mut w-16 text-right hidden sm:inline">≈${F.usd(usd)}</span>` : ''}</div>`;
      }).join('') + `<div class="px-4 py-1.5 text-[9.5px] text-mut num">top-10 hold ${b.topPct.toFixed(1)}% · ${b.contractPct.toFixed(0)}% in contracts</div>`;
    } catch(e){
      const h2 = root && root.querySelector('#plsHolders');
      if (h2) h2.innerHTML = '<div class="px-4 py-6 text-sm text-mut">Explorer unreachable — retrying on next cycle.</div>';
    }
  }
  const holderChips = () => holderTokens().map(t =>
    `<button data-hold="${t.ca}" data-sym="${t.sym}" class="text-[10px] rounded px-1.5 py-0.5 border ${t.ca === holderCa ? 'border-pls/60 text-white bg-pls/15' : 'border-line text-mut hover:text-white'}">${F.esc(t.sym)}</button>`).join('');
  /* ---- wallet clustering (pulse pools only) ---- */
  function vClusters(){
    const pulseIds = new Set(pulsePairs().map(p => p.id));
    const cs = CDX.WalletIntel.clusters(2).filter(c => c.pairs.some(id => pulseIds.has(id))).slice(0, 4);
    if (!cs.length) return '';
    return cs.map((c, i) => `<div class="px-4 py-2.5 border-b border-line/40 last:border-0">
      <div class="flex items-center gap-2 text-[11px] flex-wrap mb-1">
        <span class="text-[9px] font-bold uppercase tracking-wider text-pls" style="color:#FF0080">Cluster ${i + 1}</span>
        <span class="text-mut">${c.wallets.length} wallets · ${c.pairs.length} pools</span>
        <span class="ml-auto num font-semibold ${c.net >= 0 ? 'text-up' : 'text-down'}">${money(c.net)}</span></div>
      <div class="flex items-center gap-1 flex-wrap">${c.wallets.slice(0, 4).map(a => {
        const w = CDX.DataRaw.walletByAddr.get(a);
        return `<span class="num text-[9.5px] border border-line rounded px-1.5 py-0.5 text-slate-300">${w ? F.esc(w.label) : short(a)}</span>`;
      }).join('')}${c.wallets.length > 4 ? `<span class="text-[9px] text-mut">+${c.wallets.length - 4}</span>` : ''}</div></div>`).join('');
  }
  /* ---- LP events + migrations (pulse only) ---- */
  function vLpFlow(){
    const evs = CDX.Liq.events(60).filter(e => { const p = CDX.Data.byKey('d:' + e.pairId); return p && p.chain === 'pulsechain'; }).slice(0, 6);
    const ms = CDX.Liq.migrations(20).filter(m => { const p = CDX.Data.byKey('d:' + m.toId); return p && p.chain === 'pulsechain'; }).slice(0, 3);
    if (!evs.length && !ms.length) return '';
    return (ms.length ? `<div class="px-4 pt-2 pb-1 text-[9.5px] uppercase tracking-wider text-mut">Migrations</div>` + ms.map(m => {
      const from = CDX.Data.byKey('d:' + m.fromId), to = CDX.Data.byKey('d:' + m.toId);
      return from && to ? `<div class="px-4 py-1.5 text-[11px] flex items-center gap-1.5 flex-wrap border-b border-line/30">
        <span class="text-white font-medium">${F.esc(m.sym)}</span><span class="num text-gold">≈${F.usd(m.usd)}</span>
        <a href="#/pair/${from.id}" class="text-down num text-[10px]">${F.esc(from.dex)}</a><span class="text-mut">→</span>
        <a href="#/pair/${to.id}" class="text-up num text-[10px]">${F.esc(to.dex)}</a>
        <span class="ml-auto num text-[9px] text-mut">${F.rel(m.ts)}</span></div>` : '';
    }).join('') : '')
    + (evs.length ? `<div class="px-4 pt-2 pb-1 text-[9.5px] uppercase tracking-wider text-mut">LP adds / removals</div>` + evs.map(e => {
      const p = CDX.Data.byKey('d:' + e.pairId);
      return `<div class="row-hov px-4 py-1.5 text-[11px] flex items-center gap-2 border-b border-line/30 last:border-0" data-go="/pair/${p.id}" style="cursor:pointer">
        <span class="num text-[9px] text-mut w-10">${F.rel(e.ts)}</span>
        <span class="num text-[9.5px] font-bold w-12 ${e.type === 'add' ? 'text-up' : 'text-down'}">${e.type === 'add' ? '＋ADD' : '−PULL'}</span>
        <span class="text-white">${F.esc(p.base)}</span>
        <span class="ml-auto num ${e.delta >= 0 ? 'text-up' : 'text-down'}">${money(e.delta)}</span>
        <span class="num text-[9px] text-mut w-10 text-right">${e.pct >= 0 ? '+' : ''}${e.pct.toFixed(1)}%</span></div>`;
    }).join('') : '');
  }
  /* ---- fresh launches ---- */
  function vFresh(){
    const rows = pulsePairs().filter(p => p.ageH <= 96).sort((a, b) => a.ageH - b.ageH).slice(0, 8);
    if (!rows.length) return '';
    return rows.map(p => `<div class="row-hov px-4 py-2 border-b border-line/40 last:border-0" data-go="/pair/${p.id}" style="cursor:pointer">
      <div class="flex items-center gap-2 text-[12px]">${U.logo(p.base, '#FF0080', 5)}
        <span class="text-white font-medium">${F.esc(p.base)}<span class="text-mut font-normal">/${F.esc(p.quote)}</span></span>
        <span class="num text-up text-[10px]">${p.ageH <= 6 ? '⚡ ' : ''}${F.age(p.ageH)}</span>
        <span class="num text-[9px] text-gold">${pulseVel(p).toFixed(1)} tx/m</span>
        <span class="ml-auto">${CDX.Risk.ui.chip(CDX.Risk.quick(p))}</span></div>
      <div class="num text-[9.5px] text-mut mt-0.5">${F.esc(p.dex)} · Liq ${F.usd(p.liq)} · ${F.num(p.buys + p.sells)} tx · <span class="${F.cls(p.ch.h6)}">${F.pctAuto(p.ch.h6)}</span> 6h${p.holders ? ' · ' + F.num(p.holders) + ' holders' : ''}</div></div>`).join('');
  }
  /* ---- contract deployments (real Blockscout verified contracts) ---- */
  async function loadDeploys(){
    const host = root && root.querySelector('#plsDeploys');
    if (!host) return;
    try {
      const rows = await CDX.Net.Cache.swr('plsDeploys',
        () => CDX.Providers.pulsex.recentContracts(), { ttl: 300e3, stale: 1800e3 });
      const h2 = root && root.querySelector('#plsDeploys');
      if (!h2) return;
      h2.innerHTML = rows.length ? rows.slice(0, 8).map(c => `
        <div class="flex items-center gap-2.5 px-4 py-1.5 border-b border-line/40 last:border-0 text-[11.5px]">
          <span class="w-1.5 h-1.5 rounded-full shrink-0" style="background:#FF0080"></span>
          <span class="text-white truncate">${F.esc(c.name)}</span>
          ${c.lang ? `<span class="text-[8.5px] border border-line rounded px-1 text-mut uppercase">${F.esc(c.lang)}</span>` : ''}
          <span class="ml-auto num text-[9.5px] text-mut shrink-0">${c.txs != null ? F.num(c.txs) + ' tx · ' : ''}${c.verifiedAt ? F.rel(c.verifiedAt) : ''}</span>
          <button data-copy="${c.addr}" class="num text-[9.5px] text-mut hover:text-acc shrink-0">${short(c.addr)} ⧉</button></div>`).join('')
        : '<div class="px-4 py-6 text-sm text-mut">No recently verified contracts.</div>';
    } catch(e){
      const h2 = root && root.querySelector('#plsDeploys');
      if (h2) h2.innerHTML = '<div class="px-4 py-6 text-sm text-mut">Explorer unreachable.</div>';
    }
  }
  function vHolderGrowth(){
    const rows = pulsePairs().map(p => ({ p, hg: CDX.Alpha.holderGrowth(p.id) }))
      .filter(x => x.hg && Math.abs(x.hg.perHr) > 0.2)
      .sort((a, b) => b.hg.perHr - a.hg.perHr).slice(0, 7);
    if (!rows.length) return '';
    const max = Math.max(...rows.map(r => Math.abs(r.hg.perHr)), 1);
    return rows.map(({ p, hg }) => `<div class="row-hov px-4 py-2 border-b border-line/40 last:border-0" data-go="/pair/${p.id}" style="cursor:pointer">
      <div class="flex items-center gap-2 text-[12px]">${U.logo(p.base, '#FF0080', 5)}
        <span class="text-white font-medium">${F.esc(p.base)}</span>
        <span class="num text-[9.5px] text-mut">${p.holders ? F.num(p.holders) + ' holders' : ''}</span>
        <span class="ml-auto num ${hg.perHr >= 0 ? 'text-up' : 'text-down'}">${hg.perHr >= 0 ? '+' : ''}${hg.perHr.toFixed(1)}/hr</span></div>
      <div class="flex items-center gap-2 mt-1"><div class="flex-1">${bar(Math.abs(hg.perHr) / max * 100, hg.perHr >= 0 ? '#2DD480' : '#FF5C5C')}</div>
        <span class="num text-[9px] text-mut">${hg.pct >= 0 ? '+' : ''}${hg.pct.toFixed(2)}%</span></div></div>`).join('');
  }
  function vPulseWallets(){
    const pulseIds = new Set(pulsePairs().map(p => p.id));
    const rows = CDX.WalletIntel.leaderboard()
      .filter(r => r.a.trades >= 2 && CDX.WalletIntel.ledgerFor(r.addr).some(t => pulseIds.has(t.pairId)))
      .sort((a, b) => b.rankScore - a.rankScore).slice(0, 6);
    if (!rows.length) return '';
    return rows.map((r, i) => `<div class="row-hov px-4 py-2 border-b border-line/40 last:border-0" >
      <div class="flex items-center gap-2 text-[12px]">
        <span class="num text-mut w-4">${['🥇','🥈','🥉'][i] || i + 1}</span>
        <span class="text-white font-medium">${F.esc(r.label)}</span>
        <span class="text-[8.5px] font-bold uppercase tracking-wider border rounded px-1 py-px" style="color:#FF0080;border-color:#FF008055">${r.b.archetype}</span>
        <span class="ml-auto num font-semibold ${r.a.totalPnl >= 0 ? 'text-up' : 'text-down'}">${money(r.a.totalPnl)}</span></div>
      <div class="num text-[9.5px] text-mut mt-0.5">win ${r.a.winRate != null ? r.a.winRate.toFixed(0) + '%' : '—'} · ${r.a.trades} prints${r.m ? ` · mirror <span class="${r.m.ret >= 0 ? 'text-up' : 'text-down'}">${r.m.ret >= 0 ? '+' : ''}${r.m.ret.toFixed(1)}%</span>` : ''} · cov ${r.a.coverage.toFixed(0)}%</div></div>`).join('');
  }
  function paintIntel(){
    D.$('#plsTrend', root).innerHTML = panel('Pulse Trending', 'turnover × activity × momentum × freshness × live tx velocity', vTrending());
    D.$('#plsMap', root).innerHTML = panel('Buy Pressure Heatmap', 'live pressure model: tx-delta imbalance ⊕ measured prints ⊕ whale net', vPressureMap());
    const heatHost = root.querySelector('#plsHeat');
    if (heatHost){
      const items = pulsePairs().filter(p => p.vol > 500).slice(0, 44).map(p => {
        const pr = CDX.Alpha.buyPressure(p, null);   // live model: tx deltas + measured prints
        return { label: p.base, value: p.vol, ch: (pr - 50) / 50 * 8, sub: pr.toFixed(0), go: '/pair/' + p.id };
      });
      CDX.Heatmap.render(heatHost, items, { maxAbs: 8 });
    }
    D.$('#plsAccum', root).innerHTML = panel('Whale Accumulation', 'net large-print flow per pool · 6h · real prints', vAccumulation());
    D.$('#plsHold', root).innerHTML = panel('Holder Leaderboard', 'on-chain registry · Blockscout', `<div class="px-4 py-2 border-b border-line flex gap-1 flex-wrap" id="plsHoldChips">${holderChips()}</div><div id="plsHolders"></div>`);
    D.$('#plsClust', root).innerHTML = panel('Wallet Clusters', 'wallets co-trading the same Pulse pools', vClusters());
    D.$('#plsLp', root).innerHTML = panel('Liquidity Migration & LP Flow <span class="w-1.5 h-1.5 rounded-full bg-down live-dot inline-block ml-1"></span>', 'pool-delta detection · pulse only', vLpFlow());
    D.$('#plsFresh', root).innerHTML = panel('Fresh Launches', '90s fast-lane discovery · ⚡ ≤6h · risk-chipped', vFresh());
    D.$('#plsGrow', root).innerHTML = panel('Holder Growth', 'on-chain holder velocity per pool', vHolderGrowth());
    D.$('#plsWallets', root).innerHTML = panel('Pulse Wallet Leaderboard', 'wallets active in Pulse pools · coverage-trusted ranking', vPulseWallets());
    D.$('#plsDeployP', root).innerHTML = panel('Contract Deployments', 'recently verified on Blockscout', '<div id="plsDeploys"><div class="p-4 space-y-2"><div class="shimmer h-4"></div><div class="shimmer h-4 w-5/6"></div><div class="shimmer h-4 w-4/6"></div></div></div>');
    loadHolders();
    loadDeploys();
  }
  function trackedStrip(s){
    const want = CDX.Providers.pulsex.TOKENS.map(t => t.baseSym.toUpperCase());
    const byBase = new Map();
    for (const p of s.pairs){
      const b = p.base.toUpperCase();
      if (!want.includes(b)) continue;
      if (!byBase.has(b) || byBase.get(b).liq < p.liq) byBase.set(b, p);
    }
    return want.filter(b => byBase.has(b)).map(b => {
      const p = byBase.get(b);
      return `<a href="#/pair/${p.id}" class="shrink-0 flex items-center gap-2 bg-panel border border-line hover:border-pls/50 rounded-lg px-3 py-2 transition-colors">
        ${U.logo(p.base, '#FF0080', 5)}
        <span class="text-xs font-semibold text-white">${F.esc(p.base)}</span>
        <span class="num text-xs text-slate-300" data-live="pt:${p.id}">${F.price(p.price)}</span>
        <span class="num text-[11px] ${F.cls(p.ch.h24)}">${F.pctAuto(p.ch.h24)}</span></a>`;
    }).join('');
  }
  function headChips(){
    const h = CDX.LiveData.pulseHead;
    return `<span class="inline-flex items-center gap-1.5 text-[11px] bg-panel border border-line rounded-lg px-2.5 py-1">
        <span class="w-1.5 h-1.5 rounded-full bg-up live-dot"></span>
        <span class="text-mut">Block</span> <span class="num text-white" id="plsHeight">${h ? '#' + F.num(h.height) : 'syncing…'}</span></span>
      <span class="inline-flex items-center gap-1.5 text-[11px] bg-panel border border-line rounded-lg px-2.5 py-1">
        <span class="text-mut">Base fee</span> <span class="num text-white" id="plsGas">${h && h.gasGwei != null ? h.gasGwei < 1 ? h.gasGwei.toFixed(3) : F.num(h.gasGwei) : '—'}</span> <span class="text-mut">gwei</span></span>`;
  }
  function render(){
    const s = I.chainStats('pulsechain');
    const n = I.narrative('pulsechain');
    CDX.WhaleFlow.start(); const whales = CDX.WhaleFlow.feed(10000, { chain: 'pulsechain', limit: 8 });
    const pairs = [...s.pairs].sort((a,b)=>b.vol-a.vol);
    const ecosystem = [...n.coins].sort((a,b)=>b.mcap-a.mcap);
    root.innerHTML = `<div class="space-y-5">
      <div class="rounded-2xl border border-pls/50 pls-ring bg-gradient-to-r from-pls/15 via-plx/10 to-transparent px-5 py-5">
        <div class="flex items-center gap-3 flex-wrap">
          <span class="w-10 h-10 rounded-xl pls-grad grid place-items-center font-disp font-bold text-white text-lg">◆</span>
          <div><h1 class="font-disp font-bold text-white text-2xl">PulseChain Hub</h1>
          <p class="text-[12px] text-mut">Ecosystem intelligence · PLS · PulseX · HEX · the PRC-20 long tail</p></div>
          <div class="ml-auto flex items-center gap-2 flex-wrap">${headChips()}<span class="text-[10px] uppercase tracking-wider text-mut ml-1">Heat</span>${IU.heatChip(n.heat)}</div></div>
        <div class="flex gap-2 overflow-x-auto pb-1 mt-4 -mb-1">${trackedStrip(s)}</div>
        <div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3 mt-4">
          ${U.statCard('Market Cap', F.usd(s.mcap), 'ecosystem')}
          ${U.statCard('TVL', F.usd(s.tvl), 'PulseX + protocols')}
          ${U.statCard('DEX Volume', F.usd(s.dexVol), '24h')}
          ${U.statCard('Active Wallets', F.num(s.activeWallets), '24h')}
          ${U.statCard('Active Pairs', s.activePairs, 'tracked')}
          ${U.statCard('New Tokens', F.num(s.newTokens), '24h deploys')}</div></div>
      <div class="grid lg:grid-cols-2 xl:grid-cols-3 gap-4">
        <div id="plsTrend"></div><div id="plsMap"></div><div id="plsAccum"></div>
        <div id="plsHold"></div><div id="plsClust"></div><div id="plsLp"></div>
        <div id="plsFresh"></div><div id="plsGrow"></div><div id="plsWallets"></div><div id="plsDeployP"></div>
        ${IU.flowPanel(s.flow, 'PulseChain Flow')}
        <div class="bg-panel border border-line rounded-xl overflow-hidden">
          <div class="flex items-center justify-between px-4 py-3 border-b border-line">
            <h3 class="font-disp font-semibold text-white">Pulse Whale Activity</h3>
            </div>
          <div id="plsWhales">${whales.length ? whales.map(CDX.WhaleFlow.miniRow).join('') : '<div class="px-4 py-6 text-sm text-mut">Scanning live pools for large prints…</div>'}</div></div></div>
      <div class="grid lg:grid-cols-2 gap-4">
        <div class="bg-panel border border-line rounded-xl overflow-hidden">
          <div class="flex items-center justify-between px-4 py-3 border-b border-line">
            <h3 class="font-disp font-semibold text-white">PulseX Pairs</h3>
            <a href="#/dex?chain=pulsechain" class="text-xs text-acc hover:underline">Open screener →</a></div>
          ${pairs.map(p => `<div class="row-hov flex items-center gap-3 px-4 py-2 border-b border-line/50 last:border-0" data-go="/pair/${p.id}">
            ${U.logo(p.base, '#FF0080', 6)}
            <div class="min-w-0"><div class="text-sm font-medium text-white leading-tight">${F.esc(p.base)}<span class="text-mut font-normal">/${F.esc(p.quote)}</span>${p.ageH<=48?U.badge('NEW','up'):''}</div>
            <div class="text-[10px] text-mut flex items-center gap-1.5 flex-wrap">${F.esc(p.dex)} · ${F.age(p.ageH)} · <span class="text-up num">${F.num(p.buys)}</span>/<span class="text-down num">${F.num(p.sells)}</span>${p.holders ? ' · ' + F.num(p.holders) + ' holders' : ''} <span>${CDX.Risk.ui.chip(CDX.Risk.quick(p))}</span></div></div>
            <span class="ml-auto flex items-center gap-3 text-right shrink-0">
              <span class="num text-[11px] text-mut hidden lg:inline">FDV ${F.usd(p.fdv)}</span>
              <span class="num text-xs text-mut hidden sm:inline">Liq ${F.usd(p.liq)}</span>
              <span class="num text-xs text-slate-300">Vol ${F.usd(p.vol)}</span>
              <span class="num text-xs ${F.cls(p.ch.h1)} hidden md:inline">${F.pctAuto(p.ch.h1)}<span class="text-mut text-[9px]"> 1h</span></span>
              <span class="num text-sm ${F.cls(p.ch.h24)}">${F.pctAuto(p.ch.h24)}</span></span></div>`).join('')}</div>
        <div class="space-y-4">
          <div class="bg-panel border border-line rounded-xl overflow-hidden">
            <div class="px-4 py-3 border-b border-line font-disp font-semibold text-white">Ecosystem Assets</div>
            ${ecosystem.map(c => `<div class="row-hov flex items-center gap-3 px-4 py-2.5 border-b border-line/50 last:border-0" data-go="/token/${c.id}">
              ${U.logo(c.sym, c.color, 6)}<span class="text-sm font-medium text-white">${F.esc(c.sym)}</span>
              <span class="text-[11px] text-mut truncate">${F.esc(c.name)}</span>
              <span class="ml-auto flex items-center gap-3">
                <span class="num text-xs text-mut">MC ${F.usd(c.mcap)}</span>
                <span class="num text-sm text-slate-200" data-live="ph:${c.id}">${F.price(c.price)}</span>
                <span class="num text-sm ${F.cls(c.ch24)}">${F.pct(c.ch24)}</span></span></div>`).join('')}</div>
          <div class="ai-card rounded-xl p-4">
            <div class="text-[10px] uppercase tracking-wider font-semibold text-acc mb-1.5">Ecosystem Read</div>
            <p class="text-[12.5px] leading-relaxed text-mut">${
              s.flow.netFlow >= 0
                ? `Net DEX flow is <b class="text-up">positive</b> with accumulation at <b class="text-white">${s.flow.accumulation}</b>. Buy-side transactions lead ${F.num(s.flow.buyTx)} vs ${F.num(s.flow.sellTx)} — breadth across PulseX rather than a single-pair squeeze.`
                : `Net DEX flow is <b class="text-down">negative</b> with distribution at <b class="text-white">${s.flow.distribution}</b>. Sellers lead ${F.num(s.flow.sellTx)} vs ${F.num(s.flow.buyTx)} transactions — watch WPLS pools for stabilization before sizing entries.`
            } Momentum score: <b class="text-white">${s.flow.momentum}</b>/100.</p></div></div></div></div>`;
  }
  return {
    mount(el){ root = el; render();
      const ht = holderTokens();
      if (!holderCa || !ht.some(t => t.ca === holderCa)){ holderCa = ht.length ? ht[0].ca : null; holderSym = ht.length ? ht[0].sym : null; }
      paintIntel();
      let intelN = 0;
      subs.push(CDX.Bus.on('tick', () => { if (++intelN % 7 === 0) paintIntel(); }));
      subs.push(CDX.Bus.on('liq:event', () => {
        const h = D.$('#plsLp', root);
        if (h) h.innerHTML = panel('Liquidity Migration & LP Flow <span class="w-1.5 h-1.5 rounded-full bg-down live-dot inline-block ml-1"></span>', 'pool-delta detection · pulse only', vLpFlow());
      }));
      undelegate = D.delegate(root, {
        '[data-hold]': t => { holderCa = t.dataset.hold; holderSym = t.dataset.sym;
          const ch = root.querySelector('#plsHoldChips'); if (ch) ch.innerHTML = holderChips(); loadHolders(); },
        '[data-go]': t => CDX.Router.go(t.dataset.go) });
      subs.push(CDX.Bus.on('whale:new', t => {
        const p = CDX.Data.byKey('d:' + t.pairId);
        if (!p || p.chain !== 'pulsechain') return;
        const host = D.$('#plsWhales', root);
        if (host) host.innerHTML = CDX.Intel.whaleTrades({ chain:'pulsechain' }).slice(0, 8).map(CDX.IntelUI.whaleRow).join('');
      }));
      subs.push(CDX.Bus.on('tick', changed => {
        for (const { key, dir } of changed){
          const it = CDX.Data.byKey(key);
          if (!it) continue;
          const node = key.startsWith('c:')
            ? root.querySelector(`[data-live="ph:${key.slice(2)}"]`)
            : root.querySelector(`[data-live="pt:${key.slice(2)}"]`);
          if (node) D.liveSet(node, F.price(it.price), dir);
        }
      }));
      subs.push(CDX.Bus.on('pls:block', h => {
        const hh = D.$('#plsHeight', root), gg = D.$('#plsGas', root);
        if (hh) D.liveSet(hh, '#' + F.num(h.height), 1);
        if (gg && h.gasGwei != null) gg.textContent = h.gasGwei < 1 ? h.gasGwei.toFixed(3) : F.num(h.gasGwei);
      }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; root=null; }
  };
})();
