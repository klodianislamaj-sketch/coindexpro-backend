/* Page: Terminal — pro dashboards with multi-column density control. Route: #/terminal/:view */
CDX.Pages.terminal = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI, I = CDX.Intel, IU = CDX.IntelUI;
  let subs = [], root = null, undelegate = null, view = 'movers';
  const VIEWS = [['movers','Top Movers'],['trending','Trending'],['new','New Listings'],['rotation','Capital Rotation'],['compare','Cross-Chain']];
  const colsClass = () => ({ 2:'grid gap-4 lg:grid-cols-2', 3:'grid gap-4 lg:grid-cols-2 xl:grid-cols-3', 4:'grid gap-4 md:grid-cols-2 xl:grid-cols-4' })[CDX.Store.state.prefs.termCols || 4];

  const panel = (title, body, tone) => `<div class="bg-panel border border-line rounded-xl overflow-hidden">
    <div class="px-4 py-3 border-b border-line font-disp font-semibold ${tone || 'text-white'}">${title}</div>${body}</div>`;
  const coinRow = (c, i) => `<div class="row-hov flex items-center gap-3 px-4 py-2 border-b border-line/50 last:border-0" data-go="/token/${c.id}">
    <span class="text-mut text-xs w-4">${i+1}</span>${U.logo(c.sym, c.color, 6)}
    <span class="text-sm font-medium text-white">${F.esc(c.sym)}</span>
    <span class="ml-auto flex items-center gap-3">
      <span class="num text-xs text-slate-300">${F.price(c.price)}</span>
      <span class="num text-sm ${F.cls(c.ch24)}">${F.pct(c.ch24)}</span></span></div>`;
  const pairRow = (p, i, ch) => `<div class="row-hov flex items-center gap-3 px-4 py-2 border-b border-line/50 last:border-0" data-go="/pair/${p.id}">
    <span class="text-mut text-xs w-4">${i+1}</span>${U.logo(p.base, CDX.Data.CHAINS[p.chain].color, 6)}
    <div class="min-w-0"><div class="text-sm font-medium text-white">${F.esc(p.base)}<span class="text-mut font-normal">/${F.esc(p.quote)}</span></div>
    <div class="mt-0.5">${U.chainBadge(p.chain)}</div></div>
    <span class="ml-auto flex items-center gap-3 text-right">
      <span class="num text-xs text-mut">${F.usd(p.vol)}</span>
      <span class="num text-sm ${F.cls(ch!=null?ch:p.ch.h24)}">${F.pctAuto(ch!=null?ch:p.ch.h24)}</span></span></div>`;

  function vMovers(){
    const cs = CDX.Data.coins.filter(c=>!['usdt','usdc'].includes(c.id));
    const gain = [...cs].sort((a,b)=>b.ch24-a.ch24).slice(0,8);
    const lose = [...cs].sort((a,b)=>a.ch24-b.ch24).slice(0,8);
    const pg = [...CDX.Data.pairs].sort((a,b)=>b.ch.h24-a.ch.h24).slice(0,8);
    const pl = [...CDX.Data.pairs].sort((a,b)=>a.ch.h24-b.ch.h24).slice(0,8);
    return `<div class="${colsClass()}">
      ${panel('Coin Gainers · 24h', gain.map(coinRow).join(''), 'text-up')}
      ${panel('Coin Losers · 24h', lose.map(coinRow).join(''), 'text-down')}
      ${panel('Pair Gainers · 24h', pg.map((p,i)=>pairRow(p,i)).join(''), 'text-up')}
      ${panel('Pair Losers · 24h', pl.map((p,i)=>pairRow(p,i)).join(''), 'text-down')}</div>`;
  }
  function vTrending(){
    const score = p => (p.vol / Math.max(p.liq,1)) * Math.log10(p.vol + 10) * (1 + Math.max(0, p.ch.h24)/40);
    const hot = [...CDX.Data.pairs].sort((a,b)=>score(b)-score(a)).slice(0,10);
    const tokens = [...CDX.Data.coins].filter(c=>!['usdt','usdc'].includes(c.id))
      .sort((a,b)=>(b.ch24*(b.vol/b.mcap))-(a.ch24*(a.vol/a.mcap))).slice(0,10);
    const ns = [...I.allNarratives()].sort((a,b)=>b.heat-a.heat);
    return `<div class="${colsClass()}">
      ${panel('🔥 Trending Pairs <span class="text-mut text-xs font-body font-normal">churn × volume × momentum</span>',
        hot.map((p,i)=>pairRow(p,i)).join(''))}
      ${panel('Trending Tokens <span class="text-mut text-xs font-body font-normal">turnover-weighted momentum</span>',
        tokens.map(coinRow).join(''))}
      ${panel('Narrative Heat', ns.map(n => `<div class="row-hov flex items-center gap-3 px-4 py-2.5 border-b border-line/50 last:border-0" data-go="/narrative/${n.id}">
        <span class="text-sm font-medium" style="color:${n.color}">${n.name}</span>
        <span class="num text-xs text-mut">${F.usd(n.mcap)}</span>
        <span class="ml-auto flex items-center gap-3">
          <span class="num text-xs ${F.cls(n.wCh24)}">${F.pct(n.wCh24)}</span>
          <span>${IU.heatChip(n.heat)}</span></span></div>`).join(''))}
      ${panel('Whale Pulse <span class="text-mut text-xs font-body font-normal">latest prints</span>',
        `<div id="tWhales">${(CDX.WhaleFlow.start(), CDX.WhaleFlow.feed(10000,{limit:8}).map(CDX.WhaleFlow.miniRow).join('')) || '<div class="px-4 py-4 text-xs text-mut">Scanning live pools…</div>'}</div>`)}</div>`;
  }
  function vNew(){
    const list = [...CDX.Data.pairs].sort((a,b)=>a.ageH-b.ageH).slice(0, 16);
    const flags = p => {
      const f = [];
      if (p.liq < 250e3) f.push(['LOW LIQ','down']);
      if (p.vol / p.liq > 3) f.push(['HIGH CHURN','gold']);
      if (p.ageH <= 24) f.push(['<24H','up']);
      return f.map(([t,c]) => U.badge(t, c)).join('');
    };
    return panel('New Listings <span class="text-mut text-xs font-body font-normal">youngest pairs first</span>',
      `<div class="overflow-x-auto"><table class="w-full text-sm" style="min-width:1020px">
        <thead class="bg-panel2 text-mut text-[11px] uppercase tracking-wider"><tr class="border-b border-line">
          <th class="px-3 py-2.5 text-left">Pair</th><th class="px-3 py-2.5 text-left">Chain</th>
          <th class="px-3 py-2.5 text-right">Age</th><th class="px-3 py-2.5 text-right">Price</th>
          <th class="px-3 py-2.5 text-right">Liquidity</th><th class="px-3 py-2.5 text-right">Vol 24h</th>
          <th class="px-3 py-2.5 text-right">Buys/Sells</th><th class="px-3 py-2.5 text-right">FDV</th>
          <th class="px-3 py-2.5 text-left">Risk Flags</th></tr></thead>
        <tbody class="divide-y divide-line/60">${list.map(p => `
          <tr class="row-hov" data-go="/pair/${p.id}">
            <td class="px-3 py-3"><div class="flex items-center gap-2">${U.logo(p.base, CDX.Data.CHAINS[p.chain].color, 6)}
              <span class="font-medium text-white">${F.esc(p.base)}<span class="text-mut font-normal">/${F.esc(p.quote)}</span></span></div></td>
            <td class="px-3 py-3">${U.chainBadge(p.chain)}</td>
            <td class="px-3 py-3 text-right num ${p.ageH<=24?'text-up':'text-mut'}">${F.age(p.ageH)}</td>
            <td class="px-3 py-3 text-right num text-white">${F.price(p.price)}</td>
            <td class="px-3 py-3 text-right num ${p.liq<250e3?'text-down':'text-slate-300'}">${F.usd(p.liq)}</td>
            <td class="px-3 py-3 text-right num text-slate-300">${F.usd(p.vol)}</td>
            <td class="px-3 py-3 text-right num"><span class="text-up">${F.num(p.buys)}</span><span class="text-mut">/</span><span class="text-down">${F.num(p.sells)}</span></td>
            <td class="px-3 py-3 text-right num text-mut">${F.usd(p.fdv)}</td>
            <td class="px-3 py-3">${flags(p)}</td></tr>`).join('')}</tbody></table></div>`);
  }
  function vRotation(){
    const ns = [...I.allNarratives()].sort((a,b)=>b.flow.netFlow-a.flow.netFlow);
    const chs = [...I.allChains()].sort((a,b)=>b.flow.netFlow-a.flow.netFlow);
    const cs = CDX.Data.coins.filter(c=>!['usdt','usdc'].includes(c.id));
    const quad = (f, title, tone) => panel(title, cs.filter(f).sort((a,b)=>b.ch24-a.ch24).slice(0,6).map(coinRow).join('') || '<div class="px-4 py-5 text-xs text-mut">None right now.</div>', tone);
    const flowRow = (x, go, name, color) => `<div class="row-hov flex items-center gap-3 px-4 py-2.5 border-b border-line/50 last:border-0" data-go="${go}">
      <span class="text-sm font-medium" ${color?`style="color:${color}"`:'class="text-white"'}>${name}</span>
      <span class="ml-auto flex items-center gap-3">
        <span class="num text-[11px] text-up">+${F.usd(x.flow.buyVol).slice(1)}</span>
        <span class="num text-[11px] text-down">−${F.usd(x.flow.sellVol).slice(1)}</span>
        <span class="num text-sm font-semibold ${x.flow.netFlow>=0?'text-up':'text-down'}">${(x.flow.netFlow>=0?'+':'−')+F.usd(Math.abs(x.flow.netFlow)).slice(1)}</span></span></div>`;
    const inN = ns[0], outN = ns[ns.length-1];
    return `<div class="space-y-4">
      <div class="ai-card rounded-xl p-4 text-sm text-mut">Rotation signal: capital is leaving
        <a href="#/narrative/${outN.id}" class="font-medium hover:underline" style="color:${outN.color}">${outN.name}</a>
        (<span class="num text-down">−${F.usd(Math.abs(Math.min(0,outN.flow.netFlow))).slice(1)}</span>) and flowing into
        <a href="#/narrative/${inN.id}" class="font-medium hover:underline" style="color:${inN.color}">${inN.name}</a>
        (<span class="num text-up">+${F.usd(Math.max(0,inN.flow.netFlow)).slice(1)}</span>).</div>
      <div class="${colsClass()}">
        ${panel('Narrative Flows · 24h', ns.map(n => flowRow(n, '/narrative/'+n.id, n.name, n.color)).join(''))}
        ${panel('Chain Flows · 24h', chs.map(s => flowRow(s, '/chain/'+s.id, s.chain.name)).join(''))}
        ${quad(c => c.ch24 > 0 && c.ch7d < 0, 'Rotating In <span class="text-mut text-xs font-body font-normal">up 24h · down 7d</span>', 'text-up')}
        ${quad(c => c.ch24 < 0 && c.ch7d > 0, 'Rotating Out <span class="text-mut text-xs font-body font-normal">down 24h · up 7d</span>', 'text-down')}</div></div>`;
  }
  function vCompare(){
    const chains = CDX.Data.CHAIN_ORDER.slice(0, 7).map(I.chainStats);
    const rows = [
      ['Market Cap', s=>s.mcap, F.usd], ['TVL', s=>s.tvl, F.usd], ['DEX Volume 24h', s=>s.dexVol, F.usd],
      ['Active Wallets', s=>s.activeWallets, F.num], ['Active Pairs', s=>s.activePairs, v=>v],
      ['New Tokens 24h', s=>s.newTokens, F.num], ['Net Flow', s=>s.flow.netFlow, v=>(v>=0?'+':'−')+F.usd(Math.abs(v)).slice(1)],
      ['Momentum', s=>s.flow.momentum, v=>v], ['Accumulation', s=>s.flow.accumulation, v=>v],
      ['Buy Pressure %', s=>s.flow.buyTx/(s.flow.buyTx+s.flow.sellTx)*100, v=>v.toFixed(0)+'%']
    ];
    return panel('Cross-Chain Comparison',
      `<div class="overflow-x-auto"><table class="w-full text-sm" style="min-width:1080px">
        <thead class="bg-panel2 text-mut text-[11px] uppercase tracking-wider"><tr class="border-b border-line">
          <th class="px-3 py-2.5 text-left">Metric</th>
          ${chains.map(s => `<th class="px-3 py-2.5 text-right" style="cursor:pointer" data-go="/chain/${s.id}">${CDX.UI.chainBadge(s.id)}</th>`).join('')}</tr></thead>
        <tbody class="divide-y divide-line/60">${rows.map(([label, get, fmt]) => {
          const vals = chains.map(get);
          const max = Math.max(...vals.map(Math.abs)) || 1;
          const lead = vals.indexOf([...vals].sort((a,b)=>b-a)[0]);
          return `<tr><td class="px-3 py-3 text-mut text-xs uppercase tracking-wider">${label}</td>
            ${vals.map((v,i) => `<td class="px-3 py-3 text-right">
              <div class="num ${i===lead?'text-white font-semibold':'text-slate-300'}">${fmt(v)}${i===lead?' <span class="text-gold">●</span>':''}</div>
              <div class="h-1 bg-line rounded-full mt-1 overflow-hidden"><div class="h-full rounded-full ${v>=0?'bg-acc':'bg-down'}" style="width:${Math.abs(v)/max*100}%"></div></div></td>`).join('')}</tr>`;
        }).join('')}</tbody></table></div>`);
  }
  const RENDER = { movers: vMovers, trending: vTrending, new: vNew, rotation: vRotation, compare: vCompare };
  function paint(){
    const cols = CDX.Store.state.prefs.termCols || 4;
    D.$('#tBody', root).innerHTML = RENDER[view]();
    D.$('#tTabs', root).innerHTML = VIEWS.map(([id, label]) =>
      `<a href="#/terminal/${id}" class="text-xs rounded-lg px-3 py-1.5 border transition-colors ${id===view?'bg-acc/15 border-acc/50 text-white':'bg-panel border-line text-mut hover:text-white'}">${label}</a>`).join('');
    D.$('#tCols', root).innerHTML = [2,3,4].map(n =>
      `<button data-cols="${n}" class="px-2.5 py-1 rounded-md ${n===cols?'seg-active':'text-mut hover:text-white'}">${n}col</button>`).join('');
  }
  return {
    mount(el, ctx){
      view = RENDER[ctx.params.view] ? ctx.params.view : 'movers';
      root = el;
      root.innerHTML = `<div class="space-y-4">
        <div class="flex items-center gap-3 flex-wrap">
          <h2 class="font-disp font-semibold text-white text-lg">Terminal</h2>
          <div class="flex gap-1.5 flex-wrap" id="tTabs"></div>
          <div class="ml-auto flex items-center bg-panel border border-line rounded-lg p-0.5 text-xs" id="tCols"></div></div>
        <div id="tBody"></div></div>`;
      paint();
      undelegate = D.delegate(root, {
        '[data-cols]': t => { CDX.Store.setPref('termCols', +t.dataset.cols); paint(); },
        '[data-go]': t => CDX.Router.go(t.dataset.go)
      });
      subs.push(CDX.Bus.on('whale:new', () => {
        const host = D.$('#tWhales', root);
        if (host) host.innerHTML = CDX.Intel.whaleTrades().slice(0,8).map(CDX.IntelUI.whaleRow).join('');
      }));
      let n = 0;
      subs.push(CDX.Bus.on('tick', () => { if (++n % 4 === 0) paint(); }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; root=null; }
  };
})();
