/* Page: single narrative deep-dive. Route: #/narrative/:name */
CDX.Pages.narrative = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI, I = CDX.Intel, IU = CDX.IntelUI;
  let subs = [], root = null, undelegate = null, nid = null;
  function render(){
    const n = I.narrative(nid);
    if (!n){ root.innerHTML = '<div class="py-20 text-center text-mut">Unknown narrative.</div>'; return; }
    const coins = [...n.coins].sort((a,b)=>b.mcap-a.mcap);
    const pairs = [...n.pairs].sort((a,b)=>b.vol-a.vol).slice(0, 10);
    root.innerHTML = `<div class="space-y-5">
      <div class="flex items-center gap-3 flex-wrap">
        <span class="w-8 h-8 rounded-lg grid place-items-center font-disp font-bold text-white" style="background:${n.color}22;border:1px solid ${n.color}66;color:${n.color}">${n.name.slice(0,1)}</span>
        <h1 class="font-disp font-bold text-white text-2xl">${n.name}</h1>
        <span class="ml-auto flex items-center gap-2"><span class="text-[10px] uppercase tracking-wider text-mut">Heat</span>${IU.heatChip(n.heat)}</span></div>
      <p class="text-sm text-mut max-w-3xl -mt-2">${n.desc}</p>
      <div class="grid grid-cols-2 md:grid-cols-5 gap-3">
        ${U.statCard('Market Cap', F.usd(n.mcap), coins.length + ' assets')}
        ${U.statCard('24h Change', `<span class="${F.cls(n.wCh24)}">${F.pct(n.wCh24)}</span>`, 'cap-weighted')}
        ${U.statCard('7d Change', `<span class="${F.cls(n.wCh7d)}">${F.pct(n.wCh7d)}</span>`, 'cap-weighted')}
        ${U.statCard('Volume 24h', F.usd(n.vol), 'spot + DEX')}
        ${U.statCard('DEX Pairs', n.pairs.length, 'tagged')}
      </div>
      <div class="grid lg:grid-cols-2 gap-4">
        ${IU.flowPanel(n.flow, n.name + ' Flow')}
        <div class="bg-panel border border-line rounded-xl overflow-hidden">
          <div class="px-4 py-3 border-b border-line font-disp font-semibold text-white">Top DEX Pairs</div>
          ${pairs.length ? pairs.map(p => `<div class="row-hov flex items-center gap-3 px-4 py-2.5 border-b border-line/50 last:border-0" data-go="/pair/${p.id}">
            ${U.logo(p.base, CDX.Data.CHAINS[p.chain].color, 6)}
            <span class="text-sm font-medium text-white">${F.esc(p.base)}<span class="text-mut font-normal">/${F.esc(p.quote)}</span></span>
            ${U.chainBadge(p.chain)}
            <span class="ml-auto flex items-center gap-3">
              <span class="num text-xs text-mut">Vol ${F.usd(p.vol)}</span>
              <span class="num text-sm ${F.cls(p.ch.h24)}">${F.pctAuto(p.ch.h24)}</span></span></div>`).join('')
          : '<div class="px-4 py-6 text-sm text-mut">No tagged pairs.</div>'}</div></div>
      <div class="bg-panel border border-line rounded-xl overflow-hidden">
        <div class="px-4 py-3 border-b border-line font-disp font-semibold text-white">Assets</div>
        <div class="overflow-x-auto"><table class="w-full text-sm" style="min-width:860px">
          <thead class="bg-panel2 text-mut text-[11px] uppercase tracking-wider"><tr class="border-b border-line">
            <th class="px-3 py-2.5 text-left">Asset</th><th class="px-3 py-2.5 text-right">Price</th>
            <th class="px-3 py-2.5 text-right">24h %</th><th class="px-3 py-2.5 text-right">7d %</th>
            <th class="px-3 py-2.5 text-right">Market Cap</th><th class="px-3 py-2.5 text-right">Volume</th>
            <th class="px-3 py-2.5 w-10"></th></tr></thead>
          <tbody class="divide-y divide-line/60">${coins.map(c => `
            <tr class="row-hov" data-go="/token/${c.id}">
              <td class="px-3 py-3"><div class="flex items-center gap-2.5">${U.logo(c.sym, c.color)}
                <div><span class="font-medium text-white">${F.esc(c.name)}</span><span class="text-mut text-xs ml-1.5">${F.esc(c.sym)}</span></div></div></td>
              <td class="px-3 py-3 text-right num text-white">${F.price(c.price)}</td>
              <td class="px-3 py-3 text-right num ${F.cls(c.ch24)}">${F.pct(c.ch24)}</td>
              <td class="px-3 py-3 text-right num ${F.cls(c.ch7d)}">${F.pct(c.ch7d)}</td>
              <td class="px-3 py-3 text-right num text-slate-300">${F.usd(c.mcap)}</td>
              <td class="px-3 py-3 text-right num text-slate-300">${F.usd(c.vol)}</td>
              <td class="px-2 py-3 text-center">${U.star('c:'+c.id)}</td></tr>`).join('')}
          </tbody></table></div></div></div>`;
  }
  return {
    mount(el, ctx){ nid = ctx.params.name; root = el; render();
      undelegate = D.delegate(root, { '[data-star]': () => {}, '[data-go]': t => CDX.Router.go(t.dataset.go) });
      let n = 0;
      subs.push(CDX.Bus.on('tick', () => { if (++n % 5 === 0) render(); }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; root=null; nid=null; }
  };
})();
