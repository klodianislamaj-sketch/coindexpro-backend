/* Page: DEX Screener — multi-chain pair intelligence. Route: #/dex[?chain=pulsechain] */
CDX.Pages.dex = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI;
  const TF_LABEL = { m5:'5m', h1:'1h', h6:'6h', h24:'24h' };
  let subs = [], root = null, table = null, undelegate = null;

  function filtered(){
    const p = CDX.Store.state.prefs;
    let list = CDX.Data.pairs.filter(x =>
      (p.dexChain === 'all' || x.chain === p.dexChain) && (!p.newOnly || x.ageH <= 72));
    const tf = p.dexTf;
    switch (p.dexSort){
      case 'volume':    list.sort((a,b)=>b.vol-a.vol); break;
      case 'liquidity': list.sort((a,b)=>b.liq-a.liq); break;
      case 'change':    list.sort((a,b)=>b.ch[tf]-a.ch[tf]); break;
      case 'new':       list.sort((a,b)=>a.ageH-b.ageH); break;
      case 'fdv':       list.sort((a,b)=>b.fdv-a.fdv); break;
      case 'buys':      list.sort((a,b)=>b.buys-a.buys); break;
      case 'sells':     list.sort((a,b)=>b.sells-a.sells); break;
      default:          list.sort((a,b)=>trendScore(b,tf)-trendScore(a,tf));
    }
    return list;
  }
  /* smart pair ranking: turnover-weighted volume × activity × momentum × freshness, liquidity-floored */
  function trendScore(p, tf){
    const turnover = Math.min(p.vol / Math.max(p.liq, 1), 12);
    const activity = Math.log10(p.buys + p.sells + 10);
    const momentum = 1 + Math.min(Math.abs(p.ch[tf] || 0), 80) / 40;
    const fresh = p.ageH <= 24 ? 1.6 : p.ageH <= 72 ? 1.25 : 1;
    const floor = p.liq < 5000 ? 0.25 : 1;
    const vel = 1 + Math.min(txVelocity(p).perMin, 10) / 12;
    return Math.log10(p.vol + 1) * (1 + turnover / 4) * activity * momentum * fresh * floor * vel;
  }
  const pctCell = (p, tf) => `<span class="num text-[12px] ${F.cls(p.ch[tf])}" data-live="d${tf}:${p.id}">${F.pctAuto(p.ch[tf])}</span>`;
  /* tx velocity: live Δ(txns) since first sighting this session; falls back to 24h average */
  const vel0 = new Map();   // id → { ts, n }
  function txVelocity(p){
    const n = p.buys + p.sells;
    let v = vel0.get(p.id);
    if (!v) vel0.set(p.id, v = { ts: Date.now(), n });
    const mins = (Date.now() - v.ts) / 60e3;
    if (mins >= 1.5 && n >= v.n) return { perMin: (n - v.n) / mins, live: true };
    return { perMin: n / (24 * 60), live: false };
  }
  /* wallet pressure: txn-ratio imbalance blended with measured print flow + Liq drain */
  function pressureOf(p){
    const tx = p.buys + p.sells;
    const m = p.flowMeasured;
    const buyShare = m && m.buyVol + m.sellVol > 0 ? m.buyVol / (m.buyVol + m.sellVol)
                   : tx ? p.buys / tx : 0.5;
    const drain = CDX.Liq.pressure(p).score;
    return { buyShare, drain };
  }
  function columns(){
    const tf = CDX.Store.state.prefs.dexTf;
    return [
      { key:'i', label:'#', width:'36px', render:(p,i)=>`<span class="text-mut text-[11px] num">${i+1}</span>` },
      { key:'pair', label:'Pair', render:p=>{
          const isNew = p.ageH <= 48;
          const trending = !isNew && p.vol/p.liq > 1.8 && p.ch[tf] > 5;
          return `<div class="flex items-center gap-2 leading-tight">${U.logo(p.base, CDX.Data.CHAINS[p.chain].color, 6)}
            <div><div class="font-medium text-white text-[13px]">${F.esc(p.base)}<span class="text-mut font-normal">/${F.esc(p.quote)}</span>
              <span class="text-[10px] text-mut font-normal ml-1">${F.esc(p.dex)}</span>
              ${isNew?U.badge('NEW','up'):''}${trending?U.badge('🔥','gold'):''}</div>
            <div class="text-[10px] text-mut">${U.chainBadge(p.chain)} <button data-copy="${p.ca}" class="hover:text-acc num" title="Copy contract address">${p.ca.slice(0,6)}…${p.ca.slice(-4)} ⧉</button></div></div></div>`; } },
      { key:'price', label:'Price', align:'right', render:p=>`<span class="num text-white text-[12.5px]" data-live="dpx:${p.id}">${F.price(p.price)}</span>` },
      { key:'age', label:'Age', align:'right', render:p=>`<span class="num text-[11px] ${p.ageH<=48?'text-up':'text-mut'}">${F.age(p.ageH)}</span>` },
      { key:'txns', label:'Txns', align:'right', render:p=>{
          const tx = p.buys + p.sells, bs = tx ? p.buys / tx * 100 : 50;
          return `<div class="num text-[12px] text-slate-200">${F.num(tx)}</div>
            <div class="num text-[9px]"><span class="text-up">${F.num(p.buys)}</span><span class="text-mut">/</span><span class="text-down">${F.num(p.sells)}</span></div>
            <div class="h-[3px] w-16 ml-auto rounded-full overflow-hidden flex bg-line mt-0.5"><div class="bg-up/80" style="width:${bs.toFixed(0)}%"></div><div class="bg-down/80 flex-1"></div></div>`; } },
      { key:'vel', label:'Tx/m', align:'right', cls:'hidden md:table-cell', render:p=>{
          const v = txVelocity(p);
          const hot = v.perMin >= 2;
          return `<span class="num text-[11px] ${hot ? 'text-gold' : 'text-mut'}">${v.live ? '⚡' : ''}${v.perMin >= 10 ? v.perMin.toFixed(0) : v.perMin.toFixed(1)}</span>`; } },
      { key:'wp', label:'WP', align:'right', cls:'hidden lg:table-cell', render:p=>{
          const { buyShare, drain } = pressureOf(p);
          const col = drain >= 55 ? '#FF5C5C' : drain >= 30 ? '#F5C04E' : '#2DD480';
          return `<span class="inline-flex items-center gap-1 num text-[10px]" title="Wallet pressure: ${(buyShare*100).toFixed(0)}% buy-side · liq drain ${drain}/100">
            <span class="w-1.5 h-1.5 rounded-full" style="background:${col}"></span>${(buyShare*100).toFixed(0)}b</span>`; } },
      { key:'vol', label:'Volume', align:'right', render:p=>`<span class="num text-slate-300 text-[12px]">${F.usd(p.vol)}</span>` },
      { key:'m5',  label:'5m',  align:'right', render:p=>pctCell(p,'m5') },
      { key:'h1',  label:'1h',  align:'right', render:p=>pctCell(p,'h1') },
      { key:'h6',  label:'6h',  align:'right', render:p=>pctCell(p,'h6') },
      { key:'h24', label:'24h', align:'right', render:p=>pctCell(p,'h24') },
      { key:'liq', label:'Liquidity', align:'right', render:p=>`<span class="num text-slate-300 text-[12px]">${F.usd(p.liq)}</span>` },
      { key:'fdv', label:'MCap/FDV', align:'right', render:p=>`<span class="num text-mut text-[12px]">${F.usd(p.fdv)}</span>` },
      { key:'star', label:'', width:'36px', align:'center', render:p=>U.star('d:'+p.id) }
    ];
  }
  function chainPillsHtml(){
    const cur = CDX.Store.state.prefs.dexChain;
    const counts = {};
    CDX.Data.pairs.forEach(p => counts[p.chain] = (counts[p.chain]||0)+1);
    const mk = (id, label, n) => {
      const act = cur === id;
      if (id === 'pulsechain')
        return `<button data-chain="pulsechain" class="text-xs rounded-lg px-3 py-1.5 font-semibold transition-all ${act?'pls-grad text-white pls-ring':'bg-panel border border-pls/40 pls-text hover:pls-ring'}">◆ PulseChain <span class="opacity-80 font-normal">${n||0}</span></button>`;
      const dot = id !== 'all' ? `<span class="inline-block w-1.5 h-1.5 rounded-full mr-1 align-middle" style="background:${CDX.Data.CHAINS[id].color}"></span>` : '';
      return `<button data-chain="${id}" class="text-xs rounded-lg px-2.5 py-1.5 border transition-colors ${act?'bg-acc/15 border-acc/50 text-white':'bg-panel border-line text-mut hover:text-white hover:border-acc/40'}">${dot}${label}${n!=null?` <span class="opacity-70 num">${n}</span>`:''}</button>`;
    };
    return mk('all','All Chains', CDX.Data.pairs.length)
      + CDX.Data.CHAIN_ORDER.map(c => mk(c, CDX.Data.CHAINS[c].name, counts[c]||0)).join('');
  }
  function controlsState(){
    const p = CDX.Store.state.prefs;
    D.$$('#dexTf [data-tf]', root).forEach(b => {
      b.classList.toggle('seg-active', b.dataset.tf === p.dexTf);
      b.classList.toggle('text-mut', b.dataset.tf !== p.dexTf);
    });
    D.$('#dexSort', root).value = p.dexSort;
    D.$('#newOnly', root).checked = p.newOnly;
  }
  const rowBudget = () => (window.matchMedia && window.matchMedia('(max-width: 640px)').matches) ? 120 : 400;
  function newStrip(){
    const fresh = [...CDX.Data.pairs].filter(p => p.ageH <= 24 && p.liq >= 3000)
      .sort((a, b) => a.ageH - b.ageH).slice(0, 10);
    if (!fresh.length) return '';
    return `<div class="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">${fresh.map(p => `
      <button data-go="/pair/${p.id}" class="shrink-0 bg-panel border border-up/30 rounded-lg px-2.5 py-1.5 text-left hover:border-up/60 transition-colors">
        <div class="flex items-center gap-1.5 text-[12px]">${U.logo(p.base, CDX.Data.CHAINS[p.chain].color, 4)}
          <span class="text-white font-medium">${F.esc(p.base)}</span>
          <span class="num text-up text-[10px]">${F.age(p.ageH)}</span></div>
        <div class="num text-[9.5px] text-mut">${U.chainBadge(p.chain)} Liq ${F.usd(p.liq)} · ${F.num(p.buys + p.sells)} tx · <span class="${F.cls(p.ch.h1)}">${F.pctAuto(p.ch.h1)}</span></div>
      </button>`).join('')}</div>`;
  }
  function refresh(){
    const all = filtered();
    const budget = rowBudget();
    const ns = D.$('#dexNew', root);
    if (ns) ns.innerHTML = newStrip();
    table = U.table({ columns: columns(), rows: all.slice(0, budget), minWidth:'1480px', maxH:'74vh', dense: true, pad: 'px-2 py-[6px]',
      rowAttr: p => `data-go="/pair/${p.id}" style="cursor:pointer"` });
    const host = D.$('#dexTable', root);
    host.innerHTML = ''; host.appendChild(table.el);
    D.$('#dexCount', root).textContent = all.length + ' pairs indexed' + (all.length > budget ? ` · top ${budget} shown` : '');
  }
  return {
    mount(el, ctx){
      root = el;
      if (ctx.query.chain) CDX.Store.setPref('dexChain', ctx.query.chain);
      root.innerHTML = `<div class="space-y-4">
        <div class="flex flex-wrap items-center gap-2">
          <h2 class="font-disp font-semibold text-white text-lg mr-1">DEX Screener</h2>
          <span class="text-xs text-mut" id="dexCount"></span></div>
        <div class="flex flex-wrap gap-1.5" id="chainPills">${chainPillsHtml()}</div>
        <div class="flex flex-wrap items-center gap-3">
          <div class="flex items-center gap-1.5 text-xs"><span class="text-[10px] uppercase tracking-wider text-mut">Sort window</span>
          <div class="flex items-center bg-panel border border-line rounded-lg p-0.5" id="dexTf">
            ${Object.keys(TF_LABEL).map(tf=>`<button data-tf="${tf}" class="px-2.5 py-1 rounded-md text-mut">${TF_LABEL[tf]}</button>`).join('')}</div></div>
          <select id="dexSort" class="bg-panel border border-line rounded-lg text-xs px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-acc/60">
            <option value="trending">Sort: Trending</option><option value="volume">Sort: Volume 24h</option>
            <option value="liquidity">Sort: Liquidity</option><option value="change">Sort: % Change</option>
            <option value="new">Sort: Newest pairs</option><option value="fdv">Sort: FDV</option>
            <option value="buys">Sort: Highest buys</option><option value="sells">Sort: Highest sells</option></select>
          <label class="flex items-center gap-1.5 text-xs text-mut cursor-pointer select-none">
            <input type="checkbox" id="newOnly" class="accent-up w-3.5 h-3.5"> New pairs only</label></div>
        <div id="dexNew"></div>
        <div id="dexTable"></div></div>`;
      refresh(); controlsState();
      D.$('#dexSort', root).addEventListener('change', e => { CDX.Store.setPref('dexSort', e.target.value); refresh(); });
      D.$('#newOnly', root).addEventListener('change', e => { CDX.Store.setPref('newOnly', e.target.checked); refresh(); });
      undelegate = D.delegate(root, {
        '[data-star]': () => {},
        '[data-copy]': () => {},
        '[data-chain]': t => { CDX.Store.setPref('dexChain', t.dataset.chain); D.$('#chainPills', root).innerHTML = chainPillsHtml(); refresh(); },
        '[data-tf]':   t => { CDX.Store.setPref('dexTf', t.dataset.tf); controlsState(); refresh(); },
        '[data-go]':   t => CDX.Router.go(t.dataset.go)
      });
      subs.push(CDX.Bus.on('tick', changed => {
        if (!table) return;
        const TFS = ['m5','h1','h6','h24'];
        const updates = {};
        for (const { key, dir } of changed){
          if (!key.startsWith('d:')) continue;
          const p = CDX.Data.byKey(key);
          updates['dpx:' + p.id] = { html: F.price(p.price), dir };
          for (const tf of TFS) updates['d' + tf + ':' + p.id] = { html: F.pctAuto(p.ch[tf]), dir: 0 };
        }
        table.patch(updates);
        for (const id of Object.keys(updates)){
          const m = /^d(m5|h1|h6|h24):(.+)$/.exec(id);
          if (!m) continue;
          const node = table.body.querySelector(`[data-live="${id}"]`);
          const p = CDX.Data.byKey('d:' + m[2]);
          if (node && p) node.className = 'num text-[12px] ' + F.cls(p.ch[m[1]]);
        }
      }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; table=null; root=null; }
  };
})();
