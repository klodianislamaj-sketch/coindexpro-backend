/* Page: Whale Flow — REAL on-chain large swaps. Route: #/whales
   Source: CDX.WhaleFlow (GeckoTerminal / PulseX per-pool /trades, live).
   Columns: token · side · amount · USD · wallet · tx · time.
   Filters: $10k / $50k / $100k / $500k. No PnL, no win-rate, no labels. */
CDX.Pages.whales = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI, WF = CDX.WhaleFlow;
  let subs = [], root = null, undelegate = null, minUsd = 10000;
  const short = a => a ? a.slice(0, 6) + '…' + a.slice(-4) : '—';

  function statBar(){
    const s = WF.stats(minUsd);
    const card = (label, val, cls) => `<div class="bg-panel border border-line rounded-lg px-3 py-2">
      <div class="text-[10px] text-mut uppercase tracking-wide">${label}</div>
      <div class="num text-base font-bold ${cls||'text-white'}">${val}</div></div>`;
    return `<div class="grid grid-cols-2 sm:grid-cols-4 gap-2">
      ${card('Buy volume', F.usd(s.buyVol), 'text-up')}
      ${card('Sell volume', F.usd(s.sellVol), 'text-down')}
      ${card('Net flow', (s.net>=0?'+':'−')+F.usd(Math.abs(s.net)).slice(1), s.net>=0?'text-up':'text-down')}
      ${card('Prints · wallets', s.count+' · '+s.wallets)}</div>`;
  }

  function filters(){
    return `<div class="flex items-center gap-2 flex-wrap">
      <span class="text-[11px] text-mut uppercase tracking-wide mr-1">Min size</span>
      ${WF.THRESHOLDS.map(t => `<button data-thr="${t}"
        class="px-3 py-1.5 rounded-lg text-xs num border transition-colors ${minUsd===t
          ? 'border-acc text-acc bg-acc/10' : 'border-line text-slate-300 hover:border-acc/40'}">
        $${t>=1000?(t/1000)+'k':t}+</button>`).join('')}</div>`;
  }

  function row(t){
    const sideCls = t.side === 'buy' ? 'text-up' : 'text-down';
    const sideLbl = t.side === 'buy' ? 'BUY' : 'SELL';
    return `<tr class="row-hov border-b border-line/40 last:border-0">
      <td class="px-3 py-2.5">
        <div class="flex items-center gap-2">${U.logo(t.base, '#5B8CFF', 5)}
          <div><div class="font-medium text-slate-200 text-sm">${F.esc(t.base)}<span class="text-mut">/${F.esc(t.quote)}</span></div>
          <div class="text-[10px] text-mut">${U.chainBadge ? U.chainBadge(t.chain) : t.chain}</div></div></div></td>
      <td class="px-3 py-2.5 num text-xs font-bold ${sideCls}">${sideLbl}</td>
      <td class="px-3 py-2.5 text-right num text-xs text-slate-300">${F.num(t.amount)} ${F.esc(t.base)}</td>
      <td class="px-3 py-2.5 text-right num text-sm font-semibold ${sideCls}">${F.usd(t.usd)}</td>
      <td class="px-3 py-2.5 num text-[11px]">
        <a href="${WF.explorerAddr(t.chain,t.wallet)}" target="_blank" rel="noopener"
           class="text-slate-300 hover:text-acc">${short(t.wallet)}</a></td>
      <td class="px-3 py-2.5 num text-[11px]">
        <a href="${WF.explorerTx(t.chain,t.tx)}" target="_blank" rel="noopener"
           class="text-mut hover:text-acc">${short(t.tx)} ↗</a></td>
      <td class="px-3 py-2.5 text-right num text-[11px] text-mut whitespace-nowrap">${F.rel(t.ts)}</td></tr>`;
  }

  function table(){
    const rows = WF.feed(minUsd, { limit: 60 });
    if (!rows.length) return `<div class="px-4 py-10 text-center text-mut text-sm">
      Scanning live pools for swaps over $${minUsd>=1000?(minUsd/1000)+'k':minUsd}…<br>
      <span class="text-xs">Large on-chain trades appear here as they print. Lower the threshold to see more.</span></div>`;
    const body = rows.map(t => { try { return row(t); } catch(e){ return ''; } }).join('');
    return `<div class="overflow-x-auto"><table class="w-full text-left">
      <thead><tr class="text-[10px] uppercase tracking-wide text-mut border-b border-line">
        <th class="px-3 py-2 font-medium">Token</th><th class="px-3 py-2 font-medium">Side</th>
        <th class="px-3 py-2 font-medium text-right">Amount</th><th class="px-3 py-2 font-medium text-right">USD value</th>
        <th class="px-3 py-2 font-medium">Wallet</th><th class="px-3 py-2 font-medium">Tx</th>
        <th class="px-3 py-2 font-medium text-right">Time</th></tr></thead>
      <tbody>${body}</tbody></table></div>`;
  }

  function render(){
    root.innerHTML = `<div class="max-w-5xl mx-auto px-3 sm:px-4 py-4 space-y-4">
      <div>
        <h1 class="font-disp text-xl font-bold text-white">Whale Flow</h1>
        <p class="text-[12px] text-mut">Real large on-chain swaps from live DEX pools · GeckoTerminal · PulseX. Verifiable wallets and tx hashes only — no PnL, scores, or labels.</p>
      </div>
      <div id="wfFilters">${filters()}</div>
      <div id="wfStats">${statBar()}</div>
      <div class="bg-panel border border-line rounded-xl overflow-hidden">
        <div class="px-4 py-3 border-b border-line font-disp font-semibold text-white flex items-center gap-2">
          <span class="w-2 h-2 rounded-full bg-down animate-pulse"></span> Live prints
          <span class="text-[10px] text-mut font-normal">over $${minUsd>=1000?(minUsd/1000)+'k':minUsd}</span></div>
        <div id="wfTable">${table()}</div>
      </div>
      <p class="text-[10px] text-mut text-center">On-chain trade data is bounded to the deepest-liquidity tracked pools per chain. Always verify via the linked block explorer before acting.</p></div>`;

    undelegate = D.delegate(root, {
      '[data-thr]': (el) => {
        minUsd = +el.getAttribute('data-thr');
        D.$('#wfFilters', root).innerHTML = filters();
        D.$('#wfStats', root).innerHTML = statBar();
        D.$('#wfTable', root).innerHTML = table();
      }
    });
  }

  function refresh(){
    if (!root) return;
    D.$('#wfStats', root).innerHTML = statBar();
    D.$('#wfTable', root).innerHTML = table();
  }

  return {
    mount(el){
      root = el;
      WF.start();
      render();
      subs.push(CDX.Bus.on('whaleflow:updated', refresh));
      subs.push(CDX.Bus.on('whaleflow:new', () => { /* coalesced via updated */ }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; root=null; }
  };
})();
