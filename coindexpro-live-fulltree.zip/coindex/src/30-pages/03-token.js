/* Page: Token detail — TradingView candles, stats, related pairs. Route: #/token/:id */
CDX.Pages.token = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI;
  let subs = [], root = null, chart = null, undelegate = null, key = null;

  function header(c){
    return `<div class="flex items-start gap-3 flex-wrap">
      ${U.logo(c.sym, c.color, 10)}
      <div class="min-w-0 flex-1">
        <div class="flex items-center gap-2 flex-wrap">
          <h1 class="font-disp font-bold text-white text-2xl">${F.esc(c.name)}</h1>
          <span class="text-mut">${F.esc(c.sym)}</span>
          <span class="text-[10px] text-mut border border-line rounded px-1.5 py-0.5">Rank #${c.rank}</span>
          ${c.chain === 'pulsechain' ? U.chainBadge('pulsechain', true) : ''}
          <span class="ml-1">${U.star('c:' + c.id)}</span>
        </div>
        <div class="flex items-end gap-3 mt-1.5 flex-wrap">
          <span class="font-disp font-bold text-white text-3xl num" data-live="tpx">${F.price(c.price)}</span>
          <span class="num text-lg font-semibold ${F.cls(c.ch24)}" data-live="tch">${F.pct(c.ch24)} <span class="text-xs font-normal text-mut">24h</span></span>
          <span class="num text-sm ${F.cls(c.ch1h)}">${F.pct(c.ch1h)} <span class="text-mut font-normal">1h</span></span>
          <span class="num text-sm ${F.cls(c.ch7d)}">${F.pct(c.ch7d)} <span class="text-mut font-normal">7d</span></span>
        </div>
      </div></div>`;
  }
  const dt = iso => iso ? new Date(iso).toLocaleDateString('en-US', { month:'short', year:'numeric' }) : '';
  function stats(c){
    const holders = Math.max(0, ...CDX.Data.pairsForToken(c).filter(p => p.chain === 'pulsechain').map(p => p.holders || 0));
    const supPct = c.maxSupply ? Math.min(100, c.supply / c.maxSupply * 100) : null;
    const items = [
      ['Market Cap', F.usd(c.mcap), 'Rank #' + c.rank],
      ['Volume 24h', F.usd(c.vol), 'Vol/MCap ' + (c.vol / c.mcap * 100).toFixed(1) + '%'],
      ['FDV', c.fdv ? F.usd(c.fdv) : '—', c.fdv && c.mcap ? 'MC/FDV ' + (c.mcap / c.fdv).toFixed(2) : ''],
      ['Circulating Supply', F.num(c.supply) + ' ' + c.sym,
        supPct != null ? supPct.toFixed(0) + '% of max' : (c.totalSupply ? 'total ' + F.num(c.totalSupply) : ''), supPct],
      ['Max Supply', c.maxSupply ? F.num(c.maxSupply) + ' ' + c.sym : '∞',
        c.totalSupply ? 'total ' + F.num(c.totalSupply) : ''],
      c.ath != null
        ? ['All-Time High', F.price(c.ath), `<span class="${F.cls(c.athCh)}">${(c.athCh||0).toFixed(1)}%</span> · ${dt(c.athDate)}`]
        : ['Category', c.cat === 'meme' ? 'Memecoin' : c.cat === 'large' ? 'Large Cap' : 'Mid Cap', ''],
      c.atl != null
        ? ['All-Time Low', F.price(c.atl), `<span class="${F.cls(c.atlCh)}">+${F.num(c.atlCh||0)}%</span> · ${dt(c.atlDate)}`]
        : null,
      holders > 0 ? ['Holders', F.num(holders), 'PulseChain · on-chain'] : null
    ].filter(Boolean);
    return items.map(([l, v, sub, bar]) => `<div class="bg-panel2 border border-line rounded-lg px-3 py-2.5">
      <div class="text-[10px] uppercase tracking-wider text-mut mb-0.5">${l}</div>
      <div class="num text-white font-medium">${v}</div>
      ${sub ? `<div class="text-[10px] text-mut mt-0.5">${sub}</div>` : ''}
      ${bar != null ? `<div class="h-1 bg-line rounded-full mt-1.5 overflow-hidden"><div class="h-full bg-acc/70 rounded-full" style="width:${bar}%"></div></div>` : ''}
    </div>`).join('');
  }
  function riskCard(c){
    const r = CDX.Risk.forToken(c);
    return `<div class="bg-panel border border-line rounded-xl p-4" id="tkRisk">
      <div class="flex items-center justify-between mb-3">
        <h3 class="font-disp font-semibold text-white">Risk Intelligence</h3>
        ${r.pair ? `<a href="#/pair/${r.pair.id}" class="text-[10px] text-mut hover:text-acc">worst pool: ${F.esc(r.pair.base)}/${F.esc(r.pair.quote)} →</a>` : ''}</div>
      ${CDX.Risk.ui.gauges(r)}
      <div>${r.vectors.slice(0, 5).map(CDX.Risk.ui.vectorRow).join('')}</div>
      <div class="text-[9px] text-mut mt-2">Liquidity-weighted across tracked pools · safety floor = weakest pool.</div></div>`;
  }
  function venueBreakdown(c){
    const ps = CDX.Data.pairsForToken(c);
    if (!ps.length) return '';
    const byDex = new Map();
    let total = 0;
    for (const p of ps){
      byDex.set(p.dex, (byDex.get(p.dex) || 0) + p.vol);
      total += p.vol;
    }
    const rows = [...byDex.entries()].sort((a,b)=>b[1]-a[1]).slice(0,6);
    return `<div class="bg-panel border border-line rounded-xl overflow-hidden">
      <div class="px-4 py-3 border-b border-line font-disp font-semibold text-white">Markets <span class="text-mut text-xs font-body font-normal">DEX volume share</span></div>
      <div class="p-4 space-y-2.5">${rows.map(([dex, vol], i) => `
        <div><div class="flex justify-between text-[12px] mb-1">
          <span class="text-slate-200 font-medium">${i+1}. ${F.esc(dex)}</span>
          <span class="num text-mut">${F.usd(vol)} · ${(vol/total*100).toFixed(1)}%</span></div>
        <div class="h-1.5 bg-line rounded-full overflow-hidden"><div class="h-full bg-acc rounded-full" style="width:${(vol/total*100).toFixed(1)}%"></div></div></div>`).join('')}</div></div>`;
  }
  function relatedPairs(c){
    const ps = [...CDX.Data.pairsForToken(c)].sort((a,b)=>b.vol-a.vol);
    if (!ps.length) return '<div class="px-4 py-6 text-sm text-mut">No tracked DEX pairs for this asset yet.</div>';
    const total = ps.reduce((a,p)=>a+p.vol,0) || 1;
    return ps.map(p => `<a href="#/pair/${p.id}" class="row-hov flex items-center gap-3 px-4 py-2 border-b border-line/50 last:border-0">
      ${U.logo(p.base, CDX.Data.CHAINS[p.chain].color, 6)}
      <span class="text-sm font-medium text-white">${F.esc(p.base)}<span class="text-mut font-normal">/${F.esc(p.quote)}</span></span>
      ${U.chainBadge(p.chain)}<span class="text-[11px] text-mut">${F.esc(p.dex)}</span>
      <span class="ml-auto flex items-center gap-3 text-right">
        <span class="num text-xs text-mut">Liq ${F.usd(p.liq)}</span>
        <span class="num text-xs text-mut">Vol ${F.usd(p.vol)} <span class="text-[10px]">(${(p.vol/total*100).toFixed(0)}%)</span></span>
        <span class="num text-sm ${F.cls(p.ch.h24)}">${F.pctAuto(p.ch.h24)}</span></span></a>`).join('');
  }
  function tfButtons(){
    const cur = chart ? chart.getTf() : CDX.Store.state.prefs.chartTf;
    return CDX.Chart.TFS.map(tf => `<button data-ctf="${tf}" class="px-2.5 py-1 rounded-md ${tf===cur?'seg-active':'text-mut hover:text-white'}">${tf}</button>`).join('');
  }
  return {
    mount(el, ctx){
      const c = CDX.Data.coins.find(x => x.id === ctx.params.id);
      root = el;
      if (!c){ root.innerHTML = '<div class="py-20 text-center text-mut">Unknown token.</div>'; return; }
      key = 'c:' + c.id;
      root.innerHTML = `<div class="space-y-5">
        <div>${header(c)}</div>
        <div class="bg-panel border border-line rounded-xl p-4">
          <div class="flex items-center justify-between mb-3 flex-wrap gap-2">
            <h3 class="font-disp font-semibold text-white">Price Chart <span class="text-mut text-xs font-body font-normal">TradingView Lightweight · live</span></h3>
            <div class="flex items-center bg-panel2 border border-line rounded-lg p-0.5 text-xs" id="ctfSeg">${tfButtons()}</div>
          </div>
          <div id="tvChart" class="w-full" style="height:420px"></div>
        </div>
        <div class="grid grid-cols-2 sm:grid-cols-4 xl:grid-cols-8 gap-3">${stats(c)}</div>
        <div class="grid lg:grid-cols-3 gap-4">
          <div class="lg:col-span-2 space-y-4">
            <div class="bg-panel border border-line rounded-xl overflow-hidden">
              <div class="px-4 py-3 border-b border-line font-disp font-semibold text-white">DEX Pairs <span class="text-mut text-xs font-body font-normal">tracked deployments · sorted by volume</span></div>
              ${relatedPairs(c)}
            </div>
            ${venueBreakdown(c)}
          </div>
          ${riskCard(c)}
        </div></div>`;
      chart = CDX.Chart.create(D.$('#tvChart', root), key, c);
      undelegate = D.delegate(root, {
        '[data-ctf]': t => { chart.setTf(t.dataset.ctf); D.$('#ctfSeg', root).innerHTML = tfButtons(); }
      });
      subs.push(CDX.Bus.on('tick', changed => {
        const hit = changed.find(x => x.key === key);
        if (!hit) return;
        D.liveSet(root.querySelector('[data-live="tpx"]'), F.price(c.price), hit.dir);
        const chNode = root.querySelector('[data-live="tch"]');
        if (chNode){ chNode.innerHTML = `${F.pct(c.ch24)} <span class="text-xs font-normal text-mut">24h</span>`; chNode.className = 'num text-lg font-semibold ' + F.cls(c.ch24); }
      }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (chart) chart.destroy(); chart=null; if (undelegate) undelegate(); undelegate=null; root=null; }
  };
})();
