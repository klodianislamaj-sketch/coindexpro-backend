/* Page: Alert Engine — rule builder, channels, rules list, live alert log. Route: #/alerts */
CDX.Pages.alerts = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI, S = CDX.Store;
  let subs = [], root = null, undelegate = null;
  let draft = { type: 'price', key: null, channels: ['toast', 'browser'] };
  const TYPES = [['price','Price'],['volume','Volume'],['liquidity','Liquidity'],['whale','Whale'],['wallet','Wallet'],
                 ['risk','Risk'],['narrative','Narrative'],['newpair','New Pair'],['pulsechain','PulseChain']];
  const CH = [['toast','Toast'],['browser','Browser'],['webhook','Webhook'],['telegram','Telegram'],['email','Email']];
  const num = v => { const m = String(v).trim().toLowerCase().match(/^(-?[\d.]+)\s*([kmbt]?)$/);
    return m ? parseFloat(m[1]) * ({ k:1e3, m:1e6, b:1e9, t:1e12, '':1 })[m[2]] : NaN; };
  const sel = (id, opts, cur) => `<select data-f="${id}" class="actl">${opts.map(([v, l]) => `<option value="${v}" ${v === cur ? 'selected' : ''}>${l}</option>`).join('')}</select>`;
  const inp = (id, ph, cls) => `<input data-f="${id}" placeholder="${ph}" autocomplete="off" class="actl ${cls || 'w-28'}">`;
  const chainOpts = [['any','Any chain']].concat(CDX.Data.CHAIN_ORDER.map(c => [c, CDX.Data.CHAINS[c].name]));

  function paramFields(){
    const t = draft.type;
    const asset = `<div class="relative"><input data-asset placeholder="Search asset…" autocomplete="off" class="actl w-44">
      <div data-assetres class="hidden absolute top-full mt-1 left-0 w-60 bg-panel border border-line rounded-xl shadow-2xl shadow-black/60 z-30 overflow-hidden"></div></div>
      <span data-assetpick class="text-xs ${draft.key ? 'text-white font-medium' : 'text-mut'}">${draft.key ? F.esc(CDX.Data.label(CDX.Data.byKey(draft.key))) : 'no asset selected'}</span>`;
    if (t === 'price') return asset + sel('op', [['above','crosses above'],['below','crosses below'],['pctMove','moves ±%']], 'above') + inp('value', 'price or %');
    if (t === 'volume') return asset + sel('op', [['volAbove','24h volume above $'],['turnoverAbove','turnover above ×']], 'volAbove') + inp('value', 'e.g. 5m or 3');
    if (t === 'liquidity') return asset + sel('op', [['below','drops below $'],['above','rises above $'],['changePct','LP event ≥ ±%']], 'below') + inp('value', 'e.g. 100k or 10');
    if (t === 'whale') return inp('minUsd', 'min print $ (e.g. 100k)') + sel('side', [['any','any side'],['buy','buys only'],['sell','sells only']], 'any') + sel('chain', chainOpts, 'any');
    if (t === 'wallet') return inp('addr', 'wallet address 0x…', 'w-64 num') + sel('side', [['any','any side'],['buy','buys'],['sell','sells']], 'any');
    if (t === 'risk') return sel('chain', chainOpts, 'pulsechain') + inp('value', 'risk score ≥ (e.g. 70)') + '<span class="text-[10px] text-mut">or pick a single pair:</span>' + asset;
    if (t === 'narrative') return sel('id', CDX.DataRaw.NARRATIVE_ORDER.map(n => [n, CDX.DataRaw.NARRATIVES[n].name]), 'pulsechain')
      + sel('metric', [['netFlow','net flow'],['heat','heat']], 'netFlow') + sel('op', [['above','above'],['below','below']], 'above') + inp('value', 'e.g. 2m or 75');
    if (t === 'newpair') return sel('chain', chainOpts, 'any') + inp('minLiq', 'min liquidity $ (e.g. 25k)');
    if (t === 'pulsechain') return sel('kind', [['trackedMove','tracked pair moves ±% (1h)'],['gasAbove','base fee above gwei'],['blockStall','blocks stalled (min)']], 'trackedMove') + inp('value', 'threshold');
    return '';
  }
  function readDraft(){
    const get = id => { const el = root.querySelector(`[data-f="${id}"]`); return el ? el.value : null; };
    const p = {};
    for (const el of root.querySelectorAll('[data-f]')){
      const v = el.value;
      p[el.dataset.f] = ['value','minUsd','minLiq'].includes(el.dataset.f) ? num(v) : v;
    }
    if (draft.key){ p.key = draft.key; if (draft.key.startsWith('d:')) p.pairId = draft.key.slice(2); }
    return p;
  }
  function summary(r){
    const p = r.params, lbl = p.key ? F.esc(CDX.Data.label(CDX.Data.byKey(p.key)) || p.key) : '';
    const u = v => F.usd(v);
    switch (r.type){
      case 'price': return `${lbl} ${p.op === 'pctMove' ? 'moves ±' + p.value + '%' : p.op + ' ' + F.price(p.value)}`;
      case 'volume': return `${lbl} ${p.op === 'volAbove' ? 'vol > ' + u(p.value) : 'turnover > ' + p.value + '×'}`;
      case 'liquidity': return `${lbl} liq ${p.op === 'changePct' ? 'event ≥ ±' + p.value + '%' : p.op + ' ' + u(p.value)}`;
      case 'whale': return `prints ≥ ${u(p.minUsd)} · ${p.side} · ${p.chain}`;
      case 'wallet': return `${(p.addr || '').slice(0, 10)}… · ${p.side}`;
      case 'risk': return `${lbl || p.chain} risk ≥ ${p.value}`;
      case 'narrative': return `${CDX.DataRaw.NARRATIVES[p.id] ? CDX.DataRaw.NARRATIVES[p.id].name : p.id} ${p.metric} ${p.op} ${p.metric === 'heat' ? p.value : u(p.value)}`;
      case 'newpair': return `${p.chain} · liq ≥ ${u(p.minLiq || 0)}`;
      case 'pulsechain': return `${p.kind} ≥ ${p.value}`;
      default: return r.type;
    }
  }
  function builder(){
    return `<div class="bg-panel border border-line rounded-xl p-4 space-y-3">
      <div class="flex items-center gap-1.5 flex-wrap">${TYPES.map(([id, l]) =>
        `<button data-atype="${id}" class="text-xs rounded-lg px-2.5 py-1 border ${draft.type === id ? 'bg-acc/15 border-acc/50 text-white' : 'bg-panel2 border-line text-mut hover:text-white'}">${l}</button>`).join('')}</div>
      <div class="flex items-center gap-2 flex-wrap" id="aParams">${paramFields()}</div>
      <div class="flex items-center gap-3 flex-wrap">
        <span class="text-[10px] uppercase tracking-wider text-mut">Deliver via</span>
        ${CH.map(([id, l]) => `<label class="flex items-center gap-1.5 text-xs text-slate-300 ${id === 'toast' ? 'opacity-60' : 'cursor-pointer'}">
          <input type="checkbox" data-ch="${id}" ${draft.channels.includes(id) ? 'checked' : ''} ${id === 'toast' ? 'disabled' : ''} class="accent-acc w-3.5 h-3.5">${l}</label>`).join('')}
        <button data-create class="ml-auto text-xs bg-acc/15 border border-acc/50 text-white rounded-lg px-3.5 py-1.5 hover:bg-acc/25">+ Create alert</button></div></div>`;
  }
  function rulesList(){
    const rs = S.state.alerts;
    if (!rs.length) return '<div class="px-4 py-8 text-center text-sm text-mut">No alert rules yet — build one above.</div>';
    return rs.map(r => `<div class="flex items-center gap-3 px-4 py-2.5 border-b border-line/40 last:border-0">
      <button data-tgl="${r.id}" class="w-8 h-4.5 rounded-full relative transition-colors ${r.enabled ? 'bg-up/70' : 'bg-line'}" style="height:18px">
        <span class="absolute top-0.5 ${r.enabled ? 'right-0.5' : 'left-0.5'} w-3.5 h-3.5 rounded-full bg-white transition-all"></span></button>
      <span class="text-[9px] font-bold uppercase tracking-wider border border-acc/40 text-acc bg-acc/10 rounded px-1.5 py-0.5 w-20 text-center shrink-0">${r.type}</span>
      <div class="min-w-0 flex-1"><div class="text-sm text-white truncate">${summary(r)}</div>
        <div class="text-[10px] text-mut">${(r.channels || []).join(' · ')} · fired ${r.fireCount || 0}×${r.lastFired ? ' · last ' + F.rel(r.lastFired) : ''}</div></div>
      <button data-del="${r.id}" class="text-mut hover:text-down text-sm px-1">✕</button></div>`).join('');
  }
  function channelsCard(){
    const c = S.state.alertChannels;
    const perm = typeof Notification !== 'undefined' ? Notification.permission : 'unsupported';
    return `<div class="p-4 space-y-3 text-xs">
      <div class="flex items-center gap-2">
        <span class="w-24 text-mut">Browser</span>
        <button data-perm class="actl">${perm === 'granted' ? '✓ enabled' : 'Enable notifications'}</button>
        <span class="text-[10px] text-mut">${perm}</span></div>
      <div class="flex items-center gap-2"><span class="w-24 text-mut">Webhook URL</span>
        <input data-cfg="webhookUrl" value="${F.esc(c.webhookUrl)}" placeholder="https://…" class="actl flex-1 num">
        <button data-test="webhook" class="actl">test</button></div>
      <div class="flex items-center gap-2"><span class="w-24 text-mut">Telegram</span>
        <input data-cfg="tgToken" value="${F.esc(c.tgToken)}" placeholder="bot token" class="actl flex-1 num">
        <input data-cfg="tgChat" value="${F.esc(c.tgChat)}" placeholder="chat id" class="actl w-28 num">
        <button data-test="telegram" class="actl">test</button></div>
      <div class="flex items-center gap-2"><span class="w-24 text-mut">Email relay</span>
        <input data-cfg="emailEndpoint" value="${F.esc(c.emailEndpoint)}" placeholder="relay endpoint URL (Zapier/Make/own)" class="actl flex-1 num">
        <input data-cfg="emailTo" value="${F.esc(c.emailTo)}" placeholder="to@…" class="actl w-36 num">
        <button data-test="email" class="actl">test</button></div>
      <div class="text-[10px] text-mut">Telegram sends via the Bot API directly. Email requires a relay endpoint that accepts {to, subject, text}. Webhook receives the full alert JSON.</div></div>`;
  }
  function logFeed(){
    const rows = CDX.Alerts.log(14);
    if (!rows.length) return '<div class="px-4 py-8 text-center text-sm text-mut">Fired alerts land here.</div>';
    return rows.map(e => `<div class="row-hov flex items-start gap-3 px-4 py-2 border-b border-line/40 last:border-0" ${e.key ? `data-go="${e.key.startsWith('c:') ? '/token/' + e.key.slice(2) : '/pair/' + e.key.slice(2)}" style="cursor:pointer"` : ''}>
      <span class="num text-[10px] text-mut w-12 shrink-0 mt-0.5">${F.rel(e.ts)}</span>
      <div class="min-w-0"><div class="text-sm text-white">🔔 ${e.title}</div>
      <div class="text-[11px] text-mut">${e.body}</div></div></div>`).join('');
  }
  const card = (title, sub, body) => `<div class="bg-panel border border-line rounded-xl overflow-hidden">
    <div class="px-4 py-3 border-b border-line"><h3 class="font-disp font-semibold text-white">${title}</h3>
    <div class="text-[10px] text-mut">${sub}</div></div>${body}</div>`;

  function paint(){
    D.$('#alBuild', root).innerHTML = builder();
    D.$('#alRules', root).innerHTML = card('Alert Rules', S.state.alerts.length + ' configured', rulesList());
    D.$('#alChan', root).innerHTML = card('Delivery Channels', 'browser · webhook · telegram · email relay', channelsCard());
    D.$('#alLog', root).innerHTML = card('Alert Log <span class="w-1.5 h-1.5 rounded-full bg-down live-dot inline-block ml-1"></span>', 'session feed', logFeed());
    bindAsset();
  }
  function bindAsset(){
    const q2 = root.querySelector('[data-asset]'), res = root.querySelector('[data-assetres]');
    if (!q2) return;
    q2.addEventListener('input', () => {
      const v = q2.value.trim();
      if (!v){ res.classList.add('hidden'); return; }
      res.innerHTML = CDX.Data.search(v, 6).map(h => `<button data-assetkey="${h.key}" class="w-full text-left px-3 py-2 hover:bg-panel2 text-xs text-white">${F.esc(CDX.Data.label(h.it))} <span class="text-mut">${F.esc(h.it.name)}</span></button>`).join('');
      res.classList.remove('hidden');
    });
    q2.addEventListener('blur', () => setTimeout(() => res.classList.add('hidden'), 160));
  }
  return {
    mount(el){
      root = el;
      root.innerHTML = `<div class="space-y-4">
        <div class="flex items-center gap-3 flex-wrap">
          <h2 class="font-disp font-semibold text-white text-lg">Alert Engine</h2>
          <span class="text-[11px] text-mut">9 rule types · evaluated against live streams · per-target cooldowns</span></div>
        <div id="alBuild"></div>
        <div class="grid lg:grid-cols-3 gap-4">
          <div class="lg:col-span-1" id="alRules"></div>
          <div id="alChan"></div>
          <div id="alLog"></div></div>
        <style>.actl{background:#161B27;border:1px solid #1F2633;border-radius:8px;font-size:12px;padding:6px 10px;color:#E2E8F0}.actl:focus{outline:none;border-color:#5B8CFF99}</style></div>`;
      paint();
      undelegate = D.delegate(root, {
        '[data-atype]': t => { draft.type = t.dataset.atype; draft.key = null; D.$('#alBuild', root).innerHTML = builder(); bindAsset(); },
        '[data-assetkey]': t => { draft.key = t.dataset.assetkey; const s = root.querySelector('[data-assetpick]'); if (s){ s.textContent = CDX.Data.label(CDX.Data.byKey(draft.key)); s.className = 'text-xs text-white font-medium'; } },
        '[data-create]': () => {
          for (const cb of root.querySelectorAll('[data-ch]'))
            draft.channels = cb.checked ? [...new Set([...draft.channels, cb.dataset.ch])] : draft.channels.filter(c => c !== cb.dataset.ch);
          const params = readDraft();
          if (['price','volume','liquidity'].includes(draft.type) && !draft.key){ U.toast('Pick an asset first.', 'warn'); return; }
          if (draft.type === 'liquidity' && !params.pairId){ U.toast('Liquidity alerts need a DEX pair.', 'warn'); return; }
          S.saveAlert({ type: draft.type, name: draft.type, params, channels: [...draft.channels] });
          U.toast('Alert created', 'up');
          draft.key = null;
          paint();
        },
        '[data-tgl]': t => { S.toggleAlert(t.dataset.tgl); paint(); },
        '[data-del]': t => { S.deleteAlert(t.dataset.del); paint(); },
        '[data-perm]': async () => { if (typeof Notification !== 'undefined'){ const p = await Notification.requestPermission(); S.setChannels({ browser: p === 'granted' }); paint(); } },
        '[data-test]': t => CDX.Alerts.test(t.dataset.test),
        '[data-go]': t => CDX.Router.go(t.dataset.go)
      });
      root.addEventListener('change', e => {
        if (e.target.dataset && e.target.dataset.cfg) S.setChannels({ [e.target.dataset.cfg]: e.target.value.trim() });
      });
      subs.push(CDX.Bus.on('alert:fired', () => { const h = D.$('#alLog', root); if (h) h.innerHTML = card('Alert Log <span class="w-1.5 h-1.5 rounded-full bg-down live-dot inline-block ml-1"></span>', 'session feed', logFeed()); D.$('#alRules', root).innerHTML = card('Alert Rules', S.state.alerts.length + ' configured', rulesList()); }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; root=null; }
  };
})();
