/* Page: wallet intelligence profile. Route: #/wallet/:address */
CDX.Pages.wallet = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI, I = CDX.Intel, IU = CDX.IntelUI;
  let subs = [], root = null, undelegate = null, addr = null;
  const holdFmt = m => m == null ? '—' : m < 60 ? m.toFixed(0) + 'm' : (m / 60).toFixed(1) + 'h';
  const money = v => (v >= 0 ? '+' : '−') + F.usd(Math.abs(v));
  function observedHtml(){
    const a = CDX.WalletIntel.analyze(addr);
    if (!a) return '';
    const b = CDX.WalletIntel.behavior(a);
    const pref = CDX.WalletIntel.preference(addr);
    const m = CDX.WalletIntel.mirror(addr);
    const path = a.rotationPath.map(id => CDX.Data.byKey('d:' + id)).filter(Boolean);
    return `
      <div class="bg-panel border border-line rounded-xl p-4">
        <div class="flex items-center gap-2 mb-3 flex-wrap">
          <h3 class="font-disp font-semibold text-white">Observed Performance <span class="text-mut text-xs font-body font-normal">live print ledger · FIFO</span></h3>
          <span class="ml-auto text-[10px] font-bold uppercase tracking-wider border border-acc/40 text-acc bg-acc/10 rounded px-1.5 py-0.5">${b.archetype}</span></div>
        <div class="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-2.5 mb-4">
          ${[['Realized', `<span class="${a.realized >= 0 ? 'text-up' : 'text-down'}">${money(a.realized)}</span>`],
             ['Unrealized', `<span class="${a.unrealized >= 0 ? 'text-up' : 'text-down'}">${money(a.unrealized)}</span>`],
             ['Win Rate', a.winRate != null ? a.winRate.toFixed(0) + '%' : '—'],
             ['Avg Hold · Open Age', holdFmt(a.avgHoldMin) + ' · ' + holdFmt(a.openAgeMin)],
             ['Avg / Max Size', F.usd(a.avgSize) + ' / ' + F.usd(a.maxSize)],
             ['Mirror Return', m ? `<span class="${m.ret >= 0 ? 'text-up' : 'text-down'}">${m.ret >= 0 ? '+' : ''}${m.ret.toFixed(1)}%</span>` : '—'],
             ['Match Coverage', `${a.coverage.toFixed(0)}%` + (a.unmatchedSellUsd > 0 ? ` <span class="text-[9px] text-mut">(${F.usd(a.unmatchedSellUsd)} pre-ledger)</span>` : '')],
             ['Exit Win Rate', a.winRateExits != null ? a.winRateExits.toFixed(0) + '% · ' + a.exits + ' exits' : '—']]
            .map(([l, v]) => `<div class="bg-panel2 border border-line rounded-lg px-3 py-2">
              <div class="text-[9px] uppercase tracking-wider text-mut">${l}</div>
              <div class="num text-white text-sm font-medium">${v}</div></div>`).join('')}</div>
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">${b.traits.map(([l, v]) => `
          <div><div class="flex justify-between text-[9px] text-mut mb-0.5"><span>${l}</span><span class="num">${v}</span></div>
          <div class="h-1 bg-line rounded-full overflow-hidden"><div class="h-full bg-acc rounded-full" style="width:${v}%"></div></div></div>`).join('')}</div>
        ${a.positions.length ? `<div class="text-[10px] uppercase tracking-wider text-mut mb-1.5">Open Positions <span class="normal-case">(from observed entries)</span></div>
          ${a.positions.slice(0, 5).map(pos => pos.p ? `<div class="flex items-center gap-2.5 py-1.5 border-b border-line/40 last:border-0 text-[12px]" data-go="/pair/${pos.p.id}" style="cursor:pointer">
            <span class="text-white font-medium">${F.esc(pos.p.base)}/${F.esc(pos.p.quote)}</span>
            <span class="num text-mut">avg ${F.price(pos.avgPrice)}</span>
            <span class="ml-auto num text-slate-300">${F.usd(pos.value)}</span>
            <span class="num w-16 text-right ${pos.uPnl >= 0 ? 'text-up' : 'text-down'}">${pos.uPnlPct >= 0 ? '+' : ''}${pos.uPnlPct.toFixed(1)}%</span></div>` : '').join('')}` : ''}
        ${pref.syms.length ? `<div class="text-[10px] uppercase tracking-wider text-mut mt-3 mb-1.5">Token Preference <span class="normal-case">· volume share</span></div>
          <div class="space-y-1.5">${pref.syms.map(x => `<div class="flex items-center gap-2 text-[11px]">
            <span class="text-slate-300 w-14 font-medium">${F.esc(x.k)}</span>
            <div class="h-1.5 flex-1 bg-line rounded-full overflow-hidden"><div class="h-full bg-acc rounded-full" style="width:${x.pct.toFixed(0)}%"></div></div>
            <span class="num text-mut w-10 text-right">${x.pct.toFixed(0)}%</span></div>`).join('')}</div>` : ''}
        ${a.realizedByPair.length ? `<div class="text-[10px] uppercase tracking-wider text-mut mt-3 mb-1.5">Realized by Token</div>
          ${a.realizedByPair.slice(0, 4).map(r => r.p ? `<div class="flex items-center gap-2 py-1 text-[11.5px]" data-go="/pair/${r.p.id}" style="cursor:pointer">
            <span class="text-slate-300 font-medium w-16">${F.esc(r.p.base)}</span>
            <span class="num text-[9.5px] text-mut">vol ${F.usd(r.vol)}</span>
            <span class="ml-auto num ${r.realized >= 0 ? 'text-up' : 'text-down'}">${money(r.realized)}</span></div>` : '').join('')}` : ''}
        ${a.transitions.length ? `<div class="text-[10px] uppercase tracking-wider text-mut mt-3 mb-1.5">Top Rotation Edges</div>
          <div class="space-y-0.5">${a.transitions.slice(0, 3).map(t => {
            const fp = CDX.Data.byKey('d:' + t.from), tp = CDX.Data.byKey('d:' + t.to);
            return `<div class="text-[11px] num"><span class="text-slate-300">${fp ? F.esc(fp.base) : '…'}</span>
              <span class="text-mut">→</span> <span class="text-slate-300">${tp ? F.esc(tp.base) : '…'}</span>
              <span class="text-mut"> · ${t.n}× · ${F.usd(t.usd)}</span></div>`; }).join('')}</div>` : ''}
        ${path.length > 1 ? `<div class="text-[10px] uppercase tracking-wider text-mut mt-3 mb-1.5">Rotation Path${a.revisits ? ` <span class="normal-case">· ${a.revisits} revisits</span>` : ''}</div>
          <div class="flex items-center gap-1.5 flex-wrap text-[11px]">${path.map(p => `<a href="#/pair/${p.id}" class="num border border-line rounded px-1.5 py-0.5 text-slate-300 hover:border-acc/50">${F.esc(p.base)}</a>`).join('<span class="text-mut">→</span>')}</div>` : ''}
      </div>`;
  }
  function render(){
    let w = I.wallet(addr);
    if (!w && CDX.WalletIntel.ledgerFor(addr).length){
      w = { addr, label: addr.slice(0, 6) + '…' + addr.slice(-4), type: 'Unlabeled',
            chains: [], pnl30d: 0, winRate: 0, trades30d: 0, score: 50, since: 'observed live' };
    }
    if (!w){ root.innerHTML = '<div class="py-20 text-center text-mut">No tracked profile and no observed prints for this address yet.</div>'; return; }
    const holdings = I.walletHoldings(w);
    const totalH = holdings.reduce((a,h)=>a+h.usd,0);
    const trades = I.whaleTrades({ wallet: addr }).slice(0, 10);
    const breakdown = I.scoreBreakdown(w);
    const scoreColor = w.score >= 80 ? '#2DD480' : w.score >= 60 ? '#F5C04E' : '#FF5C5C';
    root.innerHTML = `<div class="space-y-5">
      <div class="flex items-start gap-4 flex-wrap">
        <div class="w-14 h-14 rounded-xl grid place-items-center font-disp font-bold text-xl text-white shrink-0" style="background:${scoreColor}22;border:1px solid ${scoreColor}66">${F.esc(w.label.slice(0,2).toUpperCase())}</div>
        <div class="min-w-0 flex-1">
          <div class="flex items-center gap-2 flex-wrap">
            <h1 class="font-disp font-bold text-white text-2xl">${F.esc(w.label)}</h1>
            ${IU.typeBadge(w.type)}${w.chains.map(c=>U.chainBadge(c)).join(' ')}</div>
          <div class="flex items-center gap-2 mt-1">
            <span class="num text-xs text-mut">${w.addr}</span>
            <button data-copy="${w.addr}" class="text-[10px] text-mut hover:text-acc border border-line hover:border-acc/50 rounded px-1.5 py-0.5">copy ⧉</button></div></div>
        <div class="text-right">
          <div class="text-[11px] uppercase tracking-wider text-mut">Smart Money Score</div>
          <div class="font-disp font-bold text-4xl num" style="color:${scoreColor}">${w.score}</div></div></div>
      <div class="grid grid-cols-2 md:grid-cols-5 gap-3">
        ${U.statCard('PnL 30d', `<span class="${w.pnl30d>=0?'text-up':'text-down'}">${(w.pnl30d>=0?'+':'−')+F.usd(Math.abs(w.pnl30d)).slice(1)}</span>`, 'realized + unrealized')}
        ${U.statCard('Win Rate', w.winRate + '%', '30d closed trades')}
        ${U.statCard('Trades 30d', w.trades30d, (w.trades30d/30).toFixed(1) + ' / day avg')}
        ${U.statCard('Tracked Holdings', F.usd(totalH), holdings.length + ' positions')}
        ${U.statCard('Tracked Since', w.since, 'first flagged')}
      </div>
      <div class="grid lg:grid-cols-2 gap-4">
        <div class="bg-panel border border-line rounded-xl p-4">
          <h3 class="font-disp font-semibold text-white mb-3">Score Breakdown</h3>
          <div class="space-y-3">${breakdown.map(([l,v]) => IU.scoreBar(l, v, scoreColor)).join('')}</div>
          <p class="text-[10px] text-mut mt-3">Composite of timing, sizing, exit quality and consistency over tracked prints.</p></div>
        <div class="bg-panel border border-line rounded-xl overflow-hidden">
          <div class="px-4 py-3 border-b border-line font-disp font-semibold text-white">Tracked Holdings</div>
          ${holdings.map(h => {
            const isCoin = !!h.it.sym;
            return `<div class="row-hov flex items-center gap-3 px-4 py-2.5 border-b border-line/50 last:border-0" data-go="${isCoin?'/token/'+h.it.id:'/pair/'+h.it.id}">
              ${U.logo(isCoin?h.it.sym:h.it.base, isCoin?h.it.color:CDX.Data.CHAINS[h.it.chain].color, 6)}
              <span class="text-sm font-medium text-white">${F.esc(CDX.Data.label(h.it))}</span>
              ${!isCoin ? U.chainBadge(h.it.chain) : ''}
              <span class="ml-auto flex items-center gap-3">
                <span class="num text-xs text-mut">${F.num(h.amount)}</span>
                <span class="num text-sm text-slate-200">${F.usd(h.usd)}</span>
                <span class="num text-xs text-mut">${(h.usd/totalH*100).toFixed(0)}%</span></span></div>`;
          }).join('')}</div></div>
      ${observedHtml()}
      <div class="bg-panel border border-line rounded-xl overflow-hidden">
        <div class="px-4 py-3 border-b border-line font-disp font-semibold text-white">Recent Prints</div>
        <div id="wTrades">${trades.length ? trades.map(IU.whaleRow).join('') : '<div class="px-4 py-6 text-sm text-mut">No prints in the current window.</div>'}</div></div></div>`;
  }
  return {
    mount(el, ctx){ addr = ctx.params.address; root = el; render();
      undelegate = D.delegate(root, { '[data-copy]': () => {}, '[data-go]': t => CDX.Router.go(t.dataset.go) });
      subs.push(CDX.Bus.on('whale:new', t => {
        if (t.wallet !== addr) return;
        const host = D.$('#wTrades', root);
        if (host) host.innerHTML = CDX.Intel.whaleTrades({ wallet: addr }).slice(0, 10).map(CDX.IntelUI.whaleRow).join('');
      }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; root=null; addr=null; }
  };
})();
