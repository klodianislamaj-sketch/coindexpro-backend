/* Pages: Risk Radar (#/risk) · News Wire (#/news) · alias resolvers (/asset/:symbol,
   /pair/:chain/:pair) · concrete not-found handler. Replaces the roadmap fallback. */
CDX.Pages.risk = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI;
  let subs = [], root = null, undelegate = null;
  function rows(){
    return CDX.Data.pairs
      .filter(p => p.liq > 5e3 && p.vol > 1e3)
      .map(p => ({ p, r: CDX.Risk.quick(p) }))
      .sort((a, b) => b.r.risk - a.r.risk);
  }
  function board(list, title, sub){
    return `<div class="bg-panel border border-line rounded-xl overflow-hidden">
      <div class="px-4 py-3 border-b border-line"><h3 class="font-disp font-semibold text-white">${title}</h3>
      <div class="text-[10px] text-mut">${sub}</div></div>
      ${list.map(({ p, r }) => `<div class="row-hov flex items-center gap-2.5 px-4 py-2 border-b border-line/40 last:border-0" data-go="/pair/${p.id}" style="cursor:pointer">
        ${U.logo(p.base, CDX.Data.CHAINS[p.chain].color, 5)}
        <div class="min-w-0"><div class="text-[12.5px] font-medium text-white leading-tight">${F.esc(p.base)}<span class="text-mut font-normal">/${F.esc(p.quote)}</span></div>
        <div class="text-[10px] text-mut leading-tight">${U.chainBadge(p.chain)} <span class="num">Liq ${F.usd(p.liq)} · ${F.age(p.ageH)}</span></div></div>
        <span class="ml-auto shrink-0 text-right">
          <div>${CDX.Risk.ui.chip(r)}</div>
          <div class="text-[9px] text-mut mt-0.5">${(r.vectors.find(v => v.level === 'high') || r.vectors.find(v => v.level === 'med') || { label: 'no elevated vectors' }).label}</div></span></div>`).join('')
        || '<div class="px-4 py-8 text-center text-sm text-mut">Scoring the universe…</div>'}</div>`;
  }
  function paint(){
    const all = rows();
    const safe = [...all].sort((a, b) => b.r.safety - a.r.safety).slice(0, 10);
    D.$('#rkHi', root).innerHTML = board(all.slice(0, 10), 'Highest Risk', 'composite exposure across 10 vectors');
    D.$('#rkSafe', root).innerHTML = board(safe, 'Highest Safety', 'accumulated positive on-chain evidence');
    D.$('#rkFresh', root).innerHTML = board(all.filter(x => x.p.ageH <= 96).slice(0, 10), 'Fresh & Risky', 'pools ≤96h ranked by exposure');
  }
  return {
    mount(el){
      root = el;
      root.innerHTML = `<div class="space-y-4">
        <div class="flex items-center gap-3 flex-wrap">
          <h2 class="font-disp font-semibold text-white text-lg">Risk Radar</h2>
          <span class="text-[11px] text-mut">quick vectors universe-wide · deep on-chain evidence on PulseChain pair pages</span></div>
        <div class="grid lg:grid-cols-2 xl:grid-cols-3 gap-3">
          <div id="rkHi"></div><div id="rkSafe"></div><div id="rkFresh"></div></div></div>`;
      paint();
      undelegate = D.delegate(root, { '[data-go]': t => CDX.Router.go(t.dataset.go) });
      let n = 0;
      subs.push(CDX.Bus.on('tick', () => { if (++n % 8 === 0) paint(); }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; root=null; }
  };
})();

CDX.Pages.news = (() => {
  const D = CDX.Dom, F = CDX.Fmt;
  let subs = [], root = null, undelegate = null, filter = 'all';
  const FILTERS = [['all','All'],['bull','▲ Bullish'],['bear','▼ Bearish'],['wire','⚡ Live Wire']];
  function items(){
    let list = CDX.News.all();
    if (filter === 'bull' || filter === 'bear') list = list.filter(n => n.kind === filter);
    if (filter === 'wire') list = list.filter(n => n.wire);
    return list.slice(0, 40);
  }
  function row(n){
    const it = n.tag ? CDX.Data.byKey(n.tag) : null;
    const href = it ? (n.tag.startsWith('c:') ? '#/token/' + it.id : '#/pair/' + it.id) : '#/research';
    const dot = n.kind === 'bull' ? 'bg-up' : n.kind === 'bear' ? 'bg-down' : 'bg-acc';
    return `<a href="${href}" class="row-hov flex items-start gap-2.5 px-4 py-2.5 border-b border-line/40 last:border-0">
      <span class="mt-1.5 w-1.5 h-1.5 rounded-full ${dot} shrink-0 ${n.wire ? 'live-dot' : ''}"></span>
      <div class="min-w-0 flex-1"><div class="text-[13px] text-slate-200 leading-snug">${n.h}</div>
      <div class="flex items-center gap-2 text-[10px] text-mut mt-0.5">
        <span class="font-medium ${n.wire ? 'text-acc' : 'text-slate-400'}">${F.esc(n.src)}</span> · <span class="num">${F.rel(n.ts)}</span>
        ${it ? `· <span class="text-slate-300">${F.esc(CDX.Data.label(it))}</span>` : ''}</div></div></a>`;
  }
  function paint(){
    D.$('#nwTabs', root).innerHTML = FILTERS.map(([id, l]) =>
      `<button data-nf="${id}" class="text-xs rounded-lg px-2.5 py-1 border ${id === filter ? 'bg-acc/15 border-acc/50 text-white' : 'bg-panel border-line text-mut hover:text-white'}">${l}</button>`).join('');
    let rows = '';
    try { rows = items().map(row).join(''); } catch(e){ rows = ''; }
    D.$('#nwFeed', root).innerHTML = rows || `<div class="px-4 py-10 text-center">
      <div class="text-sm text-mut">No headlines available right now.</div>
      <button data-nw-retry class="mt-3 text-xs rounded-lg px-3 py-1.5 border border-acc/50 text-acc hover:bg-acc/10">Retry</button></div>`;
  }
  return {
    mount(el){
      root = el;
      root.innerHTML = `<div class="space-y-3 max-w-3xl">
        <div class="flex items-center gap-3 flex-wrap">
          <h2 class="font-disp font-semibold text-white text-lg">News</h2>
          <div class="flex gap-1.5" id="nwTabs"></div>
          <span class="ml-auto flex items-center gap-1.5 text-[11px] text-mut"><span class="w-2 h-2 rounded-full bg-down live-dot"></span> curated stream + live event wire</span></div>
        <div class="bg-panel border border-line rounded-xl overflow-hidden" id="nwFeed"></div></div>`;
      paint();
      undelegate = D.delegate(root, {
        '[data-nf]': t => { filter = t.dataset.nf; paint(); },
        '[data-nw-retry]': () => paint()
      });
      subs.push(CDX.Bus.on('news:changed', () => { const h = D.$('#nwFeed', root); if (h) h.innerHTML = items().map(row).join(''); }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; root=null; filter='all'; }
  };
})();

/* /asset/:symbol → resolve a symbol or id to the token page (concrete mount, no fallback) */
CDX.Pages.assetAlias = {
  mount(el, ctx){
    const q = decodeURIComponent(ctx.params.symbol || '').toLowerCase();
    const c = CDX.Data.coins.find(x => x.id === q)
           || CDX.Data.coins.find(x => x.sym.toLowerCase() === q)
           || CDX.Data.coins.find(x => x.name.toLowerCase() === q);
    if (c){ CDX.Router.replace('/token/' + c.id); return; }
    const hit = CDX.Data.search(q, 1)[0];
    if (hit){ CDX.Router.replace(hit.key.startsWith('c:') ? '/token/' + hit.it.id : '/pair/' + hit.it.id); return; }
    el.innerHTML = `<div class="py-16 text-center text-mut text-sm">No asset matches “${CDX.Fmt.esc(q)}”. <a href="#/markets" class="text-acc hover:underline">Browse markets →</a></div>`;
  },
  unmount(){}
};
/* /pair/:chain/:pair → canonical /pair/{chain_address} (id convention: chain + '_' + address) */
CDX.Pages.pairAlias = {
  mount(el, ctx){
    const id = ctx.params.chain + '_' + ctx.params.pair;
    if (CDX.Data.byKey('d:' + id)){ CDX.Router.replace('/pair/' + id); return; }
    const addr = (ctx.params.pair || '').toLowerCase();
    const p = CDX.Data.pairs.find(x => x.chain === ctx.params.chain && x.address.toLowerCase() === addr);
    if (p){ CDX.Router.replace('/pair/' + p.id); return; }
    el.innerHTML = `<div class="py-16 text-center text-mut text-sm">Pool not indexed (yet). <a href="#/dex" class="text-acc hover:underline">Open the screener →</a></div>`;
  },
  unmount(){}
};
/* concrete not-found: no roadmap renderer in production */
CDX.Pages.notFound = {
  mount(el, ctx){
    CDX.UI.toast('Unknown route /' + (ctx.params.path || '') + ' — sent you home.', 'warn');
    CDX.Router.replace('/');
  },
  unmount(){}
};
