/* Page: Institutional Layer — portfolio analytics, attribution, matrices, factors,
   betas, drawdowns, backtesting, trade journal. Route: #/quant */
CDX.Pages.quant = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI, Q = CDX.Quant, S = CDX.Store;
  let subs = [], root = null, undelegate = null;
  let btKey = 'c:btc', btBusy = false, btResult = null;
  const card = (title, sub, body) => `<div class="bg-panel border border-line rounded-xl overflow-hidden">
    <div class="px-4 py-3 border-b border-line"><h3 class="font-disp font-semibold text-white">${title}</h3>
    <div class="text-[10px] text-mut">${sub}</div></div>${body || '<div class="px-4 py-8 text-center text-sm text-mut">Needs coin holdings with price history.</div>'}</div>`;
  const cell = (l, v, sub) => `<div class="bg-panel2 border border-line rounded-lg px-3 py-2">
    <div class="text-[9px] uppercase tracking-wider text-mut">${l}</div>
    <div class="num text-white text-sm font-medium">${v}</div>${sub ? `<div class="text-[9px] text-mut">${sub}</div>` : ''}</div>`;
  const corrColor = v => CDX.Heatmap.colorFor(v * 8, 8);
  function svgCurves(curves, W, H){
    let lo = Infinity, hi = -Infinity;
    for (const c of curves) for (const v of c.pts){ lo = Math.min(lo, v); hi = Math.max(hi, v); }
    const rng = hi - lo || 1;
    const path = pts => pts.map((v, i) => (i ? 'L' : 'M') + (i / (pts.length - 1) * W).toFixed(1) + ',' + (H - 3 - (v - lo) / rng * (H - 6)).toFixed(1)).join('');
    return `<svg viewBox="0 0 ${W} ${H}" class="w-full" style="height:${H}px">${curves.map(c =>
      `<path d="${path(c.pts)}" fill="none" stroke="${c.color}" stroke-width="1.6" stroke-linejoin="round" ${c.dash ? 'stroke-dasharray="4 3"' : ''}/>`).join('')}</svg>`;
  }
  /* ---- sections ---- */
  function vAnalytics(){
    const a = Q.portfolioAnalytics();
    if (!a.stats) return card('Portfolio Analytics', 'value-weighted over coin holdings', null);
    const s = a.stats;
    return card('Portfolio Analytics', `7d hourly series · ${a.coveredPct.toFixed(0)}% of value covered (pairs excluded from series math)`, `
      <div class="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-2.5 p-4">
        ${cell('Value', F.usd(a.totalAll))}
        ${cell('Return 7d', `<span class="${F.cls(s.ret7d)}">${F.pct(s.ret7d, 1)}</span>`)}
        ${cell('Volatility', s.vol.toFixed(0) + '%', 'annualized')}
        ${cell('Sharpe', s.sharpe.toFixed(2), 'rf = 0, ann.')}
        ${cell('Beta vs BTC', a.beta != null ? a.beta.toFixed(2) : '—')}
        ${cell('VaR 95 (1d)', s.var95.toFixed(1) + '%', 'historical')}</div>`);
  }
  function vAttribution(){
    const at = Q.attribution('24h');
    if (!at.rows.length) return card('Performance Attribution', 'weight × return contribution', null);
    const max = Math.max(...at.rows.map(r => Math.abs(r.contrib)), 0.01);
    return card('Performance Attribution', `24h · portfolio contribution ${at.total >= 0 ? '+' : ''}${at.total.toFixed(2)}%`, `
      <div class="p-4 space-y-1.5">${at.rows.slice(0, 7).map(r => `
        <div class="flex items-center gap-2 text-[11px]" data-go="${r.key.startsWith('c:') ? '/token/' + r.it.id : '/pair/' + r.it.id}" style="cursor:pointer">
          <span class="w-14 text-slate-200 font-medium truncate">${F.esc(CDX.Data.label(r.it))}</span>
          <span class="num text-mut w-9">${r.w.toFixed(0)}%w</span>
          <div class="flex-1 h-1.5 bg-line rounded-full overflow-hidden"><div class="h-full ${r.contrib >= 0 ? 'bg-up' : 'bg-down'}" style="width:${Math.abs(r.contrib) / max * 100}%"></div></div>
          <span class="num w-14 text-right ${F.cls(r.contrib)}">${r.contrib >= 0 ? '+' : ''}${r.contrib.toFixed(2)}%</span></div>`).join('')}
      <div class="pt-2 grid grid-cols-2 gap-3 text-[10px]">
        <div><div class="uppercase tracking-wider text-mut mb-1">By narrative</div>${at.byNarrative.slice(0, 3).map(([g, v]) => `<div class="flex justify-between"><span class="text-slate-300">${g}</span><span class="num ${F.cls(v)}">${v >= 0 ? '+' : ''}${v.toFixed(2)}%</span></div>`).join('')}</div>
        <div><div class="uppercase tracking-wider text-mut mb-1">By chain</div>${at.byChain.slice(0, 3).map(([g, v]) => `<div class="flex justify-between"><span class="text-slate-300">${g}</span><span class="num ${F.cls(v)}">${v >= 0 ? '+' : ''}${v.toFixed(2)}%</span></div>`).join('')}</div></div></div>`);
  }
  function vCorr(){
    const cm = Q.corrMatrix();
    if (!cm) return card('Correlation Matrix', '7d hourly returns', null);
    const n = cm.assets.length;
    return card('Correlation Matrix', '7d hourly returns · Pearson', `
      <div class="p-3 overflow-x-auto"><table class="num text-[10px]" style="border-collapse:separate;border-spacing:2px">
        <tr><td></td>${cm.assets.map(a => `<td class="text-mut text-center px-1">${F.esc(a.sym)}</td>`).join('')}</tr>
        ${cm.assets.map((a, i) => `<tr><td class="text-mut pr-1 text-right">${F.esc(a.sym)}</td>
          ${cm.m[i].map((v, j) => `<td class="text-center rounded" style="width:34px;height:24px;background:${i === j ? '#1F2633' : corrColor(v)};color:#fff" title="${a.sym}×${cm.assets[j].sym} = ${v.toFixed(2)}">${i === j ? '—' : v.toFixed(2)}</td>`).join('')}</tr>`).join('')}</table></div>`);
  }
  function vVol(){
    const rows = Q.volMatrix();
    if (!rows.length) return card('Volatility Matrix', 'annualized', null);
    return card('Volatility Matrix', 'annualized σ across windows', `
      <div class="p-3"><table class="w-full num text-[11px]">
        <tr class="text-mut text-[9px] uppercase tracking-wider"><td>Asset</td><td class="text-right">24h</td><td class="text-right">72h</td><td class="text-right">7d</td></tr>
        ${rows.map(({ c, v }) => `<tr class="border-t border-line/40">
          <td class="py-1.5 text-slate-200 font-medium" data-go="/token/${c.id}" style="cursor:pointer">${F.esc(c.sym)}</td>
          ${[v.h24, v.h72, v.d7].map(x => `<td class="text-right ${x > 120 ? 'text-down' : x > 60 ? 'text-gold' : 'text-slate-300'}">${x.toFixed(0)}%</td>`).join('')}</tr>`).join('')}</table></div>`);
  }
  function vFactorsBeta(){
    const fe = Q.factorExposure();
    const bs = Q.betas();
    const fmax = Math.max(...fe.map(f => Math.abs(f.beta)), 1);
    return card('Factor Exposure & Beta', 'univariate exposure betas · 7d hourly', `
      <div class="p-4 space-y-1.5">
        ${fe.length ? fe.map(f => `<div class="flex items-center gap-2 text-[11px]">
          <span class="w-28 text-slate-200">${f.name}</span>
          <div class="flex-1 h-1.5 bg-line rounded-full overflow-hidden"><div class="h-full ${f.beta >= 0 ? 'bg-acc' : 'bg-down'}" style="width:${Math.abs(f.beta) / fmax * 100}%"></div></div>
          <span class="num w-12 text-right text-white">${f.beta.toFixed(2)}</span></div>`).join('')
        : '<div class="text-[11px] text-mut">Portfolio factor exposure needs coin holdings.</div>'}
        <div class="pt-2 text-[10px] uppercase tracking-wider text-mut">Asset beta vs BTC</div>
        <div class="grid grid-cols-2 gap-x-4 gap-y-1">${bs.map(({ c, beta }) => `
          <div class="flex justify-between text-[11px]" data-go="/token/${c.id}" style="cursor:pointer">
            <span class="text-slate-300">${F.esc(c.sym)}</span>
            <span class="num ${beta > 1.4 ? 'text-gold' : 'text-white'}">${beta.toFixed(2)}β</span></div>`).join('')}</div></div>`);
  }
  function vDrawdown(){
    const a = Q.portfolioAnalytics();
    if (!a.stats) return card('Drawdown Analysis', 'portfolio equity vs peak', null);
    const dd = a.stats.dd;
    const worst = Q.volMatrix().map(({ c }) => ({ c, dd: Q.seriesStats(Q.retsOf(c)).dd.maxDD }))
      .sort((x, y) => y.dd - x.dd).slice(0, 4);
    return card('Drawdown Analysis', '7d portfolio equity curve', `
      <div class="p-4">${svgCurves([{ pts: dd.curve, color: '#5B8CFF' }], 320, 70)}
      <div class="grid grid-cols-3 gap-2 mt-2">
        ${cell('Max DD', `<span class="text-down">−${dd.maxDD.toFixed(1)}%</span>`)}
        ${cell('Current DD', `<span class="${dd.currentDD > 1 ? 'text-down' : 'text-up'}">−${dd.currentDD.toFixed(1)}%</span>`)}
        ${cell('Underwater', dd.underHours + 'h', 'longest stretch')}</div>
      <div class="pt-2 text-[10px] uppercase tracking-wider text-mut mb-1">Deepest asset drawdowns (7d)</div>
      ${worst.map(w => `<div class="flex justify-between text-[11px]"><span class="text-slate-300">${F.esc(w.c.sym)}</span><span class="num text-down">−${w.dd.toFixed(1)}%</span></div>`).join('')}</div>`);
  }
  function vBacktest(){
    const it = CDX.Data.byKey(btKey);
    const r = btResult;
    return card('Strategy Backtesting', 'real OHLC · long-only · 0.3% fee per side', `
      <div class="p-4 space-y-3">
        <div class="flex items-center gap-2 flex-wrap">
          <div class="relative"><input data-btq placeholder="Asset…" autocomplete="off" class="qctl w-36">
            <div data-btres class="hidden absolute top-full mt-1 left-0 w-56 bg-panel border border-line rounded-xl shadow-2xl shadow-black/60 z-30 overflow-hidden"></div></div>
          <span class="text-xs text-white font-medium">${it ? F.esc(CDX.Data.label(it)) : '—'}</span>
          <select data-bttf class="qctl"><option value="4H">4H · 30d</option><option value="1D">1D · 180d</option></select>
          <select data-btstrat class="qctl">
            <option value="smacross">SMA Cross 10/30</option>
            <option value="rsi">RSI Reversion 30/70</option>
            <option value="breakout">Breakout 20/10</option></select>
          <button data-btrun class="text-xs bg-acc/15 border border-acc/50 text-white rounded-lg px-3 py-1.5 hover:bg-acc/25" ${btBusy ? 'disabled' : ''}>${btBusy ? 'Running…' : '▶ Run'}</button></div>
        ${r ? `${svgCurves([{ pts: r.bhC, color: '#8B94A7', dash: true }, { pts: r.eqC, color: '#5B8CFF' }], 320, 90)}
          <div class="flex items-center gap-3 text-[9px] text-mut"><span><span class="inline-block w-3 h-0.5 bg-acc align-middle mr-1"></span>strategy</span><span><span class="inline-block w-3 h-0.5 bg-mut align-middle mr-1" style="border-bottom:1px dashed"></span>buy & hold</span><span class="ml-auto">${r.bars} bars</span></div>
          <div class="grid grid-cols-3 gap-2">
            ${cell('Strategy', `<span class="${F.cls(r.ret)}">${F.pct(r.ret, 1)}</span>`, `B&H ${F.pct(r.bhRet, 1)}`)}
            ${cell('Sharpe', r.sharpe.toFixed(2), 'per-bar, ann.')}
            ${cell('Max DD', `<span class="text-down">−${r.maxDD.toFixed(1)}%</span>`)}
            ${cell('Trades', r.trades)}
            ${cell('Win Rate', r.winRate.toFixed(0) + '%')}
            ${cell('Alpha vs B&H', `<span class="${F.cls(r.ret - r.bhRet)}">${F.pct(r.ret - r.bhRet, 1)}</span>`)}</div>`
        : '<div class="text-[11px] text-mut">Pick an asset, timeframe and strategy, then run.</div>'}</div>`);
  }
  function vJournal(){
    const rows = S.state.journal.slice(0, 10);
    return card('Trade Journal', 'simulated trades auto-log · attach a thesis to anything', `
      <div class="px-4 py-2.5 border-b border-line flex items-center gap-2 flex-wrap">
        <div class="relative"><input data-jq placeholder="Asset…" autocomplete="off" class="qctl w-32">
          <div data-jres class="hidden absolute top-full mt-1 left-0 w-56 bg-panel border border-line rounded-xl shadow-2xl shadow-black/60 z-30 overflow-hidden"></div></div>
        <select data-jside class="qctl"><option value="buy">Buy</option><option value="sell">Sell</option></select>
        <input data-jqty placeholder="qty" class="qctl w-20 num">
        <input data-jthesis placeholder="Thesis / setup…" class="qctl flex-1 min-w-[120px]">
        <button data-jadd class="text-xs bg-acc/15 border border-acc/50 text-white rounded-lg px-3 py-1.5 hover:bg-acc/25">+ Log</button></div>
      ${rows.length ? rows.map(e => {
        const it = CDX.Data.byKey(e.key);
        const ret = it && e.side === 'buy' && e.price ? (it.price / e.price - 1) * 100 : null;
        return `<div class="px-4 py-2 border-b border-line/40 last:border-0">
          <div class="flex items-center gap-2 text-[12px] flex-wrap">
            <span class="num text-[10px] font-bold ${e.side === 'buy' ? 'text-up' : 'text-down'}">${e.side.toUpperCase()}</span>
            <span class="text-white font-medium" ${it ? `data-go="${e.key.startsWith('c:') ? '/token/' + it.id : '/pair/' + it.id}" style="cursor:pointer"` : ''}>${it ? F.esc(CDX.Data.label(it)) : e.key}</span>
            <span class="num text-mut">${F.num(e.qty)} @ ${F.price(e.price)}</span>
            ${e.auto ? '<span class="text-[8px] border border-line rounded px-1 text-mut">AUTO</span>' : ''}
            ${ret != null ? `<span class="num ${F.cls(ret)}">${ret >= 0 ? '+' : ''}${ret.toFixed(1)}% since</span>` : ''}
            <span class="ml-auto num text-[10px] text-mut">${F.rel(e.ts)}</span>
            <button data-jdel="${e.id}" class="text-mut hover:text-down">✕</button></div>
          ${e.thesis ? `<div class="text-[11px] text-mut mt-0.5">${F.esc(e.thesis)}</div>` : ''}</div>`;
      }).join('') : '<div class="px-4 py-6 text-center text-sm text-mut">No entries yet — log a trade or use the portfolio trade sim.</div>'}`);
  }
  function bindTypeahead(inputSel, resSel, onPick){
    const q = root.querySelector(inputSel), res = root.querySelector(resSel);
    if (!q) return;
    q.addEventListener('input', () => {
      const v = q.value.trim();
      if (!v){ res.classList.add('hidden'); return; }
      res.innerHTML = CDX.Data.search(v, 6).map(h => `<button data-pick="${h.key}" class="w-full text-left px-3 py-2 hover:bg-panel2 text-xs text-white">${F.esc(CDX.Data.label(h.it))}</button>`).join('');
      res.classList.remove('hidden');
      res.querySelectorAll('[data-pick]').forEach(b => b.addEventListener('mousedown', () => { onPick(b.dataset.pick); res.classList.add('hidden'); q.value = ''; }));
    });
    q.addEventListener('blur', () => setTimeout(() => res.classList.add('hidden'), 160));
  }
  let jKey = 'c:btc';
  function paint(){
    D.$('#qAna', root).innerHTML = vAnalytics();
    D.$('#qAttr', root).innerHTML = vAttribution();
    D.$('#qCorr', root).innerHTML = vCorr();
    D.$('#qVol', root).innerHTML = vVol();
    D.$('#qFac', root).innerHTML = vFactorsBeta();
    D.$('#qDD', root).innerHTML = vDrawdown();
    D.$('#qBT', root).innerHTML = vBacktest();
    D.$('#qJrn', root).innerHTML = vJournal();
    bindTypeahead('[data-btq]', '[data-btres]', k => { btKey = k; btResult = null; paintBT(); });
    bindTypeahead('[data-jq]', '[data-jres]', k => { jKey = k; const el = root.querySelector('[data-jq]'); if (el) el.placeholder = CDX.Data.label(CDX.Data.byKey(k)); });
  }
  function paintBT(){ D.$('#qBT', root).innerHTML = vBacktest(); bindTypeahead('[data-btq]', '[data-btres]', k => { btKey = k; btResult = null; paintBT(); }); }
  return {
    mount(el){
      root = el;
      root.innerHTML = `<div class="space-y-4">
        <div class="flex items-center gap-3 flex-wrap">
          <h2 class="font-disp font-semibold text-white text-lg">Institutional Layer</h2>
          <span class="text-[11px] text-mut">real 7d hourly series + real OHLC backtests · simulated portfolio</span></div>
        <div id="qAna"></div>
        <div class="grid lg:grid-cols-2 xl:grid-cols-3 gap-4">
          <div id="qAttr"></div><div id="qCorr"></div><div id="qVol"></div>
          <div id="qFac"></div><div id="qDD"></div><div id="qBT"></div></div>
        <div id="qJrn"></div>
        <style>.qctl{background:#161B27;border:1px solid #1F2633;border-radius:8px;font-size:12px;padding:6px 10px;color:#E2E8F0}.qctl:focus{outline:none;border-color:#5B8CFF99}</style></div>`;
      paint(); paintBT();
      undelegate = D.delegate(root, {
        '[data-btrun]': async () => {
          if (btBusy) return;
          btBusy = true; paintBT();
          const tf = root.querySelector('[data-bttf]') ? root.querySelector('[data-bttf]').value : '4H';
          const strat = root.querySelector('[data-btstrat]') ? root.querySelector('[data-btstrat]').value : 'smacross';
          const params = { fast: 10, slow: 30, buy: 30, sell: 70, entry: 20, exit: 10 };
          try { btResult = await Q.backtest(btKey, tf, strat, params); }
          catch(e){ U.toast('Backtest failed: ' + e.message, 'warn'); btResult = null; }
          btBusy = false; paintBT();
        },
        '[data-jadd]': () => {
          const qty = parseFloat(root.querySelector('[data-jqty]').value);
          const it = CDX.Data.byKey(jKey);
          if (!it || !(qty > 0)){ U.toast('Pick an asset and quantity.', 'warn'); return; }
          S.saveJournal({ key: jKey, side: root.querySelector('[data-jside]').value, qty,
                          price: it.price, strategy: 'manual', thesis: root.querySelector('[data-jthesis]').value.trim() });
          U.toast('Journal entry logged', 'up');
        },
        '[data-jdel]': t => S.deleteJournal(t.dataset.jdel),
        '[data-go]': t => CDX.Router.go(t.dataset.go)
      });
      subs.push(CDX.Bus.on('journal:changed', () => { D.$('#qJrn', root).innerHTML = vJournal(); bindTypeahead('[data-jq]', '[data-jres]', k => { jKey = k; }); }));
      let n = 0;
      subs.push(CDX.Bus.on('tick', () => { if (++n % 8 === 0){ D.$('#qAna', root).innerHTML = vAnalytics(); D.$('#qAttr', root).innerHTML = vAttribution(); } }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; root=null; btResult=null; btBusy=false; }
  };
})();
