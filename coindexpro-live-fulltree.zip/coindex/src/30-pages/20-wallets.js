/* Page: Wallet Intelligence — leaderboards, top performers, copy-trading dashboard,
   smart money clusters, behavior models. Route: #/wallets */
CDX.Pages.wallets = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI, W = CDX.WalletIntel, IU = CDX.IntelUI;
  let subs = [], root = null, undelegate = null;
  const short = a => a.length > 12 ? a.slice(0, 6) + '…' + a.slice(-4) : a;
  const money = v => (v >= 0 ? '+' : '−') + F.usd(Math.abs(v));
  const holdFmt = m => m == null ? '—' : m < 60 ? m.toFixed(0) + 'm' : (m / 60).toFixed(1) + 'h';
  const wChip = addr => {
    const w = CDX.DataRaw.walletByAddr.get(addr);
    return `<a href="#/wallet/${addr}" class="inline-flex items-center gap-1 text-[11px] bg-panel2 border border-line rounded px-1.5 py-0.5 hover:border-acc/50 text-slate-200">${w ? F.esc(w.label) : short(addr)}</a>`;
  };
  const panel = (title, sub, body) => `<div class="bg-panel border border-line rounded-xl overflow-hidden">
    <div class="px-4 py-3 border-b border-line"><h3 class="font-disp font-semibold text-white">${title}</h3>
    <div class="text-[10px] text-mut">${sub}</div></div>${body || '<div class="px-4 py-8 text-center text-sm text-mut">Waiting for prints…</div>'}</div>`;

  function vLeaderboard(){
    const rows = W.leaderboard().filter(r => r.a.trades >= 2).sort((a, b) => b.rankScore - a.rankScore);
    if (!rows.length) return '';
    return `<div class="overflow-x-auto"><table class="w-full text-sm" style="min-width:1080px">
      <thead class="bg-panel2 text-mut text-[11px] uppercase tracking-wider sticky top-0"><tr class="border-b border-line">
        <th class="px-3 py-2.5 text-left">#</th><th class="px-3 py-2.5 text-left">Wallet</th>
        <th class="px-3 py-2.5 text-left">Archetype</th><th class="px-3 py-2.5 text-right">Observed PnL</th>
        <th class="px-3 py-2.5 text-right">Realized</th><th class="px-3 py-2.5 text-right">Unrealized</th>
        <th class="px-3 py-2.5 text-right">Win Rate</th><th class="px-3 py-2.5 text-right">Avg Hold</th>
        <th class="px-3 py-2.5 text-right">Avg Size</th><th class="px-3 py-2.5 text-right">Prints</th>
        <th class="px-3 py-2.5 text-right">Volume</th></tr></thead>
      <tbody class="divide-y divide-line/60">${rows.map((r, i) => `
        <tr class="row-hov ${i % 2 ? 'bg-white/[0.015]' : ''}" data-go="/wallet/${r.addr}" style="cursor:pointer">
          <td class="px-3 py-2 text-mut text-xs num">${i + 1}</td>
          <td class="px-3 py-2"><div class="flex items-center gap-2">
            <span class="text-sm font-medium text-white">${F.esc(r.label)}</span>${IU.typeBadge(r.type)}</div>
            <div class="num text-[10px] text-mut">${short(r.addr)}</div></td>
          <td class="px-3 py-2"><span class="text-[10px] font-bold uppercase tracking-wider border border-acc/40 text-acc bg-acc/10 rounded px-1.5 py-0.5">${r.b.archetype}</span></td>
          <td class="px-3 py-2 text-right num font-semibold ${r.a.totalPnl >= 0 ? 'text-up' : 'text-down'}">${money(r.a.totalPnl)}</td>
          <td class="px-3 py-2 text-right num ${r.a.realized >= 0 ? 'text-up' : 'text-down'}">${money(r.a.realized)}</td>
          <td class="px-3 py-2 text-right num ${r.a.unrealized >= 0 ? 'text-up' : 'text-down'}">${money(r.a.unrealized)}</td>
          <td class="px-3 py-2 text-right num text-slate-300">${r.a.winRate != null ? r.a.winRate.toFixed(0) + '%' : '—'}${r.a.winRateExits != null ? `<div class="text-[9px] text-mut">${r.a.winRateExits.toFixed(0)}% exits · cov ${r.a.coverage.toFixed(0)}%</div>` : ''}</td>
          <td class="px-3 py-2 text-right num text-mut">${holdFmt(r.a.avgHoldMin)}</td>
          <td class="px-3 py-2 text-right num text-mut">${F.usd(r.a.avgSize)}</td>
          <td class="px-3 py-2 text-right num text-mut">${r.a.trades}</td>
          <td class="px-3 py-2 text-right num text-slate-300">${F.usd(r.a.volume)}</td></tr>`).join('')}</tbody></table></div>`;
  }
  function vPerformers(){
    return W.topPerformers(3).map((r, i) => `
      <div class="bg-panel border ${i === 0 ? 'border-gold/50' : 'border-line'} rounded-xl p-4" data-go="/wallet/${r.addr}" style="cursor:pointer">
        <div class="flex items-center gap-2 mb-2">
          <span class="text-lg">${['🥇','🥈','🥉'][i]}</span>
          <div><div class="text-sm font-semibold text-white">${F.esc(r.label)}</div>
          <div class="text-[10px] text-mut">${r.b.archetype} · ${r.a.trades} prints</div></div>
          <span class="ml-auto num font-disp font-bold text-xl ${r.m.ret >= 0 ? 'text-up' : 'text-down'}">${r.m.ret >= 0 ? '+' : ''}${r.m.ret.toFixed(1)}%</span></div>
        <div class="text-[11px] text-mut">mirror return · best entry ${r.m.best && r.m.best.t ? `<span class="num ${r.m.best.ret >= 0 ? 'text-up' : 'text-down'}">${r.m.best.ret >= 0 ? '+' : ''}${r.m.best.ret.toFixed(1)}%</span>` : '—'}
          · win ${r.a.winRate != null ? r.a.winRate.toFixed(0) + '%' : '—'}</div></div>`).join('')
      || '<div class="lg:col-span-3 bg-panel border border-line rounded-xl px-4 py-8 text-center text-sm text-mut">Performance ranks unlock after enough prints land.</div>';
  }
  function vSignals(){
    const feed = W.signalFeed(10);
    if (!feed.length) return '';
    return feed.map(({ t, p, ret }) => `<div class="row-hov flex items-center gap-3 px-4 py-2 border-b border-line/40 last:border-0" data-go="${p ? '/pair/' + p.id : ''}" style="cursor:pointer">
      <span class="num text-[10px] text-mut w-12 shrink-0">${F.rel(t.ts)}</span>
      ${p ? U.logo(p.base, CDX.Data.CHAINS[p.chain].color, 5) : ''}
      <div class="min-w-0"><div class="text-sm font-medium text-white leading-tight">${p ? F.esc(p.base) + '<span class="text-mut font-normal">/' + F.esc(p.quote) + '</span>' : t.pairId}</div>
      <div class="text-[10px] text-mut">${wChip(t.wallet)} entered @ <span class="num">${F.price(t.price)}</span></div></div>
      <span class="ml-auto text-right shrink-0">
        <div class="num text-xs text-slate-300">${F.usd(t.usd)}</div>
        <div class="num text-sm font-semibold ${ret >= 0 ? 'text-up' : 'text-down'}">${ret >= 0 ? '+' : ''}${ret.toFixed(1)}% since</div></span></div>`).join('');
  }
  function vClusters(){
    const cs = W.clusters(2).slice(0, 5);
    if (!cs.length) return '';
    return cs.map((c, i) => `<div class="px-4 py-3 border-b border-line/40 last:border-0">
      <div class="flex items-center gap-2 flex-wrap mb-1.5">
        <span class="text-[10px] font-bold uppercase tracking-wider text-acc">Cluster ${i + 1}</span>
        <span class="text-[10px] text-mut">${c.wallets.length} wallets · ${c.pairs.length} pools · cohesion ${c.cohesion} · ${F.rel(c.lastTs)}</span>
        <span class="ml-auto num text-sm font-semibold ${c.net >= 0 ? 'text-up' : 'text-down'}">${money(c.net)} net</span></div>
      <div class="flex items-center gap-1.5 flex-wrap">${c.wallets.slice(0, 4).map(wChip).join('')}${c.wallets.length > 4 ? `<span class="text-[10px] text-mut">+${c.wallets.length - 4}</span>` : ''}</div>
      <div class="flex items-center gap-1.5 flex-wrap mt-1.5">${c.pairs.slice(0, 4).map(id => {
        const p = CDX.Data.byKey('d:' + id);
        return p ? `<a href="#/pair/${p.id}" class="num text-[10px] border border-line rounded px-1.5 py-0.5 text-slate-300 hover:border-acc/50">${F.esc(p.base)}/${F.esc(p.quote)}</a>` : '';
      }).join('')}</div></div>`).join('');
  }
  function vBehavior(){
    const rows = W.leaderboard().sort((a, b) => b.a.volume - a.a.volume).slice(0, 4);
    if (!rows.length) return '';
    return rows.map(r => `<div class="px-4 py-3 border-b border-line/40 last:border-0" data-go="/wallet/${r.addr}" style="cursor:pointer">
      <div class="flex items-center gap-2 mb-2">
        <span class="text-sm font-medium text-white">${F.esc(r.label)}</span>
        <span class="text-[10px] font-bold uppercase tracking-wider border border-acc/40 text-acc bg-acc/10 rounded px-1.5 py-0.5">${r.b.archetype}</span>
        <span class="ml-auto text-[10px] text-mut num">rotation ${(r.a.rotationRate * 100).toFixed(0)}% · top pos ${r.a.concentration.toFixed(0)}%</span></div>
      <div class="grid grid-cols-4 gap-2">${r.b.traits.map(([l, v]) => `
        <div><div class="flex justify-between text-[9px] text-mut mb-0.5"><span>${l}</span><span class="num">${v}</span></div>
        <div class="h-1 bg-line rounded-full overflow-hidden"><div class="h-full bg-acc rounded-full" style="width:${v}%"></div></div></div>`).join('')}</div></div>`).join('');
  }
  function paint(){
    D.$('#wiPerf', root).innerHTML = vPerformers();
    D.$('#wiBoard', root).innerHTML = panel('Wallet Leaderboard', 'session-observed PnL from real prints · FIFO lot matching · marked to live prices', vLeaderboard());
    D.$('#wiSignals', root).innerHTML = panel('Copy-Trading Feed', 'latest qualified entries · live Δ since wallet entry', vSignals());
    D.$('#wiClusters', root).innerHTML = panel('Smart Money Clusters', 'wallets co-trading the same pools', vClusters());
    D.$('#wiBehavior', root).innerHTML = panel('Behavior Models', 'trait scoring across the most active wallets', vBehavior());
  }
  return {
    mount(el){
      root = el;
      root.innerHTML = `<div class="space-y-4">
        <div class="flex items-center gap-3 flex-wrap">
          <h2 class="font-disp font-semibold text-white text-lg">Wallet Intelligence</h2>
          <span class="flex items-center gap-1.5 text-[11px] text-mut"><span class="w-2 h-2 rounded-full bg-down live-dot"></span> live print ledger</span>
          <a href="#/whales" class="ml-auto text-xs text-acc hover:underline">Whale feed →</a></div>
        <div class="grid lg:grid-cols-3 gap-4" id="wiPerf"></div>
        <div id="wiBoard"></div>
        <div class="grid lg:grid-cols-3 gap-4">
          <div id="wiSignals"></div><div id="wiClusters"></div><div id="wiBehavior"></div></div></div>`;
      paint();
      undelegate = D.delegate(root, { '[data-go]': t => { if (t.dataset.go) CDX.Router.go(t.dataset.go); } });
      let n = 0;
      subs.push(CDX.Bus.on('tick', () => { if (++n % 5 === 0) paint(); }));
      subs.push(CDX.Bus.on('whale:new', () => paint()));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; root=null; }
  };
})();
