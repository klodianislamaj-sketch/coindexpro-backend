/* Page: Markets — terminal-density ranked table: dominance + supply visuals, sector/chain
   tags, expandable metadata rows, responsive column budget. Route: #/markets[?f=gainers] */
CDX.Pages.markets = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI;
  let subs = [], root = null, table = null, undelegate = null, onExpand = null, page = 0, totMcap = 1;
  const PER = 25;
  const PILLS = [['all','All'],['gainers','Gainers'],['losers','Losers'],['large','&gt; $1B'],
    ['meme','Memecoins'],['ai','AI'],['defi','DeFi'],['rwa','RWA'],['gaming','Gaming'],['pulsechain','◆ Pulse']];
  const hasTag = (c, t) => (c.tags || []).includes(t);
  /* computed sort accessors for virtual columns */
  const ACC = {
    volMcap:   c => c.mcap ? c.vol / c.mcap : 0,
    supplyPct: c => c.maxSupply ? c.supply / c.maxSupply : 1.000001,
    name:      c => c.name
  };
  function filtered(){
    const p = CDX.Store.state.prefs;
    let list = CDX.Data.coins.filter(c => {
      switch (p.marketFilter){
        case 'gainers': return c.ch24 > 0;
        case 'losers':  return c.ch24 < 0;
        case 'large':   return c.mcap >= 1e9;
        case 'meme':    return c.cat === 'meme' || hasTag(c, 'memecoins');
        case 'ai': case 'defi': case 'rwa': case 'gaming': case 'pulsechain': return hasTag(c, p.marketFilter);
        default: return true;
      }
    });
    const { key, dir } = p.marketSort;
    const get = ACC[key] || (c => c[key]);
    list.sort((a, b) => {
      const x = get(a), y = get(b);
      return (typeof x === 'string' ? x.localeCompare(y) : ((x ?? -Infinity) - (y ?? -Infinity))) * dir;
    });
    return list;
  }
  const tagChips = (c, n) => (c.tags || []).slice(0, n).map(t => {
    const nr = CDX.DataRaw.NARRATIVES[t];
    return nr ? `<span class="text-[8.5px] font-bold uppercase tracking-wide rounded px-1 py-px border align-middle" style="color:${nr.color};border-color:${nr.color}55">${nr.name}</span>` : '';
  }).join(' ');
  const bar = (pct, color, w) => `<div class="h-[3px] ${w || 'w-20'} ml-auto bg-line rounded-full mt-1 overflow-hidden"><div class="h-full rounded-full" style="width:${Math.min(100, pct).toFixed(1)}%;background:${color}"></div></div>`;
  const pctLive = (id, field, v) => `<span class="num ${F.cls(v)}" data-live="${field}:${id}">${F.pct(v)}</span>`;

  const columns = [
    { key:'star', label:'', width:'34px', align:'center', render:c=>U.star('c:'+c.id) },
    { key:'rank', label:'#', sortable:true, width:'40px', render:c=>`<span class="text-mut text-[11px] num">${c.rank}</span>` },
    { key:'name', label:'Coin', sortable:true, render:c=>`<div class="flex items-center gap-2 leading-tight">${U.logo(c.sym, c.color, 6)}
        <div class="min-w-0"><div class="truncate"><span class="font-medium text-white text-[13px]">${F.esc(c.sym)}</span>
          <span class="text-mut text-[11px] ml-1.5">${F.esc(c.name)}</span></div>
        <div class="mt-0.5 flex items-center gap-1">${tagChips(c, 2)}${c.chain === 'pulsechain' ? U.chainBadge('pulsechain') : ''}</div></div></div>` },
    { key:'price', label:'Price', sortable:true, align:'right', render:c=>`<span class="num text-white text-[12.5px]" data-live="px:${c.id}">${F.price(c.price)}</span>` },
    { key:'ch1h', label:'1h', sortable:true, align:'right', cls:'hidden sm:table-cell', render:c=>pctLive(c.id, 'c1', c.ch1h) },
    { key:'ch24', label:'24h', sortable:true, align:'right', render:c=>pctLive(c.id, 'c24', c.ch24) },
    { key:'ch7d', label:'7d', sortable:true, align:'right', cls:'hidden md:table-cell', render:c=>`<span class="num ${F.cls(c.ch7d)}">${F.pct(c.ch7d)}</span>` },
    { key:'mcap', label:'Market Cap · Dom', sortable:true, align:'right', render:c=>{
        const dom = c.mcap / totMcap * 100;
        const dil = c.fdv > 0 ? c.mcap / c.fdv * 100 : null;
        return `<span class="num text-slate-300 text-[12px]">${F.usd(c.mcap)}</span>
          <span class="num text-[9.5px] text-mut ml-1">${dom >= 0.01 ? dom.toFixed(dom >= 1 ? 1 : 2) + '%' : '<0.01%'}</span>
          ${bar(Math.max(dom, 0.4), '#5B8CFF99', 'w-24')}
          ${dil != null && dil < 99.5 ? `<div class="flex items-center gap-1 justify-end mt-0.5"><span class="num text-[8.5px] text-mut">FDV ${F.usd(c.fdv)}</span>${bar(dil, dil < 50 ? '#F5C04EAA' : '#8B94A777', 'w-14')}<span class="num text-[8.5px] ${dil < 50 ? 'text-gold' : 'text-mut'}">${dil.toFixed(0)}%</span></div>` : ''}`; } },
    { key:'vol', label:'Volume 24h', sortable:true, align:'right', render:c=>{
        const r = c.mcap ? c.vol / c.mcap * 100 : null;
        return `<span class="num text-slate-300 text-[12px]">${F.usd(c.vol)}</span>
          ${r != null ? `<div class="flex items-center gap-1 justify-end">${bar(Math.min(r * 2.5, 100), r >= 20 ? '#F5C04EAA' : '#46C2CB88', 'w-14')}<span class="num text-[8.5px] ${r >= 20 ? 'text-gold' : 'text-mut'}">${r.toFixed(1)}%</span></div>` : ''}`; } },
    { key:'supplyPct', label:'Circ. Supply', sortable:true, align:'right', cls:'hidden lg:table-cell', render:c=>{
        const pct = c.maxSupply ? Math.min(100, c.supply / c.maxSupply * 100) : null;
        return `<span class="num text-mut text-[12px]">${F.num(c.supply)} <span class="text-[9.5px]">${F.esc(c.sym)}</span></span>
          ${pct != null ? `<div class="flex items-center gap-1.5 justify-end">${bar(pct, pct > 92 ? '#2DD480AA' : '#8B94A7AA')}<span class="num text-[9px] text-mut">${pct.toFixed(0)}%</span></div>`
                        : '<div class="num text-[9px] text-mut mt-0.5">∞ no max</div>'}`; } },
    { key:'athCh', label:'ATH Δ', sortable:true, align:'right', cls:'hidden xl:table-cell', render:c=>c.athCh != null
        ? `<span class="num text-[11px] ${c.athCh > -10 ? 'text-up' : 'text-mut'}">${c.athCh.toFixed(1)}%</span>` : '<span class="text-mut">—</span>' },
    { key:'spark', label:'Last 7d', align:'right', cls:'hidden sm:table-cell', render:c=>U.sparkline('sp'+c.id, c.ch7d, 96, 24) },
    { key:'x', label:'', width:'30px', align:'center', render:c=>`<button data-x="${c.id}" class="text-mut hover:text-white text-[11px] px-1" title="Details">▾</button>` }
  ];
  /* expandable metadata row */
  function detailHtml(c){
    const cell = (l, v, sub) => `<div class="bg-panel border border-line rounded-lg px-2.5 py-1.5">
      <div class="text-[8.5px] uppercase tracking-wider text-mut">${l}</div>
      <div class="num text-white text-[12px]">${v}</div>${sub ? `<div class="text-[9px] text-mut num">${sub}</div>` : ''}</div>`;
    const pools = CDX.Data.pairsForToken(c).slice(0, 3);
    return `<div class="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-2 mb-2.5">
      ${cell('ATH', c.ath != null ? F.price(c.ath) : '—', c.athDate ? new Date(c.athDate).toLocaleDateString() + ' · ' + (c.athCh != null ? c.athCh.toFixed(0) + '%' : '') : '')}
      ${cell('ATL', c.atl != null ? F.price(c.atl) : '—', c.atlDate ? new Date(c.atlDate).toLocaleDateString() : '')}
      ${cell('FDV', F.usd(c.fdv))}
      ${cell('Vol / MCap', c.mcap ? (c.vol / c.mcap * 100).toFixed(1) + '%' : '—')}
      ${cell('Total Supply', c.totalSupply ? F.num(c.totalSupply) : '—', c.maxSupply ? 'max ' + F.num(c.maxSupply) : 'no max')}
      ${cell('Dominance', (c.mcap / totMcap * 100).toFixed(2) + '%')}</div>
    <div class="flex items-center gap-1.5 flex-wrap">
      ${tagChips(c, 6)}
      ${pools.map(p => `<a href="#/pair/${p.id}" class="inline-flex items-center gap-1 text-[10px] border border-line rounded px-1.5 py-0.5 text-slate-300 hover:border-acc/50">${U.chainBadge(p.chain)} ${F.esc(p.dex)} · Liq ${F.usd(p.liq)}</a>`).join('')}
      <a href="#/token/${c.id}" class="ml-auto text-[11px] text-acc hover:underline">Open ${F.esc(c.sym)} →</a></div>`;
  }
  function pillsHtml(){
    const cur = CDX.Store.state.prefs.marketFilter;
    return PILLS.map(([id,label]) =>
      `<button data-pill="${id}" class="text-xs rounded-lg px-2.5 py-1 border transition-colors ${id===cur ? 'bg-acc/15 border-acc/50 text-white' : 'bg-panel border-line text-mut hover:text-white hover:border-acc/40'}">${label}</button>`).join('');
  }
  function refresh(){
    totMcap = CDX.Data.coins.reduce((a, c) => a + (c.mcap || 0), 0) || 1;
    const all = filtered();
    const pages = Math.max(1, Math.ceil(all.length / PER));
    page = Math.min(page, pages - 1);
    const rows = all.slice(page * PER, page * PER + PER);
    table.setRows(rows);
    D.$('#mCount', root).textContent = all.length ? `${page*PER+1}–${page*PER+rows.length} of ${all.length} assets` : '0 assets';
    const pager = D.$('#mPager', root);
    const win = [];
    for (let i = 0; i < pages; i++) if (i < 2 || i >= pages - 2 || Math.abs(i - page) <= 2) win.push(i);
    const btns = [];
    let last = -1;
    for (const i of win){
      if (i - last > 1) btns.push('<span class="text-mut px-1">…</span>');
      btns.push(`<button data-pg="${i}" class="px-2.5 py-1 rounded-md border ${i===page?'border-acc/50 bg-acc/15 text-white':'border-line text-mut hover:text-white'}">${i+1}</button>`);
      last = i;
    }
    pager.innerHTML = pages > 1 ? `
      <button data-pg="prev" class="px-2 py-1 rounded-md border border-line text-mut hover:text-white disabled:opacity-30" ${page===0?'disabled':''}>‹</button>
      ${btns.join('')}
      <button data-pg="next" class="px-2 py-1 rounded-md border border-line text-mut hover:text-white disabled:opacity-30" ${page===pages-1?'disabled':''}>›</button>` : '';
  }
  return {
    mount(el, ctx){
      root = el;
      if (ctx.query.f) CDX.Store.setPref('marketFilter', ctx.query.f);
      root.innerHTML = `<div class="space-y-3">
        <div class="flex flex-wrap items-center gap-2">
          <h2 class="font-disp font-semibold text-white text-lg mr-2">Markets</h2>
          <div class="flex flex-wrap gap-1.5" id="mPills">${pillsHtml()}</div>
          <span class="ml-auto text-xs text-mut" id="mCount"></span>
        </div><div id="mTable"></div>
        <div class="flex items-center justify-center gap-1.5 text-xs flex-wrap" id="mPager"></div></div>`;
      table = U.table({
        columns, rows: [], minWidth:'1380px', maxH:'76vh', dense: true, pad: 'px-2.5 py-[7px]',
        sort: CDX.Store.state.prefs.marketSort,
        onSort: s => { page = 0; CDX.Store.setPref('marketSort', s); refresh(); },
        rowAttr: c => `data-go="/token/${c.id}" data-cid="${c.id}" style="cursor:pointer"`
      });
      D.$('#mTable', root).appendChild(table.el);
      refresh();
      /* expandable rows: capture-phase so row navigation never fires */
      onExpand = e => {
        const x = e.target.closest('[data-x]');
        if (!x || !root.contains(x)) return;
        e.preventDefault(); e.stopPropagation();
        const tr = x.closest('tr');
        const open = tr.nextElementSibling && tr.nextElementSibling.hasAttribute('data-xrow');
        root.querySelectorAll('[data-xrow]').forEach(n => n.remove());
        root.querySelectorAll('[data-x]').forEach(b => b.textContent = '▾');
        if (open) return;
        const c = CDX.Data.byKey('c:' + x.dataset.x);
        if (!c) return;
        x.textContent = '▴';
        tr.insertAdjacentHTML('afterend',
          `<tr data-xrow><td colspan="${columns.length}" class="px-4 py-3 bg-panel2/50 border-y border-line/60">${detailHtml(c)}</td></tr>`);
      };
      document.addEventListener('click', onExpand, true);
      undelegate = D.delegate(root, {
        '[data-star]': () => {},
        '[data-pill]': t => { page = 0; CDX.Store.setPref('marketFilter', t.dataset.pill); D.$('#mPills', root).innerHTML = pillsHtml(); refresh(); },
        '[data-pg]': t => {
          const v = t.dataset.pg;
          page = v === 'prev' ? page - 1 : v === 'next' ? page + 1 : +v;
          refresh();
          D.$('#mTable', root).scrollIntoView({ block: 'start', behavior: 'smooth' });
        },
        '[data-go]':   t => CDX.Router.go(t.dataset.go)
      });
      subs.push(CDX.Bus.on('tick', changed => {
        const updates = {};
        for (const { key, dir } of changed){
          if (!key.startsWith('c:')) continue;
          const c = CDX.Data.byKey(key);
          updates['px:' + c.id]  = { html: F.price(c.price), dir };
          updates['c1:' + c.id]  = { html: F.pct(c.ch1h), dir: 0 };
          updates['c24:' + c.id] = { html: F.pct(c.ch24), dir: 0 };
        }
        table.patch(updates);
        for (const id of Object.keys(updates)){
          const m = /^(c1|c24):(.+)$/.exec(id);
          if (!m) continue;
          const node = table.body.querySelector(`[data-live="${id}"]`);
          const c = CDX.Data.byKey('c:' + m[2]);
          if (node && c) node.className = 'num ' + F.cls(m[1] === 'c1' ? c.ch1h : c.ch24);
        }
      }));
    },
    unmount(){
      subs.forEach(u=>u()); subs=[];
      if (undelegate) undelegate(); undelegate=null;
      if (onExpand) document.removeEventListener('click', onExpand, true); onExpand=null;
      table=null; root=null;
    }
  };
})();
