/* Page: Advanced Screener — multi-condition filtering, column picker, saved screeners. Route: #/screener */
CDX.Pages.screener = (() => {
  const D = CDX.Dom, F = CDX.Fmt, U = CDX.UI;
  let subs = [], root = null, undelegate = null, table = null;

  const FIELDS = {
    coins: {
      price:{ label:'Price ($)', get:c=>c.price }, mcap:{ label:'Market Cap ($)', get:c=>c.mcap },
      vol:{ label:'Volume 24h ($)', get:c=>c.vol }, ch1h:{ label:'1h %', get:c=>c.ch1h },
      ch24:{ label:'24h %', get:c=>c.ch24 }, ch7d:{ label:'7d %', get:c=>c.ch7d },
      volMcap:{ label:'Vol / MCap %', get:c=>c.vol/c.mcap*100 }
    },
    pairs: {
      price:{ label:'Price ($)', get:p=>p.price }, liq:{ label:'Liquidity ($)', get:p=>p.liq },
      vol:{ label:'Volume 24h ($)', get:p=>p.vol }, ch24:{ label:'24h %', get:p=>p.ch.h24 },
      volLiq:{ label:'Vol / Liq ×', get:p=>p.vol/p.liq }, ageH:{ label:'Age (hours)', get:p=>p.ageH },
      buyRatio:{ label:'Buy ratio %', get:p=>p.buys/(p.buys+p.sells)*100 }
    }
  };
  const COLS = {
    coins: {
      name:{ label:'Coin', def:1, col:{ key:'name', label:'Coin', render:c=>`<div class="flex items-center gap-2.5">${U.logo(c.sym,c.color)}<div><span class="font-medium text-white">${F.esc(c.name)}</span><span class="text-mut text-xs ml-1.5">${F.esc(c.sym)}</span></div></div>` } },
      price:{ label:'Price', def:1, col:{ key:'price', label:'Price', sortable:1, align:'right', render:c=>`<span class="num text-white">${F.price(c.price)}</span>` } },
      ch24:{ label:'24h %', def:1, col:{ key:'ch24', label:'24h %', sortable:1, align:'right', render:c=>`<span class="num ${F.cls(c.ch24)}">${F.pct(c.ch24)}</span>` } },
      ch7d:{ label:'7d %', def:1, col:{ key:'ch7d', label:'7d %', sortable:1, align:'right', render:c=>`<span class="num ${F.cls(c.ch7d)}">${F.pct(c.ch7d)}</span>` } },
      mcap:{ label:'Market Cap', def:1, col:{ key:'mcap', label:'Market Cap', sortable:1, align:'right', render:c=>`<span class="num text-slate-300">${F.usd(c.mcap)}</span>` } },
      vol:{ label:'Volume', def:1, col:{ key:'vol', label:'Volume 24h', sortable:1, align:'right', render:c=>`<span class="num text-slate-300">${F.usd(c.vol)}</span>` } },
      volMcap:{ label:'Vol/MCap', def:0, col:{ key:'volMcap', label:'Vol/MCap', align:'right', render:c=>`<span class="num text-mut">${(c.vol/c.mcap*100).toFixed(1)}%</span>` } },
      supply:{ label:'Supply', def:0, col:{ key:'supply', label:'Supply', sortable:1, align:'right', render:c=>`<span class="num text-mut">${F.num(c.supply)}</span>` } },
      fdv:{ label:'FDV', def:0, col:{ key:'fdv', label:'FDV', sortable:1, align:'right', render:c=>`<span class="num text-mut">${F.usd(c.fdv)}</span>` } },
      spark:{ label:'7d Chart', def:1, col:{ key:'spark', label:'Last 7 Days', align:'right', render:c=>U.sparkline('sc'+c.id, c.ch7d, 90, 28) } },
      star:{ label:'★', def:1, col:{ key:'star', label:'', width:'40px', align:'center', render:c=>U.star('c:'+c.id) } }
    },
    pairs: {
      pair:{ label:'Pair', def:1, col:{ key:'pair', label:'Pair', render:p=>`<div class="flex items-center gap-2.5">${U.logo(p.base, CDX.Data.CHAINS[p.chain].color)}<div><div class="font-medium text-white">${F.esc(p.base)}<span class="text-mut font-normal">/${F.esc(p.quote)}</span>${p.ageH<=48?U.badge('NEW','up'):''}</div><div class="text-[11px] text-mut">${F.esc(p.dex)}</div></div></div>` } },
      chain:{ label:'Chain', def:1, col:{ key:'chain', label:'Chain', render:p=>U.chainBadge(p.chain) } },
      price:{ label:'Price', def:1, col:{ key:'price', label:'Price', sortable:1, align:'right', render:p=>`<span class="num text-white">${F.price(p.price)}</span>` } },
      ch24:{ label:'24h %', def:1, col:{ key:'ch24', label:'24h %', align:'right', render:p=>`<span class="num ${F.cls(p.ch.h24)}">${F.pctAuto(p.ch.h24)}</span>` } },
      liq:{ label:'Liquidity', def:1, col:{ key:'liq', label:'Liquidity', sortable:1, align:'right', render:p=>`<span class="num text-slate-300">${F.usd(p.liq)}</span>` } },
      vol:{ label:'Volume', def:1, col:{ key:'vol', label:'Volume 24h', sortable:1, align:'right', render:p=>`<span class="num text-slate-300">${F.usd(p.vol)}</span>` } },
      volLiq:{ label:'Vol/Liq', def:0, col:{ key:'volLiq', label:'Vol/Liq', align:'right', render:p=>`<span class="num ${p.vol/p.liq>2?'text-gold':'text-mut'}">${(p.vol/p.liq).toFixed(2)}×</span>` } },
      bs:{ label:'Buys/Sells', def:1, col:{ key:'bs', label:'Buys / Sells', align:'right', render:p=>`<span class="num"><span class="text-up">${F.num(p.buys)}</span><span class="text-mut"> / </span><span class="text-down">${F.num(p.sells)}</span></span>` } },
      age:{ label:'Age', def:1, col:{ key:'age', label:'Age', align:'right', render:p=>`<span class="num text-mut">${F.age(p.ageH)}</span>` } },
      fdv:{ label:'FDV', def:0, col:{ key:'fdv', label:'FDV', sortable:1, align:'right', render:p=>`<span class="num text-mut">${F.usd(p.fdv)}</span>` } },
      star:{ label:'★', def:1, col:{ key:'star', label:'', width:'40px', align:'center', render:p=>U.star('d:'+p.id) } }
    }
  };
  const defCols = mode => Object.keys(COLS[mode]).filter(k => COLS[mode][k].def);
  let cfg = null;
  const freshCfg = () => ({ id:null, name:'', mode:'pairs', chain:'any', narrative:'any',
                            conds:[{ field:'vol', op:'>', val:'1m' }], cols: defCols('pairs') });
  function parseNum(s){
    if (typeof s === 'number') return s;
    const m = String(s).trim().toLowerCase().match(/^(-?[\d.]+)\s*([kmbt]?)$/);
    if (!m) return NaN;
    return parseFloat(m[1]) * ({ k:1e3, m:1e6, b:1e9, t:1e12, '':1 })[m[2]];
  }
  function run(){
    const isCoin = cfg.mode === 'coins';
    let rows = isCoin ? [...CDX.Data.coins] : [...CDX.Data.pairs];
    if (cfg.chain !== 'any') rows = rows.filter(r => r.chain === cfg.chain);
    if (cfg.narrative !== 'any') rows = rows.filter(r => (r.tags||[]).includes(cfg.narrative));
    for (const c of cfg.conds){
      const f = FIELDS[cfg.mode][c.field];
      const v = parseNum(c.val);
      if (!f || isNaN(v)) continue;
      rows = rows.filter(r => c.op === '>' ? f.get(r) > v : f.get(r) < v);
    }
    return rows;
  }
  function condRow(c, i){
    const fields = FIELDS[cfg.mode];
    return `<div class="flex items-center gap-2 flex-wrap">
      <select data-cf="${i}" class="ctl">${Object.keys(fields).map(k=>`<option value="${k}" ${k===c.field?'selected':''}>${fields[k].label}</option>`).join('')}</select>
      <select data-co="${i}" class="ctl w-16">${['>','<'].map(o=>`<option ${o===c.op?'selected':''}>${o}</option>`).join('')}</select>
      <input data-cv="${i}" value="${F.esc(c.val)}" placeholder="e.g. 1m, 500k, 5" class="ctl w-28 num">
      <button data-cx="${i}" class="text-mut hover:text-down text-sm px-1" title="Remove">✕</button></div>`;
  }
  function controls(){
    return `<div class="bg-panel border border-line rounded-xl p-4 space-y-3">
      <div class="flex items-center gap-2 flex-wrap">
        <div class="flex items-center bg-panel2 border border-line rounded-lg p-0.5 text-xs">
          <button data-mode="pairs" class="px-3 py-1 rounded-md ${cfg.mode==='pairs'?'seg-active':'text-mut'}">DEX Pairs</button>
          <button data-mode="coins" class="px-3 py-1 rounded-md ${cfg.mode==='coins'?'seg-active':'text-mut'}">Coins</button></div>
        <select data-chain class="ctl"><option value="any">Any chain</option>
          ${CDX.Data.CHAIN_ORDER.map(c=>`<option value="${c}" ${cfg.chain===c?'selected':''}>${CDX.Data.CHAINS[c].name}</option>`).join('')}</select>
        <select data-narr class="ctl"><option value="any">Any narrative</option>
          ${CDX.DataRaw.NARRATIVE_ORDER.map(n=>`<option value="${n}" ${cfg.narrative===n?'selected':''}>${CDX.DataRaw.NARRATIVES[n].name}</option>`).join('')}</select>
        <div class="relative ml-auto">
          <button data-colbtn class="ctl">Columns ▾</button>
          <div data-colmenu class="hidden absolute right-0 top-full mt-1 bg-panel border border-line rounded-xl shadow-2xl shadow-black/60 p-3 z-30 w-44 space-y-1.5">
            ${Object.keys(COLS[cfg.mode]).map(k=>`<label class="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
              <input type="checkbox" data-colk="${k}" ${cfg.cols.includes(k)?'checked':''} class="accent-acc w-3.5 h-3.5">${COLS[cfg.mode][k].label}</label>`).join('')}</div></div></div>
      <div class="space-y-2" id="scConds">${cfg.conds.map(condRow).join('')}</div>
      <div class="flex items-center gap-2 flex-wrap">
        <button data-addcond class="text-xs text-acc hover:underline">+ Add condition</button>
        <span class="flex-1"></span>
        <input data-scname value="${F.esc(cfg.name)}" placeholder="Screener name…" class="ctl w-44">
        <button data-save class="text-xs bg-acc/15 border border-acc/50 text-white rounded-lg px-3 py-1.5 hover:bg-acc/25">Save screener</button></div></div>`;
  }
  function savedChips(){
    const list = CDX.Store.state.screeners;
    if (!list.length) return '<span class="text-xs text-mut">No saved screeners yet — configure conditions and save.</span>';
    return list.map(s => `<span class="inline-flex items-center gap-1.5 bg-panel border ${cfg.id===s.id?'border-acc/60':'border-line'} rounded-lg pl-3 pr-1.5 py-1 text-xs">
      <button data-load="${s.id}" class="text-slate-200 hover:text-acc font-medium">${F.esc(s.name)}</button>
      <span class="text-mut">${s.mode==='coins'?'coins':'pairs'} · ${s.conds.length}</span>
      <button data-del="${s.id}" class="text-mut hover:text-down px-1">✕</button></span>`).join('');
  }
  function results(){
    const rows = run();
    const cols = cfg.cols.map(k => COLS[cfg.mode][k]?.col).filter(Boolean);
    table = U.table({ columns: cols, rows, minWidth: (cols.length*120) + 'px', maxH:'62vh',
      rowAttr: r => `data-go="${cfg.mode==='coins'?'/token/'+r.id:'/pair/'+r.id}" style="cursor:pointer"`,
      empty: 'Nothing matches these conditions.' });
    const host = D.$('#scResults', root);
    host.innerHTML = `<div class="flex items-center justify-between mb-2">
      <span class="text-xs text-mut">${rows.length} results</span></div>`;
    host.appendChild(table.el);
  }
  function paint(){
    D.$('#scControls', root).innerHTML = controls();
    D.$('#scSaved', root).innerHTML = savedChips();
    results();
    bindInputs();
  }
  function bindInputs(){
    D.$$('#scControls select, #scControls input', root).forEach(el => {
      el.addEventListener('change', e => {
        const t = e.target;
        if (t.dataset.cf != null) cfg.conds[+t.dataset.cf].field = t.value;
        else if (t.dataset.co != null) cfg.conds[+t.dataset.co].op = t.value;
        else if (t.dataset.cv != null) cfg.conds[+t.dataset.cv].val = t.value;
        else if (t.dataset.chain != null) cfg.chain = t.value;
        else if (t.dataset.narr != null) cfg.narrative = t.value;
        else if (t.dataset.scname != null){ cfg.name = t.value; return; }
        else if (t.dataset.colk != null){
          t.checked ? cfg.cols.push(t.dataset.colk) : cfg.cols = cfg.cols.filter(k => k !== t.dataset.colk);
          cfg.cols = Object.keys(COLS[cfg.mode]).filter(k => cfg.cols.includes(k));   // keep canonical order
          results(); return;
        }
        results();
      });
    });
  }
  return {
    mount(el){
      root = el;
      cfg = cfg || freshCfg();
      root.innerHTML = `<div class="space-y-4">
        <div class="flex items-center gap-3 flex-wrap">
          <h2 class="font-disp font-semibold text-white text-lg">Advanced Screener</h2>
          <div class="flex items-center gap-2 flex-wrap" id="scSaved"></div></div>
        <div id="scControls"></div><div id="scResults"></div></div>
        <style>.ctl{background:#161B27;border:1px solid #1F2633;border-radius:8px;font-size:12px;padding:6px 10px;color:#E2E8F0}.ctl:focus{outline:none;border-color:#5B8CFF99}</style>`;
      paint();
      undelegate = D.delegate(root, {
        '[data-star]': () => {},
        '[data-mode]': t => { cfg.mode = t.dataset.mode; cfg.conds = [{ field: cfg.mode==='coins'?'mcap':'vol', op:'>', val: cfg.mode==='coins'?'100m':'1m' }]; cfg.cols = defCols(cfg.mode); paint(); },
        '[data-addcond]': () => { cfg.conds.push({ field: Object.keys(FIELDS[cfg.mode])[0], op:'>', val:'' }); paint(); },
        '[data-cx]': t => { cfg.conds.splice(+t.dataset.cx, 1); paint(); },
        '[data-colbtn]': () => D.$('[data-colmenu]', root).classList.toggle('hidden'),
        '[data-save]': () => {
          if (!cfg.name.trim()){ U.toast('Name the screener before saving.', 'warn'); return; }
          const saved = CDX.Store.saveScreener({ ...cfg, conds: cfg.conds.map(c=>({...c})), cols:[...cfg.cols] });
          cfg.id = saved.id;
          D.$('#scSaved', root).innerHTML = savedChips();
          U.toast('Screener saved: ' + cfg.name, 'up');
        },
        '[data-load]': t => { const s = CDX.Store.state.screeners.find(x=>x.id===t.dataset.load); if (s){ cfg = JSON.parse(JSON.stringify(s)); paint(); } },
        '[data-del]': t => { CDX.Store.deleteScreener(t.dataset.del); if (cfg.id===t.dataset.del) cfg.id=null; D.$('#scSaved', root).innerHTML = savedChips(); },
        '[data-go]': t => CDX.Router.go(t.dataset.go)
      });
      let n = 0;
      subs.push(CDX.Bus.on('tick', () => { if (++n % 4 === 0) results(); }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (undelegate) undelegate(); undelegate=null; table=null; root=null; }
  };
})();
