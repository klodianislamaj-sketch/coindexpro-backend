/* Page: System Status — hidden diagnostics at #/status (not in nav).
   Read-only health view built entirely from real runtime telemetry:
   network queues (rate-limit cooldowns + backlog), connectivity state,
   per-feed cache freshness, and active chains. No fabricated values. */
CDX.Pages.status = (() => {
  const D = CDX.Dom, F = CDX.Fmt;
  let subs = [], root = null, timer = null;

  function feedRows(){
    const queues = (CDX.Net.Queue.all && CDX.Net.Queue.all()) || [];
    if (!queues.length) return '<div class="px-4 py-5 text-sm text-mut">No network queues registered.</div>';
    const now = Date.now();
    return queues.map(q => {
      const cooling = q.coolUntil > now;
      const backlog = (q.jobs && q.jobs.length) || 0;
      const lastRun = q.lastRun ? F.rel(q.lastRun) : 'never';
      const dot = cooling ? 'bg-down' : backlog > 4 ? 'bg-gold' : 'bg-up';
      const label = cooling ? 'rate-limited' : backlog > 4 ? 'busy' : 'ok';
      const labelCls = cooling ? 'text-down' : backlog > 4 ? 'text-gold' : 'text-up';
      return `<div class="flex items-center gap-3 px-4 py-2.5 border-b border-line/40 last:border-0">
        <span class="w-2 h-2 rounded-full ${dot} shrink-0"></span>
        <span class="font-medium text-slate-200 text-sm">${F.esc(q.name)}</span>
        <span class="num text-[10px] ${labelCls} uppercase tracking-wide">${label}</span>
        <span class="ml-auto num text-[11px] text-mut">${cooling ? 'cooldown ' + Math.ceil((q.coolUntil - now)/1000) + 's · ' : ''}queue ${backlog} · last ${lastRun}</span></div>`;
    }).join('');
  }

  function connRow(){
    const s = CDX.Net.Conn.state || {};
    const online = s.online !== false;
    const sinceOk = s.lastOk ? F.rel(s.lastOk) : '—';
    const dot = !online ? 'bg-down' : s.degraded ? 'bg-gold' : 'bg-up';
    const txt = !online ? 'Offline' : s.degraded ? 'Degraded — reconnecting' : 'Online';
    const cls = !online ? 'text-down' : s.degraded ? 'text-gold' : 'text-up';
    return `<div class="flex items-center gap-3 px-4 py-3">
      <span class="w-2.5 h-2.5 rounded-full ${dot} ${s.degraded||!online?'animate-pulse':''} shrink-0"></span>
      <span class="font-medium ${cls}">${txt}</span>
      <span class="ml-auto num text-[11px] text-mut">last good fetch ${sinceOk} · fail streak ${s.failStreak || 0}</span></div>`;
  }

  function chainRows(){
    const order = CDX.Data.CHAIN_ORDER || [];
    return order.map(id => {
      const ch = CDX.Data.CHAINS[id];
      const pairs = CDX.Data.pairs.filter(p => p.chain === id);
      const live = pairs.filter(p => p.price > 0).length;
      const dot = live > 0 ? 'bg-up' : 'bg-mut';
      return `<div class="flex items-center gap-3 px-4 py-2 border-b border-line/40 last:border-0">
        <span class="w-2 h-2 rounded-full ${dot} shrink-0"></span>
        <span class="text-sm text-slate-200">${ch ? F.esc(ch.name) : id}</span>
        <span class="ml-auto num text-[11px] text-mut">${live}/${pairs.length} pairs priced</span></div>`;
    }).join('');
  }

  function summary(){
    const queues = (CDX.Net.Queue.all && CDX.Net.Queue.all()) || [];
    const now = Date.now();
    const limited = queues.filter(q => q.coolUntil > now).length;
    const total = CDX.Data.pairs.length;
    const priced = CDX.Data.pairs.filter(p => p.price > 0).length;
    const stale = total - priced;
    // normalized-layer stale detection: pairs whose resolved asset is flagged stale
    let staleAssets = 0;
    if (CDX.Asset){
      for (const p of CDX.Data.pairs){
        const a = CDX.Asset.resolve('d:' + p.id);
        if (a && a.valid && a.stale) staleAssets++;
      }
    }
    const card = (l, v, cls) => `<div class="bg-panel border border-line rounded-lg px-3 py-2">
      <div class="text-[10px] text-mut uppercase tracking-wide">${l}</div>
      <div class="num text-base font-bold ${cls||'text-white'}">${v}</div></div>`;
    const cache = CDX.Net.Cache.stats ? CDX.Net.Cache.stats() : null;
    const cons = CDX.Asset && CDX.Asset.consensusStats ? CDX.Asset.consensusStats() : { rejectedOutliers: 0, disagreements: 0 };
    const hitRate = cache && cache.hitRate != null ? Math.round(cache.hitRate * 100) + '%' : '—';
    return `<div class="grid grid-cols-2 sm:grid-cols-4 gap-2">
      ${card('Feeds', queues.length)}
      ${card('Rate-limited', limited, limited?'text-down':'text-up')}
      ${card('Cache hit rate', hitRate, 'text-up')}
      ${card('Stale assets', staleAssets, staleAssets?'text-gold':'text-up')}</div>
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2">
      ${card('Pairs priced', priced + '/' + total, 'text-up')}
      ${card('Outliers rejected', cons.rejectedOutliers, cons.rejectedOutliers?'text-gold':'text-up')}
      ${card('Source disagreements', cons.disagreements, cons.disagreements?'text-gold':'text-up')}
      ${card('Cache entries', cache ? cache.size : '—')}</div>`;
  }

  function paint(){
    if (!root) return;
    const set = (sel, html) => { const el = D.$(sel, root); if (el) el.innerHTML = html; };
    set('#stSummary', summary());
    set('#stConn', connRow());
    set('#stFeeds', feedRows());
    set('#stChains', chainRows());
    set('#stBackend', backendRows());
  }

  function backendRows(){
    if (!CDX.Backend || !CDX.Backend.subsystems) return '<div class="px-4 py-3 text-sm text-mut">Backend layer not loaded.</div>';
    const subs = CDX.Backend.subsystems();
    const rows = subs.map(s => {
      const dot = s.configured ? 'bg-up' : 'bg-mut';
      const state = s.configured ? ['configured', 'text-up'] : ['not configured', 'text-mut'];
      return `<div class="flex items-center gap-3 px-4 py-2 border-b border-line/40 last:border-0">
        <span class="w-2 h-2 rounded-full ${dot} shrink-0"></span>
        <span class="text-sm text-slate-200">${F.esc(s.name)}</span>
        <span class="num text-[10px] ${state[1]} uppercase tracking-wide">${state[0]}</span>
        <span class="ml-auto text-[10px] text-mut">needs: ${F.esc(s.needs)}</span></div>`;
    }).join('');
    // live provider-trust summary
    let pt = '';
    try {
      const r = CDX.Backend.providerTrust.report();
      pt = `<div class="px-4 py-2 text-[11px] text-mut border-t border-line/40">Provider trust (live): ${r.providers.length} observed · ${r.global.rejectedOutliers} outliers · ${r.global.disagreements} disagreements</div>`;
    } catch(e){}
    return rows + pt;
  }

  function render(){
    root.innerHTML = `<div class="max-w-3xl mx-auto px-3 sm:px-4 py-4 space-y-4">
      <div>
        <h1 class="font-disp text-xl font-bold text-white">System Status</h1>
        <p class="text-[12px] text-mut">Live diagnostics · network feeds, connectivity, and per-chain pricing coverage. Read-only.</p></div>
      <div id="stSummary"></div>
      <div class="bg-panel border border-line rounded-xl overflow-hidden">
        <div class="px-4 py-2.5 border-b border-line font-disp font-semibold text-white text-sm">Connectivity</div>
        <div id="stConn"></div></div>
      <div class="bg-panel border border-line rounded-xl overflow-hidden">
        <div class="px-4 py-2.5 border-b border-line font-disp font-semibold text-white text-sm">Data feeds <span class="text-[10px] text-mut font-normal">· rate-limit + backlog</span></div>
        <div id="stFeeds"></div></div>
      <div class="bg-panel border border-line rounded-xl overflow-hidden">
        <div class="px-4 py-2.5 border-b border-line font-disp font-semibold text-white text-sm">Active chains <span class="text-[10px] text-mut font-normal">· pricing coverage</span></div>
        <div id="stChains"></div></div>
      <div class="bg-panel border border-line rounded-xl overflow-hidden">
        <div class="px-4 py-2.5 border-b border-line font-disp font-semibold text-white text-sm">Backend readiness <span class="text-[10px] text-mut font-normal">· adapter configuration</span></div>
        <div id="stBackend"></div></div>
      <p class="text-[10px] text-mut text-center">Auto-refreshes every 3s. All values are live runtime telemetry.</p></div>`;
    paint();
  }

  return {
    mount(el){
      root = el;
      render();
      timer = setInterval(paint, 3000);
      subs.push(CDX.Bus.on('tick', paint));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (timer) clearInterval(timer); timer=null; root=null; }
  };
})();
