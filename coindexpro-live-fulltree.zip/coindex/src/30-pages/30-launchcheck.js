/* Page: Launch Check — hidden at #/launch-check (not in nav).
   Comprehensive PASS/FAIL deploy gate. Each check inspects real runtime state;
   nothing is mocked. Open right after deploy: all-green = safe. Read-only. */
CDX.Pages.launchCheck = (() => {
  const D = CDX.Dom, F = CDX.Fmt, A = CDX.Asset;
  let root = null, timer = null;

  function run(){
    const pairs = CDX.Data.pairs || [];
    const coins = CDX.Data.coins || [];
    const c = [];
    const push = (name, pass, detail) => c.push({ name, pass, detail });

    push('Homepage data', coins.length > 0 || pairs.length > 0, `${coins.length} coins · ${pairs.length} pairs loaded`);
    const priced = pairs.filter(p => { const a = A.resolve('d:' + p.id); return a && a.valid; });
    push('Prices render', priced.length > 0, `${priced.length}/${pairs.length} pairs valid via Asset layer`);
    push('Charts engine', !!(CDX.Chart && CDX.Chart.create), CDX.Chart ? 'chart engine present' : 'missing');
    push('Whales engine', !!(CDX.WhaleFlow && CDX.WhaleFlow.feed), CDX.WhaleFlow ? `${CDX.WhaleFlow.feed(10000,{limit:50}).length} prints buffered` : 'missing');
    const order = CDX.Data.CHAIN_ORDER || [];
    const livedChains = order.filter(id => pairs.some(p => p.chain === id && p.price > 0)).length;
    push('Chains render', livedChains > 0, `${livedChains}/${order.length} chains priced`);
    const tok = coins[0] ? CDX.Data.byKey('c:' + coins[0].id) : null;
    push('Token pages', !!tok, tok ? `resolves ${tok.sym}` : 'no token resolves');
    let searchOk = false; try { searchOk = CDX.Data.search('eth', 3).length > 0; } catch(e){}
    push('Search works', searchOk, searchOk ? 'query returns hits + dedupe' : 'search returned nothing');
    push('News works', !!(CDX.News && CDX.News.all && CDX.News.all().length > 0), `${(CDX.News&&CDX.News.all&&CDX.News.all().length)||0} headlines`);
    push('Alerts engine', !!(CDX.Alerts), CDX.Alerts ? 'alerts engine present' : 'missing');
    push('Status route', !!(CDX.Pages.status), CDX.Pages.status ? 'present' : 'missing');
    push('Integrity route', !!(CDX.Pages.integrity), CDX.Pages.integrity ? 'present' : 'missing');
    push('Trust score', !!(CDX.TrustScore && CDX.TrustScore.score), CDX.TrustScore ? 'explainable score available' : 'missing');
    push('Consensus engine', !!(A && A.consensus), A.consensus ? 'multi-source consensus present' : 'missing');
    return c;
  }

  function row(x){
    const st = x.pass ? ['bg-up', 'text-up', 'PASS'] : ['bg-down', 'text-down', 'FAIL'];
    return `<div class="flex items-center gap-3 px-4 py-2.5 border-b border-line/40 last:border-0">
      <span class="w-2 h-2 rounded-full ${st[0]} shrink-0"></span>
      <span class="font-medium text-slate-200 text-sm w-36">${F.esc(x.name)}</span>
      <span class="num text-[10px] ${st[1]} uppercase w-12">${st[2]}</span>
      <span class="text-[11px] text-mut flex-1">${F.esc(x.detail)}</span></div>`;
  }

  function paint(){
    if (!root) return;
    const cs = run();
    const fail = cs.filter(x => !x.pass).length;
    const verdict = fail === 0 ? ['DEPLOY SAFE', 'text-up', 'border-up/40 bg-up/10']
                              : [fail + ' CHECK(S) FAILED', 'text-down', 'border-down/40 bg-down/10'];
    const hdr = D.$('#lcHdr', root), body = D.$('#lcBody', root);
    if (hdr) hdr.innerHTML = `<div class="rounded-xl border ${verdict[2]} px-4 py-3 flex items-center gap-3">
      <span class="font-disp font-bold text-lg ${verdict[1]}">${verdict[0]}</span>
      <span class="num text-sm text-slate-300">${cs.length - fail}/${cs.length} pass</span>
      <span class="ml-auto text-[10px] text-mut">re-runs every 4s</span></div>`;
    if (body) body.innerHTML = cs.map(row).join('');
  }

  return {
    mount(el){
      root = el;
      root.innerHTML = `<div class="max-w-3xl mx-auto px-3 sm:px-4 py-4 space-y-3">
        <div><h1 class="font-disp text-xl font-bold text-white">Launch Check</h1>
        <p class="text-[12px] text-mut">Comprehensive deploy gate across every subsystem. All-green = safe to ship. Some checks show WARMING-style transient fails for the first ~30s.</p></div>
        <div id="lcHdr"></div>
        <div class="bg-panel border border-line rounded-xl overflow-hidden" id="lcBody"></div></div>`;
      paint();
      timer = setInterval(paint, 4000);
    },
    unmount(){ if (timer) clearInterval(timer); timer = null; root = null; }
  };
})();
