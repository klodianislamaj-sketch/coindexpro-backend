/* Page: Market / Sector / Chain heatmaps. Route: #/heatmaps/:kind */
CDX.Pages.heatmaps = (() => {
  const D = CDX.Dom, F = CDX.Fmt;
  let subs = [], root = null, undelegate = null, kind = 'market', ro = null;
  const KINDS = [['market','Market'],['sectors','Sectors'],['chains','Chains']];

  function draw(){
    const host = D.$('#hmHost', root);
    if (!host) return;
    if (kind === 'market'){
      CDX.Heatmap.render(host, CDX.Data.coins.map(c => ({
        id: c.id, label: c.sym, sub: F.usd(c.mcap), value: c.mcap, ch: c.ch24, go: '/token/' + c.id
      })), { height: 560, maxAbs: 8 });
    } else if (kind === 'sectors'){
      CDX.Heatmap.renderGrouped(host, CDX.Intel.allNarratives().map(n => ({
        label: n.name, color: n.color,
        items: n.coins.map(c => ({ id: c.id, label: c.sym, sub: F.usd(c.mcap), value: c.mcap, ch: c.ch24, go: '/token/' + c.id }))
      })).filter(g => g.items.length), { height: 640, maxAbs: 8 });
    } else {
      CDX.Heatmap.render(host, CDX.Intel.allChains().map(s => {
        const wsum = s.pairs.reduce((a,p)=>a+p.vol,0);
        const ch = wsum ? s.pairs.reduce((a,p)=>a + p.ch.h24*p.vol, 0) / wsum : 0;
        return { id: s.id, label: s.chain.name, sub: 'TVL ' + F.usd(s.tvl), value: s.tvl, ch, go: '/chain/' + s.id };
      }), { height: 520, maxAbs: 10 });
    }
  }
  function tabs(){
    return KINDS.map(([id, label]) => `<a href="#/heatmaps/${id}" class="text-xs rounded-lg px-3 py-1.5 border transition-colors ${id===kind?'bg-acc/15 border-acc/50 text-white':'bg-panel border-line text-mut hover:text-white'}">${label}</a>`).join('');
  }
  function legend(){
    return `<div class="flex items-center gap-2 text-[10px] text-mut">
      <span>−8%</span>
      ${[-8,-4,-1,1,4,8].map(v => `<span class="w-6 h-3 rounded-sm inline-block" style="background:${CDX.Heatmap.colorFor(v, 8)}"></span>`).join('')}
      <span>+8%</span> · size = ${kind==='chains'?'TVL':'market cap'} · 24h change</div>`;
  }
  return {
    mount(el, ctx){
      kind = KINDS.some(k => k[0] === ctx.params.kind) ? ctx.params.kind : 'market';
      root = el;
      root.innerHTML = `<div class="space-y-4">
        <div class="flex items-center gap-3 flex-wrap">
          <h2 class="font-disp font-semibold text-white text-lg">Heatmaps</h2>
          <div class="flex gap-1.5">${tabs()}</div>
          <span class="ml-auto">${legend()}</span></div>
        <div class="bg-panel border border-line rounded-xl p-2">
          <div id="hmHost" class="w-full"></div></div></div>`;
      draw();
      undelegate = D.delegate(root, { '[data-go]': t => { if (t.dataset.go) CDX.Router.go(t.dataset.go); } });
      let rt = null;
      ro = new ResizeObserver(() => { clearTimeout(rt); rt = setTimeout(draw, 120); });
      ro.observe(D.$('#hmHost', root));
      let n = 0;
      subs.push(CDX.Bus.on('tick', () => { if (++n % 4 === 0) draw(); }));
    },
    unmount(){ subs.forEach(u=>u()); subs=[]; if (ro) ro.disconnect(); ro=null; if (undelegate) undelegate(); undelegate=null; root=null; }
  };
})();
