/* CDX.Providers.dexscreener — live pair refresh by address batch + search.
   Free: 300 req/min. We use ≤1 call per chain per 20s cycle. */
CDX.Providers.dexscreener = (() => {
  const BASE = 'https://api.dexscreener.com/latest/dex';
  const CHAIN = { pulsechain:'pulsechain', ethereum:'ethereum', solana:'solana', base:'base',
                  arbitrum:'arbitrum', bnb:'bsc', avalanche:'avalanche', optimism:'optimism', polygon:'polygon',
                  sui:'sui', ton:'ton', linea:'linea', sonic:'sonic' };
  const queue = CDX.Net.Queue.create({ name: 'dexscreener', rps: 3.5, burst: 8, minGap: 120 });
  const get = path => CDX.Net.http.json(BASE + path, { queue, retries: 2, timeout: 12000 });
  const cleanSym = s => String(s || '?').trim().replace(/^\$+/, '').slice(0, 12);
  function normalize(p){
    const tx = (p.txns && p.txns.h24) || {};
    const ch = p.priceChange || {};
    return {
      address: p.pairAddress || '',
      base: cleanSym(p.baseToken && p.baseToken.symbol), quote: cleanSym(p.quoteToken && p.quoteToken.symbol),
      name: ((p.baseToken && p.baseToken.name) || '').trim(),
      img: (p.info && p.info.imageUrl) || null,
      ca: (p.baseToken && p.baseToken.address) || p.pairAddress || '',
      price: parseFloat(p.priceUsd) || 0,
      ch: { m5: +ch.m5 || 0, h1: +ch.h1 || 0, h6: +ch.h6 || 0, h24: +ch.h24 || 0 },
      liq: (p.liquidity && p.liquidity.usd) || 0,
      vol: (p.volume && p.volume.h24) || 0,
      buys: tx.buys || 0, sells: tx.sells || 0,
      fdv: p.fdv || p.marketCap || 0,
      ageH: p.pairCreatedAt ? Math.max(0.1, (Date.now() - p.pairCreatedAt) / 36e5) : 0,
      dex: p.dexId || ''
    };
  }
  /* batch fetch up to 30 pair addresses on one chain */
  async function pairs(chain, addresses){
    if (!addresses.length) return [];
    const j = await get(`/pairs/${CHAIN[chain] || chain}/${addresses.slice(0, 30).join(',')}`);
    return (j.pairs || []).map(normalize);
  }
  async function search(q){
    const j = await get(`/search?q=${encodeURIComponent(q)}`);
    const rows = (j.pairs || []).map(normalize);
    /* collapse to the deepest pool per token contract — DexScreener shows the deepest pool */
    const best = new Map();
    for (const p of rows){
      const k = (p.chain ? p.chain + '|' : '') + (p.ca || p.address).toLowerCase();
      if (!best.has(k) || p.liq > best.get(k).liq) best.set(k, p);
    }
    return [...best.values()].sort((a, b) => b.liq - a.liq);
  }
  return { pairs, search, normalize, CHAIN };
})();
