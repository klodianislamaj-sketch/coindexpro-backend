/* CDX.Providers.coingecko — live coin market data + OHLC + Fear & Greed.
   Free tier: ~10-30 req/min. We use 1 markets call / 60s and on-demand cached OHLC. */
window.CDX = window.CDX || {};
CDX.Providers = CDX.Providers || {};
CDX.Providers.coingecko = (() => {
  const BASE = 'https://api.coingecko.com/api/v3';
  const queue = CDX.Net.Queue.create({ name: 'coingecko', rps: 0.15, burst: 3, minGap: 2200 });
  const get = path => CDX.Net.http.json(BASE + path, { queue, retries: 2, timeout: 12000 });
  function normRow(r){
    return {
      cgId:   r.id, sym: (r.symbol || '').toUpperCase(), name: r.name || r.id,
      price:  r.current_price ?? 0,
      mcap:   r.market_cap ?? 0,
      vol:    r.total_volume ?? 0,
      supply: r.circulating_supply ?? 0,
      fdv:    r.fully_diluted_valuation ?? r.market_cap ?? 0,
      rank:   r.market_cap_rank ?? 9999,
      ch1h:   r.price_change_percentage_1h_in_currency ?? 0,
      ch24:   r.price_change_percentage_24h_in_currency ?? 0,
      ch7d:   r.price_change_percentage_7d_in_currency ?? 0,
      spark:  (r.sparkline_in_7d && r.sparkline_in_7d.price) || null,
      img:    r.image || null,
      totalSupply: r.total_supply ?? null,
      maxSupply:   r.max_supply ?? null,
      ath: r.ath ?? null, athCh: r.ath_change_percentage ?? null, athDate: r.ath_date ?? null,
      atl: r.atl ?? null, atlCh: r.atl_change_percentage ?? null, atlDate: r.atl_date ?? null
    };
  }
  /* top assets by market cap: page of 250 → array of normalized rows */
  /* page 2 (ranks 251-500) skips sparklines: ~50% payload cut, series math unaffected (majors+holdings only) */
  async function marketsPage(page, sparkline){
    const rows = await get(`/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=250&page=${page || 1}&sparkline=${sparkline !== false}&price_change_percentage=1h,24h,7d`);
    return (rows || []).map(normRow);
  }
  /* sector pages: real CoinGecko categories → narrative-tagged rows */
  async function categoryMarkets(category, perPage){
    const rows = await get(`/coins/markets?vs_currency=usd&category=${category}&order=market_cap_desc&per_page=${perPage || 50}&page=1&sparkline=false&price_change_percentage=1h,24h,7d`);
    return (rows || []).map(normRow);
  }
  /* ids: array of coingecko ids → normalized rows keyed by cg id */
  async function markets(ids){
    const rows = await get(`/coins/markets?vs_currency=usd&ids=${ids.join(',')}&order=market_cap_desc&per_page=${ids.length}&page=1&sparkline=true&price_change_percentage=1h,24h,7d`);
    const out = {};
    for (const r of rows){
      out[r.id] = {
        price:  r.current_price ?? 0,
        mcap:   r.market_cap ?? 0,
        vol:    r.total_volume ?? 0,
        supply: r.circulating_supply ?? 0,
        fdv:    r.fully_diluted_valuation ?? r.market_cap ?? 0,
        rank:   r.market_cap_rank ?? 9999,
        ch1h:   r.price_change_percentage_1h_in_currency ?? 0,
        ch24:   r.price_change_percentage_24h_in_currency ?? 0,
        ch7d:   r.price_change_percentage_7d_in_currency ?? 0,
        spark:  (r.sparkline_in_7d && r.sparkline_in_7d.price) || null,
        img:    r.image || null,
        totalSupply: r.total_supply ?? null,
        maxSupply:   r.max_supply ?? null,
        ath: r.ath ?? null, athCh: r.ath_change_percentage ?? null, athDate: r.ath_date ?? null,
        atl: r.atl ?? null, atlCh: r.atl_change_percentage ?? null, atlDate: r.atl_date ?? null
      };
    }
    return out;
  }
  /* candles: [{time(sec), open, high, low, close}] · CG granularity: 1d→30m, ≤30d→4h, >30d→4d */
  async function ohlc(cgId, days){
    const rows = await get(`/coins/${cgId}/ohlc?vs_currency=usd&days=${days}`);
    return rows.map(r => ({ time: Math.floor(r[0] / 1000), open: r[1], high: r[2], low: r[3], close: r[4] }));
  }
  /* Fear & Greed (alternative.me, CORS-open) */
  const fngQueue = CDX.Net.Queue.create({ name: 'fng', rps: 0.05, burst: 1 });
  async function fearGreed(){
    const j = await CDX.Net.http.json('https://api.alternative.me/fng/?limit=1',
      { queue: fngQueue, retries: 1, timeout: 8000 });
    return parseInt(j.data[0].value, 10);
  }
  /* real community metrics: X followers, Telegram members, Reddit activity, vote sentiment */
  async function coinSocial(cgId){
    const j = await get(`/coins/${cgId}?localization=false&tickers=false&market_data=false&community_data=true&developer_data=false&sparkline=false`);
    const c = j.community_data || {};
    return {
      twitter: c.twitter_followers ?? null,
      telegram: c.telegram_channel_user_count ?? null,
      redditSubs: c.reddit_subscribers ?? null,
      redditPosts48h: c.reddit_average_posts_48h ?? null,
      redditComments48h: c.reddit_average_comments_48h ?? null,
      redditActive48h: c.reddit_accounts_active_48h ?? null,
      upPct: j.sentiment_votes_up_percentage ?? null,
      downPct: j.sentiment_votes_down_percentage ?? null
    };
  }
  /* crowd attention: real top trending searches */
  async function trending(){
    const j = await get('/search/trending');
    return ((j.coins) || []).map((x, i) => ({
      cgId: x.item.id, name: x.item.name, sym: (x.item.symbol || '').toUpperCase(),
      rank: i + 1, mcapRank: x.item.market_cap_rank ?? null
    }));
  }
  return { markets, marketsPage, categoryMarkets, ohlc, fearGreed, coinSocial, trending };
})();
