/* CDX.Providers.pulsex — PulseChain-specific adapter.
   Composes PulseChain RPC, PulseX pools (via DexScreener token/search endpoints),
   GeckoTerminal pool trades, and the PulseChain Blockscout explorer into the
   provider-normalized pair shape used everywhere else. */
CDX.Providers.pulsex = (() => {
  const SCAN = 'https://api.scan.pulsechain.com/api/v2';
  const DS = 'https://api.dexscreener.com/latest/dex';
  const scanQueue = CDX.Net.Queue.create({ name: 'plsscan', rps: 0.9, burst: 2, minGap: 500 });
  const dsQueue = () => CDX.Net.Queue.get('dexscreener');
  const gt = () => CDX.Providers.geckoterminal;

  /* tracked universe — address-pinned where canonical, symbol-resolved otherwise */
  const TOKENS = [
    { sym: 'PLS',    query: 'WPLS',       addr: '0xA1077a294dDE1B09bB078844df40758a5D0f9a27', pools: 2, baseSym: 'WPLS' },
    { sym: 'PLSX',   query: 'PLSX',       addr: '0x95B303987A60C71504D99Aa1b13B4DA07b0790ab', pools: 2, baseSym: 'PLSX' },
    { sym: 'INC',    query: 'INC',        addr: '0x2fa878Ab3F87CC1C9737Fc071108F904c0B0C95d', pools: 2, baseSym: 'INC' },
    { sym: 'HEX',    query: 'HEX',        addr: '0x2b591e99afE9f32eAA6214f7B7629768c40Eeb39', pools: 2, baseSym: 'HEX' },
    { sym: 'eHEX',   query: 'eHEX',       addr: '0x57fde0a71132198BBeC939B98976993d8D89D225', pools: 1, baseSym: 'eHEX' },
    { sym: 'HDRN',   query: 'HDRN',       addr: '0x3819f64f282bf135d62168C1e513280dAF905e06', pools: 1, baseSym: 'HDRN' },
    { sym: 'ICSA',   query: 'ICSA',       addr: '0xfc4913214444aF5c715cc9F7b52655e788A569ed', pools: 1, baseSym: 'ICSA' },
    { sym: 'ATROPA', query: 'ATROPA',     addr: '0xCc78A0acDF847A2C1714D2A925bB4477df5d48a6', pools: 1, baseSym: 'ATROPA' },
    { sym: 'TEDDY',  query: 'TEDDY',      addr: null, pools: 1, baseSym: 'TEDDY' },
    { sym: 'BEAR',   query: 'TEDDY BEAR', addr: null, pools: 1, baseSym: 'BEAR' },
    { sym: 'DWB',    query: 'DWB',        addr: null, pools: 1, baseSym: 'DWB' },
    { sym: '9MM',    query: '9MM',        addr: null, pools: 1, baseSym: '9MM' }
  ];
  const pretty = id => String(id || 'PulseX').split(/[_-]/).map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');

  function normalizePool(p){
    const n = CDX.Providers.dexscreener.normalize(p);
    return Object.assign(n, { chain: 'pulsechain', dex: pretty(p.dexId) });
  }
  async function dsJson(path){
    return CDX.Net.http.json(DS + path, { queue: dsQueue(), retries: 2, timeout: 12000 });
  }
  /* resolve a tracked token to its deepest live PulseX pools */
  async function resolveToken(t){
    let raw = [];
    if (t.addr){
      try {
        raw = ((await dsJson('/tokens/' + t.addr)).pairs || [])
          .filter(p => p.baseToken && (p.baseToken.address || '').toLowerCase() === t.addr.toLowerCase());
      } catch(e){ raw = []; }
    }
    if (!raw.length){                                    // pin missing/dead → symbol search fallback
      raw = ((await dsJson('/search?q=' + encodeURIComponent(t.query))).pairs || [])
        .filter(p => p.baseToken && (p.baseToken.symbol || '').toUpperCase() === t.baseSym.toUpperCase());
    }
    const pools = raw
      .filter(p => p.chainId === 'pulsechain' && p.liquidity && p.liquidity.usd > 500)
      .sort((a, b) => (b.liquidity.usd || 0) - (a.liquidity.usd || 0))
      .slice(0, t.pools)
      .map(normalizePool);
    return { token: t.sym, address: pools[0] ? pools[0].ca : t.addr, pools };
  }
  /* full tracked universe → provider-normalized pool list */
  async function trackedPairs(filterSyms){
    const list = filterSyms && filterSyms.length
      ? TOKENS.filter(t => filterSyms.includes(t.baseSym)) : TOKENS;
    const settled = await Promise.allSettled(list.map(resolveToken));
    const out = [];
    const seen = new Set();
    for (const r of settled){
      if (r.status !== 'fulfilled') continue;
      for (const n of r.value.pools){
        const k = n.address.toLowerCase();
        if (!n.price || seen.has(k)) continue;
        seen.add(k);
        out.push(n);
      }
    }
    return out;
  }

  /* ---- holders + on-chain supply: Blockscout primary, RPC fallback ---- */
  async function scanToken(addr){
    const j = await CDX.Net.http.json(SCAN + '/tokens/' + addr, { queue: scanQueue, retries: 1, timeout: 10000 });
    return {
      holders: (j.holders ?? j.holders_count) != null ? parseInt(j.holders ?? j.holders_count, 10) : null,
      supply: j.total_supply != null && j.decimals != null
        ? Number(j.total_supply) / Math.pow(10, parseInt(j.decimals, 10)) : null,
      decimals: j.decimals != null ? parseInt(j.decimals, 10) : null
    };
  }
  async function rpcSupply(addr){
    const rpc = CDX.Providers.pulsechain.rpc;
    const [supHex, decHex] = await Promise.all([
      rpc('eth_call', [{ to: addr, data: '0x18160ddd' }, 'latest']),
      rpc('eth_call', [{ to: addr, data: '0x313ce567' }, 'latest'])
    ]);
    const dec = parseInt(decHex, 16) || 18;
    return { holders: null, supply: parseInt(supHex, 16) / Math.pow(10, dec), decimals: dec };
  }
  async function tokenStats(addr){
    if (!addr) return null;
    try { return await scanToken(addr); }
    catch(e){
      try { return await rpcSupply(addr); }
      catch(e2){ return null; }
    }
  }

  /* ---- real whale trades + measured buy/sell volume (GeckoTerminal pool trades) ---- */
  async function poolTrades(poolAddress, minUsd){
    const j = await CDX.Net.http.json(
      'https://api.geckoterminal.com/api/v2/networks/pulsechain/pools/' + poolAddress +
      '/trades?trade_volume_in_usd_greater_than=' + (minUsd || 0),
      { queue: CDX.Net.Queue.get('geckoterminal'), retries: 1, timeout: 12000,
        headers: { accept: 'application/json;version=20230302' } });
    return ((j.data) || []).map(t => {
      const a = t.attributes || {};
      return {
        ts: a.block_timestamp ? Date.parse(a.block_timestamp) : Date.now(),
        side: a.kind === 'buy' ? 'buy' : 'sell',
        usd: parseFloat(a.volume_in_usd) || 0,
        price: parseFloat(a.price_to_in_usd) || parseFloat(a.price_from_in_usd) || 0,
        wallet: a.tx_from_address || '',
        tx: a.tx_hash || ''
      };
    }).filter(t => t.usd > 0);
  }
  function flowFromTrades(trades){
    let buyVol = 0, sellVol = 0;
    for (const t of trades) t.side === 'buy' ? buyVol += t.usd : sellVol += t.usd;
    return { buyVol, sellVol, n: trades.length };
  }
  /* top holders of any PRC-20 (token → holder concentration; LP token → LP concentration) */
  async function topHolders(addr, limit){
    const j = await CDX.Net.http.json(SCAN + '/tokens/' + addr + '/holders',
      { queue: scanQueue, retries: 1, timeout: 10000 });
    return ((j.items) || []).slice(0, limit || 10).map(it => ({
      addr: (it.address && it.address.hash) || '',
      label: (it.address && it.address.name) || null,
      isContract: !!(it.address && it.address.is_contract),
      value: parseFloat(it.value) || 0
    }));
  }
  async function holdersBreakdown(addr, limit){
    const [tops, stats] = await Promise.all([topHolders(addr, limit), tokenStats(addr)]);
    const dec = stats && stats.decimals != null ? stats.decimals : 18;
    const supplyRaw = stats && stats.supply != null ? stats.supply * Math.pow(10, dec) : 0;
    let topPct = 0, contractPct = 0;
    const top = tops.map(t => {
      const pct = supplyRaw > 0 ? t.value / supplyRaw * 100 : 0;
      topPct += pct;
      if (t.isContract) contractPct += pct;
      return { ...t, pct };
    });
    return { top, topPct, contractPct, eoaPct: topPct - contractPct,
             holders: stats ? stats.holders : null, supply: stats ? stats.supply : null };
  }
  /* recently verified contract deployments (Blockscout v2) */
  async function recentContracts(){
    const j = await CDX.Net.http.json(SCAN + '/smart-contracts', { queue: scanQueue, retries: 1, timeout: 12000 });
    return ((j && j.items) || []).slice(0, 14).map(it => ({
      addr: (it.address && it.address.hash) || '',
      name: (it.address && it.address.name) || it.name || 'Contract',
      lang: it.language || '',
      verifiedAt: it.verified_at ? Date.parse(it.verified_at) : null,
      txs: it.transaction_count ?? it.tx_count ?? null,
      balance: it.coin_balance != null ? parseFloat(it.coin_balance) / 1e18 : null
    })).filter(c => c.addr);
  }

  return { TOKENS, trackedPairs, resolveToken, tokenStats, poolTrades, flowFromTrades,
           topHolders, holdersBreakdown , recentContracts };
})();
