/* CDX.Providers.pulsechain — normalized PulseChain JSON-RPC: chain head + gas,
   with eth_subscribe(newHeads) over WS and HTTP polling fallback. */
CDX.Providers.pulsechain = (() => {
  const RPC = 'https://rpc.pulsechain.com';
  const WSS = 'wss://rpc.pulsechain.com';
  const queue = CDX.Net.Queue.create({ name: 'plsrpc', rps: 0.8, burst: 2, minGap: 600 });
  async function rpc(method, params){
    const j = await CDX.Net.http.json(RPC, {
      method: 'POST', queue, retries: 1, timeout: 9000,
      headers: { 'content-type': 'application/json' },
      body: { jsonrpc: '2.0', id: 1, method, params: params || [] }
    });
    if (j.error) throw new Error('rpc ' + j.error.message);
    return j.result;
  }
  const hexInt = h => parseInt(h, 16);
  function normalizeHead(raw){
    return { height: hexInt(raw.number), gasGwei: raw.baseFeePerGas ? hexInt(raw.baseFeePerGas) / 1e9 : null,
             ts: raw.timestamp ? hexInt(raw.timestamp) * 1000 : Date.now() };
  }
  const blockNumber = async () => hexInt(await rpc('eth_blockNumber'));
  const head = async () => normalizeHead(await rpc('eth_getBlockByNumber', ['latest', false]));
  /* live head stream; falls back to HTTP polling via Conn if the socket dies */
  function subscribeHeads(onHead){
    let fallbackPoller = null;
    const sock = CDX.Net.WS.connect('plsrpc', WSS, {
      onOpen: ws => ws.send(JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'eth_subscribe', params: ['newHeads'] })),
      onMessage: raw => {
        try {
          const j = JSON.parse(raw);
          if (j.method === 'eth_subscription' && j.params && j.params.result) onHead(normalizeHead(j.params.result));
        } catch(e){}
      }
    });
    CDX.Bus.on('ws:fallback', ({ name }) => {
      if (name !== 'plsrpc' || fallbackPoller) return;
      fallbackPoller = CDX.Net.Conn.poller('plsrpc-poll',
        async () => onHead(await head()), 12000, { immediate: true }).start();
    });
    return sock;
  }
  return { rpc, blockNumber, head, subscribeHeads };
})();
