/* CDX.Providers.geckoterminal — pool discovery (trending/top) + real DEX OHLCV.
   Free: 30 req/min. Discovery is staggered at boot; OHLCV is on-demand and cached upstream. */
CDX.Providers.geckoterminal = (() => {
  const BASE = 'https://api.geckoterminal.com/api/v2';
  const NET = { pulsechain:'pulsechain', ethereum:'eth', solana:'solana', base:'base',
                arbitrum:'arbitrum', bnb:'bsc', avalanche:'avax', optimism:'optimism', polygon:'polygon_pos',
                sui:'sui-network', ton:'ton', linea:'linea', sonic:'sonic' };
  const queue = CDX.Net.Queue.create({ name: 'geckoterminal', rps: 0.42, burst: 4, minGap: 700 });
  const get = path => CDX.Net.http.json(BASE + path,
    { queue, retries: 2, timeout: 12000, headers: { accept: 'application/json;version=20230302' } });
  function dexName(rel, included){
    const id = rel && rel.dex && rel.dex.data && rel.dex.data.id;
    if (!id) return 'DEX';
    if (included){
      const hit = included.find(x => x.type === 'dex' && x.id === id);
      if (hit && hit.attributes && hit.attributes.name) return hit.attributes.name;
    }
    return id.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
  }
  function normalize(pool, included, chain){
    const a = pool.attributes || {};
    const nm = (a.name || ' / ').split(' / ').map(x => x.trim().replace(/^\$+/, ''));
    const tx = (a.transactions && a.transactions.h24) || {};
    const pc = a.price_change_percentage || {};
    return {
      chain,
      address: a.address || '',
      base: (nm[0] || '?').trim(), quote: (nm[1] || '?').trim().split(' ')[0],
      name: (nm[0] || '?').trim(),
      ca: (a.address || ''),
      price: parseFloat(a.base_token_price_usd) || 0,
      ch: { m5: +pc.m5 || 0, h1: +pc.h1 || 0, h6: +pc.h6 || 0, h24: +pc.h24 || 0 },
      liq: parseFloat(a.reserve_in_usd) || 0,
      vol: (a.volume_usd && parseFloat(a.volume_usd.h24)) || 0,
      buys: tx.buys || 0, sells: tx.sells || 0,
      fdv: parseFloat(a.fdv_usd) || parseFloat(a.market_cap_usd) || 0,
      ageH: a.pool_created_at ? Math.max(0.1, (Date.now() - Date.parse(a.pool_created_at)) / 36e5) : 0,
      dex: dexName(pool.relationships, included, chain)
    };
  }
  async function trendingPools(chain, page){
    const j = await get(`/networks/${NET[chain]}/trending_pools?include=dex&page=${page || 1}`);
    return (j.data || []).map(p => normalize(p, j.included, chain));
  }
  async function topPools(chain, page){
    const j = await get(`/networks/${NET[chain]}/pools?include=dex&sort=h24_volume_usd_desc&page=${page || 1}`);
    return (j.data || []).map(p => normalize(p, j.included, chain));
  }
  /* newest pools per network — pair discovery for fresh deployments */
  async function newPools(chain, page){
    const j = await get(`/networks/${NET[chain]}/new_pools?include=dex&page=${page || 1}`);
    return (j.data || []).map(p => normalize(p, j.included, chain));
  }
  /* real candles: tf ∈ minute|hour|day, agg per GT spec */
  async function ohlcv(chain, poolAddress, tf, agg){
    const j = await get(`/networks/${NET[chain]}/pools/${poolAddress}/ohlcv/${tf}?aggregate=${agg}&limit=1000&currency=usd`);
    const list = (j.data && j.data.attributes && j.data.attributes.ohlcv_list) || [];
    return list.map(r => ({
      candle: { time: r[0], open: +r[1], high: +r[2], low: +r[3], close: +r[4] },
      vol: +r[5] || 0
    })).sort((a,b) => a.candle.time - b.candle.time);
  }
  /* recent pool trades (any supported network) → normalized tape rows */
  async function trades(chain, poolAddress, minUsd){
    const j = await get(`/networks/${NET[chain]}/pools/${poolAddress}/trades?trade_volume_in_usd_greater_than=${minUsd || 0}`);
    return ((j.data) || []).map(t => {
      const a = t.attributes || {};
      return { ts: a.block_timestamp ? Date.parse(a.block_timestamp) : Date.now(),
               side: a.kind === 'buy' ? 'buy' : 'sell',
               usd: parseFloat(a.volume_in_usd) || 0,
               price: parseFloat(a.price_to_in_usd) || parseFloat(a.price_from_in_usd) || 0,
               wallet: a.tx_from_address || '', tx: a.tx_hash || '' };
    }).filter(t => t.usd > 0);
  }
  return { trendingPools, topPools, newPools, ohlcv, trades, NET };
})();
