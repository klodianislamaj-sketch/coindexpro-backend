/* CDX.Fmt — number/time formatting, DexScreener sub-zero price notation. */
CDX.Fmt = (() => {
  const SUBS = '₀₁₂₃₄₅₆₇₈₉';
  const sub = n => String(n).split('').map(d => SUBS[+d]).join('');
  function price(p){
    if (p == null || !Number.isFinite(p)) return 'Unavailable';   // guard: null/undefined/NaN/Infinity
    if (p >= 1000) return '$' + p.toLocaleString('en-US', { maximumFractionDigits: 0 });
    if (p >= 1)    return '$' + p.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 3 });
    if (p >= 0.01) return '$' + p.toFixed(4);
    if (p <= 0)    return '$0.00';
    const m = p.toFixed(18).match(/^0\.(0*)(\d+)/);
    if (!m) return '$0.00';
    const zeros = m[1].length;
    const sig = m[2].slice(0, 4).replace(/0+$/, '') || m[2].slice(0, 4);
    if (zeros >= 4) return '$0.0' + sub(zeros) + sig;
    return '$' + p.toFixed(Math.min(zeros + 4, 10)).replace(/0+$/, '');
  }
  function usd(n){
    if (n == null || !Number.isFinite(n)) return 'Unavailable';   // guard: invalid → not rendered as real
    const a = Math.abs(n);
    if (a >= 1e12) return '$' + (n/1e12).toFixed(2) + 'T';
    if (a >= 1e9)  return '$' + (n/1e9).toFixed(2) + 'B';
    if (a >= 1e6)  return '$' + (n/1e6).toFixed(2) + 'M';
    if (a >= 1e3)  return '$' + (n/1e3).toFixed(1) + 'K';
    return '$' + n.toFixed(2);
  }
  function num(n){
    if (n == null || !Number.isFinite(n)) return '—';             // guard: invalid count
    const a = Math.abs(n);
    if (a >= 1e12) return (n/1e12).toFixed(2) + 'T';
    if (a >= 1e9)  return (n/1e9).toFixed(2) + 'B';
    if (a >= 1e6)  return (n/1e6).toFixed(2) + 'M';
    if (a >= 1e3)  return (n/1e3).toFixed(1) + 'K';
    return n.toLocaleString('en-US', { maximumFractionDigits: 2 });
  }
  const pct = (v, d) => (!Number.isFinite(v) ? '—' : (v > 0 ? '+' : '') + v.toFixed(d == null ? 2 : d) + '%');
  const pctAuto = v => (!Number.isFinite(v) ? '—' : pct(v, Math.abs(v) >= 100 ? 0 : 2));
  const cls = v => v > 0 ? 'text-up' : v < 0 ? 'text-down' : 'text-mut';
  function age(h){
    if (h < 1)    return Math.max(1, Math.round(h*60)) + 'm';
    if (h < 24)   return Math.round(h) + 'h';
    if (h < 720)  return Math.round(h/24) + 'd';
    if (h < 8760) return Math.round(h/720) + 'mo';
    const y = Math.floor(h/8760), mo = Math.round((h % 8760)/720);
    return y + 'y' + (mo ? ' ' + mo + 'mo' : '');
  }
  function rel(ts){
    const m = Math.max(0, Math.round((Date.now()-ts)/60e3));
    if (m < 1) return 'just now';
    if (m < 60) return m + 'm ago';
    const h = Math.floor(m/60);
    return h + 'h ' + (m % 60) + 'm ago';
  }
  const esc = s => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  function mulberry32(a){ return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
  const seedOf = s => s.split('').reduce((x,c)=>x+c.charCodeAt(0), 7);
  return { price, usd, num, pct, pctAuto, cls, age, rel, esc, mulberry32, seedOf };
})();
