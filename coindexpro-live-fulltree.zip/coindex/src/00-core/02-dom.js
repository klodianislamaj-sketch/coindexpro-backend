/* CDX.Dom — element creation, delegation, live-cell flash updates. */
CDX.Dom = (() => {
  const $  = (s, root) => (root || document).querySelector(s);
  const $$ = (s, root) => [...(root || document).querySelectorAll(s)];
  function el(tag, cls, html){
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    return e;
  }
  /* One delegated click handler per container; selectorMap = { '[data-x]': fn } (first match wins) */
  function delegate(root, selectorMap){
    const handler = (e) => {
      for (const sel of Object.keys(selectorMap)){
        const t = e.target.closest(sel);
        if (t && root.contains(t)){ selectorMap[sel](t, e); return; }
      }
    };
    root.addEventListener('click', handler);
    return () => root.removeEventListener('click', handler);
  }
  /* Update a live cell in place: set content, restart flash animation. */
  function liveSet(node, html, dir){
    if (!node) return;
    node.innerHTML = html;
    if (!dir) return;
    node.classList.remove('flash-up','flash-down');
    void node.offsetWidth;
    node.classList.add(dir > 0 ? 'flash-up' : 'flash-down');
  }
  return { $, $$, el, delegate, liveSet };
})();
