/* CDX.Bus — tiny pub/sub event bus. All cross-module communication flows here. */
window.CDX = window.CDX || {};
CDX.Bus = (() => {
  const map = new Map();
  return {
    on(evt, fn){
      if (!map.has(evt)) map.set(evt, new Set());
      map.get(evt).add(fn);
      return () => map.get(evt)?.delete(fn);   // unsubscribe handle
    },
    emit(evt, payload){
      map.get(evt)?.forEach(fn => { try { fn(payload); } catch(e){ console.error('[bus]', evt, e); } });
    }
  };
})();
