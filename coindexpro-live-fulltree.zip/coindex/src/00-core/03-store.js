/* CDX.Store — app state + persistence. Emits Bus events on mutation. */
CDX.Store = (() => {
  const safe = {
    get(k){ try { return JSON.parse(window.localStorage.getItem(k)); } catch(e){ return null; } },
    set(k,v){ try { window.localStorage.setItem(k, JSON.stringify(v)); } catch(e){} }
  };
  const state = {
    watch: new Set(),                                  // derived view of the active list
    lists: [{ id:'default', name:'Default', keys:['c:btc','c:pls','c:plsx','c:hex','c:inc'] }],
    activeList: 'default',
    screeners: [],
    notes: [],
    alerts: [],
    journal: [],
    alertChannels: { browser: false, webhookUrl: '', tgToken: '', tgChat: '', emailTo: '', emailEndpoint: '' },
    holdings: [
      { key:'c:btc',  amount:0.18,     avg:58400 },
      { key:'c:eth',  amount:2.4,      avg:1821 },
      { key:'c:plsx', amount:84000000, avg:0.0000071 },
      { key:'c:hex',  amount:1200000,  avg:0.00118 }
    ],
    prefs: { dexTf:'h24', dexChain:'all', dexSort:'trending', newOnly:false,
             marketFilter:'all', marketSort:{ key:'rank', dir:1 }, chartTf:'1H' }
  };
  function syncWatch(){
    let l = state.lists.find(x => x.id === state.activeList);
    if (!l){ l = state.lists[0]; state.activeList = l.id; }
    state.watch = new Set(l.keys);
  }
  function restore(){
    const L = safe.get('cdx_lists');
    if (Array.isArray(L) && L.length && L.every(x => x && x.id && Array.isArray(x.keys))) state.lists = L;
    else {
      const w = safe.get('cdx_watch');                 // migrate legacy single watchlist
      if (Array.isArray(w)) state.lists[0].keys = w;
    }
    const a = safe.get('cdx_active');   if (typeof a === 'string') state.activeList = a;
    const sc = safe.get('cdx_screeners'); if (Array.isArray(sc)) state.screeners = sc;
    const no = safe.get('cdx_notes');     if (Array.isArray(no)) state.notes = no;
    const al = safe.get('cdx_alerts');    if (Array.isArray(al)) state.alerts = al;
    const jr = safe.get('cdx_journal');   if (Array.isArray(jr)) state.journal = jr;
    const ch = safe.get('cdx_channels');  if (ch && typeof ch === 'object') Object.assign(state.alertChannels, ch);
    const h = safe.get('cdx_holdings'); if (Array.isArray(h) && h.length && h.every(x=>x && x.key)) state.holdings = h;
    const p = safe.get('cdx_prefs');    if (p && typeof p === 'object') Object.assign(state.prefs, p);
    syncWatch();
  }
  function persist(){
    safe.set('cdx_watch', [...state.watch]);
    safe.set('cdx_lists', state.lists);
    safe.set('cdx_active', state.activeList);
    safe.set('cdx_screeners', state.screeners);
    safe.set('cdx_notes', state.notes);
    safe.set('cdx_alerts', state.alerts);
    safe.set('cdx_journal', state.journal);
    safe.set('cdx_channels', state.alertChannels);
    safe.set('cdx_holdings', state.holdings);
    safe.set('cdx_prefs', state.prefs);
  }
  function toggleWatch(key){
    const l = state.lists.find(x => x.id === state.activeList) || state.lists[0];
    const i = l.keys.indexOf(key);
    i >= 0 ? l.keys.splice(i, 1) : l.keys.push(key);
    syncWatch(); persist();
    CDX.Bus.emit('watch:changed', key);
    return state.watch.has(key);
  }
  /* ---- multi-watchlist API ---- */
  const uid = () => 'l' + Date.now().toString(36) + Math.floor(Math.random()*1e4).toString(36);
  function createList(name){
    const l = { id: uid(), name: name || 'List ' + (state.lists.length + 1), keys: [] };
    state.lists.push(l); persist(); CDX.Bus.emit('lists:changed'); return l;
  }
  function renameList(id, name){
    const l = state.lists.find(x => x.id === id);
    if (l && name){ l.name = name; persist(); CDX.Bus.emit('lists:changed'); }
  }
  function deleteList(id){
    if (id === 'default') return;
    state.lists = state.lists.filter(x => x.id !== id);
    if (state.activeList === id) state.activeList = 'default';
    syncWatch(); persist(); CDX.Bus.emit('lists:changed');
  }
  function setActiveList(id){
    if (!state.lists.some(x => x.id === id)) return;
    state.activeList = id; syncWatch(); persist();
    CDX.Bus.emit('lists:changed'); CDX.Bus.emit('watch:changed', null);
  }
  function addToList(id, key){
    const l = state.lists.find(x => x.id === id);
    if (l && !l.keys.includes(key)){ l.keys.push(key); syncWatch(); persist(); CDX.Bus.emit('lists:changed'); }
  }
  function removeFromList(id, key){
    const l = state.lists.find(x => x.id === id);
    if (l){ l.keys = l.keys.filter(k => k !== key); syncWatch(); persist(); CDX.Bus.emit('lists:changed'); }
  }
  /* ---- portfolio trade engine ---- */
  function trade(key, side, amount, price){
    if (!(amount > 0)) return { ok: false, msg: 'Enter an amount above zero.' };
    let h = state.holdings.find(x => x.key === key);
    if (side === 'buy'){
      if (h){ h.avg = (h.avg * h.amount + price * amount) / (h.amount + amount); h.amount += amount; }
      else state.holdings.push({ key, amount, avg: price });
    } else {
      if (!h || h.amount <= 0) return { ok: false, msg: 'No position to sell.' };
      amount = Math.min(amount, h.amount);
      h.amount -= amount;
      if (h.amount <= 1e-12) state.holdings = state.holdings.filter(x => x !== h);
    }
    state.journal.unshift({ id: uid(), ts: Date.now(), key, side, qty: amount, price,
                            strategy: 'manual', thesis: '', auto: true });
    if (state.journal.length > 200) state.journal.length = 200;
    persist();
    CDX.Bus.emit('holdings:changed');
    CDX.Bus.emit('journal:changed');
    return { ok: true, amount };
  }
  function removeHolding(key){
    state.holdings = state.holdings.filter(x => x.key !== key);
    persist(); CDX.Bus.emit('holdings:changed');
  }
  /* ---- research notes API ---- */
  function saveNote(n){
    const note = { ...n, id: n.id || uid(), updated: Date.now() };
    const i = state.notes.findIndex(x => x.id === note.id);
    i >= 0 ? state.notes[i] = note : state.notes.unshift(note);
    persist(); CDX.Bus.emit('notes:changed'); return note;
  }
  function deleteNote(id){
    state.notes = state.notes.filter(x => x.id !== id);
    persist(); CDX.Bus.emit('notes:changed');
  }
  /* ---- trade journal API ---- */
  function saveJournal(entry){
    const e = { ...entry, id: entry.id || uid(), ts: entry.ts || Date.now() };
    const i = state.journal.findIndex(x => x.id === e.id);
    i >= 0 ? state.journal[i] = e : state.journal.unshift(e);
    if (state.journal.length > 200) state.journal.length = 200;
    persist(); CDX.Bus.emit('journal:changed'); return e;
  }
  function deleteJournal(id){
    state.journal = state.journal.filter(x => x.id !== id);
    persist(); CDX.Bus.emit('journal:changed');
  }
  /* ---- alert rules API ---- */
  function saveAlert(rule){
    const r = { enabled: true, fireCount: 0, lastFired: 0, cooldownMs: 600e3, channels: ['toast'],
                ...rule, id: rule.id || uid(), created: rule.created || Date.now() };
    const i = state.alerts.findIndex(x => x.id === r.id);
    i >= 0 ? state.alerts[i] = r : state.alerts.push(r);
    persist(); CDX.Bus.emit('alerts:changed'); return r;
  }
  function deleteAlert(id){
    state.alerts = state.alerts.filter(x => x.id !== id);
    persist(); CDX.Bus.emit('alerts:changed');
  }
  function toggleAlert(id){
    const r = state.alerts.find(x => x.id === id);
    if (r){ r.enabled = !r.enabled; persist(); CDX.Bus.emit('alerts:changed'); }
  }
  function setChannels(patchObj){
    Object.assign(state.alertChannels, patchObj);
    persist(); CDX.Bus.emit('channels:changed');
  }
  /* ---- saved screeners API ---- */
  function saveScreener(cfg){
    const sc = { ...cfg, id: cfg.id || uid() };
    const i = state.screeners.findIndex(x => x.id === sc.id);
    i >= 0 ? state.screeners[i] = sc : state.screeners.push(sc);
    persist(); CDX.Bus.emit('screeners:changed'); return sc;
  }
  function deleteScreener(id){
    state.screeners = state.screeners.filter(x => x.id !== id);
    persist(); CDX.Bus.emit('screeners:changed');
  }
  function setPref(k, v){ state.prefs[k] = v; persist(); }
  return { state, restore, persist, toggleWatch, setPref,
           createList, renameList, deleteList, setActiveList, addToList, removeFromList,
           saveScreener, deleteScreener, trade, removeHolding, saveNote, deleteNote,
           saveAlert, deleteAlert, toggleAlert, setChannels, saveJournal, deleteJournal };
})();
