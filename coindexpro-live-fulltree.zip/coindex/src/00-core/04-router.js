/* CDX.Router — hash router with :params, query strings, page lifecycle.
   Pages implement { mount(el, ctx), unmount() }. Unmount is guaranteed before next mount. */
CDX.Router = (() => {
  const routes = [];
  let current = null, outlet = null, fallback = null;
  /* nav hardening state */
  const scrollMem = new Map();          // full hash → scrollY (state preservation)
  let lastResolvedHash = null;          // dedupe double hashchange / double pushes
  let navIntent = null;                 // 'push' | 'replace' | null (null = browser back/fwd)
  let lastGo = { path: null, ts: 0 };   // tap debounce
  const DEBOUNCE_MS = 350;
  function register(pattern, page){ routes.push({ parts: pattern.split('/').filter(Boolean), page, pattern }); }
  function setFallback(page){ fallback = page; }
  function parse(){
    const raw = (location.hash || '#/').slice(1);
    const [pathStr, queryStr] = raw.split('?');
    const path = pathStr.split('/').filter(Boolean);
    const query = {};
    (queryStr || '').split('&').forEach(kv => {
      if (!kv) return;
      const [k, v] = kv.split('=');
      query[decodeURIComponent(k)] = decodeURIComponent(v || '');
    });
    return { path, query };
  }
  function match(path){
    for (const r of routes){
      if (r.parts.length !== path.length) continue;
      const params = {};
      let ok = true;
      for (let i = 0; i < r.parts.length; i++){
        if (r.parts[i].startsWith(':')) params[r.parts[i].slice(1)] = path[i];
        else if (r.parts[i] !== path[i]) { ok = false; break; }
      }
      if (ok) return { page: r.page, params, pattern: r.pattern };
    }
    return null;
  }
  function resolve(){
    if (!outlet) return;                                                     // never resolve before start()
    const hash = location.hash || '#/';
    if (hash === lastResolvedHash && current){ navIntent = null; return; }   // no full rerender on duplicate transitions
    const { path, query } = parse();
    const hit = match(path) || (fallback && { page: fallback, params: { path: path.join('/') }, pattern: '*' });
    if (!hit){ navIntent = null; return; }
    if (lastResolvedHash != null) scrollMem.set(lastResolvedHash, window.scrollY);  // preserve scroll of outgoing route
    if (scrollMem.size > 60) scrollMem.delete(scrollMem.keys().next().value);        // bounded
    if (current && current.unmount) { try { current.unmount(); } catch(e){ console.error('[router] unmount', e); } }
    outlet.innerHTML = '';
    const intent = navIntent; navIntent = null;
    lastResolvedHash = hash;
    current = hit.page;
    current.mount(outlet, { params: hit.params, query, pattern: hit.pattern });
    /* push/replace → top; browser back/forward → restore remembered position */
    const y = intent ? 0 : (scrollMem.get(hash) || 0);
    requestAnimationFrame(() => window.scrollTo(0, y));
    CDX.Bus.emit('route:changed', { pattern: hit.pattern, params: hit.params, query });
  }
  function normalize(path){
    if (typeof path !== 'string') return '/';
    path = path.trim();
    if (path.startsWith('#')) path = path.slice(1);
    if (!path.startsWith('/')) path = '/' + path;
    return path;
  }
  function go(path){
    path = normalize(path);
    const now = Date.now();
    if (path === lastGo.path && now - lastGo.ts < DEBOUNCE_MS) return;       // debounce taps / double pushes
    lastGo = { path, ts: now };
    if ('#' + path === location.hash) return;                                // already here — never remount
    navIntent = 'push';
    location.hash = '#' + path;
  }
  function replace(path){
    path = normalize(path);
    if ('#' + path === location.hash) return;
    navIntent = 'replace';
    history.replaceState(null, '', location.pathname + location.search + '#' + path);
    resolve();                                                               // replaceState fires no hashchange
  }
  function back(){
    if (history.length > 1) history.back();
    else go('/');
  }
  /* capture-phase interceptor: every internal anchor navigates through the router —
     no default anchor behavior, no browser open-link dialogs (iOS) */
  function intercept(e){
    if (e.defaultPrevented || e.button === 1 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    const a = e.target.closest && e.target.closest('a[href]');
    if (!a) return;
    const href = a.getAttribute('href') || '';
    if (!href.startsWith('#')) return;                                       // external links untouched
    e.preventDefault();
    if (href === '#' || href === '') return;
    go(href);
  }
  function start(el){
    outlet = el;
    document.addEventListener('click', intercept, true);
    /* iOS: suppress long-press open-link callouts on internal anchors */
    const st = document.createElement('style');
    st.textContent = 'a[href^="#"]{-webkit-touch-callout:none;-webkit-tap-highlight-color:transparent}';
    document.head.appendChild(st);
    window.addEventListener('hashchange', resolve);
    if (!location.hash) replace('/');
    else resolve();
  }
  return { register, setFallback, start, go, replace, back, parse,
           path: () => '/' + parse().path.join('/') };
})();
