/* CDX boot — restore state, mount shell, register routes, start live engine. */
(() => {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;   // SSR/no-DOM: never boot
  CDX.Store.restore();
  const outlet = CDX.Shell.mount(document.getElementById('app'));
  CDX.Router.register('/',          CDX.Pages.home);
  CDX.Router.register('/markets',   CDX.Pages.markets);
  CDX.Router.register('/dex',       CDX.Pages.dex);
  CDX.Router.register('/token/:id', CDX.Pages.token);
  CDX.Router.register('/pair/:id',  CDX.Pages.pair);
  CDX.Router.register('/chains',           CDX.Pages.chains);
  CDX.Router.register('/chain/:name',      CDX.Pages.chain);
  CDX.Router.register('/whales',           CDX.Pages.whales);
  CDX.Router.register('/smart-money',      CDX.Pages.smartMoney);
  /* DISABLED — wallet profile (placeholder data).
  CDX.Router.register('/wallet/:address',  CDX.Pages.wallet); */
  CDX.Router.register('/wallet/:address',  { mount: () => CDX.Router.replace('/'), unmount(){} });
  CDX.Router.register('/narratives',       CDX.Pages.narratives);
  CDX.Router.register('/narrative/:name',  CDX.Pages.narrative);
  CDX.Router.register('/pulsechain',       CDX.Pages.pulsechain);
  CDX.Router.register('/screener',         CDX.Pages.screener);
  CDX.Router.register('/watchlist',        CDX.Pages.watchlists);
  CDX.Router.register('/heatmaps',         { mount: () => CDX.Router.go('/heatmaps/market'), unmount(){} });
  CDX.Router.register('/heatmaps/:kind',   CDX.Pages.heatmaps);
  CDX.Router.register('/terminal',         { mount: () => CDX.Router.go('/terminal/movers'), unmount(){} });
  CDX.Router.register('/terminal/:view',   CDX.Pages.terminal);
  CDX.Router.register('/portfolio',        CDX.Pages.portfolio);
  CDX.Router.register('/research',         CDX.Pages.research);
  CDX.Router.register('/alpha',            CDX.Pages.alpha);
  /* DISABLED — wallet leaderboard (placeholder data).
  CDX.Router.register('/wallets',          CDX.Pages.wallets); */
  CDX.Router.register('/wallets',          { mount: () => CDX.Router.replace('/'), unmount(){} });
  CDX.Router.register('/liquidity',        CDX.Pages.liquidity);
  CDX.Router.register('/social',           CDX.Pages.social);
  CDX.Router.register('/flows',            { mount: () => CDX.Router.go('/flows/capital'), unmount(){} });
  CDX.Router.register('/flows/:view',      CDX.Pages.flows);
  CDX.Router.register('/alerts',           CDX.Pages.alerts);
  CDX.Router.register('/quant',            CDX.Pages.quant);
  CDX.Router.register('/risk',             CDX.Pages.risk);
  CDX.Router.register('/news',             CDX.Pages.news);
  CDX.Router.register('/status',           CDX.Pages.status);   /* hidden diagnostics — not in nav */
  CDX.Router.register('/smoke',            CDX.Pages.smoke);    /* hidden deploy smoke test — not in nav */
  CDX.Router.register('/integrity',        CDX.Pages.integrity);    /* hidden integrity monitor — not in nav */
  CDX.Router.register('/launch-check',     CDX.Pages.launchCheck);  /* hidden deploy gate — not in nav */
  CDX.Router.register('/asset/:symbol',    CDX.Pages.assetAlias);
  CDX.Router.register('/pair/:chain/:pair', CDX.Pages.pairAlias);
  CDX.Router.setFallback(CDX.Pages.notFound);
  CDX.Router.start(outlet);
  CDX.Data.startLive(4000);
  if (CDX.Scaffold && CDX.Scaffold.history) try { CDX.Scaffold.history.start(); } catch(e){}   // real session history recorder
})();
