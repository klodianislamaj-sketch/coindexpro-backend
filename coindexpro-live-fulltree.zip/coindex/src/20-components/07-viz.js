/* CDX.Viz — dependency-free SVG visualizations: donut allocation, sentiment gauge, weight bars. */
CDX.Viz = (() => {
  const F = CDX.Fmt;
  function arc(cx, cy, r, a0, a1){
    const p = a => [cx + r * Math.cos(a), cy + r * Math.sin(a)];
    const [x0, y0] = p(a0), [x1, y1] = p(a1);
    return `M ${x0.toFixed(2)} ${y0.toFixed(2)} A ${r} ${r} 0 ${a1 - a0 > Math.PI ? 1 : 0} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}`;
  }
  /* items: [{ label, value, color }] */
  function donut(items, size, center){
    const S = size || 180, r = S/2 - 14, total = items.reduce((a,i)=>a+i.value,0) || 1;
    let a = -Math.PI/2, paths = '';
    for (const it of items){
      const sweep = it.value / total * Math.PI * 2;
      if (sweep > 0.004) paths += `<path d="${arc(S/2, S/2, r, a + 0.012, a + sweep - 0.012)}" fill="none" stroke="${it.color}" stroke-width="18" stroke-linecap="butt"><title>${F.esc(it.label)} · ${(it.value/total*100).toFixed(1)}%</title></path>`;
      a += sweep;
    }
    return `<svg viewBox="0 0 ${S} ${S}" class="w-full max-w-[200px] mx-auto">${paths}
      <text x="${S/2}" y="${S/2 - 4}" text-anchor="middle" fill="#fff" font-size="15" font-weight="700" font-family="Space Grotesk">${center ? F.esc(center[0]) : ''}</text>
      <text x="${S/2}" y="${S/2 + 13}" text-anchor="middle" fill="#8B94A7" font-size="9">${center ? F.esc(center[1]) : ''}</text></svg>`;
  }
  function legend(items){
    const total = items.reduce((a,i)=>a+i.value,0) || 1;
    return items.map(i => `<div class="flex items-center gap-2 text-[12px]">
      <span class="w-2.5 h-2.5 rounded-sm shrink-0" style="background:${i.color}"></span>
      <span class="text-slate-300 truncate">${F.esc(i.label)}</span>
      <span class="ml-auto num text-mut">${F.usd(i.value)}</span>
      <span class="num text-slate-300 w-12 text-right">${(i.value/total*100).toFixed(1)}%</span></div>`).join('');
  }
  /* semicircle gauge 0-100 */
  function gauge(value, label, color){
    const W = 200, H = 116, cx = W/2, cy = H - 10, r = 78;
    const a = -Math.PI + (value / 100) * Math.PI;
    const ticks = [];
    for (let i = 0; i <= 20; i++){
      const t = -Math.PI + i/20*Math.PI;
      const c = i/20*100 <= value ? color : '#1F2633';
      ticks.push(`<line x1="${cx + (r-8)*Math.cos(t)}" y1="${cy + (r-8)*Math.sin(t)}" x2="${cx + r*Math.cos(t)}" y2="${cy + r*Math.sin(t)}" stroke="${c}" stroke-width="5" stroke-linecap="round"/>`);
    }
    return `<svg viewBox="0 0 ${W} ${H}" class="w-full max-w-[230px] mx-auto">${ticks.join('')}
      <line x1="${cx}" y1="${cy}" x2="${cx + (r-22)*Math.cos(a)}" y2="${cy + (r-22)*Math.sin(a)}" stroke="${color}" stroke-width="2.5" stroke-linecap="round"/>
      <circle cx="${cx}" cy="${cy}" r="4" fill="${color}"/>
      <text x="${cx}" y="${cy - 26}" text-anchor="middle" fill="${color}" font-size="26" font-weight="700" font-family="JetBrains Mono">${Math.round(value)}</text>
      <text x="${cx}" y="${cy - 8}" text-anchor="middle" fill="#8B94A7" font-size="10">${F.esc(label)}</text></svg>`;
  }
  return { donut, legend, gauge };
})();
