/* CDX.UI — reusable presentational components (pure HTML-string renderers + toast). */
CDX.UI = (() => {
  const F = CDX.Fmt;
  function logo(sym, color, size){
    const s = size || 7;
    const url = CDX.Data.LOGOS[sym] || (CDX.LiveData && CDX.LiveData.logoOf && CDX.LiveData.logoOf(sym));
    const img = url ? `<img src="${url}" alt="" loading="lazy" class="absolute inset-0 w-full h-full object-contain rounded-full bg-ink/40" onerror="this.style.display='none'">` : '';
    return `<span class="relative overflow-hidden w-${s} h-${s} rounded-full grid place-items-center text-[10px] font-bold shrink-0" style="background:${color}22;border:1px solid ${color}66;color:${color}">${F.esc(sym.slice(0,4))}${img}</span>`;
  }
  function chainBadge(c, lg){
    const ch = CDX.Data.CHAINS[c];
    if (!ch) return `<span class="text-[10px] text-mut capitalize">${F.esc(c)}</span>`;
    if (c === 'pulsechain')
      return `<span class="inline-flex items-center gap-1 text-[10px] font-semibold pls-grad text-white rounded px-1.5 ${lg?'py-0.5':'py-px'}">◆ PulseChain</span>`;
    return `<span class="inline-flex items-center gap-1 text-[10px] rounded px-1.5 ${lg?'py-0.5':'py-px'} border" style="color:${ch.color};border-color:${ch.color}55;background:${ch.color}14">● ${ch.name}</span>`;
  }
  function star(key){
    const on = CDX.Store.state.watch.has(key);
    return `<button data-star="${key}" aria-label="Toggle watchlist" class="text-base leading-none ${on?'text-gold':'text-mut/50 hover:text-gold'} transition-colors px-1">${on?'★':'☆'}</button>`;
  }
  function statCard(label, val, sub, bar){
    return `<div class="bg-panel border border-line rounded-xl px-4 py-3">
      <div class="text-[11px] uppercase tracking-wider text-mut mb-1">${label}</div>
      <div class="font-disp font-bold text-white text-xl num">${val}</div>
      <div class="text-[11px] text-mut mt-0.5">${sub || ''}</div>
      ${bar ? `<div class="h-1 bg-line rounded-full mt-2 overflow-hidden"><div class="h-full rounded-full" style="width:${bar.pct}%;background:${bar.color}"></div></div>` : ''}
    </div>`;
  }
  function sparkline(id, ch7d, W, H){
    W = W || 110; H = H || 34;
    let pts = CDX.LiveData && CDX.LiveData.sparkOf && CDX.LiveData.sparkOf(id);
    if (pts && pts.length > 10){
      const step = Math.max(1, Math.floor(pts.length / 28));
      pts = pts.filter((_, i) => i % step === 0);
    } else {
      const rnd = F.mulberry32(F.seedOf(id));
      const n = 24, drift = (ch7d/100)/n; let v = 1; pts = [];
      for (let i=0;i<n;i++){ v *= 1 + drift + (rnd()-0.5)*0.014; pts.push(v); }
      pts[n-1] = 1 + ch7d/100;
    }
    const len = pts.length;
    const min = Math.min(...pts), max = Math.max(...pts), rng = (max - min) || 1;
    const X = i => (i / (len - 1) * W).toFixed(1);
    const Y = p => (H - 2 - (p - min) / rng * (H - 4)).toFixed(1);
    const d = pts.map((p, i) => (i ? 'L' : 'M') + X(i) + ',' + Y(p)).join('');
    const col = ch7d >= 0 ? '#2DD480' : '#FF5C5C';
    const gid = 'sg' + String(id).replace(/[^a-zA-Z0-9]/g, '');
    return `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" aria-hidden="true">
      <defs><linearGradient id="${gid}" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="${col}" stop-opacity="0.28"/><stop offset="100%" stop-color="${col}" stop-opacity="0"/></linearGradient></defs>
      <path d="${d} L ${W},${H} L 0,${H} Z" fill="url(#${gid})" stroke="none"/>
      <path d="${d}" fill="none" stroke="${col}" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round"/>
      <circle cx="${X(len - 1)}" cy="${Y(pts[len - 1])}" r="1.8" fill="${col}"/></svg>`;
  }
  function badge(text, tone){
    const map = { up:'bg-up/15 text-up border-up/40', gold:'bg-gold/15 text-gold border-gold/40', acc:'bg-acc/15 text-acc border-acc/40' };
    return `<span class="ml-1.5 text-[9px] font-bold border rounded px-1 py-px align-middle ${map[tone]||map.acc}">${text}</span>`;
  }
  function toast(msg, kind){
    const colors = { up:'border-up/50 text-up', down:'border-down/50 text-down', warn:'border-gold/50 text-gold' };
    const host = CDX.Dom.$('#toasts');
    const el = CDX.Dom.el('div', `bg-panel border ${colors[kind]||'border-line text-slate-200'} rounded-lg px-3.5 py-2.5 text-sm shadow-xl shadow-black/40`, CDX.Fmt.esc(msg));
    host.appendChild(el);
    setTimeout(()=>{ el.style.transition='opacity .4s'; el.style.opacity='0'; setTimeout(()=>el.remove(), 420); }, 2600);
  }
  function copy(text){
    const done = () => toast('Contract address copied', 'up');
    const fallback = () => {
      const ta = CDX.Dom.el('textarea'); ta.value = text; ta.style.cssText = 'position:fixed;opacity:0';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); done(); } catch(e){ toast('Copy failed','warn'); }
      ta.remove();
    };
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done).catch(fallback);
    else fallback();
  }
  return { logo, chainBadge, star, statCard, sparkline, badge, toast, copy };
})();
