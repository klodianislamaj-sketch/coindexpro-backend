/* CDX.Palette — global command palette (Ctrl/Cmd+K), go-to shortcuts (g + key), help overlay (?). */
CDX.Palette = (() => {
  const D = CDX.Dom, F = CDX.Fmt;
  const PAGES = [
    ['Home','/'],['Markets','/markets'],['DEX Screener','/dex'],['Advanced Screener','/screener'],
    ['Heatmaps','/heatmaps/market'],['Terminal · Movers','/terminal/movers'],['Terminal · Trending','/terminal/trending'],
    ['Terminal · New Listings','/terminal/new'],['Terminal · Rotation','/terminal/rotation'],
    ['Terminal · Cross-Chain','/terminal/compare'],['Chains','/chains'],['Whales','/whales'],
    ['Narratives','/narratives'],['PulseChain Hub','/pulsechain'],['Watchlists','/watchlist'],
    ['Portfolio','/portfolio'],['Research Suite','/research'],['Alpha Discovery','/alpha'],['Wallet Intelligence','/wallets'],['Liquidity Intelligence','/liquidity'],['Social Intelligence','/social'],
    ['Capital Flow Dashboard','/flows/capital'],['Rotation Dashboard','/flows/rotation'],['Liquidity Migration Dashboard','/flows/migration'],['Alert Engine','/alerts'],['Institutional Layer','/quant']
  ];
  const KEYS = [
    ['Ctrl / ⌘ + K','Command palette'],['/','Focus search'],['?','Shortcuts help'],['Esc','Close overlays'],
    ['g h','Home'],['g m','Markets'],['g d','DEX Screener'],['g s','Advanced Screener'],['g e','Heatmaps'],
    ['g t','Terminal'],['g c','Chains'],['g w','Whales'],['g n','Narratives'],['g p','PulseChain Hub'],['g l','Watchlists'],['g o','Portfolio'],['g r','Research'],['g a','Alpha Discovery'],['g i','Wallet Intelligence'],['g q','Liquidity Intelligence'],['g x','Social Intelligence'],['g f','Capital Flows'],['g b','Alerts'],['g u','Institutional / Quant']
  ];
  const GO = { h:'/', m:'/markets', d:'/dex', s:'/screener', e:'/heatmaps/market', t:'/terminal/movers',
               c:'/chains', w:'/whales', n:'/narratives', p:'/pulsechain', l:'/watchlist', o:'/portfolio', r:'/research', a:'/alpha', i:'/wallets', q:'/liquidity', x:'/social', f:'/flows/capital', b:'/alerts', u:'/quant' };
  let overlay, input, list, items = [], sel = 0, open = false, helpEl = null, gAt = 0;

  function commands(q){
    const out = [];
    if (!q){
      PAGES.forEach(([label, path]) => out.push({ kind:'Page', label, go: path }));
      return out.slice(0, 12);
    }
    const lq = q.toLowerCase();
    PAGES.forEach(([label, path]) => { if (label.toLowerCase().includes(lq)) out.push({ kind:'Page', label, go: path }); });
    CDX.Data.CHAIN_ORDER.forEach(id => {
      if (CDX.Data.CHAINS[id].name.toLowerCase().includes(lq)) out.push({ kind:'Chain', label: CDX.Data.CHAINS[id].name + ' Intelligence', go: '/chain/' + id });
    });
    CDX.DataRaw.NARRATIVE_ORDER.forEach(id => {
      const n = CDX.DataRaw.NARRATIVES[id];
      if (n.name.toLowerCase().includes(lq)) out.push({ kind:'Narrative', label: n.name + ' narrative', go: '/narrative/' + id });
    });
    CDX.DataRaw.WALLETS.forEach(w => {
      if (w.label.toLowerCase().includes(lq)) out.push({ kind:'Wallet', label: w.label, sub: w.type, go: '/wallet/' + w.addr });
    });
    CDX.Data.search(q, 8).forEach(h => {
      const isCoin = h.type === 'coin';
      out.push({ kind: isCoin ? 'Token' : 'Pair', label: CDX.Data.label(h.it), sub: h.it.name,
        pct: CDX.Data.ch24(h.it), go: isCoin ? '/token/' + h.it.id : '/pair/' + h.it.id });
    });
    return out.slice(0, 14);
  }
  function render(){
    list.innerHTML = items.map((c, i) => `
      <div data-pi="${i}" class="flex items-center gap-3 px-4 py-2.5 cursor-pointer ${i===sel?'bg-panel2':''}">
        <span class="text-[9px] font-bold uppercase tracking-wider text-mut border border-line rounded px-1.5 py-0.5 w-20 text-center shrink-0">${c.kind}</span>
        <span class="text-sm text-white font-medium">${F.esc(c.label)}</span>
        ${c.sub ? `<span class="text-[11px] text-mut truncate">${F.esc(c.sub)}</span>` : ''}
        ${c.pct != null ? `<span class="ml-auto num text-xs ${F.cls(c.pct)}">${F.pctAuto(c.pct)}</span>` : ''}
      </div>`).join('') || '<div class="px-4 py-4 text-sm text-mut">No matches</div>';
    const cur = list.querySelector(`[data-pi="${sel}"]`);
    if (cur) cur.scrollIntoView({ block: 'nearest' });
  }
  function show(){
    open = true; overlay.classList.remove('hidden');
    input.value = ''; sel = 0; items = commands(''); render(); input.focus();
  }
  function hide(){ open = false; overlay.classList.add('hidden'); }
  function exec(c){ if (!c) return; hide(); CDX.Router.go(c.go); }
  function showHelp(){
    if (!helpEl){
      helpEl = D.el('div', 'fixed inset-0 z-[85] modal-bg hidden', `
        <div class="min-h-full flex items-center justify-center p-4" data-help-bg>
          <div class="bg-panel border border-line rounded-2xl w-full max-w-md shadow-2xl shadow-black/60 p-5">
            <div class="flex items-center justify-between mb-4">
              <h3 class="font-disp font-semibold text-white">Keyboard Shortcuts</h3>
              <button data-help-x class="text-mut hover:text-white">✕</button></div>
            <div class="grid grid-cols-1 gap-1.5">${KEYS.map(([k,d]) => `
              <div class="flex items-center justify-between text-sm">
                <span class="num text-[12px] bg-panel2 border border-line rounded px-2 py-0.5 text-slate-300">${k}</span>
                <span class="text-mut text-[12px]">${d}</span></div>`).join('')}</div></div></div>`);
      document.body.appendChild(helpEl);
      helpEl.addEventListener('click', e => {
        if (e.target.closest('[data-help-x]') || e.target.dataset.helpBg != null) helpEl.classList.add('hidden');
      });
    }
    helpEl.classList.toggle('hidden');
  }
  function init(){
    overlay = D.el('div', 'fixed inset-0 z-[80] modal-bg hidden');
    overlay.innerHTML = `<div class="min-h-full flex items-start justify-center pt-[12vh] px-4" data-pal-bg>
      <div class="bg-panel border border-line rounded-2xl w-full max-w-xl shadow-2xl shadow-black/60 overflow-hidden">
        <div class="flex items-center gap-2 px-4 border-b border-line">
          <span class="text-mut">⌘</span>
          <input data-pal-input type="text" placeholder="Jump to page, token, pair, chain, narrative, wallet…"
            class="w-full bg-transparent py-3 text-sm text-white placeholder:text-mut/70 focus:outline-none" autocomplete="off">
          <span class="text-[10px] text-mut border border-line rounded px-1.5 py-0.5">ESC</span></div>
        <div data-pal-list class="max-h-[50vh] overflow-y-auto"></div></div></div>`;
    document.body.appendChild(overlay);
    input = overlay.querySelector('[data-pal-input]');
    list  = overlay.querySelector('[data-pal-list]');
    input.addEventListener('input', () => { items = commands(input.value.trim()); sel = 0; render(); });
    list.addEventListener('click', e => { const t = e.target.closest('[data-pi]'); if (t) exec(items[+t.dataset.pi]); });
    overlay.addEventListener('click', e => { if (e.target.dataset.palBg != null) hide(); });
    document.addEventListener('keydown', e => {
      const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName) || e.target.isContentEditable;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k'){ e.preventDefault(); open ? hide() : show(); return; }
      if (open){
        if (e.key === 'Escape'){ hide(); return; }
        if (e.key === 'ArrowDown'){ e.preventDefault(); sel = Math.min(items.length-1, sel+1); render(); }
        if (e.key === 'ArrowUp'){ e.preventDefault(); sel = Math.max(0, sel-1); render(); }
        if (e.key === 'Enter'){ e.preventDefault(); exec(items[sel]); }
        return;
      }
      if (typing) return;
      if (e.key === '?'){ e.preventDefault(); showHelp(); return; }
      if (e.key === 'g'){ gAt = Date.now(); return; }
      if (Date.now() - gAt < 800 && GO[e.key]){ e.preventDefault(); gAt = 0; CDX.Router.go(GO[e.key]); }
    });
  }
  init();
  return { show, hide };
})();
