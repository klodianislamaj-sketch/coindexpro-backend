/* CDX.TrustUI — presentational renderers that surface the trust/confidence
   engines into pages. Pure HTML-string builders, no data of their own — they
   read CDX.TrustScore, CDX.Asset (freshness/source), and CDX.SmartMoney. Every
   number shown traces to a real engine output or renders "Unavailable". */
CDX.TrustUI = (() => {
  const F = CDX.Fmt;

  function bar(pct, color){
    const w = Math.max(0, Math.min(100, pct || 0));
    return `<div class="h-1.5 rounded-full bg-panel2 overflow-hidden"><div class="h-full rounded-full" style="width:${w}%;background:${color}"></div></div>`;
  }

  /* freshness + source confidence chip from the normalized Asset layer */
  function sourceChip(asset){
    const f = CDX.Asset.freshness(asset);
    const src = asset && asset.source ? asset.source : 'unknown';
    return `<span class="inline-flex items-center gap-1 text-[10px] num border border-line rounded px-1.5 py-0.5 ${f.cls}">
      <span class="w-1.5 h-1.5 rounded-full ${f.cls === 'text-up' ? 'bg-up' : f.cls === 'text-gold' ? 'bg-gold' : 'bg-mut'}"></span>${f.label} · ${F.esc(src)}</span>`;
  }

  /* full explainable trust panel for a pair */
  function trustPanel(pairId){
    const t = CDX.TrustScore ? CDX.TrustScore.score(pairId) : null;
    if (!t || !t.available){
      return `<div class="text-sm text-mut">Trust score unavailable — insufficient real signals.</div>`;
    }
    const color = t.trust >= 70 ? '#2DD480' : t.trust >= 40 ? '#F5C04E' : '#FF5C5C';
    const confCls = t.confidence === 'high' ? 'text-up' : t.confidence === 'medium' ? 'text-gold' : 'text-mut';
    const factorRows = t.factors.map(f => {
      if (!f.available) return `<div class="flex items-center gap-2 text-[11px] py-1 opacity-60">
        <span class="text-mut w-36">${F.esc(f.label)}</span>
        <span class="text-mut flex-1">${F.esc(f.reason)}</span>
        <span class="num text-mut">Unavailable</span></div>`;
      const pctF = f.max ? (f.points / f.max) * 100 : 0;
      return `<div class="text-[11px] py-1">
        <div class="flex items-center gap-2">
          <span class="text-slate-300 w-36">${F.esc(f.label)}</span>
          <div class="flex-1">${bar(pctF, pctF >= 60 ? '#2DD480' : pctF >= 30 ? '#F5C04E' : '#FF5C5C')}</div>
          <span class="num text-slate-300 w-12 text-right">${f.points}/${f.max}</span></div>
        <div class="text-[10px] text-mut mt-0.5 ml-[9.5rem]">${F.esc(f.reason)}</div></div>`;
    }).join('');
    return `<div class="space-y-3">
      <div class="flex items-end gap-3">
        <div><div class="num font-disp font-bold text-3xl" style="color:${color}">${t.trust}<span class="text-mut text-lg">/100</span></div>
        <div class="text-[10px] uppercase tracking-wide ${confCls}">${t.confidence} confidence · ${t.factorsAvailable}/${t.factorsTotal} signals</div></div>
        <span class="ml-auto text-[10px] text-mut border border-line rounded px-1.5 py-0.5">heuristic</span></div>
      <div class="border-t border-line/50 pt-2">${factorRows}</div>
      <div class="text-[10px] text-mut">${F.esc(t.note)}</div></div>`;
  }

  /* whale participation summary for a pair (observed-only, real) */
  function whaleParticipation(pairId){
    const raw = (CDX.WhaleFlow && CDX.WhaleFlow.raw && CDX.WhaleFlow.raw()) || [];
    const onPair = raw.filter(t => t.pairId === pairId);
    if (!onPair.length) return `<div class="text-[11px] text-mut">No large trades observed yet.</div>`;
    const buys = onPair.filter(t => t.side === 'buy'), sells = onPair.filter(t => t.side === 'sell');
    const bv = buys.reduce((a, t) => a + t.usd, 0), sv = sells.reduce((a, t) => a + t.usd, 0);
    const wallets = new Set(onPair.map(t => t.wallet)).size;
    return `<div class="grid grid-cols-3 gap-2 text-center">
      <div><div class="num text-up text-sm font-semibold">${F.usd(bv)}</div><div class="text-[9px] text-mut uppercase">whale buys</div></div>
      <div><div class="num text-down text-sm font-semibold">${F.usd(sv)}</div><div class="text-[9px] text-mut uppercase">whale sells</div></div>
      <div><div class="num text-white text-sm font-semibold">${onPair.length} · ${wallets}</div><div class="text-[9px] text-mut uppercase">prints · wallets</div></div></div>`;
  }

  /* compact trust/confidence badges for search results */
  function searchBadges(it, isCoin){
    if (isCoin) return '';
    const a = CDX.Asset.resolve('d:' + it.id);
    const f = CDX.Asset.freshness(a);
    const liq = it.liq || 0;
    const liqTier = liq >= 1e6 ? ['deep', 'text-up'] : liq >= 100e3 ? ['mid', 'text-gold'] : ['thin', 'text-mut'];
    return `<span class="num text-[9px] ${f.cls}">${f.label}</span>
      <span class="num text-[9px] ${liqTier[1]}" title="liquidity ${F.usd(liq)}">${liqTier[0]}</span>`;
  }

  return { trustPanel, whaleParticipation, sourceChip, searchBadges, bar };
})();
