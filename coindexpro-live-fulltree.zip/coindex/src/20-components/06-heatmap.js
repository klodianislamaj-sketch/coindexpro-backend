/* CDX.Heatmap — dependency-free squarified treemap with optional grouping.
   items: [{ id, label, sub, value, ch, go }]  ·  groups: [{ label, color, items }] */
CDX.Heatmap = (() => {
  const F = CDX.Fmt;
  function colorFor(ch, maxAbs){
    const m = maxAbs || 8;
    const t = Math.min(1, Math.abs(ch) / m);
    const a = 0.14 + 0.6 * t;
    return ch >= 0 ? `rgba(45,212,128,${a.toFixed(2)})` : `rgba(255,92,92,${a.toFixed(2)})`;
  }
  /* squarified layout → [{x,y,w,h,item}] */
  function layout(items, x, y, w, h){
    const total = items.reduce((a,i)=>a+i.value,0) || 1;
    const scaled = items.map(i => ({ item: i, area: i.value / total * w * h })).filter(s => s.area > 0);
    const out = [];
    let rx = x, ry = y, rw = w, rh = h, row = [], rowArea = 0;
    const worst = (row, side) => {
      const s = row.reduce((a,r)=>a+r.area,0);
      let mx = 0;
      for (const r of row){
        const ratio = Math.max((side*side*r.area)/(s*s), (s*s)/(side*side*r.area));
        if (ratio > mx) mx = ratio;
      }
      return mx;
    };
    const flush = () => {
      const horiz = rw < rh;                       // lay row along the shorter side
      const side = horiz ? rw : rh;
      const thick = rowArea / side;
      let off = 0;
      for (const r of row){
        const len = r.area / thick;
        out.push(horiz
          ? { x: rx + off, y: ry, w: len, h: thick, item: r.item }
          : { x: rx, y: ry + off, w: thick, h: len, item: r.item });
        off += len;
      }
      if (horiz){ ry += thick; rh -= thick; } else { rx += thick; rw -= thick; }
      row = []; rowArea = 0;
    };
    for (const s of scaled){
      const side = Math.min(rw, rh);
      if (row.length && worst([...row, s], side) > worst(row, side)) flush();
      row.push(s); rowArea += s.area;
    }
    if (row.length) flush();
    return out;
  }
  function cellHtml(c, maxAbs){
    const big = c.w > 88 && c.h > 52, mid = c.w > 54 && c.h > 32;
    const fs = Math.max(10, Math.min(17, Math.sqrt(c.w * c.h) / 7));
    return `<div data-go="${c.item.go || ''}" class="absolute overflow-hidden flex flex-col items-center justify-center text-center transition-opacity hover:opacity-85 ${c.item.go?'cursor-pointer':''}"
      style="left:${c.x}px;top:${c.y}px;width:${c.w-2}px;height:${c.h-2}px;background:${colorFor(c.item.ch, maxAbs)};border:1px solid #0A0D14;border-radius:4px"
      title="${F.esc(c.item.label)} · ${F.pctAuto(c.item.ch)}${c.item.sub ? ' · ' + F.esc(c.item.sub) : ''}">
      ${mid ? `<span class="font-disp font-bold text-white leading-tight" style="font-size:${fs}px">${F.esc(c.item.label)}</span>` : ''}
      ${mid ? `<span class="num text-white/90 leading-tight" style="font-size:${Math.max(9, fs-4)}px">${F.pctAuto(c.item.ch)}</span>` : ''}
      ${big && c.item.sub ? `<span class="num text-white/70" style="font-size:${Math.max(8, fs-6)}px">${F.esc(c.item.sub)}</span>` : ''}</div>`;
  }
  function render(container, items, opts){
    const o = opts || {};
    const W = container.clientWidth || 800, H = o.height || 540;
    container.style.position = 'relative';
    container.style.height = H + 'px';
    container.innerHTML = layout(items.filter(i=>i.value>0).sort((a,b)=>b.value-a.value), 0, 0, W, H)
      .map(c => cellHtml(c, o.maxAbs)).join('');
  }
  function renderGrouped(container, groups, opts){
    const o = opts || {};
    const W = container.clientWidth || 800, H = o.height || 600, HEAD = 20;
    container.style.position = 'relative';
    container.style.height = H + 'px';
    const gItems = groups.map(g => ({ value: Math.max(1, g.items.reduce((a,i)=>a+i.value,0)), g }))
                         .sort((a,b)=>b.value-a.value);
    const rects = layout(gItems.map(x => ({ ...x, ch: 0 })), 0, 0, W, H);
    let html = '';
    for (const r of rects){
      const g = r.item.g;
      html += `<div class="absolute" style="left:${r.x}px;top:${r.y}px;width:${r.w-2}px;height:${r.h-2}px;border:1px solid ${g.color}66;border-radius:6px;overflow:hidden">
        <div class="px-2 flex items-center justify-between" style="height:${HEAD}px;background:${g.color}1f">
          <span class="text-[10px] font-bold uppercase tracking-wider" style="color:${g.color}">${F.esc(g.label)}</span>
          <span class="num text-[9px] text-mut">${F.usd(g.items.reduce((a,i)=>a+i.value,0))}</span></div>
        <div class="relative" style="height:${r.h-2-HEAD}px">`;
      if (r.w > 40 && r.h - HEAD > 24)
        html += layout([...g.items].sort((a,b)=>b.value-a.value), 0, 0, r.w-2, r.h-2-HEAD)
          .map(c => cellHtml(c, o.maxAbs)).join('');
      html += '</div></div>';
    }
    container.innerHTML = html;
  }
  return { render, renderGrouped, colorFor };
})();
