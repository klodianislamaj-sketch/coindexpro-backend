/* CDX.Chart — TradingView Lightweight Charts wrapper: candles + volume, timeframes, live bar updates.
   Used by token and pair pages. Always destroy() on page unmount. */
CDX.Chart = (() => {
  /* Normalize a candle series once before render:
     - timestamps to Unix SECONDS (Lightweight Charts intraday unit). Both providers
       already emit seconds (CG divides ms→s; GT is native seconds), so we only convert
       a value that is unambiguously milliseconds (> 1e12) — prevents double conversion.
     - drop non-finite OHLC, enforce strictly increasing time (de-dupe equal stamps),
       align the volume array to surviving candle times. */
  function sanitizeSeries(s){
    const toSec = t => (t > 1e12 ? Math.floor(t / 1000) : Math.floor(t));
    const seen = new Set();
    const candles = [];
    for (const c of (s.candles || [])){
      if (!c) continue;
      const time = toSec(c.time);
      const { open, high, low, close } = c;
      if (![time, open, high, low, close].every(Number.isFinite)) continue;
      if (time <= 0 || seen.has(time)) continue;       // strictly monotonic, no dupes
      seen.add(time);
      candles.push({ time, open, high, low, close });
    }
    candles.sort((a, b) => a.time - b.time);
    const okTimes = new Set(candles.map(c => c.time));
    const volumes = (s.volumes || [])
      .map(v => ({ time: toSec(v.time), value: v.value, color: v.color }))
      .filter(v => Number.isFinite(v.time) && Number.isFinite(v.value) && okTimes.has(v.time));
    // de-dupe volume to one row per time, preserving order
    const vseen = new Set();
    const vol = [];
    for (const v of volumes){ if (vseen.has(v.time)) continue; vseen.add(v.time); vol.push(v); }
    return { candles, volumes: vol };
  }
  function precisionFor(p){
    if (p >= 1000) return 0;
    if (p >= 1) return 2;
    if (p >= 0.01) return 4;
    const m = p.toFixed(18).match(/^0\.(0*)/);
    return Math.min(12, (m ? m[1].length : 4) + 4);
  }
  function create(container, key, item){
    const isCoin = !!item.sym;
    let tf = CDX.Store.state.prefs.chartTf || '1H';
    if (typeof LightweightCharts === 'undefined'){
      container.innerHTML = '<div class="h-full grid place-items-center text-mut text-sm">Chart engine failed to load — check your connection and refresh.</div>';
      return { setTf(){}, getTf: () => tf, destroy(){} };
    }
    const prec = precisionFor(item.price);
    container.style.transition = 'opacity 140ms ease';
    const chart = LightweightCharts.createChart(container, {
      handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: false },
      handleScale:  { mouseWheel: true, pinch: true, axisPressedMouseMove: true },
      kineticScroll: { touch: true, mouse: false },
      autoSize: false,
      width: container.clientWidth,
      height: container.clientHeight || 420,
      layout: { background: { color: 'transparent' }, textColor: '#8B94A7',
                fontFamily: "'JetBrains Mono', monospace", fontSize: 11 },
      grid: { vertLines: { color: '#161B27' }, horzLines: { color: '#161B27' } },
      rightPriceScale: { borderColor: '#1F2633' },
      timeScale: { borderColor: '#1F2633', timeVisible: true, secondsVisible: false },
      crosshair: { mode: 0,
        vertLine: { color: '#5B8CFF55', labelBackgroundColor: '#222B3D' },
        horzLine: { color: '#5B8CFF55', labelBackgroundColor: '#222B3D' } }
    });
    const candles = chart.addCandlestickSeries({
      upColor: '#2DD480', downColor: '#FF5C5C', borderVisible: false,
      wickUpColor: '#2DD480', wickDownColor: '#FF5C5C',
      priceFormat: { type: 'price', precision: prec, minMove: 1 / Math.pow(10, prec) }
    });
    const volume = chart.addHistogramSeries({ priceFormat: { type: 'volume' }, priceScaleId: '' });
    chart.priceScale('').applyOptions({ scaleMargins: { top: 0.82, bottom: 0 } });

    let destroyed = false;
    function load(){
      container.style.opacity = '0.45';
      const note = container.querySelector('[data-chart-note]');
      if (note) note.remove();
      candles.setData([]); volume.setData([]);
      CDX.LiveData.candles(key, tf, item).then(s => {
        if (destroyed) return;
        const { candles: cd, volumes: vol } = sanitizeSeries(s);
        if (!cd.length){
          container.insertAdjacentHTML('beforeend',
            '<div data-chart-note class="absolute inset-0 grid place-items-center text-mut text-sm pointer-events-none">No candle history for this pool yet.</div>');
          container.style.opacity = '1';
          return;
        }
        candles.setData(cd);
        volume.setData(vol);
        chart.timeScale().fitContent();
        container.style.opacity = '1';
      }).catch(e => {
        if (!destroyed) container.insertAdjacentHTML('beforeend',
          '<div data-chart-note class="absolute inset-0 grid place-items-center text-mut text-sm pointer-events-none">Candle feed unavailable for this timeframe.</div>');
      });
    }
    container.style.position = 'relative';
    load();

    const unsubTick = CDX.Bus.on('tick', changed => {
      if (destroyed || !changed.some(c => c.key === key)) return;
      const bar = CDX.LiveData.lastBar(key, tf);
      if (bar) candles.update(bar);
    });
    let roRaf = null;
    const ro = new ResizeObserver(() => {
      if (roRaf) cancelAnimationFrame(roRaf);
      roRaf = requestAnimationFrame(() => chart.applyOptions({ width: container.clientWidth }));
    });
    ro.observe(container);

    return {
      setTf(next){ tf = next; CDX.Store.setPref('chartTf', next); load(); },
      getTf: () => tf,
      destroy(){ destroyed = true; unsubTick(); ro.disconnect(); chart.remove(); }
    };
  }
  return { create, TFS: ['1m','15m','1H','4H','1D'] };
})();
