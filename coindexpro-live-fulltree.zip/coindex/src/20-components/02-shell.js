/* CDX.Shell — navbar, live ticker tape, search typeahead, global delegation, footer. */
CDX.Shell = (() => {
  const D = CDX.Dom, F = CDX.Fmt;
  const NAV = [
    { path: '/',          label: 'Home',         match: p => p === '/' },
    { path: '/markets',   label: 'Markets',      match: p => p.startsWith('/markets') || p.startsWith('/token') },
    { path: '/dex',       label: 'DEX Screener', match: p => p.startsWith('/dex') || p.startsWith('/pair') },
    { path: '/pulsechain', label: '◆ PulseChain', match: p => p.startsWith('/pulsechain') },
    { path: '/chains',     label: 'Chains',       match: p => p.startsWith('/chain') },
    /* DISABLED for production — whale/wallet data is not yet from a real on-chain source
    { path: '/wallets',    label: 'Wallets',      match: p => p.startsWith('/wallets') },
    */
    { path: '/liquidity',  label: 'Liquidity',    match: p => p.startsWith('/liquidity') },
    { path: '/social',     label: 'Social',       match: p => p.startsWith('/social') },
    { path: '/flows/capital', label: 'Flows',      match: p => p.startsWith('/flows') },
    { path: '/alerts',     label: '🔔 Alerts',     match: p => p.startsWith('/alerts') },
    { path: '/quant',      label: 'Quant',        match: p => p.startsWith('/quant') },
    { path: '/whales',     label: 'Whales',       match: p => p.startsWith('/whales') },
    { path: '/smart-money', label: '✦ Smart Money', match: p => p.startsWith('/smart-money') },
    { path: '/narratives', label: 'Narratives',   match: p => p.startsWith('/narrative') },
    { path: '/alpha',      label: '✦ Alpha',      match: p => p.startsWith('/alpha') },
    { path: '/screener',   label: 'Screener',     match: p => p.startsWith('/screener') },
    { path: '/heatmaps/market', label: 'Heatmaps', match: p => p.startsWith('/heatmaps') },
    { path: '/terminal/movers', label: 'Terminal', match: p => p.startsWith('/terminal') },
    { path: '/watchlist', label: 'Watchlist',    match: p => p.startsWith('/watchlist') },
    { path: '/portfolio', label: 'Portfolio',    match: p => p.startsWith('/portfolio') },
    { path: '/research',  label: 'Research',     match: p => p.startsWith('/research') || p.startsWith('/news') }
  ];
  function tickerHtml(){
    return ['btc','eth','sol','pls'].map(id => {
      const c = CDX.Data.coins.find(x => x.id === id);
      return `<a href="#/token/${id}" class="hover:text-white transition-colors whitespace-nowrap">
        <span class="text-slate-400">${c.sym}</span>
        <span class="num text-slate-200" data-live="tick:${id}">${F.price(c.price)}</span>
        <span class="num ${F.cls(c.ch24)}">${F.pct(c.ch24,1)}</span></a>`;
    }).join('<span class="text-line">|</span>');
  }
  function mount(root){
    root.innerHTML = `
    <header class="sticky top-0 z-40 bg-ink/95 backdrop-blur border-b border-line">
      <div class="max-w-[1480px] mx-auto px-4">
        <div class="flex items-center gap-3 h-14">
          <a href="#/" data-brand class="flex items-center gap-2 shrink-0" style="-webkit-touch-callout:none">
            <span class="w-7 h-7 rounded-lg pls-grad grid place-items-center font-disp font-bold text-white text-sm">C</span>
            <span class="font-disp font-bold text-lg text-white tracking-tight">CoinDex <span class="text-acc">Pro</span></span>
          </a>
          <div class="hidden lg:flex items-center gap-4 text-[11px] text-mut ml-2" id="ticker"></div>
          <div class="flex-1"></div>
          <div class="relative w-44 sm:w-72 md:w-96">
            <input id="q" type="text" placeholder="Search tokens, pairs, chains…  ( / )" autocomplete="off"
              class="w-full bg-panel border border-line rounded-lg pl-9 pr-3 py-1.5 text-sm placeholder:text-mut/70 focus:border-acc/60 focus:outline-none transition-colors">
            <svg class="w-4 h-4 text-mut absolute left-3 top-1/2 -translate-y-1/2" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
            <div id="qResults" class="hidden absolute top-full mt-1.5 right-0 left-auto sm:left-0 min-w-[300px] sm:min-w-0 bg-panel border border-line rounded-xl shadow-2xl shadow-black/60 overflow-hidden max-h-96 overflow-y-auto z-50"></div>
          </div>
          <div class="hidden sm:flex items-center gap-1.5 text-[11px] text-mut shrink-0">
            <span class="w-2 h-2 rounded-full bg-up live-dot"></span> LIVE
          </div>
        </div>
        <nav class="flex gap-1 overflow-x-auto -mx-1 px-1" id="nav"></nav>
      </div>
    </header>
    <main id="outlet" class="max-w-[1480px] mx-auto px-4 py-5 w-full flex-1"></main>
    <footer class="border-t border-line mt-8">
      <div class="max-w-[1480px] mx-auto px-4 py-5 text-xs text-mut flex flex-col sm:flex-row gap-2 sm:items-center justify-between">
        <span><span class="inline-flex items-center gap-1.5"><span class="w-1.5 h-1.5 rounded-full bg-up live-dot"></span><span class="text-slate-300 font-medium">Live data</span></span>
          · CoinGecko · DexScreener · GeckoTerminal · PulseChain RPC · Blockscout · Binance WS
          <span class="text-mut/70">— portfolio &amp; trade journal are simulated · not financial advice.</span></span>
        <span class="font-disp shrink-0">CoinDex <span class="text-acc">Pro</span> · <span class="num text-slate-300">v16</span> · Live Terminal Build</span>
      </div>
    </footer>
    <div id="toasts" class="fixed bottom-4 right-4 z-[70] space-y-2 w-72"></div>`;

    D.$('#ticker').innerHTML = tickerHtml();
    renderNav(CDX.Router.path ? CDX.Router.path() : '/');
    D.$('#nav').addEventListener('click', e => {
      const b = e.target.closest('[data-nav]');
      if (!b) return;
      e.preventDefault();
      CDX.Router.go(b.dataset.nav);
    });
    let metaTick = 0;
    CDX.Bus.on('tick', () => {           // live titles on asset routes, throttled
      if (++metaTick % 10 !== 0) return;
      const p = CDX.Router.path();
      if (p.startsWith('/token/') || p.startsWith('/pair/')) applyMeta();
    });
    CDX.Bus.on('data:ready', applyMeta);
    CDX.Bus.on('route:changed', () => {
      applyMeta();
      renderNav(CDX.Router.path());
      const res = D.$('#qResults'), q = D.$('#q');                 // close open popovers after navigation
      if (res) res.classList.add('hidden');
      if (q && document.activeElement === q) q.blur();             // mobile: dismiss keyboard
    });
    let tickN = 0;
    CDX.Bus.on('tick', changed => {
      if (++tickN % 8 === 0){ D.$('#ticker').innerHTML = tickerHtml(); return; }
      for (const { key, dir } of changed){
        if (!key.startsWith('c:')) continue;
        const node = D.$(`#ticker [data-live="tick:${key.slice(2)}"]`);
        if (node) D.liveSet(node, F.price(CDX.Data.byKey(key).price), dir);
      }
    });
    CDX.Bus.on('data:ready', () => { D.$('#ticker').innerHTML = tickerHtml(); });

    /* search typeahead */
    const q = D.$('#q'), res = D.$('#qResults');
    let qTimer = null;
    q.addEventListener('input', () => {
      clearTimeout(qTimer);
      qTimer = setTimeout(() => {
        const v = q.value.trim();
        if (!v){ res.classList.add('hidden'); return; }
        const hits = CDX.Data.search(v);
        res.innerHTML = hits.length ? hits.map(h => {
          const it = h.it, isCoin = h.type === 'coin';
          return `<a href="${isCoin ? '#/token/' + it.id : '#/pair/' + it.id}" class="flex items-center gap-2.5 px-3 py-2.5 hover:bg-panel2 border-b border-line/50 last:border-0">
            ${CDX.UI.logo(isCoin ? it.sym : it.base, isCoin ? it.color : CDX.Data.CHAINS[it.chain].color, 6)}
            <span class="text-sm text-white font-medium">${F.esc(CDX.Data.label(it))}</span>
            <span class="text-[11px] text-mut truncate">${F.esc(it.name)}</span>
            <span class="ml-auto flex items-center gap-2">
              ${CDX.TrustUI ? CDX.TrustUI.searchBadges(it, isCoin) : ''}
              ${!isCoin ? CDX.UI.chainBadge(it.chain) : ''}
              <span class="num text-xs ${F.cls(CDX.Data.ch24(it))}">${F.pctAuto(CDX.Data.ch24(it))}</span>
            </span></a>`;
        }).join('') : '<div class="px-3 py-3 text-sm text-mut">No results</div>';
        res.classList.remove('hidden');
      }, 120);
    });
    document.addEventListener('click', e => { if (!e.target.closest('#q') && !e.target.closest('#qResults')) res.classList.add('hidden'); });
    res.addEventListener('click', () => { res.classList.add('hidden'); q.value = ''; q.blur(); });
    document.addEventListener('keydown', e => {
      const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName) || e.target.isContentEditable;
      if (e.key === '/' && !typing && document.activeElement !== q){ e.preventDefault(); q.focus(); }
      if (e.key === 'Escape') res.classList.add('hidden');
    });

    /* global delegation: watch stars + CA copy work on every page */
    document.addEventListener('click', e => {
      const star = e.target.closest('[data-star]');
      if (star){ e.preventDefault(); e.stopPropagation(); CDX.Store.toggleWatch(star.dataset.star); return; }
      const cp = e.target.closest('[data-copy]');
      if (cp){ e.preventDefault(); e.stopPropagation(); CDX.UI.copy(cp.dataset.copy); }
    }, true);
    CDX.Bus.on('watch:changed', key => {
      const sync = b => {
        const on = CDX.Store.state.watch.has(b.dataset.star);
        b.className = `text-base leading-none ${on?'text-gold':'text-mut/50 hover:text-gold'} transition-colors px-1`;
        b.textContent = on ? '★' : '☆';
      };
      if (!key){ D.$$('[data-star]').forEach(sync); return; }   // active-list switch: resync all stars
      D.$$(`[data-star="${key}"]`).forEach(sync);
      const it = CDX.Data.byKey(key);
      if (it) CDX.UI.toast((CDX.Store.state.watch.has(key) ? '★ Added to' : 'Removed from') + ' watchlist: ' + CDX.Data.label(it), CDX.Store.state.watch.has(key) ? 'up' : undefined);
    });
    return D.$('#outlet');
  }
  /* ---- SEO meta engine: per-route titles/descriptions, canonical, OG/Twitter, JSON-LD ---- */
  const SITE = 'CoinDex Pro';
  const STATIC_META = {
    '/':            ['Live Crypto Intelligence Terminal', 'Live markets, DEX pairs, PulseChain, whales, risk, liquidity, flows, alerts and quant — one terminal.'],
    '/markets':     ['Crypto Markets — Top 500 by Market Cap', 'Live prices, 7-day charts, market caps, supply and ATH data for 500+ assets across memecoins, AI, DeFi, RWA, gaming, L1 and L2.'],
    '/dex':         ['DEX Screener — 2000+ Live Pairs', 'Multi-chain DEX pair screener: trending, newest, highest liquidity, volume, buys and sells with live 5m/1h/6h/24h moves.'],
    '/pulsechain':  ['PulseChain Terminal — PLS, PLSX, HEX & Live Pools', 'Live PulseChain blocks, base fee, PulseX and 9MM pools, holders, whale prints and risk scores.'],
    '/chains':      ['Chains — Cross-Chain Market Overview', 'Volume, liquidity and flow across Ethereum, Solana, Base, BNB, Arbitrum, PulseChain and more.'],
    '/wallets':     ['Wallet Intelligence — Leaderboards & Copy Trading', 'Wallet PnL, win rates, behavior models, smart-money clusters and a live copy-trading feed.'],
    '/liquidity':   ['Liquidity Intelligence — LP Events & Migrations', 'Live LP adds and pulls, liquidity migrations, dying pools, concentration and pressure/stability scores.'],
    '/social':      ['Social Intelligence — Momentum & Sentiment', 'X, Telegram and Reddit metrics, social spikes, mention velocity and Social Momentum scores.'],
    '/flows':       ['Capital Flow Engine — Stablecoins, Rotation & Migration', 'Stablecoin issuance, exchange taker flow, chain and sector rotation, whale rotation and the Risk-On bias gauge.'],
    '/alerts':      ['Alert Engine — Price, Whale & On-Chain Alerts', 'Nine alert types delivered to browser, webhook, Telegram and email.'],
    '/quant':       ['Quant Layer — Backtesting & Portfolio Analytics', 'Strategy backtests on real OHLC, correlation and volatility matrices, factor exposure, Sharpe and drawdowns.'],
    '/whales':      ['Whale Tracker — Live Large Prints', 'Real-time whale buys and sells across DEX pools and exchange flow.'],
    '/narratives':  ['Narratives — Sector Flows & Heat', 'Capital flow and momentum across memecoins, AI, DeFi, RWA, gaming and PulseChain.'],
    '/alpha':       ['Alpha Discovery — Early Gems & Smart Money', 'Early gems, fresh liquidity, smart-money accumulation, viral tokens and fresh launches.'],
    '/screener':    ['Screener — Custom Asset Filters', 'Build and save custom screens across the live universe.'],
    '/heatmaps':    ['Heatmaps — Market at a Glance', 'Squarified treemaps of market cap, volume and performance.'],
    '/terminal':    ['Terminal — Multi-Panel Market View', 'Dense multi-panel live market terminal.'],
    '/watchlist':   ['Watchlist', 'Your tracked assets and pairs, live.'],
    '/portfolio':   ['Portfolio (Simulated)', 'Simulated holdings with live pricing and auto-journaling.'],
    '/research':    ['Research — News & Catalysts', 'Market commentary, catalysts and the news stream.']
  };
  function metaFor(){
    const path = CDX.Router.path();
    const seg = '/' + (path.split('/')[1] || '');
    let title, desc;
    if (path.startsWith('/token/')){
      const c = CDX.Data.byKey('c:' + path.split('/')[2]);
      if (c){ title = `${c.sym} ${F.price(c.price)} (${F.pct(c.ch24,1)} 24h) — ${c.name} Price, Chart & Liquidity`;
              desc = `Live ${c.name} (${c.sym}) price ${F.price(c.price)}, market cap ${F.usd(c.mcap)}, 24h volume ${F.usd(c.vol)}, charts, pools and risk analysis.`; }
    } else if (path.startsWith('/pair/')){
      const p = CDX.Data.byKey('d:' + path.split('/').slice(2).join('/'));
      if (p){ title = `${p.base}/${p.quote} ${F.price(p.price)} on ${p.dex} (${CDX.Data.CHAINS[p.chain].name}) — Live Chart & Trades`;
              desc = `${p.base}/${p.quote}: price ${F.price(p.price)}, liquidity ${F.usd(p.liq)}, 24h volume ${F.usd(p.vol)}, ${F.num(p.buys + p.sells)} txns. Live chart, tape, liquidity and risk.`; }
    } else if (path.startsWith('/chain/')){
      const ch = CDX.Data.CHAINS[path.split('/')[2]];
      if (ch){ title = `${ch.name} — Pairs, Liquidity & Flow`; desc = `Live ${ch.name} DEX pairs, liquidity, volume and capital flow.`; }
    } else if (path.startsWith('/narrative/')){
      const n = CDX.DataRaw.NARRATIVES[path.split('/')[2]];
      if (n){ title = `${n.name} Narrative — Flow, Heat & Leaders`; desc = n.desc; }
    } else if (path.startsWith('/wallet/')){
      const a = path.split('/')[2] || '';
      title = `Wallet ${a.slice(0, 8)}… — PnL, Positions & Behavior`;
      desc = 'Observed wallet performance: PnL, win rate, hold times, positions and rotation.';
    } else if (path.startsWith('/flows/')){
      const v = { capital: 'Capital Flow Dashboard', rotation: 'Rotation Dashboard', migration: 'Liquidity Migration Dashboard' }[path.split('/')[2]];
      if (v){ title = v; desc = STATIC_META['/flows'][1]; }
    }
    if (!title){ const m = STATIC_META[path] || STATIC_META[seg] || STATIC_META['/']; title = m[0]; desc = m[1]; }
    return { title: title + ' | ' + SITE, desc };
  }
  function applyMeta(){
    const { title, desc } = metaFor();
    document.title = title;
    const set = (sel, attr, v) => { const el = document.querySelector(sel); if (el) el.setAttribute(attr, v); };
    set('meta[name="description"]', 'content', desc);
    set('#cdxOgTitle', 'content', title); set('#cdxTwTitle', 'content', title);
    set('#cdxOgDesc', 'content', desc);  set('#cdxTwDesc', 'content', desc);
    const base = location.origin === 'null' || location.protocol === 'file:' ? '' : location.origin + location.pathname;
    if (base){ set('#cdxCanonical', 'href', base); set('#cdxOgUrl', 'content', base + location.hash); }
    const ld = document.getElementById('cdxLdRoute');
    if (ld){
      const path = CDX.Router.path();
      const crumbs = [{ '@type': 'ListItem', position: 1, name: SITE, item: (base || './') }];
      path.split('/').filter(Boolean).forEach((seg2, i) => crumbs.push({
        '@type': 'ListItem', position: i + 2, name: decodeURIComponent(seg2),
        item: (base || './') + '#/' + path.split('/').filter(Boolean).slice(0, i + 1).join('/') }));
      ld.textContent = JSON.stringify({ '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: crumbs });
    }
    /* Phase 8: richer structured data for token/pair pages (price-bearing entity).
       Only emitted when we have a VALID live price via the normalized layer —
       never fabricated. Suppressed (cleared) when unavailable. */
    const ldEntity = document.getElementById('cdxLdEntity');
    if (ldEntity){
      let entity = null;
      const path = CDX.Router.path();
      try {
        if (path.startsWith('/token/')){
          const a = CDX.Asset && CDX.Asset.resolve('c:' + path.split('/')[2]);
          const c = CDX.Data.byKey('c:' + path.split('/')[2]);
          if (a && a.valid && c) entity = {
            '@context': 'https://schema.org', '@type': 'FinancialProduct',
            name: `${c.name} (${c.sym})`, category: 'Cryptocurrency',
            url: (base || './') + '#/token/' + c.id };
        } else if (path.startsWith('/pair/')){
          const id = path.split('/').slice(2).join('/');
          const a = CDX.Asset && CDX.Asset.resolve('d:' + id);
          const p = CDX.Data.byKey('d:' + id);
          if (a && a.valid && p) entity = {
            '@context': 'https://schema.org', '@type': 'FinancialProduct',
            name: `${p.base}/${p.quote} on ${p.dex}`, category: 'CryptocurrencyPair',
            url: (base || './') + '#/pair/' + p.id };
        }
      } catch(e){}
      ldEntity.textContent = entity ? JSON.stringify(entity) : '';
    }
  }
  function renderNav(path){
    const nav = D.$('#nav');
    nav.innerHTML = NAV.map(n => {
      const act = n.match(path);
      return `<button data-nav="${n.path}" class="text-sm px-3 py-2 border-b-2 whitespace-nowrap transition-colors ${act ? 'border-acc text-white font-medium nav-active' : 'border-transparent text-mut hover:text-white'}">${n.label}</button>`;
    }).join('');
    const act = nav.querySelector('.nav-active');
    if (act && act.scrollIntoView) try { act.scrollIntoView({ block: 'nearest', inline: 'nearest' }); } catch(e){}
  }
  return { mount };
})();
