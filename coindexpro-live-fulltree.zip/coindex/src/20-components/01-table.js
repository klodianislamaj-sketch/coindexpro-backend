/* CDX.UI.table — generic sortable data table.
   columns: [{ key, label, align, sortable, width, render(row, i) }]
   Live cells: render() may emit elements with data-live="<field>:<rowKey>"; call patch() on ticks
   to update only those nodes (no full re-render → smooth at high tick rates). */
CDX.UI.table = function(cfg){
  const D = CDX.Dom;
  const wrap = D.el('div', 'bg-panel border border-line rounded-xl overflow-hidden');
  const scroll = D.el('div', 'overflow-x-auto ' + (cfg.maxH ? 'overflow-y-auto' : ''));
  if (cfg.maxH) scroll.style.maxHeight = cfg.maxH;
  const table = D.el('table', 'w-full text-sm');
  if (cfg.minWidth) table.style.minWidth = cfg.minWidth;
  const thead = D.el('thead', 'sticky top-0 z-10 bg-panel2 text-mut text-[11px] uppercase tracking-wider shadow-[0_1px_0_0_#1F2633]');
  const tbody = D.el('tbody', 'divide-y divide-line/60');
  table.append(thead, tbody);
  scroll.appendChild(table);
  wrap.appendChild(scroll);

  let rows = cfg.rows || [];
  let sort = cfg.sort || null;

  function renderHead(){
    thead.innerHTML = '<tr class="border-b border-line">' + cfg.columns.map(c => {
      const arrow = sort && sort.key === c.key ? (sort.dir === 1 ? ' ▲' : ' ▼') : '';
      return `<th ${c.sortable ? `data-sort="${c.key}"` : ''}
        style="text-align:${c.align||'left'};${c.width?`width:${c.width}`:''}"
        class="px-3 py-2.5 ${c.cls || ''} ${c.sortable ? 'cursor-pointer select-none hover:text-white' : ''}">${c.label}${arrow}</th>`;
    }).join('') + '</tr>';
  }
  const cellPad = cfg.pad || (cfg.dense ? 'px-3 py-2' : 'px-3 py-3');
  function renderBody(){
    tbody.innerHTML = rows.map((r, i) =>
      `<tr class="row-hov ${i % 2 ? 'bg-white/[0.015]' : ''}" ${cfg.rowAttr ? cfg.rowAttr(r) : ''}>` +
      cfg.columns.map(c => `<td class="${cellPad} ${c.cls || ''}" style="text-align:${c.align||'left'}">${c.render(r, i)}</td>`).join('') +
      '</tr>').join('');
    if (!rows.length && cfg.empty) tbody.innerHTML = `<tr><td colspan="${cfg.columns.length}" class="px-6 py-10 text-center text-mut text-sm">${cfg.empty}</td></tr>`;
  }
  thead.addEventListener('click', e => {
    const th = e.target.closest('[data-sort]');
    if (!th) return;
    const key = th.dataset.sort;
    sort = (sort && sort.key === key) ? { key, dir: -sort.dir } : { key, dir: -1 };
    renderHead();
    if (cfg.onSort) cfg.onSort(sort);
  });
  function setRows(next){ rows = next; renderBody(); }
  /* patch: { '<field>:<rowKey>': { html, dir } } */
  function patch(updates){
    for (const id of Object.keys(updates)){
      const node = tbody.querySelector(`[data-live="${id}"]`);
      if (node) CDX.Dom.liveSet(node, updates[id].html, updates[id].dir);
    }
  }
  renderHead(); renderBody();
  return { el: wrap, body: tbody, setRows, patch, getSort: () => sort };
};
