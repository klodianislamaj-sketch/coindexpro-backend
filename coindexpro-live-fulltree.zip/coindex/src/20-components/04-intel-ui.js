/* CDX.IntelUI — shared Phase 2 components: score gauges, flow panels, whale rows, wallet chips. */
CDX.IntelUI = (() => {
  const F = CDX.Fmt, U = CDX.UI;
  function scoreBar(label, val, color){
    return `<div>
      <div class="flex justify-between text-[11px] mb-1"><span class="text-mut uppercase tracking-wider">${label}</span>
        <span class="num font-semibold" style="color:${color}">${val}</span></div>
      <div class="h-1.5 bg-line rounded-full overflow-hidden"><div class="h-full rounded-full" style="width:${val}%;background:${color}"></div></div>
    </div>`;
  }
  function flowPanel(flow, title){
    const total = flow.buyVol + flow.sellVol || 1;
    const buyPct = flow.buyVol / total * 100;
    const netCls = flow.netFlow >= 0 ? 'text-up' : 'text-down';
    return `<div class="bg-panel border border-line rounded-xl p-4">
      <h3 class="font-disp font-semibold text-white mb-3">${title || 'Flow Intelligence'} <span class="text-mut text-xs font-body font-normal">24h DEX flow</span></h3>
      <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-4">
        <div><div class="text-[10px] uppercase tracking-wider text-mut">Buy Volume</div><div class="num text-up font-medium">${F.usd(flow.buyVol)}</div></div>
        <div><div class="text-[10px] uppercase tracking-wider text-mut">Sell Volume</div><div class="num text-down font-medium">${F.usd(flow.sellVol)}</div></div>
        <div><div class="text-[10px] uppercase tracking-wider text-mut">Net Flow</div><div class="num font-medium ${netCls}">${(flow.netFlow>=0?'+':'−') + F.usd(Math.abs(flow.netFlow)).slice(1)}</div></div>
        <div><div class="text-[10px] uppercase tracking-wider text-mut">Buy Txns</div><div class="num text-up font-medium">${F.num(flow.buyTx)}</div></div>
        <div><div class="text-[10px] uppercase tracking-wider text-mut">Sell Txns</div><div class="num text-down font-medium">${F.num(flow.sellTx)}</div></div>
        <div><div class="text-[10px] uppercase tracking-wider text-mut">Buy Pressure</div><div class="num text-white font-medium">${buyPct.toFixed(0)}%</div></div>
      </div>
      <div class="h-2 rounded-full overflow-hidden flex bg-line mb-4"><div class="bg-up" style="width:${buyPct}%"></div><div class="bg-down flex-1"></div></div>
      <div class="space-y-3">
        ${scoreBar('Momentum Score', flow.momentum, '#5B8CFF')}
        ${scoreBar('Accumulation Score', flow.accumulation, '#2DD480')}
        ${scoreBar('Distribution Score', flow.distribution, '#FF5C5C')}
      </div></div>`;
  }
  function walletChip(addr, small){
    const w = CDX.Data && CDX.DataRaw.walletByAddr.get(addr);
    if (!w) return `<span class="num text-mut text-xs">${addr.slice(0,6)}…${addr.slice(-4)}</span>`;
    return `<span class="inline-flex items-center gap-1.5">
      <span class="${small?'text-xs':'text-sm'} font-medium text-slate-200">${F.esc(w.label)}</span>
      ${typeBadge(w.type)}</span>`;
  }
  function typeBadge(type){
    const map = { 'Smart Money':'#2DD480', 'Fund':'#5B8CFF', 'Pulse OG':'#FF0080', 'Degen':'#F5C04E',
                  'Fresh Wallet':'#8B94A7', 'Market Maker':'#9B5CFF', 'Whale':'#2D9CDB' };
    const c = map[type] || '#8B94A7';
    return `<span class="text-[9px] font-bold border rounded px-1 py-px" style="color:${c};border-color:${c}55;background:${c}14">${type.toUpperCase()}</span>`;
  }
  function whaleRow(t){
    const p = CDX.Data.byKey('d:' + t.pairId);
    if (!p) return '';
    return `<div class="row-hov flex items-center gap-3 px-4 py-2.5 border-b border-line/50 last:border-0" data-go="/pair/${p.id}">
      <span class="text-[10px] font-bold rounded px-1.5 py-0.5 ${t.side==='buy'?'bg-up/15 text-up':'bg-down/15 text-down'}">${t.side.toUpperCase()}</span>
      <div class="min-w-0">
        <div class="text-sm font-medium text-white">${F.esc(p.base)}<span class="text-mut font-normal">/${F.esc(p.quote)}</span>
          <span class="ml-1.5 align-middle">${U.chainBadge(p.chain)}</span></div>
        <div class="text-[11px] text-mut mt-0.5">${walletChip(t.wallet, true)} · ${F.rel(t.ts)}</div></div>
      <div class="ml-auto text-right shrink-0">
        <div class="num text-sm font-semibold ${t.side==='buy'?'text-up':'text-down'}">${F.usd(t.usd)}</div>
        <div class="num text-[11px] text-mut">@ ${F.price(t.price)}</div></div></div>`;
  }
  function heatChip(val){
    const c = val >= 66 ? '#2DD480' : val >= 45 ? '#F5C04E' : '#FF5C5C';
    return `<span class="num text-xs font-semibold" style="color:${c}">${val}</span>
      <span class="inline-block w-16 h-1.5 bg-line rounded-full align-middle ml-1.5 overflow-hidden"><span class="block h-full rounded-full" style="width:${val}%;background:${c}"></span></span>`;
  }
  return { scoreBar, flowPanel, walletChip, typeBadge, whaleRow, heatChip };
})();
