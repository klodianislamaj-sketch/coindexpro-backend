#!/usr/bin/env bash
# provision-staging.sh — Phase 29R-Bootstrap. Provisions the minimum environment to
# run Phase 29R. MUST be run in an environment WITH network egress + cloud creds.
# It is idempotent where possible and fails fast. It does NOT touch application code.
#
# Prereqs the RUNNER must already have: a shell with sudo, outbound network, and
# cloud credentials exported (AWS_PROFILE or AWS_ACCESS_KEY_ID/SECRET).
set -euo pipefail
log(){ printf '\n=== %s ===\n' "$*"; }

# ---- Task 1: toolchain --------------------------------------------------------
log "Task 1: install toolchain"
GO_VERSION="${GO_VERSION:-1.22.4}"
install_go() {
  command -v go >/dev/null 2>&1 && return 0
  curl -fsSLo /tmp/go.tgz "https://go.dev/dl/go${GO_VERSION}.linux-amd64.tar.gz"
  sudo rm -rf /usr/local/go && sudo tar -C /usr/local -xzf /tmp/go.tgz
  export PATH=$PATH:/usr/local/go/bin
}
install_go
command -v docker  >/dev/null 2>&1 || curl -fsSL https://get.docker.com | sh
command -v kubectl >/dev/null 2>&1 || { curl -fsSLo kubectl "https://dl.k8s.io/release/$(curl -fsSL https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"; sudo install -m0755 kubectl /usr/local/bin/; }
command -v k6 >/dev/null 2>&1 || { curl -fsSL https://github.com/grafana/k6/releases/download/v0.51.0/k6-v0.51.0-linux-amd64.tar.gz | tar xz; sudo install -m0755 k6-*/k6 /usr/local/bin/; }
command -v golangci-lint >/dev/null 2>&1 || curl -fsSL https://raw.githubusercontent.com/golangci/golangci-lint/master/install.sh | sh -s -- -b /usr/local/bin v1.59.0
command -v aws >/dev/null 2>&1 || { curl -fsSLo awscli.zip "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip"; unzip -q awscli.zip; sudo ./aws/install --update; }
command -v pg_dump >/dev/null 2>&1 || sudo apt-get update && sudo apt-get install -y postgresql-client
command -v clickhouse-client >/dev/null 2>&1 || curl -fsSL https://clickhouse.com/ | sh

# ---- Task 2: verify network ---------------------------------------------------
log "Task 2: verify network"
curl -fsS -o /dev/null https://github.com && echo "github OK"
: "${REGISTRY:?set REGISTRY (e.g. ghcr.io/coindexpro)}"
echo "$REGISTRY_TOKEN" | docker login "${REGISTRY%%/*}" -u "$REGISTRY_USER" --password-stdin
: "${ETH_RPC_PRIMARY:?set ETH_RPC_PRIMARY}"; curl -fsS -X POST "$ETH_RPC_PRIMARY" \
  -H 'content-type: application/json' \
  --data '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}' >/dev/null && echo "chain RPC OK"

# ---- Task 2b: ensure ECR repositories exist (idempotent) ----------------------
log "Task 2b: ensure ECR repositories (idempotent)"
# Uses the SAME canonical service source as phase29-live.yml. For each service the
# repo name is the dir basename. describe -> create only if absent. Real aws
# responses only; fail-fast if AWS auth itself is broken.
ensure_ecr_repos() {
  command -v aws >/dev/null 2>&1 || { echo "aws CLI required for ECR bootstrap"; exit 1; }
  # fail-fast on broken AWS auth (distinct from a repo simply not existing)
  aws sts get-caller-identity >/dev/null 2>&1 || { echo "AWS auth failed (sts get-caller-identity)"; exit 1; }

  mkdir -p artifacts
  local created=() existing=() failed=()
  local repo
  for svc in $(./scripts/list-services.sh --go); do
    repo="$(basename "$svc")"
    if aws ecr describe-repositories --repository-names "$repo" >/dev/null 2>&1; then
      existing+=("$repo")
    else
      if aws ecr create-repository --repository-name "$repo" >/dev/null 2>&1; then
        created+=("$repo")
      else
        failed+=("$repo")
      fi
    fi
  done

  # emit artifact from the ACTUAL results (python builds valid JSON from the arrays)
  CREATED="${created[*]:-}" EXISTING="${existing[*]:-}" FAILED="${failed[*]:-}" \
  python3 - <<'PY'
import json, os
sp = lambda v: v.split() if v else []
data = {
  "created":  sp(os.environ.get("CREATED","")),
  "existing": sp(os.environ.get("EXISTING","")),
  "failed":   sp(os.environ.get("FAILED","")),
}
json.dump(data, open("artifacts/ecr-bootstrap.json","w"), indent=2)
print(f"ECR repos -> created={len(data['created'])} existing={len(data['existing'])} failed={len(data['failed'])}")
PY
  # fail-fast if any repo could not be ensured
  if [ "${#failed[@]}" -gt 0 ]; then
    echo "ECR bootstrap failed for: ${failed[*]}"
    exit 1
  fi
}
ensure_ecr_repos

# ---- Task 3: provision infra --------------------------------------------------
log "Task 3: provision infra (staging)"
: "${CLUSTER_NAME:?}"; : "${AWS_REGION:?}"; : "${BACKUP_S3_BUCKET:?}"
# cluster (eksctl shown; swap for your provider). Skips if context already exists.
kubectl cluster-info >/dev/null 2>&1 || eksctl create cluster --name "$CLUSTER_NAME" --region "$AWS_REGION" --nodes 3
aws s3 mb "s3://$BACKUP_S3_BUCKET" --region "$AWS_REGION" 2>/dev/null || true
# External Secrets Operator + monitoring stack via Helm
helm repo add external-secrets https://charts.external-secrets.io
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update
helm upgrade --install external-secrets external-secrets/external-secrets -n coindex --create-namespace --wait
helm upgrade --install kube-prometheus prometheus-community/kube-prometheus-stack -n monitoring --create-namespace --wait
# ingress-nginx
helm upgrade --install ingress-nginx ingress-nginx --repo https://kubernetes.github.io/ingress-nginx -n ingress-nginx --create-namespace --wait

# ---- Task 4: secrets ----------------------------------------------------------
log "Task 4: populate 34 secrets in AWS Secrets Manager + verify ESO sync"
# The 34 keys come from k8s/secrets/external-secret.yaml. Operator supplies values
# via a local env file NOT committed (secrets.env). This script reads names only.
: "${SECRETS_ENV_FILE:?path to a local key=value file with the 34 real secret values}"
python3 - "$SECRETS_ENV_FILE" << 'PYEOF'
import sys, json, subprocess
kv={}
for line in open(sys.argv[1]):
    line=line.strip()
    if not line or line.startswith('#') or '=' not in line: continue
    k,v=line.split('=',1); kv[k]=v
# single JSON secret "coindex/platform" with a property per key (matches ExternalSecret remoteRef)
subprocess.run(["aws","secretsmanager","create-secret","--name","coindex/platform",
                "--secret-string",json.dumps(kv)], check=False)
subprocess.run(["aws","secretsmanager","put-secret-value","--secret-id","coindex/platform",
                "--secret-string",json.dumps(kv)], check=True)
print(f"pushed {len(kv)} secret properties to coindex/platform")
PYEOF
kubectl apply -f k8s/secrets/service-account.yaml -f k8s/secrets/secret-store.yaml -f k8s/secrets/external-secret.yaml
# verify ESO produced the Secret with all keys
kubectl -n coindex wait --for=condition=Ready externalsecret/coindex-secrets --timeout=120s
SYNCED=$(kubectl -n coindex get secret coindex-secrets -o json | python3 -c "import json,sys;print(len(json.load(sys.stdin).get('data',{})))")
echo "coindex-secrets now has $SYNCED keys synced by ESO"

# ---- Task 5: validate prereqs -------------------------------------------------
log "Task 5: validate prerequisites"
go version
docker version --format '{{.Server.Version}}'
kubectl cluster-info
aws sts get-caller-identity
pg_dump --version
clickhouse-client --version

# ---- Task 6: hand off to 29R --------------------------------------------------
log "Task 6: re-run Phase 29R"
echo "Environment ready. Now run: bash scripts/phase29r.sh  (or the Phase 29R stage sequence)"
