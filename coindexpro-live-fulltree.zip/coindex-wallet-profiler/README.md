# coindex-wallet-profiler — Phase 6

Computes a wallet profile from **real fills only** (ClickHouse `wallet_trades`,
written by the Phase 4 enricher) using FIFO cost basis, and serves
`GET /wallet/:chain/:address/profile`. Every metric is derived from actual
buy/sell trades or returned as `{available:false}` — no estimates, no synthetic
ROI, no fabricated histories.

## Metrics (all from real fills)

| Metric | How it's derived | Unavailable when |
|---|---|---|
| realized_pnl_usd | Σ FIFO-realized PnL over closed lots | no priced close has occurred |
| win_rate | wins / closes (a win = a sell that realized > 0) | no closes |
| avg_roi | realized / closed cost basis | no closed cost basis |
| avg_hold_seconds | qty-weighted hold of closed lots | nothing closed |
| avg_trade_usd | Σ priced USD / priced-fill count | no priced fills |
| token_diversity | distinct tokens traded | — (0 if none) |
| repeat_buys | tokens bought ≥ 2 times | — |
| sector_concentration | HHI over tagged, priced volume | no tagged volume |
| conviction | transparent formula (repeat·activity·multi-chain·sector breadth) | — |

**No unrealized PnL.** This service has no live price source, and an unrealized
figure without one would be an estimate (forbidden). It is omitted entirely and
the response notes why.

## Flow

```
GET /wallet/:chain/:address/profile
  → Redis cache hit?            → serve
  → stored profile fresh?       → serve + cache
  → recompute from wallet_trades (FIFO) → persist (Postgres) → cache → serve
  → wallet has no fills         → {available:false, reason:"not indexed"}
```

## Folder tree

```
cmd/wallet-profiler/main.go        wiring, API, ops server, graceful shutdown
config/{config.go, config.yaml}
internal/
  profiler/profiler.go             FIFO engine + metric derivation (nil = unavailable)
  db/{db.go, util.go}              ClickHouse fills + Postgres sector tags + profile writers
  api/api.go                       GET /wallet/:chain/:address/profile (cache→store→compute)
  cache/cache.go                   Redis profile-JSON cache
  metrics/metrics.go
migrations/postgres/001_wallet_profiles.sql   wallet_profiles, wallet_trade_stats, wallet_sector_stats
Dockerfile · docker-compose.yml · README.md
```

## Run

```bash
export CLICKHOUSE_ADDR=... CLICKHOUSE_USER=... CLICKHOUSE_PASSWORD=...
export POSTGRES_DSN=... REDIS_ADDR=...
# apply migrations/postgres/001_wallet_profiles.sql to the shared Postgres
docker compose up --build
# API: http://localhost:8092/wallet/ethereum/0x.../profile
# ops: http://localhost:9104/healthz /readyz /metrics
```

## Honest status

- **Real, production-shaped code, NOT compiled or run here** (no Go toolchain, no
  ClickHouse/Postgres/Redis in the authoring environment). Static-reviewed
  (imports/symbols/signatures resolve) and the FIFO realized-PnL / win-rate / ROI
  logic was verified by simulation (buy 10@1, buy 10@2, sell 10@3, sell 5@1.5 →
  realized +17.5, win_rate 0.5, ROI 0.875; sell-without-buy → all nil, no invented
  basis). Before production: `go build` + `vet` + lint, and an integration run.
- **Only as real as the fills.** A wallet with no indexed trades returns
  `{available:false, reason:"not indexed"}`. Metrics that need closes/prices stay
  unavailable until the data exists — never defaulted to 0.
- **`priced_coverage`** is reported so consumers know how much of the wallet's
  activity had a USD price; PnL/ROI/size are computed only over priced fills.
- **Sector concentration needs real tags** (`graph.token_nodes.sector`); untagged
  tokens are excluded, and if a wallet has no tagged volume the metric is
  unavailable rather than guessed.
