-- =============================================================================
-- CoinDex Wallet Profiler — PostgreSQL schema (Phase 6)
-- =============================================================================
-- Profile tables materialized from REAL fills (ClickHouse wallet_trades) by the
-- profiler. Metrics that cannot be derived from real fills are stored as NULL,
-- never a fabricated zero — the API renders NULL as {available:false}. There is
-- no unrealized PnL column here at all: this service has no live price source,
-- and an unrealized figure without one would be an estimate (forbidden).
-- =============================================================================

-- -----------------------------------------------------------------------------
-- wallet_profiles — one row per wallet (the headline profile)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS wallet_profiles (
    chain               text        NOT NULL,
    address             text        NOT NULL CHECK (address = lower(address)),
    -- headline metrics (NULL = not derivable from this wallet's real fills yet)
    realized_pnl_usd    numeric,                         -- sum of FIFO-realized PnL
    win_rate            numeric CHECK (win_rate IS NULL OR (win_rate BETWEEN 0 AND 1)),
    avg_roi             numeric,                          -- realized / closed cost basis
    avg_hold_seconds    numeric CHECK (avg_hold_seconds IS NULL OR avg_hold_seconds >= 0),
    avg_trade_usd       numeric CHECK (avg_trade_usd IS NULL OR avg_trade_usd >= 0),
    token_diversity     integer CHECK (token_diversity IS NULL OR token_diversity >= 0),
    repeat_buys         integer CHECK (repeat_buys IS NULL OR repeat_buys >= 0),
    sector_concentration numeric CHECK (sector_concentration IS NULL OR (sector_concentration BETWEEN 0 AND 1)),
    conviction          integer CHECK (conviction IS NULL OR (conviction BETWEEN 0 AND 100)),
    -- provenance
    trades_counted      bigint      NOT NULL DEFAULT 0,  -- # real fills the profile is built from
    closed_trades       bigint      NOT NULL DEFAULT 0,  -- # sells that closed lots (win-rate denom)
    priced_coverage     numeric,                          -- fraction of fills that had a USD price
    computed_at         timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (chain, address)
);
CREATE INDEX IF NOT EXISTS idx_wprofile_conviction ON wallet_profiles (chain, conviction DESC)
    WHERE conviction IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_wprofile_realized ON wallet_profiles (chain, realized_pnl_usd DESC)
    WHERE realized_pnl_usd IS NOT NULL;

-- -----------------------------------------------------------------------------
-- wallet_trade_stats — per (wallet, token) trade behaviour (real counts only)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS wallet_trade_stats (
    chain          text    NOT NULL,
    address        text    NOT NULL CHECK (address = lower(address)),
    token          text    NOT NULL,
    buys           integer NOT NULL DEFAULT 0,
    sells          integer NOT NULL DEFAULT 0,
    buy_usd        numeric NOT NULL DEFAULT 0,
    sell_usd       numeric NOT NULL DEFAULT 0,
    realized_pnl_usd numeric,                            -- NULL until a close occurs
    first_trade    timestamptz,
    last_trade     timestamptz,
    PRIMARY KEY (chain, address, token)
);
CREATE INDEX IF NOT EXISTS idx_wtradestats_addr ON wallet_trade_stats (chain, address);

-- -----------------------------------------------------------------------------
-- wallet_sector_stats — per (wallet, sector) exposure (real tags only)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS wallet_sector_stats (
    chain        text    NOT NULL,
    address      text    NOT NULL CHECK (address = lower(address)),
    sector       text    NOT NULL,
    volume_usd   numeric NOT NULL DEFAULT 0,
    trades       integer NOT NULL DEFAULT 0,
    share        numeric CHECK (share IS NULL OR (share BETWEEN 0 AND 1)),  -- of wallet's tagged volume
    PRIMARY KEY (chain, address, sector)
);
CREATE INDEX IF NOT EXISTS idx_wsectorstats_addr ON wallet_sector_stats (chain, address);
