// Package db reads real fills from ClickHouse (wallet_trades) and sector tags
// from Postgres (graph.token_nodes), and persists the computed profile to the
// Phase 6 Postgres tables. It never writes a metric it did not compute from real
// data: nil profile fields are written as SQL NULL.
package db

import (
	"context"
	"time"

	"github.com/ClickHouse/clickhouse-go/v2"
	"github.com/ClickHouse/clickhouse-go/v2/lib/driver"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/coindexpro/coindex-wallet-profiler/internal/profiler"
)

type DB struct {
	ch driver.Conn
	pg *pgxpool.Pool
}

func Open(ctx context.Context, chAddrs []string, chDB, chUser, chPass, pgDSN string) (*DB, error) {
	ch, err := clickhouse.Open(&clickhouse.Options{
		Addr: chAddrs,
		Auth: clickhouse.Auth{Database: chDB, Username: chUser, Password: chPass},
	})
	if err != nil {
		return nil, err
	}
	if err := ch.Ping(ctx); err != nil {
		return nil, err
	}
	pg, err := pgxpool.New(ctx, pgDSN)
	if err != nil {
		return nil, err
	}
	if err := pg.Ping(ctx); err != nil {
		return nil, err
	}
	return &DB{ch: ch, pg: pg}, nil
}

func (d *DB) Close() {
	_ = d.ch.Close()
	d.pg.Close()
}

func (d *DB) Ping(ctx context.Context) error {
	if err := d.ch.Ping(ctx); err != nil {
		return err
	}
	return d.pg.Ping(ctx)
}

// Fills reads a wallet's real trades from ClickHouse, ascending by time so the
// FIFO engine can consume them directly. Sector tags are resolved in a second
// step (ResolveSectors) to keep this query simple and fast.
func (d *DB) Fills(ctx context.Context, chain, wallet string, limit int) ([]profiler.Fill, int, error) {
	const q = `
		SELECT token, side, qty, price_usd, usd, block_time
		FROM coindex.wallet_trades
		WHERE chain = ? AND wallet = ?
		ORDER BY block_time ASC
		LIMIT ?`
	rows, err := d.ch.Query(ctx, q, chain, wallet, limit)
	if err != nil {
		return nil, 0, err
	}
	defer rows.Close()
	var out []profiler.Fill
	for rows.Next() {
		var token, side, qtyStr string
		var price, usd float64
		var bt time.Time
		if err := rows.Scan(&token, &side, &qtyStr, &price, &usd, &bt); err != nil {
			return nil, 0, err
		}
		out = append(out, profiler.Fill{
			Token: token, Side: side, Qty: parseFloat(qtyStr),
			PriceUSD: price, USD: usd, Time: bt, Priced: usd > 0,
		})
	}
	if err := rows.Err(); err != nil {
		return nil, 0, err
	}
	// distinct chains for conviction multi-chain factor: this query is per-chain,
	// so chains>=1; the caller may profile across chains separately.
	return out, 1, nil
}

// ResolveSectors fills in Sector on each fill from graph.token_nodes (real tags
// only). Tokens with no tag stay "" and are excluded from sector concentration.
func (d *DB) ResolveSectors(ctx context.Context, chain string, fills []profiler.Fill) error {
	if len(fills) == 0 {
		return nil
	}
	tokens := map[string]struct{}{}
	for _, f := range fills {
		tokens[f.Token] = struct{}{}
	}
	list := make([]string, 0, len(tokens))
	for t := range tokens {
		list = append(list, t)
	}
	const q = `SELECT address, sector FROM graph.token_nodes WHERE chain=$1 AND address = ANY($2) AND sector IS NOT NULL`
	rows, err := d.pg.Query(ctx, q, chain, list)
	if err != nil {
		return err
	}
	defer rows.Close()
	tag := map[string]string{}
	for rows.Next() {
		var addr, sector string
		if err := rows.Scan(&addr, &sector); err != nil {
			return err
		}
		tag[addr] = sector
	}
	if err := rows.Err(); err != nil {
		return err
	}
	for i := range fills {
		if s, ok := tag[fills[i].Token]; ok {
			fills[i].Sector = s
		}
	}
	return nil
}

// SaveProfile upserts the profile + per-token + per-sector stats in one tx.
// nil metric pointers are written as NULL (no fabricated zeros).
func (d *DB) SaveProfile(ctx context.Context, chain, wallet string, p profiler.Profile) error {
	tx, err := d.pg.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)

	const up = `
		INSERT INTO wallet_profiles (chain, address, realized_pnl_usd, win_rate, avg_roi,
			avg_hold_seconds, avg_trade_usd, token_diversity, repeat_buys, sector_concentration,
			conviction, trades_counted, closed_trades, priced_coverage, computed_at)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14, now())
		ON CONFLICT (chain, address) DO UPDATE SET
			realized_pnl_usd=$3, win_rate=$4, avg_roi=$5, avg_hold_seconds=$6, avg_trade_usd=$7,
			token_diversity=$8, repeat_buys=$9, sector_concentration=$10, conviction=$11,
			trades_counted=$12, closed_trades=$13, priced_coverage=$14, computed_at=now()`
	if _, err := tx.Exec(ctx, up, chain, wallet,
		p.RealizedPnlUSD, p.WinRate, p.AvgROI, p.AvgHoldSeconds, p.AvgTradeUSD,
		p.TokenDiversity, p.RepeatBuys, p.SectorConcentration, p.Conviction,
		p.TradesCounted, p.ClosedTrades, p.PricedCoverage); err != nil {
		return err
	}

	// replace per-token + per-sector stats for this wallet (idempotent refresh)
	if _, err := tx.Exec(ctx, `DELETE FROM wallet_trade_stats WHERE chain=$1 AND address=$2`, chain, wallet); err != nil {
		return err
	}
	for _, ts := range p.TokenStats {
		if _, err := tx.Exec(ctx,
			`INSERT INTO wallet_trade_stats (chain, address, token, buys, sells, buy_usd, sell_usd, realized_pnl_usd, first_trade, last_trade)
			 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
			chain, wallet, ts.Token, ts.Buys, ts.Sells, ts.BuyUSD, ts.SellUSD, ts.RealizedUSD, ts.First, ts.Last); err != nil {
			return err
		}
	}
	if _, err := tx.Exec(ctx, `DELETE FROM wallet_sector_stats WHERE chain=$1 AND address=$2`, chain, wallet); err != nil {
		return err
	}
	for _, ss := range p.SectorStats {
		if _, err := tx.Exec(ctx,
			`INSERT INTO wallet_sector_stats (chain, address, sector, volume_usd, trades, share)
			 VALUES ($1,$2,$3,$4,$5,$6)`,
			chain, wallet, ss.Sector, ss.VolumeUSD, ss.Trades, ss.Share); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

// LoadProfile reads a stored profile (ok=false if none). freshness lets the API
// decide whether to recompute.
func (d *DB) LoadProfile(ctx context.Context, chain, wallet string) (profiler.Profile, time.Time, bool, error) {
	const q = `
		SELECT realized_pnl_usd, win_rate, avg_roi, avg_hold_seconds, avg_trade_usd,
		       token_diversity, repeat_buys, sector_concentration, conviction,
		       trades_counted, closed_trades, priced_coverage, computed_at
		FROM wallet_profiles WHERE chain=$1 AND address=$2`
	var p profiler.Profile
	var computedAt time.Time
	err := d.pg.QueryRow(ctx, q, chain, wallet).Scan(
		&p.RealizedPnlUSD, &p.WinRate, &p.AvgROI, &p.AvgHoldSeconds, &p.AvgTradeUSD,
		&p.TokenDiversity, &p.RepeatBuys, &p.SectorConcentration, &p.Conviction,
		&p.TradesCounted, &p.ClosedTrades, &p.PricedCoverage, &computedAt)
	if err == pgx.ErrNoRows {
		return profiler.Profile{}, time.Time{}, false, nil
	}
	if err != nil {
		return profiler.Profile{}, time.Time{}, false, err
	}
	return p, computedAt, true, nil
}
