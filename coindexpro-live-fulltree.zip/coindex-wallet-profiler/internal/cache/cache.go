// Package cache stores rendered profile JSON in Redis so repeat reads of a hot
// wallet within the TTL avoid recomputation. The cache holds the exact response
// body; it never holds partial or fabricated data.
package cache

import (
	"context"
	"time"

	"github.com/redis/go-redis/v9"
)

type Cache struct {
	rdb *redis.Client
	ttl time.Duration
}

func New(rdb *redis.Client, ttl time.Duration) *Cache {
	if ttl == 0 {
		ttl = 30 * time.Second
	}
	return &Cache{rdb: rdb, ttl: ttl}
}

func key(chain, wallet string) string { return "wprofile:" + chain + ":" + wallet }

func (c *Cache) Get(ctx context.Context, chain, wallet string) ([]byte, bool) {
	b, err := c.rdb.Get(ctx, key(chain, wallet)).Bytes()
	if err != nil {
		return nil, false
	}
	return b, true
}

func (c *Cache) Set(ctx context.Context, chain, wallet string, body []byte) {
	_ = c.rdb.Set(ctx, key(chain, wallet), body, c.ttl).Err()
}

func (c *Cache) Ping(ctx context.Context) error { return c.rdb.Ping(ctx).Err() }

func (c *Cache) Close() error { return c.rdb.Close() }
