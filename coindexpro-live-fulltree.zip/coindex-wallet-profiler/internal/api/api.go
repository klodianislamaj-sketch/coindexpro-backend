// Package api serves GET /wallet/:chain/:address/profile. Flow: serve from the
// Redis cache; else from the stored profile if fresh; else recompute from real
// fills, persist, cache, and return. Nil metrics render as {available:false} so
// the response is honest about what could not be derived.
package api

import (
	"context"
	"encoding/json"
	"regexp"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"

	"github.com/coindexpro/coindex-wallet-profiler/internal/cache"
	"github.com/coindexpro/coindex-wallet-profiler/internal/db"
	"github.com/coindexpro/coindex-wallet-profiler/internal/metrics"
	"github.com/coindexpro/coindex-wallet-profiler/internal/profiler"
)

type API struct {
	db        *db.DB
	cache     *cache.Cache
	freshness time.Duration
	maxFills  int
}

func New(database *db.DB, c *cache.Cache, freshness time.Duration, maxFills int) *API {
	if maxFills <= 0 {
		maxFills = 50000
	}
	return &API{db: database, cache: c, freshness: freshness, maxFills: maxFills}
}

func (a *API) Register(app *fiber.App) {
	app.Use(a.observe)
	app.Get("/wallet/:chain/:address/profile", a.profile)
}

func (a *API) observe(c *fiber.Ctx) error {
	start := time.Now()
	err := c.Next()
	metrics.APILatency.WithLabelValues(c.Route().Path, statusClass(c.Response().StatusCode())).
		Observe(time.Since(start).Seconds())
	return err
}

var (
	evmAddr    = regexp.MustCompile(`^0x[0-9a-fA-F]{40}$`)
	validChain = map[string]bool{
		"ethereum": true, "bsc": true, "base": true,
		"arbitrum": true, "polygon": true, "pulsechain": true,
	}
)

func (a *API) profile(c *fiber.Ctx) error {
	chain := strings.ToLower(c.Params("chain"))
	addr := strings.ToLower(c.Params("address"))
	if !validChain[chain] {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "unsupported chain"})
	}
	if !evmAddr.MatchString(addr) {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid address"})
	}
	ctx := c.UserContext()

	// 1) cache
	if body, ok := a.cache.Get(ctx, chain, addr); ok {
		metrics.ProfileRequests.WithLabelValues("hit_cache").Inc()
		c.Set("Content-Type", "application/json")
		return c.Send(body)
	}

	// 2) stored profile, if fresh enough
	if stored, computedAt, ok, err := a.db.LoadProfile(ctx, chain, addr); err == nil && ok {
		if time.Since(computedAt) < a.freshness {
			body := render(chain, addr, stored, computedAt)
			a.cache.Set(ctx, chain, addr, body)
			metrics.ProfileRequests.WithLabelValues("hit_store").Inc()
			c.Set("Content-Type", "application/json")
			return c.Send(body)
		}
	} else if err != nil {
		metrics.DBErrors.WithLabelValues("postgres").Inc()
	}

	// 3) recompute from real fills
	body, err := a.computeAndStore(ctx, chain, addr)
	if err != nil {
		metrics.ProfileRequests.WithLabelValues("error").Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	c.Set("Content-Type", "application/json")
	return c.Send(body)
}

func (a *API) computeAndStore(ctx context.Context, chain, addr string) ([]byte, error) {
	t := time.Now()
	fills, chains, err := a.db.Fills(ctx, chain, addr, a.maxFills)
	if err != nil {
		metrics.DBErrors.WithLabelValues("clickhouse").Inc()
		return nil, err
	}
	metrics.FillsScanned.Observe(float64(len(fills)))

	if len(fills) == 0 {
		// honest empty profile: wallet not indexed / no trades observed
		metrics.ProfileRequests.WithLabelValues("empty").Inc()
		body, _ := json.Marshal(fiber.Map{
			"chain": chain, "address": addr, "available": false, "reason": "not indexed",
		})
		a.cache.Set(ctx, chain, addr, body)
		return body, nil
	}

	if err := a.db.ResolveSectors(ctx, chain, fills); err != nil {
		metrics.DBErrors.WithLabelValues("postgres").Inc()
		// sectors are optional; proceed without them (sector_concentration → nil)
	}

	p := profiler.Compute(fills, chains)
	metrics.ComputeLatency.Observe(time.Since(t).Seconds())

	if err := a.db.SaveProfile(ctx, chain, addr, p); err != nil {
		metrics.DBErrors.WithLabelValues("postgres").Inc()
		// still return the computed profile even if persistence failed
	}
	body := render(chain, addr, p, time.Now())
	a.cache.Set(ctx, chain, addr, body)
	metrics.ProfileRequests.WithLabelValues("computed").Inc()
	return body, nil
}

// render serializes a profile. nil metrics become {available:false} objects so
// the client can distinguish "not derivable" from a real value.
func render(chain, addr string, p profiler.Profile, computedAt time.Time) []byte {
	metric := func(v any) any {
		switch x := v.(type) {
		case *float64:
			if x == nil {
				return unavail()
			}
			return *x
		case *int:
			if x == nil {
				return unavail()
			}
			return *x
		}
		return unavail()
	}
	out := fiber.Map{
		"chain":   chain,
		"address": addr,
		"available": true,
		"metrics": fiber.Map{
			"realized_pnl_usd":     metric(p.RealizedPnlUSD),
			"win_rate":             metric(p.WinRate),
			"avg_roi":              metric(p.AvgROI),
			"avg_hold_seconds":     metric(p.AvgHoldSeconds),
			"avg_trade_usd":        metric(p.AvgTradeUSD),
			"token_diversity":      metric(p.TokenDiversity),
			"repeat_buys":          metric(p.RepeatBuys),
			"sector_concentration": metric(p.SectorConcentration),
			"conviction":           metric(p.Conviction),
		},
		"provenance": fiber.Map{
			"trades_counted":  p.TradesCounted,
			"closed_trades":   p.ClosedTrades,
			"priced_coverage": metric(p.PricedCoverage),
			"computed_at":     computedAt.UTC(),
			"note":            "derived from indexed fills only; unrealized PnL omitted (no live price source in this service)",
		},
		"sectors": p.SectorStats,
	}
	b, _ := json.Marshal(out)
	return b
}

func unavail() fiber.Map { return fiber.Map{"available": false} }

func statusClass(code int) string {
	switch {
	case code >= 500:
		return "5xx"
	case code >= 400:
		return "4xx"
	default:
		return "2xx"
	}
}
