// Package profiler computes a wallet profile from REAL fills only, using FIFO
// cost basis. Every metric is either derived from actual buy/sell trades or left
// nil (→ rendered unavailable). There is no unrealized PnL here (no live price
// source), no synthetic ROI, and no fabricated history. A "win" is a real close
// (a sell that realized positive PnL against its FIFO lots).
package profiler

import (
	"container/list"
	"time"
)

// Fill is one real trade read from ClickHouse wallet_trades. Sector is resolved
// from the registry (real tag) or "" when untagged.
type Fill struct {
	Token    string
	Sector   string
	Side     string // "buy" | "sell"
	Qty      float64
	PriceUSD float64
	USD      float64
	Time     time.Time
	Priced   bool // the fill had a real USD price (usd>0)
}

// TokenStat is per-(wallet,token) behaviour.
type TokenStat struct {
	Token      string
	Buys       int
	Sells      int
	BuyUSD     float64
	SellUSD    float64
	RealizedUSD *float64 // nil until a close occurs
	First      time.Time
	Last       time.Time
}

// SectorStat is per-(wallet,sector) exposure.
type SectorStat struct {
	Sector    string
	VolumeUSD float64
	Trades    int
	Share     float64 // of the wallet's tagged volume
}

// Profile is the computed wallet profile. Pointer fields are nil when the metric
// is not derivable from this wallet's real fills.
type Profile struct {
	RealizedPnlUSD      *float64
	WinRate             *float64
	AvgROI              *float64
	AvgHoldSeconds      *float64
	AvgTradeUSD         *float64
	TokenDiversity      *int
	RepeatBuys          *int
	SectorConcentration *float64
	Conviction          *int

	TradesCounted  int64
	ClosedTrades   int64
	PricedCoverage *float64

	TokenStats  []TokenStat
	SectorStats []SectorStat
}

type lot struct {
	qty      float64
	priceUSD float64
	at       time.Time
}

// Compute builds a Profile from fills (which MUST be sorted by time ascending).
// chains is the set of chains seen (for conviction multi-chain factor); callers
// pass the wallet's distinct chains.
func Compute(fills []Fill, chains int) Profile {
	var p Profile
	p.TradesCounted = int64(len(fills))
	if len(fills) == 0 {
		return p // empty profile: every metric nil (unavailable)
	}

	tokenLots := map[string]*list.List{}
	tokenStats := map[string]*TokenStat{}
	sectorVol := map[string]float64{}
	sectorTrades := map[string]int{}
	tokenBuyCount := map[string]int{}

	var realizedTotal, closedCostBasis float64
	var closedCount, winCount int64
	var holdWeighted, closedQty float64
	var tradeUSDsum float64
	var pricedCount int64
	hasAnyRealized := false

	for _, f := range fills {
		ts := tokenStats[f.Token]
		if ts == nil {
			ts = &TokenStat{Token: f.Token, First: f.Time}
			tokenStats[f.Token] = ts
			tokenLots[f.Token] = list.New()
		}
		ts.Last = f.Time
		if f.Time.Before(ts.First) {
			ts.First = f.Time
		}
		if f.Priced {
			pricedCount++
			tradeUSDsum += f.USD
		}
		if f.Sector != "" && f.Priced {
			sectorVol[f.Sector] += f.USD
			sectorTrades[f.Sector]++
		}

		switch f.Side {
		case "buy":
			ts.Buys++
			ts.BuyUSD += f.USD
			tokenBuyCount[f.Token]++
			tokenLots[f.Token].PushBack(&lot{qty: f.Qty, priceUSD: f.PriceUSD, at: f.Time})
		case "sell":
			ts.Sells++
			ts.SellUSD += f.USD
			// FIFO match against open lots; a sell with no prior buy realizes
			// nothing (no invented basis).
			remaining := f.Qty
			q := tokenLots[f.Token]
			var realizedThis float64
			var matched bool
			for remaining > 0 && q != nil && q.Len() > 0 {
				front := q.Front()
				l := front.Value.(*lot)
				take := l.qty
				if remaining < take {
					take = remaining
				}
				if f.Priced { // realized PnL only meaningful when both sides priced
					realizedThis += take * (f.PriceUSD - l.priceUSD)
					closedCostBasis += take * l.priceUSD
				}
				holdWeighted += f.Time.Sub(l.at).Seconds() * take
				closedQty += take
				matched = true
				l.qty -= take
				remaining -= take
				if l.qty <= 1e-18 {
					q.Remove(front)
				}
			}
			if matched && f.Priced {
				closedCount++
				realizedTotal += realizedThis
				hasAnyRealized = true
				if realizedThis > 0 {
					winCount++
				}
				addRealized(ts, realizedThis)
			}
		}
	}

	// --- assemble metrics, leaving nil where not derivable ---

	if hasAnyRealized {
		rt := realizedTotal
		p.RealizedPnlUSD = &rt
	}
	if closedCount > 0 {
		wr := float64(winCount) / float64(closedCount)
		p.WinRate = &wr
		p.ClosedTrades = closedCount
	}
	if closedCostBasis > 0 {
		roi := realizedTotal / closedCostBasis
		p.AvgROI = &roi
	}
	if closedQty > 0 {
		h := holdWeighted / closedQty
		p.AvgHoldSeconds = &h
	}
	if pricedCount > 0 {
		avg := tradeUSDsum / float64(pricedCount)
		p.AvgTradeUSD = &avg
		cov := float64(pricedCount) / float64(len(fills))
		p.PricedCoverage = &cov
	}
	div := len(tokenStats)
	p.TokenDiversity = &div
	repeat := 0
	for _, n := range tokenBuyCount {
		if n >= 2 {
			repeat++
		}
	}
	p.RepeatBuys = &repeat

	// sector concentration = HHI over tagged volume (sum of squared shares).
	// nil when the wallet has no tagged, priced volume (no guessed sectors).
	var totalSectorVol float64
	for _, v := range sectorVol {
		totalSectorVol += v
	}
	if totalSectorVol > 0 {
		var hhi float64
		for s, v := range sectorVol {
			share := v / totalSectorVol
			hhi += share * share
			p.SectorStats = append(p.SectorStats, SectorStat{
				Sector: s, VolumeUSD: v, Trades: sectorTrades[s], Share: share,
			})
		}
		p.SectorConcentration = &hhi
	}

	// conviction: transparent function of observable behaviour (no outcome/profit).
	conv := conviction(len(fills), repeat, chains, len(sectorVol))
	p.Conviction = &conv

	// flatten token stats
	for _, ts := range tokenStats {
		p.TokenStats = append(p.TokenStats, *ts)
	}
	return p
}

func addRealized(ts *TokenStat, v float64) {
	if ts.RealizedUSD == nil {
		z := 0.0
		ts.RealizedUSD = &z
	}
	*ts.RealizedUSD += v
}

// conviction mirrors the enricher's transparent formula so scoring is consistent
// across services: repeat buys (≤40), activity (≤25), multi-chain (≤15), sector
// breadth (≤20). All inputs observable; none assume profit.
func conviction(trades, repeat, chains, sectors int) int {
	score := 0.0
	rp := float64(repeat) * 8
	if rp > 40 {
		rp = 40
	}
	score += rp
	act := log2(float64(trades)) * 6
	if act > 25 {
		act = 25
	}
	score += act
	mc := float64(chains-1) * 7.5
	if mc < 0 {
		mc = 0
	}
	if mc > 15 {
		mc = 15
	}
	score += mc
	sb := float64(sectors) * 5
	if sb > 20 {
		sb = 20
	}
	score += sb
	c := int(score + 0.5)
	if c > 100 {
		c = 100
	}
	return c
}

func log2(x float64) float64 {
	if x <= 1 {
		return 0
	}
	r := 0.0
	for x > 1 {
		x /= 2
		r++
	}
	return r
}
