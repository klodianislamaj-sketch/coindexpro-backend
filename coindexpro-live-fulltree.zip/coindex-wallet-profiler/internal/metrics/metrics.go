// Package metrics holds the wallet-profiler's Prometheus instruments.
package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	ProfileRequests = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_wp_profile_requests_total", Help: "Profile requests by result.",
	}, []string{"result"}) // hit_cache | hit_store | computed | empty | error

	ComputeLatency = promauto.NewHistogram(prometheus.HistogramOpts{
		Name: "coindex_wp_compute_seconds", Help: "Profile compute latency.",
		Buckets: prometheus.DefBuckets,
	})

	FillsScanned = promauto.NewHistogram(prometheus.HistogramOpts{
		Name: "coindex_wp_fills_scanned", Help: "Fills read per profile compute.",
		Buckets: []float64{10, 50, 100, 500, 1000, 5000, 10000},
	})

	DBErrors = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_wp_db_errors_total", Help: "DB errors by store.",
	}, []string{"store"})

	APILatency = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name: "coindex_wp_api_seconds", Help: "API latency by route + status.",
		Buckets: prometheus.DefBuckets,
	}, []string{"route", "status"})
)
