-- =============================================================================
-- CoinDex Flow Intelligence Engine — PostgreSQL migration (Phase 11)
-- =============================================================================
-- Stores DERIVED flow aggregates computed from real source tables (ClickHouse
-- swaps / wallet_trades / smart_money_events / token_metrics + Postgres
-- wallet_labels + graph.token_nodes/graph_edges). Every row is an aggregate of
-- observed flows over a window; nothing here is synthesized.
--
-- Sector rotation is written to the EXISTING Phase 2 Timescale `sector_history`
-- hypertable (inflow_usd/outflow_usd/net_usd) — not duplicated here.
-- All statements are idempotent.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- flow_snapshots — netflow per (scope, entity) over a window
--   scope: 'token' | 'exchange' | 'whale' | 'smart_money'
--   For exchange scope, entity is the exchange label/name; flows are signed from
--   the exchange's perspective (deposits = inflow to exchange = sell pressure).
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS flow_snapshots (
    id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    scope       text        NOT NULL CHECK (scope IN ('token','exchange','whale','smart_money')),
    chain       text        NOT NULL,
    entity      text        NOT NULL,                    -- token addr | exchange | wallet
    window_start timestamptz NOT NULL,
    window_end   timestamptz NOT NULL,
    inflow_usd  numeric     NOT NULL DEFAULT 0,
    outflow_usd numeric     NOT NULL DEFAULT 0,
    net_usd     numeric GENERATED ALWAYS AS (inflow_usd - outflow_usd) STORED,
    trades      bigint      NOT NULL DEFAULT 0,
    wallets     bigint      NOT NULL DEFAULT 0,           -- distinct wallets observed
    -- confidence: fraction of contributing trades that were actually USD-priced
    -- (amount_usd>0). Low coverage => the netflow is partial; we expose it, never hide it.
    priced_coverage numeric NOT NULL DEFAULT 0 CHECK (priced_coverage BETWEEN 0 AND 1),
    updated_at  timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_flow_snapshot UNIQUE (scope, chain, entity, window_start)
);
CREATE INDEX IF NOT EXISTS idx_fs_scope ON flow_snapshots (scope, chain, window_start DESC);
CREATE INDEX IF NOT EXISTS idx_fs_entity ON flow_snapshots (chain, entity, window_start DESC);

-- -----------------------------------------------------------------------------
-- cohort_flows — net flow by wallet cohort into a token over a window.
--   cohort: 'smart_money' | 'whale' | 'exchange' | 'retail' (retail = unlabeled)
-- Cohort membership comes from real wallet_labels; 'retail' is the explicit
-- residual of wallets with no relevant label (not a guess about who they are).
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cohort_flows (
    id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    chain        text        NOT NULL,
    token        text        NOT NULL,
    cohort       text        NOT NULL CHECK (cohort IN ('smart_money','whale','exchange','retail')),
    window_start timestamptz NOT NULL,
    window_end   timestamptz NOT NULL,
    inflow_usd   numeric     NOT NULL DEFAULT 0,
    outflow_usd  numeric     NOT NULL DEFAULT 0,
    net_usd      numeric GENERATED ALWAYS AS (inflow_usd - outflow_usd) STORED,
    wallets      bigint      NOT NULL DEFAULT 0,
    priced_coverage numeric  NOT NULL DEFAULT 0 CHECK (priced_coverage BETWEEN 0 AND 1),
    updated_at   timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_cohort_flow UNIQUE (chain, token, cohort, window_start)
);
CREATE INDEX IF NOT EXISTS idx_cf_token ON cohort_flows (chain, token, window_start DESC);

-- -----------------------------------------------------------------------------
-- netflow_anomalies — windows whose net flow deviates strongly from the entity's
-- own recent baseline. Detection is a transparent z-score over real prior windows;
-- an anomaly is only emitted when there is enough baseline history (min_samples).
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS netflow_anomalies (
    id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    scope        text        NOT NULL CHECK (scope IN ('token','exchange','whale','smart_money')),
    chain        text        NOT NULL,
    entity       text        NOT NULL,
    window_start timestamptz NOT NULL,
    net_usd      numeric     NOT NULL,
    baseline_mean numeric    NOT NULL,
    baseline_std  numeric    NOT NULL,
    zscore       numeric     NOT NULL,
    direction    text        NOT NULL CHECK (direction IN ('inflow_spike','outflow_spike')),
    samples      int         NOT NULL,                    -- baseline windows used
    detected_at  timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_anomaly UNIQUE (scope, chain, entity, window_start)
);
CREATE INDEX IF NOT EXISTS idx_na_scope ON netflow_anomalies (scope, chain, detected_at DESC);
