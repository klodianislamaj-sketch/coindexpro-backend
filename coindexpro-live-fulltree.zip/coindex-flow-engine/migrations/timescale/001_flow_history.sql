-- =============================================================================
-- CoinDex Flow Engine — TimescaleDB note (Phase 11)
-- =============================================================================
-- Sector rotation is written to the EXISTING Phase 2 hypertable `sector_history`
-- (sector, ts, inflow_usd, outflow_usd, volume_usd, net_usd). Phase 11 does NOT
-- recreate it. This file documents the dependency and (idempotently) ensures a
-- continuous-aggregate view for hourly sector netflow used by the API.
-- Apply AFTER coindex-db/migrations/timescale/002_history.sql.
-- =============================================================================

-- Hourly rollup of sector netflow for fast rotation queries.
CREATE MATERIALIZED VIEW IF NOT EXISTS sector_netflow_hourly
WITH (timescaledb.continuous) AS
SELECT
    sector,
    time_bucket('1 hour', ts) AS bucket,
    sum(inflow_usd)  AS inflow_usd,
    sum(outflow_usd) AS outflow_usd,
    sum(volume_usd)  AS volume_usd
FROM sector_history
GROUP BY sector, bucket
WITH NO DATA;
