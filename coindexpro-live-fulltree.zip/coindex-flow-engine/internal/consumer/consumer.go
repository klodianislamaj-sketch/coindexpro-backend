// Package consumer triggers flow rebuilds when new enriched activity arrives. As
// with the graph engine, Kafka messages are only a "something changed" signal —
// the rebuild reads the real source tables for the window, so no message payload
// is ever treated as flow truth.
package consumer

import (
	"context"
	"time"

	"github.com/twmb/franz-go/pkg/kgo"
	"go.uber.org/zap"

	"github.com/coindexpro/coindex-flow-engine/internal/metrics"
)

// WindowBuilder is satisfied by flows.Engine (BuildWindow).
type WindowBuilder interface {
	BuildWindow(ctx context.Context, start, end time.Time) error
}

type Consumer struct {
	cl       *kgo.Client
	builder  WindowBuilder
	window   time.Duration
	debounce time.Duration
	log      *zap.Logger
}

func New(brokers []string, group string, topics []string, builder WindowBuilder, window, debounce time.Duration, log *zap.Logger) (*Consumer, error) {
	cl, err := kgo.NewClient(
		kgo.SeedBrokers(brokers...),
		kgo.ConsumerGroup(group),
		kgo.ConsumeTopics(topics...),
	)
	if err != nil {
		return nil, err
	}
	if window <= 0 {
		window = time.Hour
	}
	if debounce <= 0 {
		debounce = 30 * time.Second
	}
	return &Consumer{cl: cl, builder: builder, window: window, debounce: debounce, log: log}, nil
}

// Run drains messages and schedules a debounced rebuild of the current window.
func (c *Consumer) Run(ctx context.Context) error {
	dirty := false
	timer := time.NewTimer(c.debounce)
	timer.Stop()
	for {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		pollCtx, cancel := context.WithTimeout(ctx, time.Second)
		fetches := c.cl.PollFetches(pollCtx)
		cancel()
		n := 0
		fetches.EachRecord(func(_ *kgo.Record) { n++ })
		if n > 0 {
			metrics.EventsSeen.Add(float64(n))
			if !dirty {
				dirty = true
				timer.Reset(c.debounce)
			}
		}
		select {
		case <-timer.C:
			if dirty {
				dirty = false
				end := time.Now().UTC().Truncate(c.window)
				start := end.Add(-c.window)
				if err := c.builder.BuildWindow(ctx, start, end); err != nil {
					c.log.Warn("triggered rebuild failed", zap.Error(err))
				}
			}
		default:
		}
	}
}

func (c *Consumer) Close() { c.cl.Close() }
