package db

import (
	"context"
	"strings"
	"sync"
	"time"

	"github.com/ClickHouse/clickhouse-go/v2"
	"github.com/ClickHouse/clickhouse-go/v2/lib/driver"
	"github.com/jackc/pgx/v5/pgxpool"
)

type Store struct {
	ch driver.Conn
	pg *pgxpool.Pool

	// small in-memory caches for label/sector/liq lookups within a build cycle
	labelCache  sync.Map // "chain|wallet" -> string
	sectorCache sync.Map // "chain|token" -> string
}

func Open(ctx context.Context, chAddrs []string, chDB, chUser, chPass, pgDSN string) (*Store, error) {
	ch, err := clickhouse.Open(&clickhouse.Options{
		Addr: chAddrs,
		Auth: clickhouse.Auth{Database: chDB, Username: chUser, Password: chPass},
	})
	if err != nil {
		return nil, err
	}
	if err := ch.Ping(ctx); err != nil {
		return nil, err
	}
	pg, err := pgxpool.New(ctx, pgDSN)
	if err != nil {
		return nil, err
	}
	if err := pg.Ping(ctx); err != nil {
		return nil, err
	}
	return &Store{ch: ch, pg: pg}, nil
}

func (s *Store) Close() {
	_ = s.ch.Close()
	s.pg.Close()
}
func (s *Store) Ping(ctx context.Context) error {
	if err := s.ch.Ping(ctx); err != nil {
		return err
	}
	return s.pg.Ping(ctx)
}

// ---------- ClickHouse readers (real source rows) ----------

// WindowTrades reads real wallet_trades for the window. A trade is Priced only
// when usd > 0 (the enricher valued it); unpriced rows are kept for activity but
// flagged so aggregates can report coverage.
func (s *Store) WindowTrades(ctx context.Context, start, end time.Time, limit int) ([]TradeRow, error) {
	const q = `
		SELECT chain, wallet, token, side, usd
		FROM coindex.wallet_trades
		WHERE block_time >= ? AND block_time < ?
		LIMIT ?`
	rows, err := s.ch.Query(ctx, q, start, end, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []TradeRow
	for rows.Next() {
		var t TradeRow
		var side string
		var usd float64
		if err := rows.Scan(&t.Chain, &t.Wallet, &t.Token, &side, &usd); err != nil {
			return nil, err
		}
		t.Side, t.USD, t.Priced, t.BlockTime = side, usd, usd > 0, start
		out = append(out, t)
	}
	return out, rows.Err()
}

// TokenWindowTrades reads real wallet_trades for one token in the window (used by
// the live capital-velocity endpoint).
func (s *Store) TokenWindowTrades(ctx context.Context, chain, token string, start, end time.Time, limit int) ([]TradeRow, error) {
	const q = `
		SELECT chain, wallet, token, side, usd
		FROM coindex.wallet_trades
		WHERE chain = ? AND token = ? AND block_time >= ? AND block_time < ?
		LIMIT ?`
	rows, err := s.ch.Query(ctx, q, chain, token, start, end, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []TradeRow
	for rows.Next() {
		var t TradeRow
		var side string
		var usd float64
		if err := rows.Scan(&t.Chain, &t.Wallet, &t.Token, &side, &usd); err != nil {
			return nil, err
		}
		t.Side, t.USD, t.Priced, t.BlockTime = side, usd, usd > 0, start
		out = append(out, t)
	}
	return out, rows.Err()
}

// SmartMoneyTrades reads real smart_money_events as trade rows.
func (s *Store) SmartMoneyTrades(ctx context.Context, start, end time.Time, limit int) ([]TradeRow, error) {
	const q = `
		SELECT chain, wallet, token, side, usd
		FROM coindex.smart_money_events
		WHERE block_time >= ? AND block_time < ?
		LIMIT ?`
	rows, err := s.ch.Query(ctx, q, start, end, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []TradeRow
	for rows.Next() {
		var t TradeRow
		var side string
		var usd float64
		if err := rows.Scan(&t.Chain, &t.Wallet, &t.Token, &side, &usd); err != nil {
			return nil, err
		}
		t.Side, t.USD, t.Priced, t.BlockTime = side, usd, usd > 0, start
		out = append(out, t)
	}
	return out, rows.Err()
}

// WindowSwaps reads real swaps for exchange/whale directional flow.
func (s *Store) WindowSwaps(ctx context.Context, start, end time.Time, limit int) ([]SwapRow, error) {
	const q = `
		SELECT chain, wallet, token_in, token_out, amount_usd
		FROM coindex.swaps
		WHERE block_time >= ? AND block_time < ?
		LIMIT ?`
	rows, err := s.ch.Query(ctx, q, start, end, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []SwapRow
	for rows.Next() {
		var sw SwapRow
		var usd float64
		if err := rows.Scan(&sw.Chain, &sw.Wallet, &sw.TokenIn, &sw.TokenOut, &usd); err != nil {
			return nil, err
		}
		sw.USD, sw.Priced, sw.BlockTime = usd, usd > 0, start
		out = append(out, sw)
	}
	return out, rows.Err()
}

// ---------- Postgres lookups (real labels / sector / liquidity) ----------

// LabelOf returns a cohort-relevant classification for a wallet from real
// wallet_labels: "exchange" for exchange/cex_hot labels, "smart_money" for the
// smart_money label, else "" (unlabeled). Cached per build cycle.
func (s *Store) LabelOf(ctx context.Context, chain, wallet string) string {
	key := chain + "|" + strings.ToLower(wallet)
	if v, ok := s.labelCache.Load(key); ok {
		return v.(string)
	}
	const q = `SELECT label_type FROM wallet_labels
		WHERE chain=$1 AND address=$2 AND active
		ORDER BY confidence DESC`
	rows, err := s.pg.Query(ctx, q, chain, strings.ToLower(wallet))
	cls := ""
	if err == nil {
		for rows.Next() {
			var lt string
			if rows.Scan(&lt) == nil {
				if lt == "exchange" || lt == "cex_hot" {
					cls = LabelExchange
					break
				}
				if lt == "smart_money" {
					cls = LabelSmartMoney
				}
			}
		}
		rows.Close()
	}
	s.labelCache.Store(key, cls)
	return cls
}

// SectorOf returns a token's sector from graph.token_nodes (real tag) or "".
func (s *Store) SectorOf(ctx context.Context, chain, token string) string {
	key := chain + "|" + strings.ToLower(token)
	if v, ok := s.sectorCache.Load(key); ok {
		return v.(string)
	}
	const q = `SELECT coalesce(sector,'') FROM graph.token_nodes WHERE chain=$1 AND address=$2`
	var sec string
	_ = s.pg.QueryRow(ctx, q, chain, strings.ToLower(token)).Scan(&sec)
	s.sectorCache.Store(key, sec)
	return sec
}

// LiquidityOf returns the latest known liq_usd for a token from token_metrics.
func (s *Store) LiquidityOf(ctx context.Context, chain, token string) (float64, bool) {
	const q = `
		SELECT liq_usd FROM coindex.token_metrics
		WHERE chain = ? AND token = ?
		ORDER BY ts DESC LIMIT 1`
	var liq float64
	if err := s.ch.QueryRow(ctx, q, chain, token).Scan(&liq); err != nil {
		return 0, false
	}
	return liq, liq > 0
}

// BaselineNet returns the prior-window net flows for an entity from flow_snapshots
// (the entity's own history) to baseline anomaly detection.
func (s *Store) BaselineNet(ctx context.Context, scope, chain, entity string, before time.Time, n int) ([]float64, error) {
	const q = `
		SELECT net_usd FROM flow_snapshots
		WHERE scope=$1 AND chain=$2 AND entity=$3 AND window_start < $4
		ORDER BY window_start DESC LIMIT $5`
	rows, err := s.pg.Query(ctx, q, scope, chain, entity, before, n)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []float64
	for rows.Next() {
		var v float64
		if err := rows.Scan(&v); err != nil {
			return nil, err
		}
		out = append(out, v)
	}
	return out, rows.Err()
}

// ResetCaches clears per-cycle lookup caches (call between build windows).
func (s *Store) ResetCaches() {
	s.labelCache.Range(func(k, _ any) bool { s.labelCache.Delete(k); return true })
	s.sectorCache.Range(func(k, _ any) bool { s.sectorCache.Delete(k); return true })
}

// ---------- writers (idempotent upserts) ----------

func (s *Store) UpsertSnapshots(ctx context.Context, snaps []Snapshot) error {
	if len(snaps) == 0 {
		return nil
	}
	tx, err := s.pg.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	for _, sn := range snaps {
		const q = `
			INSERT INTO flow_snapshots
				(scope, chain, entity, window_start, window_end, inflow_usd, outflow_usd, trades, wallets, priced_coverage)
			VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
			ON CONFLICT (scope, chain, entity, window_start) DO UPDATE SET
				window_end=$5, inflow_usd=$6, outflow_usd=$7, trades=$8, wallets=$9,
				priced_coverage=$10, updated_at=now()`
		if _, err := tx.Exec(ctx, q, sn.Scope, sn.Chain, sn.Entity, sn.WindowStart, sn.WindowEnd,
			sn.InflowUSD, sn.OutflowUSD, sn.Trades, sn.Wallets, sn.PricedCoverage); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

func (s *Store) UpsertCohortFlows(ctx context.Context, cs []CohortFlow) error {
	if len(cs) == 0 {
		return nil
	}
	tx, err := s.pg.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	for _, c := range cs {
		const q = `
			INSERT INTO cohort_flows
				(chain, token, cohort, window_start, window_end, inflow_usd, outflow_usd, wallets, priced_coverage)
			VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
			ON CONFLICT (chain, token, cohort, window_start) DO UPDATE SET
				window_end=$5, inflow_usd=$6, outflow_usd=$7, wallets=$8, priced_coverage=$9, updated_at=now()`
		if _, err := tx.Exec(ctx, q, c.Chain, c.Token, c.Cohort, c.WindowStart, c.WindowEnd,
			c.InflowUSD, c.OutflowUSD, c.Wallets, c.PricedCoverage); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

// UpsertSectorHistory writes sector rotation into the EXISTING Phase 2 Timescale
// sector_history hypertable (PK sector, ts) — idempotent per (sector, ts).
func (s *Store) UpsertSectorHistory(ctx context.Context, secs []SectorFlow) error {
	if len(secs) == 0 {
		return nil
	}
	tx, err := s.pg.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	for _, sec := range secs {
		const q = `
			INSERT INTO sector_history (sector, ts, inflow_usd, outflow_usd, volume_usd)
			VALUES ($1,$2,$3,$4,$5)
			ON CONFLICT (sector, ts) DO UPDATE SET
				inflow_usd=$3, outflow_usd=$4, volume_usd=$5`
		if _, err := tx.Exec(ctx, q, sec.Sector, sec.TS, sec.InflowUSD, sec.OutflowUSD, sec.VolumeUSD); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

func (s *Store) UpsertAnomalies(ctx context.Context, as []Anomaly) error {
	if len(as) == 0 {
		return nil
	}
	tx, err := s.pg.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	for _, a := range as {
		const q = `
			INSERT INTO netflow_anomalies
				(scope, chain, entity, window_start, net_usd, baseline_mean, baseline_std, zscore, direction, samples)
			VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
			ON CONFLICT (scope, chain, entity, window_start) DO UPDATE SET
				net_usd=$5, baseline_mean=$6, baseline_std=$7, zscore=$8, direction=$9, samples=$10, detected_at=now()`
		if _, err := tx.Exec(ctx, q, a.Scope, a.Chain, a.Entity, a.WindowStart, a.NetUSD,
			a.BaselineMean, a.BaselineStd, a.ZScore, a.Direction, a.Samples); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

// ---------- API reads ----------

func (s *Store) Snapshots(ctx context.Context, scope, chain, entity string, limit int) ([]Snapshot, error) {
	const q = `
		SELECT scope, chain, entity, window_start, window_end, inflow_usd, outflow_usd, net_usd, trades, wallets, priced_coverage
		FROM flow_snapshots WHERE scope=$1 AND chain=$2 AND entity=$3
		ORDER BY window_start DESC LIMIT $4`
	rows, err := s.pg.Query(ctx, q, scope, chain, strings.ToLower(entity), limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []Snapshot
	for rows.Next() {
		var sn Snapshot
		if err := rows.Scan(&sn.Scope, &sn.Chain, &sn.Entity, &sn.WindowStart, &sn.WindowEnd,
			&sn.InflowUSD, &sn.OutflowUSD, &sn.NetUSD, &sn.Trades, &sn.Wallets, &sn.PricedCoverage); err != nil {
			return nil, err
		}
		out = append(out, sn)
	}
	return out, rows.Err()
}

func (s *Store) CohortFlowsFor(ctx context.Context, chain, token string, limit int) ([]CohortFlow, error) {
	const q = `
		SELECT chain, token, cohort, window_start, window_end, inflow_usd, outflow_usd, net_usd, wallets, priced_coverage
		FROM cohort_flows WHERE chain=$1 AND token=$2
		ORDER BY window_start DESC LIMIT $3`
	rows, err := s.pg.Query(ctx, q, chain, strings.ToLower(token), limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []CohortFlow
	for rows.Next() {
		var c CohortFlow
		if err := rows.Scan(&c.Chain, &c.Token, &c.Cohort, &c.WindowStart, &c.WindowEnd,
			&c.InflowUSD, &c.OutflowUSD, &c.NetUSD, &c.Wallets, &c.PricedCoverage); err != nil {
			return nil, err
		}
		out = append(out, c)
	}
	return out, rows.Err()
}

func (s *Store) SectorFlows(ctx context.Context, sector string, limit int) ([]SectorFlow, error) {
	const q = `
		SELECT sector, ts, inflow_usd, outflow_usd, volume_usd, net_usd
		FROM sector_history WHERE sector=$1 ORDER BY ts DESC LIMIT $2`
	rows, err := s.pg.Query(ctx, q, sector, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []SectorFlow
	for rows.Next() {
		var sf SectorFlow
		if err := rows.Scan(&sf.Sector, &sf.TS, &sf.InflowUSD, &sf.OutflowUSD, &sf.VolumeUSD, &sf.NetUSD); err != nil {
			return nil, err
		}
		out = append(out, sf)
	}
	return out, rows.Err()
}

func (s *Store) Anomalies(ctx context.Context, scope, chain string, limit int) ([]Anomaly, error) {
	const q = `
		SELECT scope, chain, entity, window_start, net_usd, baseline_mean, baseline_std, zscore, direction, samples
		FROM netflow_anomalies WHERE scope=$1 AND chain=$2
		ORDER BY detected_at DESC LIMIT $3`
	rows, err := s.pg.Query(ctx, q, scope, chain, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []Anomaly
	for rows.Next() {
		var a Anomaly
		if err := rows.Scan(&a.Scope, &a.Chain, &a.Entity, &a.WindowStart, &a.NetUSD,
			&a.BaselineMean, &a.BaselineStd, &a.ZScore, &a.Direction, &a.Samples); err != nil {
			return nil, err
		}
		out = append(out, a)
	}
	return out, rows.Err()
}

// FundingOrigins reads a wallet's funding edges from the Phase 9 graph_edges
// (real, already-proven attribution). node id format is "<chain>:<address>".
func (s *Store) FundingOrigins(ctx context.Context, chain, wallet string, limit int) ([]FundingOrigin, error) {
	node := chain + ":" + strings.ToLower(wallet)
	const q = `
		SELECT dst, edge_type, confidence, weight
		FROM graph_edges
		WHERE src=$1 AND edge_type IN ('exchange_funded','insider_funded','vc_funded','dev_funded','funded_unknown')
		ORDER BY confidence DESC, weight DESC LIMIT $2`
	rows, err := s.pg.Query(ctx, q, node, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []FundingOrigin
	for rows.Next() {
		var o FundingOrigin
		o.Wallet = node
		if err := rows.Scan(&o.Source, &o.EdgeType, &o.Confidence, &o.AmountUSD); err != nil {
			return nil, err
		}
		out = append(out, o)
	}
	return out, rows.Err()
}
