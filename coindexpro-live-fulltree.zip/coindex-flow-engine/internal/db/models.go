// Package db holds the flow-engine persistence layer and shared domain types.
// Every flow figure here is an aggregate of REAL observed trades/swaps over a
// window. A key honesty field travels with each aggregate: PricedCoverage, the
// fraction of contributing trades that actually carried a USD value. When
// coverage is low the netflow is partial, and we surface that rather than
// presenting an aggregate as if every trade were priced.
package db

import "time"

// Scopes for flow snapshots / anomalies.
const (
	ScopeToken       = "token"
	ScopeExchange    = "exchange"
	ScopeWhale       = "whale"
	ScopeSmartMoney  = "smart_money"
)

// Cohorts for cohort_flows.
const (
	CohortSmartMoney = "smart_money"
	CohortWhale      = "whale"
	CohortExchange   = "exchange"
	CohortRetail     = "retail"
)

// Anomaly directions.
const (
	DirInflowSpike  = "inflow_spike"
	DirOutflowSpike = "outflow_spike"
)

// TradeRow is one real priced (or unpriced) trade read from ClickHouse. Priced
// is false when usd == 0 (the enricher could not value it); such rows count
// toward volume of activity but reduce PricedCoverage of the resulting aggregate.
type TradeRow struct {
	Chain     string
	Wallet    string
	Token     string
	Side      string // buy | sell
	USD       float64
	Priced    bool
	BlockTime time.Time
}

// SwapRow is one real directional swap (token_in/token_out) for exchange/whale
// directional flow.
type SwapRow struct {
	Chain     string
	Wallet    string
	TokenIn   string
	TokenOut  string
	USD       float64
	Priced    bool
	BlockTime time.Time
}

// Snapshot is a netflow aggregate for one (scope, entity, window).
type Snapshot struct {
	Scope          string    `json:"scope"`
	Chain          string    `json:"chain"`
	Entity         string    `json:"entity"`
	WindowStart    time.Time `json:"window_start"`
	WindowEnd      time.Time `json:"window_end"`
	InflowUSD      float64   `json:"inflow_usd"`
	OutflowUSD     float64   `json:"outflow_usd"`
	NetUSD         float64   `json:"net_usd"`
	Trades         int64     `json:"trades"`
	Wallets        int64     `json:"wallets"`
	PricedCoverage float64   `json:"priced_coverage"`
}

// CohortFlow is net flow by wallet cohort into a token over a window.
type CohortFlow struct {
	Chain          string    `json:"chain"`
	Token          string    `json:"token"`
	Cohort         string    `json:"cohort"`
	WindowStart    time.Time `json:"window_start"`
	WindowEnd      time.Time `json:"window_end"`
	InflowUSD      float64   `json:"inflow_usd"`
	OutflowUSD     float64   `json:"outflow_usd"`
	NetUSD         float64   `json:"net_usd"`
	Wallets        int64     `json:"wallets"`
	PricedCoverage float64   `json:"priced_coverage"`
}

// SectorFlow is a sector's flow over a window (written to Timescale sector_history).
type SectorFlow struct {
	Sector     string    `json:"sector"`
	TS         time.Time `json:"ts"`
	InflowUSD  float64   `json:"inflow_usd"`
	OutflowUSD float64   `json:"outflow_usd"`
	VolumeUSD  float64   `json:"volume_usd"`
	NetUSD     float64   `json:"net_usd"`
}

// Anomaly is a netflow window flagged against the entity's own baseline.
type Anomaly struct {
	Scope        string    `json:"scope"`
	Chain        string    `json:"chain"`
	Entity       string    `json:"entity"`
	WindowStart  time.Time `json:"window_start"`
	NetUSD       float64   `json:"net_usd"`
	BaselineMean float64   `json:"baseline_mean"`
	BaselineStd  float64   `json:"baseline_std"`
	ZScore       float64   `json:"zscore"`
	Direction    string    `json:"direction"`
	Samples      int       `json:"samples"`
}

// FundingOrigin is a traced funding source for a wallet (from Phase 9 graph edges).
type FundingOrigin struct {
	Wallet     string  `json:"wallet"`
	Source     string  `json:"source"`      // funding source node id
	EdgeType   string  `json:"edge_type"`   // exchange_funded | vc_funded | dev_funded | insider_funded | funded_unknown
	Confidence float64 `json:"confidence"`
	AmountUSD  float64 `json:"amount_usd"`
}

// LabelKind classifies a wallet for cohort assignment, derived from real labels.
const (
	LabelExchange   = "exchange"
	LabelSmartMoney = "smart_money"
	LabelWhale      = "whale" // not a stored label; assigned by size threshold (see flows)
)
