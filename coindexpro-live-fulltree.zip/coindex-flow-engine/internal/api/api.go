// Package api serves flow-intelligence reads. Every response is built from
// persisted real aggregates (or, for velocity, computed live from real rows).
// When an entity has no observed flow, the response is {available:false} — the
// API never returns a zero-filled aggregate for something never seen.
package api

import (
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"

	"github.com/coindexpro/coindex-flow-engine/internal/db"
	"github.com/coindexpro/coindex-flow-engine/internal/flows"
	"github.com/coindexpro/coindex-flow-engine/internal/metrics"
)

type API struct{ store *db.Store }

func New(store *db.Store) *API { return &API{store: store} }

func (a *API) Register(app *fiber.App) {
	app.Use(a.observe)
	app.Get("/flow/netflow/:scope/:chain/:entity", a.netflow)
	app.Get("/flow/cohorts/:chain/:token", a.cohorts)
	app.Get("/flow/sector/:sector", a.sector)
	app.Get("/flow/anomalies/:scope/:chain", a.anomalies)
	app.Get("/flow/funding/:chain/:wallet", a.funding)
	app.Get("/flow/velocity/:chain/:token", a.velocity)
}

func (a *API) observe(c *fiber.Ctx) error {
	start := time.Now()
	err := c.Next()
	metrics.APILatency.WithLabelValues(c.Route().Path, statusClass(c.Response().StatusCode())).
		Observe(time.Since(start).Seconds())
	return err
}

var validScope = map[string]bool{
	db.ScopeToken: true, db.ScopeExchange: true, db.ScopeWhale: true, db.ScopeSmartMoney: true,
}

// GET /flow/netflow/:scope/:chain/:entity
func (a *API) netflow(c *fiber.Ctx) error {
	scope := strings.ToLower(c.Params("scope"))
	if !validScope[scope] {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid scope"})
	}
	chain := strings.ToLower(c.Params("chain"))
	entity := strings.ToLower(c.Params("entity"))
	limit := clamp(c.QueryInt("limit", 48), 1, 500)
	snaps, err := a.store.Snapshots(c.UserContext(), scope, chain, entity, limit)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(snaps) == 0 {
		return c.JSON(fiber.Map{"scope": scope, "chain": chain, "entity": entity,
			"available": false, "reason": "not_indexed"})
	}
	return c.JSON(fiber.Map{"scope": scope, "chain": chain, "entity": entity,
		"available": true, "snapshots": snaps})
}

// GET /flow/cohorts/:chain/:token
func (a *API) cohorts(c *fiber.Ctx) error {
	chain := strings.ToLower(c.Params("chain"))
	token := strings.ToLower(c.Params("token"))
	limit := clamp(c.QueryInt("limit", 100), 1, 1000)
	cf, err := a.store.CohortFlowsFor(c.UserContext(), chain, token, limit)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(cf) == 0 {
		return c.JSON(fiber.Map{"chain": chain, "token": token, "available": false, "reason": "not_indexed"})
	}
	// annotate each cohort window with its observed accumulation/distribution state
	type annotated struct {
		db.CohortFlow
		State string `json:"state"`
	}
	out := make([]annotated, 0, len(cf))
	for _, f := range cf {
		out = append(out, annotated{CohortFlow: f, State: flows.AccumulationState(f.NetUSD)})
	}
	return c.JSON(fiber.Map{"chain": chain, "token": token, "available": true, "cohorts": out})
}

// GET /flow/sector/:sector
func (a *API) sector(c *fiber.Ctx) error {
	sec := c.Params("sector")
	limit := clamp(c.QueryInt("limit", 168), 1, 1000)
	sf, err := a.store.SectorFlows(c.UserContext(), sec, limit)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(sf) == 0 {
		return c.JSON(fiber.Map{"sector": sec, "available": false, "reason": "not_indexed"})
	}
	return c.JSON(fiber.Map{"sector": sec, "available": true, "history": sf})
}

// GET /flow/anomalies/:scope/:chain
func (a *API) anomalies(c *fiber.Ctx) error {
	scope := strings.ToLower(c.Params("scope"))
	if !validScope[scope] {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid scope"})
	}
	chain := strings.ToLower(c.Params("chain"))
	limit := clamp(c.QueryInt("limit", 100), 1, 500)
	an, err := a.store.Anomalies(c.UserContext(), scope, chain, limit)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(an) == 0 {
		return c.JSON(fiber.Map{"scope": scope, "chain": chain, "available": false, "reason": "no anomalies"})
	}
	return c.JSON(fiber.Map{"scope": scope, "chain": chain, "available": true, "anomalies": an})
}

// GET /flow/funding/:chain/:wallet — funding origins traced from Phase 9 graph edges
func (a *API) funding(c *fiber.Ctx) error {
	chain := strings.ToLower(c.Params("chain"))
	wallet := strings.ToLower(c.Params("wallet"))
	limit := clamp(c.QueryInt("limit", 100), 1, 500)
	origins, err := a.store.FundingOrigins(c.UserContext(), chain, wallet, limit)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(origins) == 0 {
		return c.JSON(fiber.Map{"chain": chain, "wallet": wallet, "available": false,
			"reason": "no funding edges in graph"})
	}
	traced := flows.TraceFunding(origins) // projection of real graph edges (no new attribution)
	return c.JSON(fiber.Map{"chain": chain, "wallet": wallet, "available": true,
		"origins": traced, "mix": flows.FundingMix(traced)})
}

// GET /flow/velocity/:chain/:token — live capital velocity from the recent window
func (a *API) velocity(c *fiber.Ctx) error {
	chain := strings.ToLower(c.Params("chain"))
	token := strings.ToLower(c.Params("token"))
	window := time.Duration(clamp(c.QueryInt("window_hours", 1), 1, 168)) * time.Hour
	end := time.Now().UTC()
	start := end.Add(-window)
	trades, err := a.store.TokenWindowTrades(c.UserContext(), chain, token, start, end, 500000)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(trades) == 0 {
		return c.JSON(fiber.Map{"chain": chain, "token": token, "available": false, "reason": "not_indexed"})
	}
	liqOf := func(ch, tok string) (float64, bool) { return a.store.LiquidityOf(c.UserContext(), ch, tok) }
	vs := flows.CapitalVelocity(trades, liqOf)
	if len(vs) == 0 {
		return c.JSON(fiber.Map{"chain": chain, "token": token, "available": false, "reason": "not_indexed"})
	}
	return c.JSON(vs[0]) // single token -> single velocity (carries its own available flag)
}

func clamp(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}

func statusClass(code int) string {
	switch {
	case code >= 500:
		return "5xx"
	case code >= 400:
		return "4xx"
	default:
		return "2xx"
	}
}
