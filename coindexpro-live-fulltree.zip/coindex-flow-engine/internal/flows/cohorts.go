package flows

import (
	"time"

	"github.com/coindexpro/coindex-flow-engine/internal/db"
)

// LabelLookup resolves a wallet's relevant label classification from real
// wallet_labels. Returns "" when the wallet has no relevant label (explicitly
// unlabeled — used to classify the 'retail' residual without guessing identity).
type LabelLookup func(chain, wallet string) string

// ExchangeFlows aggregates swaps that touch labeled exchange wallets into per
// exchange-wallet snapshots. Convention (from the exchange's perspective):
//   - a wallet RECEIVING tokens that is a known exchange = a deposit = inflow to
//     the exchange (commonly precedes sell pressure)
//   - a wallet SENDING tokens that is a known exchange = a withdrawal = outflow
// Only swaps where one side is a labeled exchange wallet are counted; everything
// else is ignored (no attribution without a real label).
func ExchangeFlows(swaps []db.SwapRow, label LabelLookup, start, end time.Time) []db.Snapshot {
	byEntity := map[string]map[string]*accumulator{}
	get := func(chain, ex string) *accumulator {
		if byEntity[chain] == nil {
			byEntity[chain] = map[string]*accumulator{}
		}
		if byEntity[chain][ex] == nil {
			byEntity[chain][ex] = newAcc()
		}
		return byEntity[chain][ex]
	}
	for _, s := range swaps {
		lbl := label(s.Chain, s.Wallet)
		if lbl != db.LabelExchange {
			continue // only real exchange-labeled wallets attribute to exchange flow
		}
		acc := get(s.Chain, s.Wallet)
		// token_out non-empty => wallet received token_out (deposit/inflow);
		// token_in non-empty  => wallet sent token_in (withdrawal/outflow).
		if s.TokenOut != "" {
			acc.add("buy", s.USD, s.Priced, s.Wallet) // inflow to exchange
		}
		if s.TokenIn != "" {
			acc.add("sell", s.USD, s.Priced, s.Wallet) // outflow from exchange
		}
	}
	return materialize(db.ScopeExchange, byEntity, start, end)
}

// CohortFlows splits per-token flow by wallet cohort using REAL labels. Cohort
// assignment: exchange/smart_money come from labels; whale is assigned when a
// wallet's priced volume in the window exceeds whaleUSD (a configured size
// threshold, not an identity claim); everything else is the explicit 'retail'
// residual. The residual is labeled 'retail' to mean "no relevant label", not a
// guess about who the wallet is.
func CohortFlows(trades []db.TradeRow, label LabelLookup, whaleUSD float64, start, end time.Time) []db.CohortFlow {
	// first pass: per-wallet priced volume per (chain,token) to detect whales
	type wkey struct{ chain, token, wallet string }
	vol := map[wkey]float64{}
	for _, t := range trades {
		if t.Priced {
			vol[wkey{t.Chain, t.Token, t.Wallet}] += t.USD
		}
	}

	type ckey struct{ chain, token, cohort string }
	accs := map[ckey]*accumulator{}
	getc := func(chain, token, cohort string) *accumulator {
		k := ckey{chain, token, cohort}
		if accs[k] == nil {
			accs[k] = newAcc()
		}
		return accs[k]
	}

	for _, t := range trades {
		cohort := db.CohortRetail
		switch label(t.Chain, t.Wallet) {
		case db.LabelExchange:
			cohort = db.CohortExchange
		case db.LabelSmartMoney:
			cohort = db.CohortSmartMoney
		default:
			if whaleUSD > 0 && vol[wkey{t.Chain, t.Token, t.Wallet}] >= whaleUSD {
				cohort = db.CohortWhale
			}
		}
		getc(t.Chain, t.Token, cohort).add(t.Side, t.USD, t.Priced, t.Wallet)
	}

	var out []db.CohortFlow
	for k, acc := range accs {
		out = append(out, db.CohortFlow{
			Chain: k.chain, Token: k.token, Cohort: k.cohort,
			WindowStart: start, WindowEnd: end,
			InflowUSD: round2(acc.inflow), OutflowUSD: round2(acc.outflow),
			NetUSD:         round2(acc.inflow - acc.outflow),
			Wallets:        int64(len(acc.wallets)),
			PricedCoverage: acc.coverage(),
		})
	}
	return out
}

// AccumulationState classifies a token's whale-cohort behaviour from its cohort
// flow: net positive = accumulation, net negative = distribution. Returns a
// label plus the net figure (no smoothing/guessing — it is the observed sign).
func AccumulationState(net float64) string {
	switch {
	case net > 0:
		return "accumulation"
	case net < 0:
		return "distribution"
	default:
		return "neutral"
	}
}
