package flows

import (
	"math"

	"github.com/coindexpro/coindex-flow-engine/internal/db"
)

// DetectAnomaly compares a current window's net flow to the entity's own baseline
// (its prior windows' net flows). It is a transparent z-score: an anomaly is only
// emitted when there are at least minSamples real baseline windows AND the
// baseline has non-zero spread AND |z| >= zThreshold. Insufficient history yields
// no anomaly (ok=false) — we never flag a spike we cannot ground in a baseline.
func DetectAnomaly(scope, chain, entity string, currentNet float64, baseline []float64, minSamples int, zThreshold float64) (db.Anomaly, bool) {
	if len(baseline) < minSamples {
		return db.Anomaly{}, false
	}
	mean := meanOf(baseline)
	std := stdOf(baseline, mean)
	if std == 0 {
		return db.Anomaly{}, false // no spread -> z undefined; do not fabricate
	}
	z := (currentNet - mean) / std
	if math.Abs(z) < zThreshold {
		return db.Anomaly{}, false
	}
	dir := db.DirInflowSpike
	if z < 0 {
		dir = db.DirOutflowSpike
	}
	return db.Anomaly{
		Scope: scope, Chain: chain, Entity: entity,
		NetUSD: round2(currentNet), BaselineMean: round2(mean), BaselineStd: round2(std),
		ZScore: round4(z), Direction: dir, Samples: len(baseline),
	}, true
}

func meanOf(xs []float64) float64 {
	if len(xs) == 0 {
		return 0
	}
	var s float64
	for _, x := range xs {
		s += x
	}
	return s / float64(len(xs))
}

func stdOf(xs []float64, mean float64) float64 {
	if len(xs) < 2 {
		return 0
	}
	var s float64
	for _, x := range xs {
		d := x - mean
		s += d * d
	}
	return math.Sqrt(s / float64(len(xs)-1)) // sample standard deviation
}
