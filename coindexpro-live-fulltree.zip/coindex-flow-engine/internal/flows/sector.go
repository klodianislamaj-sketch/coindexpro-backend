package flows

import (
	"time"

	"github.com/coindexpro/coindex-flow-engine/internal/db"
)

// SectorLookup maps a token to its sector (from graph.token_nodes.sector).
// Returns "" when the token has no sector tag (it is then excluded from sector
// rotation — we do not assign tokens to a sector we cannot source).
type SectorLookup func(chain, token string) string

// SectorRotation aggregates per-token flow into per-sector inflow/outflow/volume
// for one window, using REAL sector tags. Tokens without a sector tag are skipped
// (counted nowhere) rather than bucketed into a guessed sector.
func SectorRotation(trades []db.TradeRow, sectorOf SectorLookup, start, end time.Time) []db.SectorFlow {
	type acc struct{ in, out, vol float64 }
	m := map[string]*acc{}
	for _, t := range trades {
		if !t.Priced {
			continue // sector USD flow needs a real USD value
		}
		sec := sectorOf(t.Chain, t.Token)
		if sec == "" {
			continue // no sourced sector -> excluded
		}
		a := m[sec]
		if a == nil {
			a = &acc{}
			m[sec] = a
		}
		a.vol += t.USD
		if t.Side == "buy" {
			a.in += t.USD
		} else if t.Side == "sell" {
			a.out += t.USD
		}
	}
	var out []db.SectorFlow
	for sec, a := range m {
		out = append(out, db.SectorFlow{
			Sector: sec, TS: start,
			InflowUSD: round2(a.in), OutflowUSD: round2(a.out),
			VolumeUSD: round2(a.vol), NetUSD: round2(a.in - a.out),
		})
	}
	return out
}
