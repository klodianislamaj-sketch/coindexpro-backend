// Package flows contains the flow-intelligence aggregation logic. All functions
// operate on real trade/swap rows read from ClickHouse; they aggregate observed
// USD flows and never invent a value. Where trades are unpriced (usd==0) they are
// counted for activity but lower the aggregate's priced-coverage, which is
// surfaced so a partial netflow is never presented as complete.
package flows

import (
	"time"

	"github.com/coindexpro/coindex-flow-engine/internal/db"
)

// accumulator builds one Snapshot incrementally.
type accumulator struct {
	inflow, outflow float64
	trades          int64
	priced          int64
	wallets         map[string]struct{}
}

func newAcc() *accumulator { return &accumulator{wallets: map[string]struct{}{}} }

func (a *accumulator) add(side string, usd float64, priced bool, wallet string) {
	a.trades++
	if priced {
		a.priced++
		// token-flow convention: a buy is capital flowing INTO the token, a sell is
		// capital flowing OUT. Unpriced trades contribute to counts only.
		if side == "buy" {
			a.inflow += usd
		} else if side == "sell" {
			a.outflow += usd
		}
	}
	if wallet != "" {
		a.wallets[wallet] = struct{}{}
	}
}

func (a *accumulator) coverage() float64 {
	if a.trades == 0 {
		return 0
	}
	return round4(float64(a.priced) / float64(a.trades))
}

// TokenNetflow aggregates real trades into per-token snapshots for one window.
func TokenNetflow(trades []db.TradeRow, start, end time.Time) []db.Snapshot {
	byEntity := map[string]map[string]*accumulator{} // chain -> token -> acc
	for _, t := range trades {
		if byEntity[t.Chain] == nil {
			byEntity[t.Chain] = map[string]*accumulator{}
		}
		acc := byEntity[t.Chain][t.Token]
		if acc == nil {
			acc = newAcc()
			byEntity[t.Chain][t.Token] = acc
		}
		acc.add(t.Side, t.USD, t.Priced, t.Wallet)
	}
	return materialize(db.ScopeToken, byEntity, start, end)
}

// SmartMoneyNetflow aggregates real smart-money events into per-token snapshots.
// The rows passed in are already filtered to smart-money wallets by the reader.
func SmartMoneyNetflow(trades []db.TradeRow, start, end time.Time) []db.Snapshot {
	byEntity := map[string]map[string]*accumulator{}
	for _, t := range trades {
		if byEntity[t.Chain] == nil {
			byEntity[t.Chain] = map[string]*accumulator{}
		}
		acc := byEntity[t.Chain][t.Token]
		if acc == nil {
			acc = newAcc()
			byEntity[t.Chain][t.Token] = acc
		}
		acc.add(t.Side, t.USD, t.Priced, t.Wallet)
	}
	return materialize(db.ScopeSmartMoney, byEntity, start, end)
}

func materialize(scope string, byEntity map[string]map[string]*accumulator, start, end time.Time) []db.Snapshot {
	var out []db.Snapshot
	for chain, ents := range byEntity {
		for entity, acc := range ents {
			out = append(out, db.Snapshot{
				Scope: scope, Chain: chain, Entity: entity,
				WindowStart: start, WindowEnd: end,
				InflowUSD: round2(acc.inflow), OutflowUSD: round2(acc.outflow),
				NetUSD:         round2(acc.inflow - acc.outflow),
				Trades:         acc.trades,
				Wallets:        int64(len(acc.wallets)),
				PricedCoverage: acc.coverage(),
			})
		}
	}
	return out
}

func round2(x float64) float64 { return float64(int(x*100+0.5)) / 100 }
func round4(x float64) float64 { return float64(int(x*10000+0.5)) / 10000 }
