package flows

import (
	"context"
	"time"

	"go.uber.org/zap"

	"github.com/coindexpro/coindex-flow-engine/internal/db"
	"github.com/coindexpro/coindex-flow-engine/internal/metrics"
)

// Sources is the read surface (implemented by db.Store over ClickHouse + Postgres).
type Sources interface {
	WindowTrades(ctx context.Context, start, end time.Time, limit int) ([]db.TradeRow, error)
	SmartMoneyTrades(ctx context.Context, start, end time.Time, limit int) ([]db.TradeRow, error)
	WindowSwaps(ctx context.Context, start, end time.Time, limit int) ([]db.SwapRow, error)
	LabelOf(ctx context.Context, chain, wallet string) string
	SectorOf(ctx context.Context, chain, token string) string
	BaselineNet(ctx context.Context, scope, chain, entity string, before time.Time, n int) ([]float64, error)
}

// Sink persists derived flow outputs (implemented by db.Store).
type Sink interface {
	UpsertSnapshots(ctx context.Context, s []db.Snapshot) error
	UpsertCohortFlows(ctx context.Context, c []db.CohortFlow) error
	UpsertSectorHistory(ctx context.Context, s []db.SectorFlow) error
	UpsertAnomalies(ctx context.Context, a []db.Anomaly) error
}

type Engine struct {
	src Sources
	sink Sink
	cfg  Config
	log  *zap.Logger
}

type Config struct {
	Window      time.Duration
	MaxRows     int
	WhaleUSD    float64
	AnomalyMinSamples int
	AnomalyZ    float64
	BaselineWindows int
}

func NewEngine(src Sources, sink Sink, cfg Config, log *zap.Logger) *Engine {
	return &Engine{src: src, sink: sink, cfg: cfg, log: log}
}

// BuildWindow runs one full flow computation for the window [start,end). Every
// step reads real rows and aggregates them; if a window has no data, the step
// simply produces nothing (no fabricated zero-rows for entities never seen).
func (e *Engine) BuildWindow(ctx context.Context, start, end time.Time) error {
	t0 := time.Now()

	trades, err := e.src.WindowTrades(ctx, start, end, e.cfg.MaxRows)
	if err != nil {
		return err
	}
	swaps, err := e.src.WindowSwaps(ctx, start, end, e.cfg.MaxRows)
	if err != nil {
		return err
	}
	smTrades, err := e.src.SmartMoneyTrades(ctx, start, end, e.cfg.MaxRows)
	if err != nil {
		return err
	}

	label := func(chain, w string) string { return e.src.LabelOf(ctx, chain, w) }
	sector := func(chain, tok string) string { return e.src.SectorOf(ctx, chain, tok) }

	// 1) token + smart-money netflow snapshots
	tokenSnaps := TokenNetflow(trades, start, end)
	smSnaps := SmartMoneyNetflow(smTrades, start, end)
	// 2) exchange flows (only labeled exchange wallets)
	exSnaps := ExchangeFlows(swaps, label, start, end)
	allSnaps := append(append(tokenSnaps, smSnaps...), exSnaps...)
	if err := e.sink.UpsertSnapshots(ctx, allSnaps); err != nil {
		return err
	}
	metrics.SnapshotsWritten.Add(float64(len(allSnaps)))

	// 3) cohort flows
	cohorts := CohortFlows(trades, label, e.cfg.WhaleUSD, start, end)
	if err := e.sink.UpsertCohortFlows(ctx, cohorts); err != nil {
		return err
	}

	// 4) sector rotation -> Timescale sector_history
	sectors := SectorRotation(trades, sector, start, end)
	if err := e.sink.UpsertSectorHistory(ctx, sectors); err != nil {
		return err
	}

	// 5) netflow anomalies vs each entity's own baseline
	anomalies := e.detectAnomalies(ctx, tokenSnaps, start)
	if err := e.sink.UpsertAnomalies(ctx, anomalies); err != nil {
		return err
	}

	metrics.Builds.Inc()
	metrics.BuildDuration.Observe(time.Since(t0).Seconds())
	e.log.Info("flow window built",
		zap.Time("start", start), zap.Int("trades", len(trades)),
		zap.Int("snapshots", len(allSnaps)), zap.Int("cohorts", len(cohorts)),
		zap.Int("sectors", len(sectors)), zap.Int("anomalies", len(anomalies)))
	return nil
}

func (e *Engine) detectAnomalies(ctx context.Context, snaps []db.Snapshot, start time.Time) []db.Anomaly {
	var out []db.Anomaly
	for _, s := range snaps {
		baseline, err := e.src.BaselineNet(ctx, s.Scope, s.Chain, s.Entity, start, e.cfg.BaselineWindows)
		if err != nil {
			e.log.Warn("baseline read failed", zap.String("entity", s.Entity), zap.Error(err))
			continue
		}
		a, ok := DetectAnomaly(s.Scope, s.Chain, s.Entity, s.NetUSD, baseline, e.cfg.AnomalyMinSamples, e.cfg.AnomalyZ)
		if !ok {
			continue
		}
		a.WindowStart = start
		out = append(out, a)
	}
	return out
}
