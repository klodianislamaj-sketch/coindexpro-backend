package flows

import "github.com/coindexpro/coindex-flow-engine/internal/db"

// TraceFunding turns Phase 9 graph funding edges into FundingOrigin records. It
// performs NO new attribution: it reports exactly the funding edges the graph
// engine already proved (exchange_funded / vc_funded / dev_funded /
// insider_funded / funded_unknown) with their existing confidence. An unlabeled
// origin stays 'funded_unknown' — this engine never upgrades an unknown source to
// a named one.
func TraceFunding(edges []db.FundingOrigin) []db.FundingOrigin {
	// pass-through with stable ordering by confidence then amount; the inputs are
	// already real graph edges, so this is a projection, not an inference.
	out := make([]db.FundingOrigin, 0, len(edges))
	for _, e := range edges {
		// defensive: never emit a confidence outside [0,1]
		if e.Confidence < 0 {
			e.Confidence = 0
		}
		if e.Confidence > 1 {
			e.Confidence = 1
		}
		out = append(out, e)
	}
	return out
}

// FundingMix summarizes a wallet's funding origins by edge type (count + total
// observed USD). Useful for "where did this cohort's capital originate" without
// inventing proportions for unknowns.
func FundingMix(origins []db.FundingOrigin) map[string]struct {
	Count     int     `json:"count"`
	AmountUSD float64 `json:"amount_usd"`
} {
	m := map[string]struct {
		Count     int     `json:"count"`
		AmountUSD float64 `json:"amount_usd"`
	}{}
	for _, o := range origins {
		e := m[o.EdgeType]
		e.Count++
		e.AmountUSD = round2(e.AmountUSD + o.AmountUSD)
		m[o.EdgeType] = e
	}
	return m
}
