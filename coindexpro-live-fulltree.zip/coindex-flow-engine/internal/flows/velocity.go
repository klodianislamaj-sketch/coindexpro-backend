package flows

import "github.com/coindexpro/coindex-flow-engine/internal/db"

// CapitalVelocity measures how fast capital is changing hands relative to the
// pool it sits in: priced volume over the window divided by reference liquidity.
// It requires a REAL liquidity figure (liq_usd from token_metrics); when
// liquidity is unknown (<=0) velocity is unavailable, not a fabricated ratio.
type Velocity struct {
	Chain       string  `json:"chain"`
	Token       string  `json:"token"`
	VolumeUSD   float64 `json:"volume_usd"`
	LiquidityUSD float64 `json:"liquidity_usd"`
	Velocity    float64 `json:"velocity"`     // volume / liquidity
	Available   bool    `json:"available"`
	Reason      string  `json:"reason,omitempty"`
}

// CapitalVelocity computes velocity per token from the window's priced volume and
// the token's reference liquidity. liqOf returns (liq_usd, ok).
func CapitalVelocity(trades []db.TradeRow, liqOf func(chain, token string) (float64, bool)) []Velocity {
	vol := map[[2]string]float64{}
	for _, t := range trades {
		if t.Priced {
			vol[[2]string{t.Chain, t.Token}] += t.USD
		}
	}
	var out []Velocity
	for k, v := range vol {
		liq, ok := liqOf(k[0], k[1])
		if !ok || liq <= 0 {
			out = append(out, Velocity{Chain: k[0], Token: k[1], VolumeUSD: round2(v),
				Available: false, Reason: "liquidity not available"})
			continue
		}
		out = append(out, Velocity{
			Chain: k[0], Token: k[1], VolumeUSD: round2(v), LiquidityUSD: round2(liq),
			Velocity: round4(v / liq), Available: true,
		})
	}
	return out
}
