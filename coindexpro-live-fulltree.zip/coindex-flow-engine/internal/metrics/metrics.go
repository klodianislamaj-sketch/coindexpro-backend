// Package metrics holds the flow-engine's Prometheus instruments.
package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	Builds = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_flow_builds_total", Help: "Flow window builds.",
	})
	BuildDuration = promauto.NewHistogram(prometheus.HistogramOpts{
		Name: "coindex_flow_build_seconds", Help: "Flow build duration.",
		Buckets: []float64{0.5, 1, 5, 15, 30, 60, 120, 300},
	})
	SnapshotsWritten = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_flow_snapshots_total", Help: "Flow snapshots written.",
	})
	EventsSeen = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_flow_events_seen_total", Help: "Upstream events observed by the consumer.",
	})
	APILatency = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name: "coindex_flow_api_seconds", Help: "API latency by route + status.",
		Buckets: prometheus.DefBuckets,
	}, []string{"route", "status"})
	DBErrors = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_flow_db_errors_total", Help: "DB errors.",
	})
)
