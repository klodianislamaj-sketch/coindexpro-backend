// Package config loads flow-engine configuration from YAML with ${ENV} expansion.
package config

import (
	"fmt"
	"os"
	"time"

	"gopkg.in/yaml.v3"
)

type Config struct {
	Server     ServerConfig     `yaml:"server"`
	ClickHouse ClickHouseConfig `yaml:"clickhouse"`
	Postgres   PostgresConfig   `yaml:"postgres"`
	Redis      RedisConfig      `yaml:"redis"`
	Kafka      KafkaConfig      `yaml:"kafka"`
	Flow       FlowConfig       `yaml:"flow"`
	Log        LogConfig        `yaml:"log"`
}

type ServerConfig struct {
	APIAddr     string `yaml:"api_addr"`
	MetricsAddr string `yaml:"metrics_addr"`
}
type ClickHouseConfig struct {
	Addrs    []string `yaml:"addrs"`
	Database string   `yaml:"database"`
	Username string   `yaml:"username"`
	Password string   `yaml:"password"`
}
type PostgresConfig struct {
	DSN string `yaml:"dsn"`
}
type RedisConfig struct {
	Addr string `yaml:"addr"`
}
type KafkaConfig struct {
	Enabled  bool          `yaml:"enabled"`
	Brokers  []string      `yaml:"brokers"`
	GroupID  string        `yaml:"group_id"`
	Topics   []string      `yaml:"topics"`
	Debounce time.Duration `yaml:"debounce"`
}
type FlowConfig struct {
	Enabled           bool          `yaml:"enabled"`
	Interval          time.Duration `yaml:"interval"`
	Window            time.Duration `yaml:"window"`
	MaxRows           int           `yaml:"max_rows"`
	WhaleUSD          float64       `yaml:"whale_usd"`
	AnomalyMinSamples int           `yaml:"anomaly_min_samples"`
	AnomalyZ          float64       `yaml:"anomaly_z"`
	BaselineWindows   int           `yaml:"baseline_windows"`
	CacheTTL          time.Duration `yaml:"cache_ttl"`
}
type LogConfig struct {
	Level string `yaml:"level"`
}

func Load(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}
	var c Config
	if err := yaml.Unmarshal([]byte(os.Expand(string(raw), os.Getenv)), &c); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}
	c.defaults()
	return &c, c.validate()
}

func (c *Config) defaults() {
	if c.Server.APIAddr == "" {
		c.Server.APIAddr = ":8097"
	}
	if c.Server.MetricsAddr == "" {
		c.Server.MetricsAddr = ":9109"
	}
	if c.Flow.Interval == 0 {
		c.Flow.Interval = time.Hour
	}
	if c.Flow.Window == 0 {
		c.Flow.Window = time.Hour
	}
	if c.Flow.MaxRows == 0 {
		c.Flow.MaxRows = 2000000
	}
	if c.Flow.WhaleUSD == 0 {
		c.Flow.WhaleUSD = 100000 // $100k priced volume in window to be treated as whale
	}
	if c.Flow.AnomalyMinSamples == 0 {
		c.Flow.AnomalyMinSamples = 12
	}
	if c.Flow.AnomalyZ == 0 {
		c.Flow.AnomalyZ = 3.0
	}
	if c.Flow.BaselineWindows == 0 {
		c.Flow.BaselineWindows = 48
	}
	if c.Flow.CacheTTL == 0 {
		c.Flow.CacheTTL = 30 * time.Second
	}
	if c.Kafka.GroupID == "" {
		c.Kafka.GroupID = "coindex-flow-engine"
	}
}

func (c *Config) validate() error {
	if len(c.ClickHouse.Addrs) == 0 {
		return fmt.Errorf("clickhouse.addrs empty")
	}
	if c.Postgres.DSN == "" {
		return fmt.Errorf("postgres.dsn empty")
	}
	if c.Redis.Addr == "" {
		return fmt.Errorf("redis.addr empty")
	}
	if c.Kafka.Enabled && len(c.Kafka.Brokers) == 0 {
		return fmt.Errorf("kafka.enabled but brokers empty")
	}
	return nil
}
