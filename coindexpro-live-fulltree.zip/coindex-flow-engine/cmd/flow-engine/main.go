// Command flow-engine is the Phase 11 entrypoint. It computes flow-intelligence
// aggregates (netflows, cohort flows, sector rotation, capital velocity, netflow
// anomalies, funding-origin tracing) from real source tables on a schedule and/or
// on upstream activity, and serves them over a read API.
package main

import (
	"context"
	"errors"
	"flag"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/compress"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"github.com/redis/go-redis/v9"
	"go.uber.org/zap"

	"github.com/coindexpro/coindex-flow-engine/config"
	"github.com/coindexpro/coindex-flow-engine/internal/api"
	"github.com/coindexpro/coindex-flow-engine/internal/cache"
	"github.com/coindexpro/coindex-flow-engine/internal/consumer"
	"github.com/coindexpro/coindex-flow-engine/internal/db"
	"github.com/coindexpro/coindex-flow-engine/internal/flows"
)

func main() {
	cfgPath := flag.String("config", "config/config.yaml", "config path")
	flag.Parse()

	cfg, err := config.Load(*cfgPath)
	if err != nil {
		panic(err)
	}
	log, _ := zap.NewProduction()
	defer func() { _ = log.Sync() }()
	log.Info("starting flow-engine")

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	store, err := db.Open(ctx, cfg.ClickHouse.Addrs, cfg.ClickHouse.Database,
		cfg.ClickHouse.Username, cfg.ClickHouse.Password, cfg.Postgres.DSN)
	if err != nil {
		log.Fatal("db open failed", zap.Error(err))
	}
	defer store.Close()

	c := cache.New(cfg.Redis.Addr, cfg.Flow.CacheTTL)
	if err := c.Ping(ctx); err != nil {
		log.Fatal("redis ping failed", zap.Error(err))
	}
	defer func() { _ = c.Close() }()
	rdb := redis.NewClient(&redis.Options{Addr: cfg.Redis.Addr})
	defer func() { _ = rdb.Close() }()

	engine := flows.NewEngine(store, store, flows.Config{
		Window:            cfg.Flow.Window,
		MaxRows:           cfg.Flow.MaxRows,
		WhaleUSD:          cfg.Flow.WhaleUSD,
		AnomalyMinSamples: cfg.Flow.AnomalyMinSamples,
		AnomalyZ:          cfg.Flow.AnomalyZ,
		BaselineWindows:   cfg.Flow.BaselineWindows,
	}, log)

	// periodic build loop over the most recent completed window
	if cfg.Flow.Enabled {
		go func() {
			t := time.NewTicker(cfg.Flow.Interval)
			defer t.Stop()
			runOnce := func() {
				store.ResetCaches()
				end := time.Now().UTC().Truncate(cfg.Flow.Window)
				start := end.Add(-cfg.Flow.Window)
				if err := engine.BuildWindow(ctx, start, end); err != nil {
					log.Warn("scheduled build failed", zap.Error(err))
				}
			}
			runOnce()
			for {
				select {
				case <-ctx.Done():
					return
				case <-t.C:
					runOnce()
				}
			}
		}()
	}

	// optional Kafka-triggered rebuilds
	var cons *consumer.Consumer
	if cfg.Kafka.Enabled {
		cons, err = consumer.New(cfg.Kafka.Brokers, cfg.Kafka.GroupID, cfg.Kafka.Topics, engine, cfg.Flow.Window, cfg.Kafka.Debounce, log)
		if err != nil {
			log.Fatal("kafka consumer init failed", zap.Error(err))
		}
		go func() {
			if err := cons.Run(ctx); err != nil && !errors.Is(err, context.Canceled) {
				log.Error("consumer stopped", zap.Error(err))
			}
		}()
		defer cons.Close()
	}

	app := fiber.New(fiber.Config{AppName: "coindex-flow-engine"})
	app.Use(compress.New())
	api.New(store).Register(app)
	go func() {
		log.Info("api listening", zap.String("addr", cfg.Server.APIAddr))
		if err := app.Listen(cfg.Server.APIAddr); err != nil {
			log.Error("api stopped", zap.Error(err))
		}
	}()

	go serveOps(cfg.Server.MetricsAddr, store, rdb, log)

	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
	<-sig
	log.Info("shutting down")
	cancel()
	sc, scCancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer scCancel()
	_ = app.ShutdownWithContext(sc)
}

func serveOps(addr string, store *db.Store, rdb *redis.Client, log *zap.Logger) {
	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ok"))
	})
	mux.HandleFunc("/readyz", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), 3*time.Second)
		defer cancel()
		if err := store.Ping(ctx); err != nil {
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte("db down"))
			return
		}
		if err := rdb.Ping(ctx).Err(); err != nil {
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte("redis down"))
			return
		}
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ready"))
	})
	mux.Handle("/metrics", promhttp.Handler())
	srv := &http.Server{Addr: addr, Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Error("ops server failed", zap.Error(err))
	}
}
