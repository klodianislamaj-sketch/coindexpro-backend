## coindex-flow-engine — Phase 11

Flow-intelligence engine. It aggregates **real observed trades/swaps** into
netflows, cohort flows, sector rotation, capital velocity, netflow anomalies, and
funding-origin traces. Every figure is an aggregate of real rows over a window —
nothing is synthesized, and partial pricing is surfaced rather than hidden.

### Architecture

```
real source (ClickHouse + Postgres)        flow engine                  storage
───────────────────────────────────        ───────────                  ───────
wallet_trades, swaps, smart_money_events ─► engine.BuildWindow ─► flow_snapshots
token_metrics (liq_usd)                  ─► netflow / cohorts   ─► cohort_flows
wallet_labels (exchange/smart_money)     ─► sector / velocity   ─► netflow_anomalies
graph.token_nodes.sector                 ─► anomaly (z-score)   ─► sector_history (Phase 2 reuse)
graph_edges (funding_*)                  ─► funding projection
```

Builds run on a schedule (default hourly window) and/or on debounced Kafka
activity (the message is only a signal; the rebuild reads the real tables).

### Source-of-truth mapping (no new ingestion)

| Flow output | Built from |
|---|---|
| token / smart-money netflow | `wallet_trades`, `smart_money_events` (buy=inflow, sell=outflow) |
| exchange flows | `swaps` where a side is a **labeled exchange wallet** (`wallet_labels`) |
| cohort flows | `wallet_trades` split by **real labels** (+ whale by size threshold; retail = explicit residual) |
| sector rotation | `wallet_trades` bucketed by `graph.token_nodes.sector` → Phase 2 `sector_history` |
| capital velocity | window priced volume ÷ `token_metrics.liq_usd` |
| netflow anomalies | z-score of a window's net vs the entity's own prior windows |
| funding origins | **projection of Phase 9 `graph_edges`** funding edges (no new attribution) |

### Priced-coverage (the honesty field)

A trade is only counted in USD flow when it carries a real USD value
(`usd > 0` from the enricher). Unpriced trades still count toward activity but
**lower `priced_coverage`** — the fraction of contributing trades that were
priced. Every snapshot/cohort row exposes it, so a partial netflow is never
presented as if every trade were valued.

### Cohort model

Cohorts come from **real `wallet_labels`**: `exchange` (exchange/cex_hot),
`smart_money`. `whale` is assigned when a wallet's priced volume in the window
exceeds the configured `whale_usd` (a **size** threshold, not an identity claim).
Everything else is the explicit `retail` residual — meaning *no relevant label*,
not a guess about who the wallet is.

### Whale accumulation / distribution

Each cohort window is annotated with its observed state from the **sign of net
flow**: `accumulation` (net > 0), `distribution` (net < 0), `neutral` (0). No
smoothing or prediction — it is the observed sign.

### Netflow anomalies

A transparent z-score: a window's net flow vs the mean/std of the entity's prior
windows. An anomaly is emitted **only** when there are ≥ `anomaly_min_samples`
real baseline windows **and** the baseline has non-zero spread **and**
`|z| ≥ anomaly_z`. Insufficient history → no anomaly (we never flag a spike we
cannot ground in a baseline). The row exposes `baseline_mean`, `baseline_std`,
`zscore`, `samples`.

### Funding-origin tracing

`/flow/funding` projects the Phase 9 graph funding edges
(`exchange_funded`/`vc_funded`/`dev_funded`/`insider_funded`/`funded_unknown`)
with their existing confidence. It performs **no new attribution** — an unlabeled
origin stays `funded_unknown`, never upgraded to a named source.

### API

| Route | Returns |
|---|---|
| `GET /flow/netflow/:scope/:chain/:entity` | netflow snapshots (`scope`=token\|exchange\|whale\|smart_money) |
| `GET /flow/cohorts/:chain/:token` | cohort flows + accumulation state |
| `GET /flow/sector/:sector` | sector rotation history |
| `GET /flow/anomalies/:scope/:chain` | flagged netflow anomalies |
| `GET /flow/funding/:chain/:wallet` | funding origins (graph projection) + mix |
| `GET /flow/velocity/:chain/:token` | live capital velocity (volume ÷ liquidity) |

No observed flow → `{available:false, reason:"not_indexed"}`. Velocity with
unknown liquidity → `available:false`, never a fabricated ratio. Ops: `/healthz`,
`/readyz`, `/metrics`.

### Idempotency & replay

All writes upsert on natural keys (`flow_snapshots` on `(scope,chain,entity,window_start)`,
`cohort_flows` on `(chain,token,cohort,window_start)`, `netflow_anomalies` on
`(scope,chain,entity,window_start)`, `sector_history` on `(sector,ts)`), so
recomputing a window converges rather than duplicating. Aggregation is
deterministic over the same source rows.

### Honest boundaries / runtime limitations

- **Real, production-shaped code, NOT compiled or run here** (no Go toolchain, no
  ClickHouse/Postgres/Redis/Kafka, no network). Statically reviewed (imports/
  symbols/interfaces resolve; no import cycle — `db` does not import `flows`; routes
  distinct; no dead code). Netflow coverage, cohort assignment, accumulation, and
  the anomaly z-score were verified by simulation. Before production:
  `go build` + `vet` + lint and an integration run.
- **Only as real as the source.** Netflows are only as complete as pricing
  coverage (exposed per row). Exchange flows require **real exchange labels** —
  without them, exchange attribution is simply absent, not guessed. Sector
  rotation only covers tokens with a **sourced sector tag**; untagged tokens are
  excluded, not bucketed into a guessed sector.
- **No synthesized entities.** A window with no activity for an entity produces no
  row — there are no zero-filled placeholders for things never observed.
- **Funding is a projection,** not a re-derivation: it never invents a funding
  source the graph engine did not already prove.
