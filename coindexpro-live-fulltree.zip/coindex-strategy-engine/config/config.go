// Package config loads strategy-engine configuration from YAML with ${ENV} expansion.
package config

import (
	"fmt"
	"os"
	"time"

	"gopkg.in/yaml.v3"

	"github.com/coindexpro/coindex-strategy-engine/internal/strategy"
)

type Config struct {
	Server     ServerConfig     `yaml:"server"`
	Postgres   PostgresConfig   `yaml:"postgres"`
	ClickHouse ClickHouseConfig `yaml:"clickhouse"`
	Redis      RedisConfig      `yaml:"redis"`
	Kafka      KafkaConfig      `yaml:"kafka"`
	Build      BuildConfig      `yaml:"build"`
	Weights    WeightsConfig    `yaml:"weights"`
	Log        LogConfig        `yaml:"log"`
}

type ServerConfig struct {
	APIAddr     string `yaml:"api_addr"`
	MetricsAddr string `yaml:"metrics_addr"`
}
type PostgresConfig struct {
	DSN string `yaml:"dsn"`
}
type ClickHouseConfig struct {
	Addrs    []string `yaml:"addrs"`
	Database string   `yaml:"database"`
	Username string   `yaml:"username"`
	Password string   `yaml:"password"`
}
type RedisConfig struct {
	Addr string `yaml:"addr"`
}
type KafkaConfig struct {
	Enabled  bool          `yaml:"enabled"`
	Brokers  []string      `yaml:"brokers"`
	GroupID  string        `yaml:"group_id"`
	Topics   []string      `yaml:"topics"`
	Debounce time.Duration `yaml:"debounce"`
}
type BuildConfig struct {
	Enabled       bool          `yaml:"enabled"`
	Interval      time.Duration `yaml:"interval"`
	MaxTokens     int           `yaml:"max_tokens"`
	MaxWallets    int           `yaml:"max_wallets"`
	MinConfidence float64       `yaml:"min_confidence"`
	MinOppScore   float64       `yaml:"min_opp_score"`
	CacheTTL      time.Duration `yaml:"cache_ttl"`
}

// WeightsConfig mirrors strategy.Weights so operators can override defaults. A
// zero value falls back to the documented default for that weight.
type WeightsConfig struct {
	ConvSmartMoney   float64 `yaml:"conv_smart_money"`
	ConvWhale        float64 `yaml:"conv_whale"`
	ConvSentiment    float64 `yaml:"conv_sentiment"`
	ConvSocialVel    float64 `yaml:"conv_social_velocity"`
	ConvRisk         float64 `yaml:"conv_risk"`
	ConvLiquidity    float64 `yaml:"conv_liquidity"`
	FollowPnl        float64 `yaml:"follow_pnl"`
	FollowWinRate    float64 `yaml:"follow_win_rate"`
	FollowConviction float64 `yaml:"follow_conviction"`
	FollowInfluence  float64 `yaml:"follow_influence"`
	EntrySmartMoney  float64 `yaml:"entry_smart_money"`
	EntrySentiment   float64 `yaml:"entry_sentiment"`
	EntryRisk        float64 `yaml:"entry_risk"`
	ExitDistribution float64 `yaml:"exit_distribution"`
	ExitWhale        float64 `yaml:"exit_whale"`
	ExitRiskIncrease float64 `yaml:"exit_risk_increase"`
	ExitSentiment    float64 `yaml:"exit_sentiment"`
	FlowScaleUSD     float64 `yaml:"flow_scale_usd"`
}
type LogConfig struct {
	Level string `yaml:"level"`
}

func Load(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}
	var c Config
	if err := yaml.Unmarshal([]byte(os.Expand(string(raw), os.Getenv)), &c); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}
	c.defaults()
	return &c, c.validate()
}

func (c *Config) defaults() {
	if c.Server.APIAddr == "" {
		c.Server.APIAddr = ":8099"
	}
	if c.Server.MetricsAddr == "" {
		c.Server.MetricsAddr = ":9111"
	}
	if c.Build.Interval == 0 {
		c.Build.Interval = 5 * time.Minute
	}
	if c.Build.MaxTokens == 0 {
		c.Build.MaxTokens = 1000
	}
	if c.Build.MaxWallets == 0 {
		c.Build.MaxWallets = 1000
	}
	if c.Build.MinConfidence == 0 {
		c.Build.MinConfidence = 0.5
	}
	if c.Build.MinOppScore == 0 {
		c.Build.MinOppScore = 60
	}
	if c.Build.CacheTTL == 0 {
		c.Build.CacheTTL = 30 * time.Second
	}
	if c.Kafka.GroupID == "" {
		c.Kafka.GroupID = "coindex-strategy-engine"
	}
}

func (c *Config) validate() error {
	if c.Postgres.DSN == "" {
		return fmt.Errorf("postgres.dsn empty")
	}
	if len(c.ClickHouse.Addrs) == 0 {
		return fmt.Errorf("clickhouse.addrs empty")
	}
	if c.Redis.Addr == "" {
		return fmt.Errorf("redis.addr empty")
	}
	if c.Kafka.Enabled && len(c.Kafka.Brokers) == 0 {
		return fmt.Errorf("kafka.enabled but brokers empty")
	}
	return nil
}

// ResolveWeights overlays configured weights onto the documented defaults.
func (c *Config) ResolveWeights() strategy.Weights {
	w := strategy.DefaultWeights()
	set := func(dst *float64, v float64) {
		if v != 0 {
			*dst = v
		}
	}
	set(&w.ConvSmartMoney, c.Weights.ConvSmartMoney)
	set(&w.ConvWhale, c.Weights.ConvWhale)
	set(&w.ConvSentiment, c.Weights.ConvSentiment)
	set(&w.ConvSocialVel, c.Weights.ConvSocialVel)
	set(&w.ConvRisk, c.Weights.ConvRisk)
	set(&w.ConvLiquidity, c.Weights.ConvLiquidity)
	set(&w.FollowPnl, c.Weights.FollowPnl)
	set(&w.FollowWinRate, c.Weights.FollowWinRate)
	set(&w.FollowConviction, c.Weights.FollowConviction)
	set(&w.FollowInfluence, c.Weights.FollowInfluence)
	set(&w.EntrySmartMoney, c.Weights.EntrySmartMoney)
	set(&w.EntrySentiment, c.Weights.EntrySentiment)
	set(&w.EntryRisk, c.Weights.EntryRisk)
	set(&w.ExitDistribution, c.Weights.ExitDistribution)
	set(&w.ExitWhale, c.Weights.ExitWhale)
	set(&w.ExitRiskIncrease, c.Weights.ExitRiskIncrease)
	set(&w.ExitSentiment, c.Weights.ExitSentiment)
	set(&w.FlowScaleUSD, c.Weights.FlowScaleUSD)
	return w
}
