package scoring

import (
	"math"
	"testing"
)

// All-available components: confidence must be 1.0 (availW == totalW) and the
// score is the weighted average scaled to 0..100.
func TestBuilder_AllAvailableConfidenceIsOne(t *testing.T) {
	b := New()
	b.Add("a", "src.a", 0.8, 0.5, true, "")
	b.Add("b", "src.b", 0.4, 0.5, true, "")
	sig, ok := b.Build("k", "eth", "0xabc", "r")
	if !ok {
		t.Fatal("expected ok with available components")
	}
	if math.Abs(sig.Confidence-1.0) > 1e-9 {
		t.Fatalf("all-available confidence must be 1.0, got %v", sig.Confidence)
	}
	// weighted avg = (0.8*0.5 + 0.4*0.5)/(0.5+0.5) = 0.6 -> 60
	if math.Abs(sig.Score-60) > 0.01 {
		t.Fatalf("score want 60, got %v", sig.Score)
	}
}

// An unavailable component must lower confidence (it adds to total weight but not
// available weight) and be recorded in Missing — never silently dropped.
func TestBuilder_UnavailableLowersConfidenceAndRecordsMissing(t *testing.T) {
	b := New()
	b.Add("a", "src.a", 1.0, 0.5, true, "")
	b.Add("b", "src.b", 0, 0.5, false, "not indexed")
	sig, ok := b.Build("k", "eth", "0xabc", "r")
	if !ok {
		t.Fatal("one available component is enough to build")
	}
	// confidence = availW/totalW = 0.5/1.0 = 0.5
	if math.Abs(sig.Confidence-0.5) > 1e-9 {
		t.Fatalf("confidence want 0.5, got %v", sig.Confidence)
	}
	if len(sig.Missing) == 0 {
		t.Fatal("unavailable component must be recorded in Missing")
	}
}

// Zero available inputs -> ok=false (not indexed). The single most important
// honesty invariant of the scorer: no inputs => no fabricated score.
func TestBuilder_ZeroAvailableInputsIsNotOk(t *testing.T) {
	b := New()
	b.Add("a", "src.a", 0, 0.5, false, "not indexed")
	b.Add("b", "src.b", 0, 0.5, false, "not indexed")
	if _, ok := b.Build("k", "eth", "0xabc", "r"); ok {
		t.Fatal("zero available inputs must return ok=false")
	}
}

// Score is the available-weighted average — a higher-weighted component pulls it.
func TestBuilder_WeightingPullsScore(t *testing.T) {
	b := New()
	b.Add("hi", "src.hi", 1.0, 0.9, true, "")
	b.Add("lo", "src.lo", 0.0, 0.1, true, "")
	sig, _ := b.Build("k", "eth", "0xabc", "r")
	// (1*0.9 + 0*0.1)/1.0 = 0.9 -> 90
	if math.Abs(sig.Score-90) > 0.01 {
		t.Fatalf("weighted score want 90, got %v", sig.Score)
	}
}

func TestNormLinear_Bounds(t *testing.T) {
	if NormLinear(-5, 0, 100) != 0 {
		t.Fatal("below lo must clamp to 0")
	}
	if NormLinear(500, 0, 100) != 1 {
		t.Fatal("above hi must clamp to 1")
	}
	if v := NormLinear(50, 0, 100); math.Abs(v-0.5) > 1e-9 {
		t.Fatalf("midpoint want 0.5, got %v", v)
	}
}
