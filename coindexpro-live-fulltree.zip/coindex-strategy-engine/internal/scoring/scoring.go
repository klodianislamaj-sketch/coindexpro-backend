// Package scoring is the explainable scoring core. A score is built from weighted
// components; each component is either available (a real normalized input) or
// unavailable (recorded as such, contributing nothing). The final score is the
// weighted average of available components scaled to 0..100, and confidence is
// the share of total weight that was actually available. This guarantees rule 6:
// every score exposes components, weights, confidence, and the missing inputs —
// and a score is never fabricated from no inputs.
package scoring

import (
	"math"

	"github.com/coindexpro/coindex-strategy-engine/internal/db"
)

// Builder accumulates components for one score.
type Builder struct {
	components []db.Component
	missing    []string
	totalW     float64
	availW     float64
	availValW  float64 // sum(value*weight) over available components
}

func New() *Builder { return &Builder{} }

// Add records a component. value should be normalized to [0,1]; it is clamped.
// available=false marks the input as not indexed: it still contributes to the
// total weight (so confidence drops) but adds nothing to the score.
func (b *Builder) Add(name, source string, value, weight float64, available bool, reason string) {
	b.totalW += weight
	c := db.Component{Name: name, Source: source, Weight: weight, Available: available, Reason: reason}
	if available {
		v := clamp01(value)
		c.Value = round4(v)
		c.Contribution = round4(v * weight) // pre-normalization; final score scales by availW
		b.availW += weight
		b.availValW += v * weight
	} else {
		b.missing = append(b.missing, name)
	}
	b.components = append(b.components, c)
}

// Build finalizes the signal. ok=false when NO component was available — in that
// case the caller must report unavailable rather than emit a fabricated score.
// The score is the weighted average of available inputs (0..100). Confidence is
// availableWeight / totalWeight. Component contributions are re-expressed as their
// actual share of the final score so they sum to it.
func (b *Builder) Build(kind, chain, subject, rationale string) (db.Signal, bool) {
	if b.availW == 0 {
		return db.Signal{}, false
	}
	score := (b.availValW / b.availW) * 100
	confidence := b.availW / b.totalW

	// re-express each available component's contribution as its share of the score
	out := make([]db.Component, len(b.components))
	for i, c := range b.components {
		if c.Available {
			c.Contribution = round4((c.Value * c.Weight / b.availW) * 100)
		} else {
			c.Contribution = 0
		}
		out[i] = c
	}
	if b.missing == nil {
		b.missing = []string{}
	}
	return db.Signal{
		Kind: kind, Chain: chain, Subject: subject,
		SignalID:   SignalID(kind, chain, subject),
		Score:      round2(score),
		Confidence: round4(confidence),
		Components: out,
		Missing:    b.missing,
		Rationale:  rationale,
	}, true
}

// SignalID is the stable handle for a signal.
func SignalID(kind, chain, subject string) string { return kind + ":" + chain + ":" + subject }

// ---- normalization helpers (turn real upstream values into [0,1]) ----

// NormLinear maps x in [lo,hi] to [0,1] (clamped). For lo>hi it inverts (useful
// for "lower is better" signals like risk).
func NormLinear(x, lo, hi float64) float64 {
	if lo == hi {
		return 0.5
	}
	if lo < hi {
		return clamp01((x - lo) / (hi - lo))
	}
	return clamp01((lo - x) / (lo - hi))
}

// NormTanh squashes an unbounded signed value (e.g. net USD flow) to [0,1] with
// 0 -> 0.5, using a scale so that +scale -> ~0.88. Deterministic, explainable.
func NormTanh(x, scale float64) float64 {
	if scale <= 0 {
		scale = 1
	}
	return (math.Tanh(x/scale) + 1) / 2
}

func clamp01(x float64) float64 {
	if x < 0 {
		return 0
	}
	if x > 1 {
		return 1
	}
	return x
}
func round2(x float64) float64 { return math.Round(x*100) / 100 }
func round4(x float64) float64 { return math.Round(x*10000) / 10000 }
