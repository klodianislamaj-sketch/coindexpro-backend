// Package api serves the strategy reads. Every "score not found" path returns the
// mandated {available:false, reason:"not indexed"} envelope, and /explain returns
// the full component/weight/confidence/missing breakdown so any score is auditable.
package api

import (
	"regexp"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"

	"github.com/coindexpro/coindex-strategy-engine/internal/db"
	"github.com/coindexpro/coindex-strategy-engine/internal/metrics"
)

type API struct{ store *db.Store }

func New(store *db.Store) *API { return &API{store: store} }

// Register orders routes so static segments are matched before parameterized
// ones: /strategy/opportunities and /strategy/feed are registered before
// /strategy/token/:chain/:address and /strategy/wallet/:chain/:address. They do
// not collide anyway (different path prefixes), but explicit ordering is clearest.
func (a *API) Register(app *fiber.App) {
	app.Use(a.observe)
	app.Get("/strategy/opportunities", a.opportunities)
	app.Get("/strategy/feed", a.feed)
	app.Get("/strategy/explain/:signal_id", a.explain)
	app.Get("/strategy/token/:chain/:address", a.token)
	app.Get("/strategy/wallet/:chain/:address", a.wallet)
}

func (a *API) observe(c *fiber.Ctx) error {
	start := time.Now()
	err := c.Next()
	metrics.APILatency.WithLabelValues(c.Route().Path, statusClass(c.Response().StatusCode())).
		Observe(time.Since(start).Seconds())
	return err
}

var evmAddr = regexp.MustCompile(`^0x[0-9a-fA-F]{40}$`)

func addrParams(c *fiber.Ctx) (chain, addr string, ok bool) {
	chain = strings.ToLower(c.Params("chain"))
	addr = strings.ToLower(c.Params("address"))
	if chain == "" || !evmAddr.MatchString(addr) {
		return "", "", false
	}
	return chain, addr, true
}

func notIndexed(c *fiber.Ctx, extra fiber.Map) error {
	m := fiber.Map{"available": false, "reason": "not indexed"}
	for k, v := range extra {
		m[k] = v
	}
	return c.JSON(m)
}

// GET /strategy/token/:chain/:address
func (a *API) token(c *fiber.Ctx) error {
	chain, addr, ok := addrParams(c)
	if !ok {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid chain or address"})
	}
	conv, entry, exit, found, err := a.store.TokenStrategy(c.UserContext(), chain, addr)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !found {
		return notIndexed(c, fiber.Map{"chain": chain, "token": addr})
	}
	resp := fiber.Map{"chain": chain, "token": addr, "available": true}
	if conv.SignalID != "" {
		resp["conviction"] = conv
	}
	if entry.SignalID != "" {
		resp["entry"] = entry
	}
	if exit.SignalID != "" {
		resp["exit"] = exit
	}
	return c.JSON(resp)
}

// GET /strategy/wallet/:chain/:address
func (a *API) wallet(c *fiber.Ctx) error {
	chain, addr, ok := addrParams(c)
	if !ok {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid chain or address"})
	}
	sig, found, err := a.store.WalletStrategy(c.UserContext(), chain, addr)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !found {
		return notIndexed(c, fiber.Map{"chain": chain, "wallet": addr})
	}
	return c.JSON(fiber.Map{"chain": chain, "wallet": addr, "available": true, "follow": sig})
}

// GET /strategy/opportunities
func (a *API) opportunities(c *fiber.Ctx) error {
	limit := clamp(c.QueryInt("limit", 50), 1, 200)
	items, err := a.store.Opportunities(c.UserContext(), limit)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(items) == 0 {
		return notIndexed(c, nil)
	}
	return c.JSON(fiber.Map{"available": true, "opportunities": items})
}

// GET /strategy/feed
func (a *API) feed(c *fiber.Ctx) error {
	limit := clamp(c.QueryInt("limit", 50), 1, 200)
	sigs, err := a.store.RecentSignals(c.UserContext(), limit)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(sigs) == 0 {
		return notIndexed(c, nil)
	}
	return c.JSON(fiber.Map{"available": true, "feed": sigs})
}

// GET /strategy/explain/:signal_id — full component/weight/confidence/missing breakdown
func (a *API) explain(c *fiber.Ctx) error {
	id := c.Params("signal_id")
	if id == "" {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "missing signal_id"})
	}
	sig, found, err := a.store.SignalByID(c.UserContext(), id)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !found {
		return notIndexed(c, fiber.Map{"signal_id": id})
	}
	return c.JSON(fiber.Map{"available": true, "signal": sig})
}

func clamp(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}

func statusClass(code int) string {
	switch {
	case code >= 500:
		return "5xx"
	case code >= 400:
		return "4xx"
	default:
		return "2xx"
	}
}
