package db

import (
	"context"
	"encoding/json"
	"errors"
	"strings"

	"github.com/ClickHouse/clickhouse-go/v2"
	"github.com/ClickHouse/clickhouse-go/v2/lib/driver"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

// Store reads real upstream outputs and persists derived strategy signals. It
// reads Postgres (Phases 6/8/9/11/12) and ClickHouse (Phase 2 token_metrics).
type Store struct {
	pg *pgxpool.Pool
	ch driver.Conn
}

func Open(ctx context.Context, pgDSN string, chAddrs []string, chDB, chUser, chPass string) (*Store, error) {
	pg, err := pgxpool.New(ctx, pgDSN)
	if err != nil {
		return nil, err
	}
	if err := pg.Ping(ctx); err != nil {
		return nil, err
	}
	ch, err := clickhouse.Open(&clickhouse.Options{
		Addr: chAddrs,
		Auth: clickhouse.Auth{Database: chDB, Username: chUser, Password: chPass},
	})
	if err != nil {
		return nil, err
	}
	if err := ch.Ping(ctx); err != nil {
		return nil, err
	}
	return &Store{pg: pg, ch: ch}, nil
}

func (s *Store) Close() {
	s.pg.Close()
	_ = s.ch.Close()
}
func (s *Store) Ping(ctx context.Context) error {
	if err := s.pg.Ping(ctx); err != nil {
		return err
	}
	return s.ch.Ping(ctx)
}

// ---------- sources: tracked subjects (from REAL upstream tables) ----------

// TrackedTokens draws tokens that already have at least one upstream signal, so
// we only score real subjects. We union the distinct tokens seen in
// contract_analysis and flow_snapshots(token scope) and social_scores.
func (s *Store) TrackedTokens(ctx context.Context, limit int) ([]TokenRef, error) {
	const q = `
		SELECT chain, token FROM (
			SELECT chain, address AS token FROM contract_analysis
			UNION
			SELECT chain, entity AS token FROM flow_snapshots WHERE scope='token'
			UNION
			SELECT chain, token FROM social_scores
		) u
		GROUP BY chain, token
		LIMIT $1`
	rows, err := s.pg.Query(ctx, q, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []TokenRef
	for rows.Next() {
		var t TokenRef
		if err := rows.Scan(&t.Chain, &t.Token); err != nil {
			return nil, err
		}
		out = append(out, t)
	}
	return out, rows.Err()
}

// TrackedWallets draws wallets that have a real profile (Phase 6) — only wallets
// with observed trading history are candidates for a follow score.
func (s *Store) TrackedWallets(ctx context.Context, limit int) ([]WalletRef, error) {
	const q = `SELECT chain, address FROM wallet_profiles ORDER BY chain, address LIMIT $1`
	rows, err := s.pg.Query(ctx, q, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []WalletRef
	for rows.Next() {
		var w WalletRef
		if err := rows.Scan(&w.Chain, &w.Wallet); err != nil {
			return nil, err
		}
		out = append(out, w)
	}
	return out, rows.Err()
}

// ---------- sources: real inputs per subject (nil = not indexed) ----------

// TokenInputs reads every real token signal. Each field is left nil when its
// source has no row, so the scorer records it unavailable rather than zero.
func (s *Store) TokenInputs(ctx context.Context, chain, token string) (TokenInputs, error) {
	token = strings.ToLower(token)
	in := TokenInputs{Chain: chain, Token: token}

	// Phase 8: contract_analysis.score
	{
		const q = `SELECT score FROM contract_analysis WHERE chain=$1 AND address=$2`
		var sc int
		err := s.pg.QueryRow(ctx, q, chain, token).Scan(&sc)
		if err == nil {
			in.RiskScore = &sc
		} else if !errors.Is(err, pgx.ErrNoRows) {
			return in, err
		}
	}
	// Phase 11: latest smart-money flow snapshot for this token entity
	{
		const q = `
			SELECT net_usd, priced_coverage FROM flow_snapshots
			WHERE scope='smart_money' AND chain=$1 AND entity=$2
			ORDER BY window_start DESC LIMIT 1`
		var net, cov float64
		err := s.pg.QueryRow(ctx, q, chain, token).Scan(&net, &cov)
		if err == nil {
			in.SmartMoneyNetUSD = &net
			in.SmartMoneyCoverage = &cov
		} else if !errors.Is(err, pgx.ErrNoRows) {
			return in, err
		}
	}
	// Phase 11: latest whale cohort net flow into this token
	{
		const q = `
			SELECT net_usd FROM cohort_flows
			WHERE chain=$1 AND token=$2 AND cohort='whale'
			ORDER BY window_start DESC LIMIT 1`
		var net float64
		err := s.pg.QueryRow(ctx, q, chain, token).Scan(&net)
		if err == nil {
			in.WhaleNetUSD = &net
		} else if !errors.Is(err, pgx.ErrNoRows) {
			return in, err
		}
	}
	// Phase 12: latest social velocity
	{
		const q = `
			SELECT velocity FROM social_scores
			WHERE chain=$1 AND token=$2 AND velocity IS NOT NULL
			ORDER BY window_start DESC LIMIT 1`
		var vel float64
		err := s.pg.QueryRow(ctx, q, chain, token).Scan(&vel)
		if err == nil {
			in.SocialVelocity = &vel
		} else if !errors.Is(err, pgx.ErrNoRows) {
			return in, err
		}
	}
	// Phase 12: latest sentiment mean + coverage
	{
		const q = `
			SELECT mean_sentiment, coverage FROM social_sentiment
			WHERE chain=$1 AND token=$2
			ORDER BY window_start DESC LIMIT 1`
		var mean, cov float64
		err := s.pg.QueryRow(ctx, q, chain, token).Scan(&mean, &cov)
		if err == nil {
			in.Sentiment = &mean
			in.SentimentCoverage = &cov
		} else if !errors.Is(err, pgx.ErrNoRows) {
			return in, err
		}
	}
	// Phase 2 (ClickHouse): latest token_metrics.liq_usd
	{
		const q = `
			SELECT liq_usd FROM coindex.token_metrics
			WHERE chain = ? AND token = ?
			ORDER BY ts DESC LIMIT 1`
		var liq float64
		err := s.ch.QueryRow(ctx, q, chain, token).Scan(&liq)
		if err == nil && liq > 0 {
			in.LiquidityUSD = &liq
		}
		// ClickHouse "no row" surfaces as a scan error; we treat absence as nil
		// (not indexed) rather than failing the whole token.
	}
	return in, nil
}

// WalletInputs reads real wallet signals (Phase 6 profile + Phase 9 influence).
func (s *Store) WalletInputs(ctx context.Context, chain, wallet string) (WalletInputs, error) {
	wallet = strings.ToLower(wallet)
	in := WalletInputs{Chain: chain, Wallet: wallet}

	// Phase 6 wallet_profiles
	{
		const q = `SELECT realized_pnl_usd, win_rate, conviction FROM wallet_profiles WHERE chain=$1 AND address=$2`
		var pnl, win *float64
		var conv *int
		err := s.pg.QueryRow(ctx, q, chain, wallet).Scan(&pnl, &win, &conv)
		if err == nil {
			in.RealizedPnlUSD = pnl
			in.WinRate = win
			in.Conviction = conv
		} else if !errors.Is(err, pgx.ErrNoRows) {
			return in, err
		}
	}
	// Phase 9 wallet_influence (node_id = "<chain>:<address>")
	{
		const q = `SELECT score FROM wallet_influence WHERE node_id=$1`
		var sc float64
		err := s.pg.QueryRow(ctx, q, chain+":"+wallet).Scan(&sc)
		if err == nil {
			in.InfluenceScore = &sc
		} else if !errors.Is(err, pgx.ErrNoRows) {
			return in, err
		}
	}
	return in, nil
}

// ---------- sink: idempotent persistence ----------

func (s *Store) UpsertSignal(ctx context.Context, sig Signal) error {
	comps, _ := json.Marshal(sig.Components)
	missing, _ := json.Marshal(sig.Missing)
	const q = `
		INSERT INTO strategy_signals
			(signal_id, kind, chain, subject, score, confidence, components, missing, rationale)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
		ON CONFLICT (signal_id) DO UPDATE SET
			score=$5, confidence=$6, components=$7, missing=$8, rationale=$9, computed_at=now()`
	_, err := s.pg.Exec(ctx, q, sig.SignalID, sig.Kind, sig.Chain, sig.Subject,
		sig.Score, sig.Confidence, comps, missing, sig.Rationale)
	return err
}

func (s *Store) UpsertTokenConviction(ctx context.Context, chain, token string, sig Signal) error {
	const q = `
		INSERT INTO token_conviction (chain, token, score, confidence, signal_id)
		VALUES ($1,$2,$3,$4,$5)
		ON CONFLICT (chain, token) DO UPDATE SET
			score=$3, confidence=$4, signal_id=$5, updated_at=now()`
	_, err := s.pg.Exec(ctx, q, chain, strings.ToLower(token), sig.Score, sig.Confidence, sig.SignalID)
	return err
}

func (s *Store) UpsertEntryScore(ctx context.Context, chain, token string, sig Signal) error {
	const q = `
		INSERT INTO entry_scores (chain, token, score, confidence, signal_id)
		VALUES ($1,$2,$3,$4,$5)
		ON CONFLICT (chain, token) DO UPDATE SET
			score=$3, confidence=$4, signal_id=$5, updated_at=now()`
	_, err := s.pg.Exec(ctx, q, chain, strings.ToLower(token), sig.Score, sig.Confidence, sig.SignalID)
	return err
}

func (s *Store) UpsertExitScore(ctx context.Context, chain, token string, sig Signal) error {
	const q = `
		INSERT INTO exit_scores (chain, token, score, confidence, signal_id)
		VALUES ($1,$2,$3,$4,$5)
		ON CONFLICT (chain, token) DO UPDATE SET
			score=$3, confidence=$4, signal_id=$5, updated_at=now()`
	_, err := s.pg.Exec(ctx, q, chain, strings.ToLower(token), sig.Score, sig.Confidence, sig.SignalID)
	return err
}

// ReplaceWalletFollowRank rewrites the rank table for a chain in one tx
// (delete+insert) so ranks are always a consistent dense ordering.
func (s *Store) ReplaceWalletFollowRank(ctx context.Context, chain string, ranked []RankedSignal) error {
	tx, err := s.pg.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	if _, err := tx.Exec(ctx, `DELETE FROM wallet_follow_rank WHERE chain=$1`, chain); err != nil {
		return err
	}
	for _, r := range ranked {
		const q = `
			INSERT INTO wallet_follow_rank (chain, wallet, score, confidence, rank, signal_id)
			VALUES ($1,$2,$3,$4,$5,$6)`
		if _, err := tx.Exec(ctx, q, chain, strings.ToLower(r.Signal.Subject),
			r.Signal.Score, r.Signal.Confidence, r.Rank, r.Signal.SignalID); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

// ReplaceOpportunityFeed rewrites the feed in one tx so it always reflects the
// latest build exactly (no stale rows).
func (s *Store) ReplaceOpportunityFeed(ctx context.Context, items []Signal, reasonOf func(Signal) string) error {
	tx, err := s.pg.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	if _, err := tx.Exec(ctx, `DELETE FROM opportunity_feed`); err != nil {
		return err
	}
	for _, it := range items {
		const q = `
			INSERT INTO opportunity_feed (chain, token, score, confidence, reason, signal_id)
			VALUES ($1,$2,$3,$4,$5,$6)
			ON CONFLICT (chain, token) DO UPDATE SET
				score=$3, confidence=$4, reason=$5, signal_id=$6, surfaced_at=now()`
		if _, err := tx.Exec(ctx, q, it.Chain, strings.ToLower(it.Subject),
			it.Score, it.Confidence, reasonOf(it), it.SignalID); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

// ---------- API reads ----------

// SignalByID loads a full explainable signal for /strategy/explain.
func (s *Store) SignalByID(ctx context.Context, id string) (Signal, bool, error) {
	const q = `
		SELECT signal_id, kind, chain, subject, score, confidence, components, missing, rationale, computed_at
		FROM strategy_signals WHERE signal_id=$1`
	var sig Signal
	var comps, missing []byte
	err := s.pg.QueryRow(ctx, q, id).Scan(&sig.SignalID, &sig.Kind, &sig.Chain, &sig.Subject,
		&sig.Score, &sig.Confidence, &comps, &missing, &sig.Rationale, &sig.ComputedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return Signal{}, false, nil
	}
	if err != nil {
		return Signal{}, false, err
	}
	_ = json.Unmarshal(comps, &sig.Components)
	_ = json.Unmarshal(missing, &sig.Missing)
	return sig, true, nil
}

// TokenStrategy loads conviction + entry + exit signal ids for a token, then the
// full signals, for /strategy/token.
func (s *Store) TokenStrategy(ctx context.Context, chain, token string) (conv, entry, exit Signal, found bool, err error) {
	token = strings.ToLower(token)
	ids := map[string]*Signal{
		KindTokenConviction + ":" + chain + ":" + token: &conv,
		KindEntry + ":" + chain + ":" + token:           &entry,
		KindExit + ":" + chain + ":" + token:            &exit,
	}
	for id, dst := range ids {
		sig, ok, e := s.SignalByID(ctx, id)
		if e != nil {
			return conv, entry, exit, false, e
		}
		if ok {
			*dst = sig
			found = true
		}
	}
	return conv, entry, exit, found, nil
}

// WalletStrategy loads the follow signal for a wallet.
func (s *Store) WalletStrategy(ctx context.Context, chain, wallet string) (Signal, bool, error) {
	return s.SignalByID(ctx, KindWalletFollow+":"+chain+":"+strings.ToLower(wallet))
}

// Opportunities returns the ranked feed.
func (s *Store) Opportunities(ctx context.Context, limit int) ([]map[string]any, error) {
	const q = `
		SELECT chain, token, score, confidence, reason, signal_id
		FROM opportunity_feed ORDER BY score DESC, confidence DESC LIMIT $1`
	rows, err := s.pg.Query(ctx, q, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []map[string]any
	for rows.Next() {
		var chain, token, reason, sid string
		var score, conf float64
		if err := rows.Scan(&chain, &token, &score, &conf, &reason, &sid); err != nil {
			return nil, err
		}
		out = append(out, map[string]any{
			"chain": chain, "token": token, "score": score, "confidence": conf,
			"reason": reason, "signal_id": sid,
		})
	}
	return out, rows.Err()
}

// RecentSignals returns the most recently computed signals for /strategy/feed.
func (s *Store) RecentSignals(ctx context.Context, limit int) ([]Signal, error) {
	const q = `
		SELECT signal_id, kind, chain, subject, score, confidence, missing, rationale, computed_at
		FROM strategy_signals ORDER BY computed_at DESC LIMIT $1`
	rows, err := s.pg.Query(ctx, q, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []Signal
	for rows.Next() {
		var sig Signal
		var missing []byte
		if err := rows.Scan(&sig.SignalID, &sig.Kind, &sig.Chain, &sig.Subject,
			&sig.Score, &sig.Confidence, &missing, &sig.Rationale, &sig.ComputedAt); err != nil {
			return nil, err
		}
		_ = json.Unmarshal(missing, &sig.Missing)
		out = append(out, sig)
	}
	return out, rows.Err()
}
