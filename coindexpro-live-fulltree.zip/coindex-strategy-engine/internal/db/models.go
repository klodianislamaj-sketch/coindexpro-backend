// Package db holds the strategy-engine persistence layer and shared types. The
// explainability contract lives in the type model: a Signal is built from a set
// of Components, each of which records whether its input was Available, its
// Weight, and its Contribution. Confidence is the fraction of weight that came
// from available inputs — so a score computed from partial data is never
// presented as if every input were present.
package db

import "time"

// Signal kinds.
const (
	KindTokenConviction = "token_conviction"
	KindWalletFollow    = "wallet_follow"
	KindEntry           = "entry"
	KindExit            = "exit"
	KindOpportunity     = "opportunity"
)

// Component is one explainable contributor to a score.
type Component struct {
	Name         string  `json:"name"`
	Value        float64 `json:"value"`        // normalized [0,1] input value (0 when unavailable)
	Weight       float64 `json:"weight"`       // configured weight
	Contribution float64 `json:"contribution"` // value*weight*100*(applied share); 0 when unavailable
	Available    bool    `json:"available"`
	Source       string  `json:"source"`       // upstream table/phase the value came from
	Reason       string  `json:"reason,omitempty"` // why unavailable, if so
}

// Signal is a fully explainable score.
type Signal struct {
	SignalID   string      `json:"signal_id"`
	Kind       string      `json:"kind"`
	Chain      string      `json:"chain"`
	Subject    string      `json:"subject"`
	Score      float64     `json:"score"`      // 0..100
	Confidence float64     `json:"confidence"` // 0..1 = available-weight / total-weight
	Components []Component `json:"components"`
	Missing    []string    `json:"missing"`
	Rationale  string      `json:"rationale"`
	ComputedAt time.Time   `json:"computed_at,omitempty"`
}

// ---- raw upstream inputs (every field a pointer => "may be unavailable") ----

// TokenInputs are the REAL signals read for a token. nil = not indexed for that
// source; the scorer treats a nil as an unavailable component, never as zero.
type TokenInputs struct {
	Chain string
	Token string

	// Phase 8 contract_analysis.score (0..100, higher = riskier). nil if unanalyzed.
	RiskScore *int
	// Phase 11 flow: smart-money net_usd + its priced_coverage for the latest window.
	SmartMoneyNetUSD *float64
	SmartMoneyCoverage *float64
	// Phase 11 cohort net flow (whale) + coverage.
	WhaleNetUSD *float64
	// Phase 12 social: mention velocity + sentiment mean + sentiment coverage.
	SocialVelocity *float64
	Sentiment      *float64
	SentimentCoverage *float64
	// Phase 2 token_metrics: liquidity (context / floor gate).
	LiquidityUSD *float64
}

// WalletInputs are the REAL signals read for a wallet.
type WalletInputs struct {
	Chain  string
	Wallet string

	// Phase 6 wallet_profiles
	RealizedPnlUSD *float64
	WinRate        *float64 // 0..1
	Conviction     *int     // 0..100
	// Phase 9 wallet_influence.score (0..1)
	InfluenceScore *float64
}

// RankedSignal pairs a signal with its computed rank (for follow-rank / feed).
type RankedSignal struct {
	Signal Signal
	Rank   int
}

// TokenRef / WalletRef are lightweight subject references for the build loop,
// drawn from real upstream tables (not invented lists).
type TokenRef struct {
	Chain string
	Token string
}
type WalletRef struct {
	Chain  string
	Wallet string
}
