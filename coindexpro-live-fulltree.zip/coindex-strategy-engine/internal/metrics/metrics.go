// Package metrics holds the strategy-engine's Prometheus instruments. The symbol
// set here matches exactly what internal/strategy/engine.go references.
package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	Builds = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_strategy_builds_total", Help: "Strategy build cycles.",
	})
	BuildDuration = promauto.NewHistogram(prometheus.HistogramOpts{
		Name: "coindex_strategy_build_seconds", Help: "Strategy build duration.",
		Buckets: []float64{0.1, 0.5, 1, 5, 15, 30, 60, 120},
	})
	Signals = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_strategy_signals_total", Help: "Signals written by kind.",
	}, []string{"kind"})
	Skipped = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_strategy_skipped_total", Help: "Subjects skipped (no available inputs) by reason.",
	}, []string{"reason"})
	FeedSize = promauto.NewGauge(prometheus.GaugeOpts{
		Name: "coindex_strategy_feed_size", Help: "Current opportunity feed size.",
	})
	APILatency = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name: "coindex_strategy_api_seconds", Help: "API latency by route + status.",
		Buckets: prometheus.DefBuckets,
	}, []string{"route", "status"})
	DBErrors = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_strategy_db_errors_total", Help: "DB errors.",
	})
)
