// Package strategy holds the scoring recipes. Each recipe maps REAL upstream
// inputs (Phases 6/8/9/11/12 + token_metrics) to weighted, explainable components
// through the scoring builder. Weights are configurable and surfaced on every
// component; an unavailable input is recorded as such and lowers confidence — it
// is never silently treated as a neutral or zero score.
package strategy

import (
	"fmt"

	"github.com/coindexpro/coindex-strategy-engine/internal/db"
	"github.com/coindexpro/coindex-strategy-engine/internal/scoring"
)

// Weights are the configurable component weights for each recipe. They are echoed
// into every signal's components so the score is reproducible.
type Weights struct {
	// token conviction
	ConvSmartMoney float64
	ConvWhale      float64
	ConvSentiment  float64
	ConvSocialVel  float64
	ConvRisk       float64
	ConvLiquidity  float64
	// wallet follow
	FollowPnl       float64
	FollowWinRate   float64
	FollowConviction float64
	FollowInfluence float64
	// entry
	EntrySmartMoney float64
	EntrySentiment  float64
	EntryRisk       float64
	// exit
	ExitDistribution float64
	ExitWhale        float64
	ExitRiskIncrease float64
	ExitSentiment    float64
	// scales for tanh normalization of USD flows
	FlowScaleUSD float64
}

// DefaultWeights are sensible, documented defaults.
func DefaultWeights() Weights {
	return Weights{
		ConvSmartMoney: 0.30, ConvWhale: 0.15, ConvSentiment: 0.20, ConvSocialVel: 0.15, ConvRisk: 0.25, ConvLiquidity: 0.10,
		FollowPnl: 0.30, FollowWinRate: 0.25, FollowConviction: 0.20, FollowInfluence: 0.25,
		EntrySmartMoney: 0.45, EntrySentiment: 0.25, EntryRisk: 0.30,
		ExitDistribution: 0.45, ExitWhale: 0.15, ExitRiskIncrease: 0.35, ExitSentiment: 0.20,
		FlowScaleUSD: 250000,
	}
}

// flowAvailable decides whether a USD flow signal is real enough to use. A flow
// with zero priced coverage carries no actual USD signal (every contributing
// trade was unpriced), so it is reported unavailable rather than trusted — this
// consumes the Phase 11 priced_coverage honesty field instead of ignoring it.
func flowAvailable(net, cov *float64) (bool, string) {
	if net == nil {
		return false, "not indexed"
	}
	if cov != nil && *cov <= 0 {
		return false, "flow present but priced_coverage=0 (no USD signal)"
	}
	return true, ""
}

// sentimentAvailable applies the same logic to sentiment coverage: a sentiment
// mean computed over zero scored mentions is not a real signal.
func sentimentAvailable(mean, cov *float64) (bool, string) {
	if mean == nil {
		return false, "not indexed"
	}
	if cov != nil && *cov <= 0 {
		return false, "sentiment present but coverage=0 (no scored mentions)"
	}
	return true, ""
}

// TokenConviction scores how strong the case for a token is right now, from real
// smart-money flow, sentiment, social velocity, contract risk (inverted), and
// liquidity. Each input that is missing is recorded unavailable.
func TokenConviction(in db.TokenInputs, w Weights) (db.Signal, bool) {
	b := scoring.New()

	// smart-money net flow (positive = accumulation) -> tanh to [0,1]
	if ok, reason := flowAvailable(in.SmartMoneyNetUSD, in.SmartMoneyCoverage); ok {
		v := scoring.NormTanh(*in.SmartMoneyNetUSD, w.FlowScaleUSD)
		b.Add("smart_money_flow", "flow_snapshots(smart_money).net_usd", v, w.ConvSmartMoney, true, "")
	} else {
		b.Add("smart_money_flow", "flow_snapshots(smart_money)", 0, w.ConvSmartMoney, false, reason)
	}

	// whale cohort net flow (positive = accumulation) -> tanh to [0,1]
	if in.WhaleNetUSD != nil {
		v := scoring.NormTanh(*in.WhaleNetUSD, w.FlowScaleUSD)
		b.Add("whale_flow", "cohort_flows(whale).net_usd", v, w.ConvWhale, true, "")
	} else {
		b.Add("whale_flow", "cohort_flows(whale)", 0, w.ConvWhale, false, "not indexed")
	}

	// sentiment mean in [-1,1] -> [0,1]
	if ok, reason := sentimentAvailable(in.Sentiment, in.SentimentCoverage); ok {
		v := (*in.Sentiment + 1) / 2
		b.Add("sentiment", "social_sentiment.mean_sentiment", v, w.ConvSentiment, true, "")
	} else {
		b.Add("sentiment", "social_sentiment", 0, w.ConvSentiment, false, reason)
	}

	// social velocity (mentions vs baseline); >1 means rising. map 0..3 -> 0..1
	if in.SocialVelocity != nil {
		v := scoring.NormLinear(*in.SocialVelocity, 0, 3)
		b.Add("social_velocity", "social_scores.velocity", v, w.ConvSocialVel, true, "")
	} else {
		b.Add("social_velocity", "social_scores", 0, w.ConvSocialVel, false, "not indexed")
	}

	// contract risk: score 0..100 higher=riskier -> invert so safer raises conviction
	if in.RiskScore != nil {
		v := scoring.NormLinear(float64(*in.RiskScore), 100, 0) // inverted
		b.Add("contract_safety", "contract_analysis.score(inverted)", v, w.ConvRisk, true, "")
	} else {
		b.Add("contract_safety", "contract_analysis", 0, w.ConvRisk, false, "not indexed")
	}

	// liquidity floor: map $0..$500k -> 0..1 (more liquidity = safer to act on)
	if in.LiquidityUSD != nil {
		v := scoring.NormLinear(*in.LiquidityUSD, 0, 500000)
		b.Add("liquidity", "token_metrics.liq_usd", v, w.ConvLiquidity, true, "")
	} else {
		b.Add("liquidity", "token_metrics", 0, w.ConvLiquidity, false, "not indexed")
	}

	return b.Build(db.KindTokenConviction, in.Chain, in.Token,
		"conviction = weighted blend of smart-money flow, sentiment, social velocity, contract safety, liquidity")
}

// WalletFollow scores how worth-following a wallet is, from real realized PnL,
// win rate, conviction, and graph influence.
func WalletFollow(in db.WalletInputs, w Weights) (db.Signal, bool) {
	b := scoring.New()

	if in.RealizedPnlUSD != nil {
		v := scoring.NormTanh(*in.RealizedPnlUSD, 100000) // +$100k -> ~0.88
		b.Add("realized_pnl", "wallet_profiles.realized_pnl_usd", v, w.FollowPnl, true, "")
	} else {
		b.Add("realized_pnl", "wallet_profiles", 0, w.FollowPnl, false, "not indexed")
	}
	if in.WinRate != nil {
		b.Add("win_rate", "wallet_profiles.win_rate", *in.WinRate, w.FollowWinRate, true, "")
	} else {
		b.Add("win_rate", "wallet_profiles", 0, w.FollowWinRate, false, "not indexed")
	}
	if in.Conviction != nil {
		b.Add("conviction", "wallet_profiles.conviction", float64(*in.Conviction)/100, w.FollowConviction, true, "")
	} else {
		b.Add("conviction", "wallet_profiles", 0, w.FollowConviction, false, "not indexed")
	}
	if in.InfluenceScore != nil {
		b.Add("graph_influence", "wallet_influence.score", *in.InfluenceScore, w.FollowInfluence, true, "")
	} else {
		b.Add("graph_influence", "wallet_influence", 0, w.FollowInfluence, false, "not indexed")
	}

	return b.Build(db.KindWalletFollow, in.Chain, in.Wallet,
		"follow score = weighted blend of realized PnL, win rate, conviction, graph influence")
}

// EntryScore favours fresh smart-money accumulation + positive sentiment +
// acceptable contract risk. Higher = more attractive entry timing.
func EntryScore(in db.TokenInputs, w Weights) (db.Signal, bool) {
	b := scoring.New()
	if ok, reason := flowAvailable(in.SmartMoneyNetUSD, in.SmartMoneyCoverage); ok {
		v := scoring.NormTanh(*in.SmartMoneyNetUSD, w.FlowScaleUSD)
		b.Add("smart_money_inflow", "flow_snapshots(smart_money).net_usd", v, w.EntrySmartMoney, true, "")
	} else {
		b.Add("smart_money_inflow", "flow_snapshots(smart_money)", 0, w.EntrySmartMoney, false, reason)
	}
	if ok, reason := sentimentAvailable(in.Sentiment, in.SentimentCoverage); ok {
		b.Add("sentiment", "social_sentiment.mean_sentiment", (*in.Sentiment+1)/2, w.EntrySentiment, true, "")
	} else {
		b.Add("sentiment", "social_sentiment", 0, w.EntrySentiment, false, reason)
	}
	if in.RiskScore != nil {
		b.Add("contract_safety", "contract_analysis.score(inverted)", scoring.NormLinear(float64(*in.RiskScore), 100, 0), w.EntryRisk, true, "")
	} else {
		b.Add("contract_safety", "contract_analysis", 0, w.EntryRisk, false, "not indexed")
	}
	return b.Build(db.KindEntry, in.Chain, in.Token,
		"entry = smart-money inflow + positive sentiment + contract safety")
}

// ExitScore favours distribution (negative smart-money / whale flow), rising risk,
// and negative sentiment. Higher = stronger exit signal.
func ExitScore(in db.TokenInputs, w Weights) (db.Signal, bool) {
	b := scoring.New()
	// distribution: negative net flow -> high exit. invert the tanh.
	if ok, reason := flowAvailable(in.SmartMoneyNetUSD, in.SmartMoneyCoverage); ok {
		v := 1 - scoring.NormTanh(*in.SmartMoneyNetUSD, w.FlowScaleUSD)
		b.Add("distribution", "flow_snapshots(smart_money).net_usd(inverted)", v, w.ExitDistribution, true, "")
	} else {
		b.Add("distribution", "flow_snapshots(smart_money)", 0, w.ExitDistribution, false, reason)
	}
	// whale distribution: negative whale cohort flow -> high exit
	if in.WhaleNetUSD != nil {
		v := 1 - scoring.NormTanh(*in.WhaleNetUSD, w.FlowScaleUSD)
		b.Add("whale_distribution", "cohort_flows(whale).net_usd(inverted)", v, w.ExitWhale, true, "")
	} else {
		b.Add("whale_distribution", "cohort_flows(whale)", 0, w.ExitWhale, false, "not indexed")
	}
	// rising risk: higher contract risk -> higher exit
	if in.RiskScore != nil {
		b.Add("contract_risk", "contract_analysis.score", scoring.NormLinear(float64(*in.RiskScore), 0, 100), w.ExitRiskIncrease, true, "")
	} else {
		b.Add("contract_risk", "contract_analysis", 0, w.ExitRiskIncrease, false, "not indexed")
	}
	// negative sentiment -> higher exit
	if ok, reason := sentimentAvailable(in.Sentiment, in.SentimentCoverage); ok {
		b.Add("negative_sentiment", "social_sentiment.mean_sentiment(inverted)", (1-(*in.Sentiment+1)/2), w.ExitSentiment, true, "")
	} else {
		b.Add("negative_sentiment", "social_sentiment", 0, w.ExitSentiment, false, reason)
	}
	return b.Build(db.KindExit, in.Chain, in.Token,
		"exit = distribution + rising contract risk + negative sentiment")
}

// OpportunityReason renders a short feed reason from a conviction signal.
func OpportunityReason(s db.Signal) string {
	return fmt.Sprintf("conviction %.1f (confidence %.0f%%) from %d/%d available signals",
		s.Score, s.Confidence*100, len(s.Components)-len(s.Missing), len(s.Components))
}
