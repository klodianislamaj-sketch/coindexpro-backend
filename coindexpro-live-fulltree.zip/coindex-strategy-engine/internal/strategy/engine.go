package strategy

import (
	"context"
	"sort"
	"time"

	"go.uber.org/zap"

	"github.com/coindexpro/coindex-strategy-engine/internal/db"
	"github.com/coindexpro/coindex-strategy-engine/internal/metrics"
)

// Sources reads real upstream inputs (implemented by db.Store).
type Sources interface {
	TrackedTokens(ctx context.Context, limit int) ([]db.TokenRef, error)
	TrackedWallets(ctx context.Context, limit int) ([]db.WalletRef, error)
	TokenInputs(ctx context.Context, chain, token string) (db.TokenInputs, error)
	WalletInputs(ctx context.Context, chain, wallet string) (db.WalletInputs, error)
}

// Sink persists signals + projections (implemented by db.Store).
type Sink interface {
	UpsertSignal(ctx context.Context, s db.Signal) error
	UpsertTokenConviction(ctx context.Context, chain, token string, s db.Signal) error
	UpsertEntryScore(ctx context.Context, chain, token string, s db.Signal) error
	UpsertExitScore(ctx context.Context, chain, token string, s db.Signal) error
	ReplaceWalletFollowRank(ctx context.Context, chain string, ranked []db.RankedSignal) error
	ReplaceOpportunityFeed(ctx context.Context, items []db.Signal, reasonOf func(db.Signal) string) error
}

type Engine struct {
	src  Sources
	sink Sink
	cfg  Config
	w    Weights
	log  *zap.Logger
}

type Config struct {
	MaxTokens     int
	MaxWallets    int
	MinConfidence float64 // feed gate: opportunities below this confidence are not surfaced
	MinOppScore   float64 // feed gate: minimum conviction score to surface
}

func NewEngine(src Sources, sink Sink, cfg Config, w Weights, log *zap.Logger) *Engine {
	return &Engine{src: src, sink: sink, cfg: cfg, w: w, log: log}
}

// BuildOnce runs a full strategy build over tracked tokens + wallets.
func (e *Engine) BuildOnce(ctx context.Context) error {
	t0 := time.Now()

	// ---- tokens: conviction + entry + exit, feed candidates ----
	tokens, err := e.src.TrackedTokens(ctx, e.cfg.MaxTokens)
	if err != nil {
		return err
	}
	var feed []db.Signal
	for _, t := range tokens {
		in, err := e.src.TokenInputs(ctx, t.Chain, t.Token)
		if err != nil {
			return err
		}
		conv, ok := TokenConviction(in, e.w)
		if !ok {
			// no real input available for this token -> no row (not a fabricated score)
			metrics.Skipped.WithLabelValues("token_no_inputs").Inc()
			continue
		}
		if err := e.sink.UpsertSignal(ctx, conv); err != nil {
			return err
		}
		if err := e.sink.UpsertTokenConviction(ctx, t.Chain, t.Token, conv); err != nil {
			return err
		}
		metrics.Signals.WithLabelValues(db.KindTokenConviction).Inc()

		if entry, ok := EntryScore(in, e.w); ok {
			if err := e.sink.UpsertSignal(ctx, entry); err != nil {
				return err
			}
			if err := e.sink.UpsertEntryScore(ctx, t.Chain, t.Token, entry); err != nil {
				return err
			}
			metrics.Signals.WithLabelValues(db.KindEntry).Inc()
		}
		if exit, ok := ExitScore(in, e.w); ok {
			if err := e.sink.UpsertSignal(ctx, exit); err != nil {
				return err
			}
			if err := e.sink.UpsertExitScore(ctx, t.Chain, t.Token, exit); err != nil {
				return err
			}
			metrics.Signals.WithLabelValues(db.KindExit).Inc()
		}

		// feed candidate: conviction signal that clears confidence + score gates
		if conv.Confidence >= e.cfg.MinConfidence && conv.Score >= e.cfg.MinOppScore {
			feed = append(feed, conv)
		}
	}

	// ---- opportunity feed (ranked) ----
	sort.SliceStable(feed, func(i, j int) bool {
		if feed[i].Score != feed[j].Score {
			return feed[i].Score > feed[j].Score
		}
		return feed[i].Confidence > feed[j].Confidence
	})
	for i := range feed {
		oppSig := feed[i]
		oppSig.Kind = db.KindOpportunity
		oppSig.SignalID = signalIDOpp(oppSig)
		if err := e.sink.UpsertSignal(ctx, oppSig); err != nil {
			return err
		}
		feed[i] = oppSig
	}
	if err := e.sink.ReplaceOpportunityFeed(ctx, feed, OpportunityReason); err != nil {
		return err
	}
	metrics.FeedSize.Set(float64(len(feed)))

	// ---- wallets: follow rank ----
	wallets, err := e.src.TrackedWallets(ctx, e.cfg.MaxWallets)
	if err != nil {
		return err
	}
	var ranked []db.RankedSignal
	for _, wlt := range wallets {
		in, err := e.src.WalletInputs(ctx, wlt.Chain, wlt.Wallet)
		if err != nil {
			return err
		}
		sig, ok := WalletFollow(in, e.w)
		if !ok {
			metrics.Skipped.WithLabelValues("wallet_no_inputs").Inc()
			continue
		}
		if err := e.sink.UpsertSignal(ctx, sig); err != nil {
			return err
		}
		ranked = append(ranked, db.RankedSignal{Signal: sig})
		metrics.Signals.WithLabelValues(db.KindWalletFollow).Inc()
	}
	sort.SliceStable(ranked, func(i, j int) bool {
		return ranked[i].Signal.Score > ranked[j].Signal.Score
	})
	for i := range ranked {
		ranked[i].Rank = i + 1
	}
	// group rank persistence by chain
	byChain := map[string][]db.RankedSignal{}
	for _, r := range ranked {
		byChain[r.Signal.Chain] = append(byChain[r.Signal.Chain], r)
	}
	for chain, rs := range byChain {
		// re-rank densely within chain
		for i := range rs {
			rs[i].Rank = i + 1
		}
		if err := e.sink.ReplaceWalletFollowRank(ctx, chain, rs); err != nil {
			return err
		}
	}

	metrics.Builds.Inc()
	metrics.BuildDuration.Observe(time.Since(t0).Seconds())
	e.log.Info("strategy build complete",
		zap.Int("tokens", len(tokens)), zap.Int("wallets", len(wallets)),
		zap.Int("feed", len(feed)))
	return nil
}

// signalIDOpp gives the opportunity projection its own id distinct from the
// conviction signal it derives from.
func signalIDOpp(s db.Signal) string { return db.KindOpportunity + ":" + s.Chain + ":" + s.Subject }
