-- =============================================================================
-- CoinDex Strategy Engine — PostgreSQL migration (Phase 13)
-- =============================================================================
-- Synthesis layer: combines REAL derived outputs of Phases 4-12 into explainable
-- scores. Every score row stores its components, weights, and confidence so it is
-- fully reproducible and auditable. A score is NEVER written from an empty set of
-- inputs — if no real component is available, no row is produced and the API
-- reports {"available": false, "reason": "not indexed"}.
--
-- These are all NEW tables (no prior phase defines them); idempotent.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- strategy_signals — the canonical explainable signal record (one per scored
-- subject + kind). signal_id is the stable handle returned by the API and used by
-- /strategy/explain/:signal_id. components/weights are stored verbatim so the
-- score = sum(component.contribution) is reproducible.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS strategy_signals (
    signal_id   text        PRIMARY KEY,                 -- "<kind>:<chain>:<subject>"
    kind        text        NOT NULL CHECK (kind IN
                  ('token_conviction','wallet_follow','entry','exit','opportunity')),
    chain       text        NOT NULL,
    subject     text        NOT NULL,                    -- token address | wallet address
    score       numeric     NOT NULL CHECK (score BETWEEN 0 AND 100),
    confidence  numeric     NOT NULL CHECK (confidence BETWEEN 0 AND 1), -- input coverage
    components  jsonb       NOT NULL,                    -- [{name, value, weight, contribution, available, source}]
    missing     jsonb       NOT NULL DEFAULT '[]'::jsonb,-- names of unavailable inputs
    rationale   text        NOT NULL,                    -- short human explanation
    computed_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT chk_components_nonempty CHECK (jsonb_array_length(components) > 0)
);
CREATE INDEX IF NOT EXISTS idx_sig_kind ON strategy_signals (kind, chain, score DESC);
CREATE INDEX IF NOT EXISTS idx_sig_subject ON strategy_signals (chain, subject, kind);

-- -----------------------------------------------------------------------------
-- token_conviction — latest conviction score per token (a view-like projection
-- kept as a table for fast ranking; mirrors a 'token_conviction' strategy_signal).
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS token_conviction (
    chain       text        NOT NULL,
    token       text        NOT NULL CHECK (token = lower(token)),
    score       numeric     NOT NULL CHECK (score BETWEEN 0 AND 100),
    confidence  numeric     NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    signal_id   text        NOT NULL REFERENCES strategy_signals(signal_id) ON DELETE CASCADE,
    updated_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (chain, token)
);
CREATE INDEX IF NOT EXISTS idx_tc_rank ON token_conviction (chain, score DESC);

-- -----------------------------------------------------------------------------
-- wallet_follow_rank — ranked "who is worth following" per chain, from real
-- wallet profile + graph influence. rank is dense over the chain.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS wallet_follow_rank (
    chain       text        NOT NULL,
    wallet      text        NOT NULL CHECK (wallet = lower(wallet)),
    score       numeric     NOT NULL CHECK (score BETWEEN 0 AND 100),
    confidence  numeric     NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    rank        integer     NOT NULL,
    signal_id   text        NOT NULL REFERENCES strategy_signals(signal_id) ON DELETE CASCADE,
    updated_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (chain, wallet)
);
CREATE INDEX IF NOT EXISTS idx_wfr_rank ON wallet_follow_rank (chain, rank);

-- -----------------------------------------------------------------------------
-- entry_scores / exit_scores — timing scores per token. Entry favours fresh
-- smart-money inflow + positive sentiment + acceptable risk; exit favours
-- distribution / outflow / risk increase. Both expose components + confidence.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS entry_scores (
    chain       text        NOT NULL,
    token       text        NOT NULL CHECK (token = lower(token)),
    score       numeric     NOT NULL CHECK (score BETWEEN 0 AND 100),
    confidence  numeric     NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    signal_id   text        NOT NULL REFERENCES strategy_signals(signal_id) ON DELETE CASCADE,
    updated_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (chain, token)
);
CREATE TABLE IF NOT EXISTS exit_scores (
    chain       text        NOT NULL,
    token       text        NOT NULL CHECK (token = lower(token)),
    score       numeric     NOT NULL CHECK (score BETWEEN 0 AND 100),
    confidence  numeric     NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    signal_id   text        NOT NULL REFERENCES strategy_signals(signal_id) ON DELETE CASCADE,
    updated_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (chain, token)
);

-- -----------------------------------------------------------------------------
-- opportunity_feed — ranked surfaced opportunities (highest conviction/entry with
-- sufficient confidence). One row per (chain, token); refreshed each build.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS opportunity_feed (
    id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    chain       text        NOT NULL,
    token       text        NOT NULL CHECK (token = lower(token)),
    score       numeric     NOT NULL CHECK (score BETWEEN 0 AND 100),
    confidence  numeric     NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    reason      text        NOT NULL,
    signal_id   text        NOT NULL REFERENCES strategy_signals(signal_id) ON DELETE CASCADE,
    surfaced_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_opp UNIQUE (chain, token)
);
CREATE INDEX IF NOT EXISTS idx_opp_rank ON opportunity_feed (score DESC, confidence DESC);
