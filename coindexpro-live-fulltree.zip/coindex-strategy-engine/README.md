## coindex-strategy-engine — Phase 13

Synthesis layer. It combines the **real derived outputs of Phases 4–12** into
explainable strategy scores: token conviction, wallet follow-rank, entry/exit
timing, and a ranked opportunity feed. It is pure synthesis — it ingests nothing
new and reads only existing tables.

### The explainability contract (rule 6)

Every score is built from weighted **components**, and every component records:
its `value` (normalized input), its `weight`, its `contribution` (share of the
final score), whether it was `available`, and its `source` (the exact upstream
table). The signal also lists `missing` inputs and a `confidence`:

```
confidence = (sum of weights of AVAILABLE components) / (sum of ALL weights)
score      = weighted average of available components, scaled to 0..100
```

So a score computed from partial data is never presented as complete — its
confidence drops and the missing inputs are named. **A score is never produced
from zero available inputs**: such a subject is skipped at build time and the API
returns `{"available": false, "reason": "not indexed"}`.

### Source-of-truth mapping (real upstream only)

| Component | Source (verified on disk) |
|---|---|
| `smart_money_flow` / `distribution` | Phase 11 `flow_snapshots(scope='smart_money').net_usd` + `priced_coverage` |
| `whale_flow` / `whale_distribution` | Phase 11 `cohort_flows(cohort='whale').net_usd` |
| `sentiment` / `negative_sentiment` | Phase 12 `social_sentiment.mean_sentiment` + `coverage` |
| `social_velocity` | Phase 12 `social_scores.velocity` |
| `contract_safety` / `contract_risk` | Phase 8 `contract_analysis.score` (inverted for safety) |
| `liquidity` | Phase 2 `token_metrics.liq_usd` (ClickHouse) |
| `realized_pnl`, `win_rate`, `conviction` | Phase 6 `wallet_profiles` |
| `graph_influence` | Phase 9 `wallet_influence.score` |

Tracked subjects are themselves drawn from real tables — tokens that already
appear in `contract_analysis` / `flow_snapshots` / `social_scores`, and wallets
that have a `wallet_profiles` row — never an invented watchlist.

### Coverage gating (honesty carried forward)

The Phase 11/12 coverage fields are consumed, not ignored: a smart-money flow
whose `priced_coverage` is 0 (every contributing trade unpriced) carries no real
USD signal, so that component is marked **unavailable** rather than trusted.
Sentiment over zero scored mentions is treated the same way.

### Recipes & weights

Weights are configurable (echoed onto every component). Defaults:

- **token_conviction** = smart-money 0.30 · whale 0.15 · sentiment 0.20 · social-velocity 0.15 · contract-safety 0.25 · liquidity 0.10
- **wallet_follow** = realized-PnL 0.30 · win-rate 0.25 · conviction 0.20 · graph-influence 0.25
- **entry** = smart-money inflow 0.45 · sentiment 0.25 · contract-safety 0.30
- **exit** = distribution 0.45 · whale-distribution 0.15 · rising-risk 0.35 · negative-sentiment 0.20

Because the builder normalizes by available weight, weights need not sum to 1 and
a missing component simply lowers confidence.

### Outputs (tables)

`strategy_signals` (canonical explainable record, keyed by `signal_id`),
`token_conviction`, `wallet_follow_rank`, `entry_scores`, `exit_scores`,
`opportunity_feed`. The projections reference `strategy_signals(signal_id)` so
`/strategy/explain` always reconstructs the full breakdown.

### API

| Route | Returns |
|---|---|
| `GET /strategy/token/:chain/:address` | conviction + entry + exit (or not indexed) |
| `GET /strategy/wallet/:chain/:address` | follow score (or not indexed) |
| `GET /strategy/opportunities` | ranked opportunity feed |
| `GET /strategy/feed` | most recent signals across kinds |
| `GET /strategy/explain/:signal_id` | full components + weights + confidence + missing |

Static routes are registered before parameterized ones. Ops: `/healthz`,
`/readyz`, `/metrics`.

### Opportunity feed gates

A conviction signal is surfaced only when `confidence >= min_confidence` (default
0.5) **and** `score >= min_opp_score` (default 60) — so the feed never promotes a
high score built on thin coverage.

### Idempotency & replay

`strategy_signals` and the per-token projections upsert on their natural keys;
`wallet_follow_rank` and `opportunity_feed` are rewritten per build inside a
transaction (delete+insert) so ranks/feed always reflect the latest build with no
stale rows. Builds are deterministic over the same upstream snapshot.

### Honest boundaries / runtime limitations

- **Real, production-shaped code, NOT compiled or run here** (no Go toolchain, no
  Postgres/ClickHouse/Redis/Kafka, no network). Statically reviewed: imports/
  symbols/interfaces resolve, no import cycle (`db` imports neither `strategy` nor
  `scoring`), routes ordered, metrics symbols match engine references, no dead code
  (the previously-orphaned `whale`/coverage inputs are now real components). The
  scoring math — confidence, weighted average, zero-input refusal, coverage gating
  — was verified by simulation. Before production: `go build` + `vet` + lint and an
  integration run.
- **No fabricated scores.** Every number traces to a real upstream value through a
  named component with a weight. Missing inputs are surfaced, not zero-filled, and
  a subject with no available input produces no row.
- **Only as good as upstream.** Conviction/entry/exit reflect whatever Phases
  8/11/12 have actually computed for a token; a token analysed by only one phase
  gets a low-confidence score that says so. The engine adds no information beyond
  what the source phases produced.
