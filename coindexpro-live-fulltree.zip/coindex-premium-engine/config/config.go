// Package config loads premium-engine configuration from YAML with ${ENV} expansion.
package config

import (
	"fmt"
	"os"
	"time"

	"gopkg.in/yaml.v3"
)

type Config struct {
	Server    ServerConfig    `yaml:"server"`
	Postgres  PostgresConfig  `yaml:"postgres"`
	Redis     RedisConfig     `yaml:"redis"`
	Stripe    StripeConfig    `yaml:"stripe"`
	Reconcile ReconcileConfig `yaml:"reconcile"`
	Log       LogConfig       `yaml:"log"`
}

type ServerConfig struct {
	APIAddr     string `yaml:"api_addr"`
	MetricsAddr string `yaml:"metrics_addr"`
}
type PostgresConfig struct {
	DSN string `yaml:"dsn"`
}
type RedisConfig struct {
	Addr     string        `yaml:"addr"`
	CacheTTL time.Duration `yaml:"cache_ttl"`
}

// StripeConfig is OPTIONAL. An empty secret_key means billing actions report
// "not configured" rather than being faked.
type StripeConfig struct {
	SecretKey        string            `yaml:"secret_key"`
	WebhookSecret    string            `yaml:"webhook_secret"`
	WebhookTolerance time.Duration     `yaml:"webhook_tolerance"`
	PriceIDs         map[string]string `yaml:"price_ids"` // plan -> Stripe price id
}
type ReconcileConfig struct {
	Enabled  bool          `yaml:"enabled"`
	Interval time.Duration `yaml:"interval"`
	Batch    int           `yaml:"batch"`
}
type LogConfig struct {
	Level string `yaml:"level"`
}

func Load(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}
	var c Config
	if err := yaml.Unmarshal([]byte(os.Expand(string(raw), os.Getenv)), &c); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}
	c.defaults()
	return &c, c.validate()
}

func (c *Config) defaults() {
	if c.Server.APIAddr == "" {
		c.Server.APIAddr = ":8102"
	}
	if c.Server.MetricsAddr == "" {
		c.Server.MetricsAddr = ":9114"
	}
	if c.Redis.CacheTTL == 0 {
		c.Redis.CacheTTL = 15 * time.Second
	}
	if c.Stripe.WebhookTolerance == 0 {
		c.Stripe.WebhookTolerance = 5 * time.Minute
	}
	if c.Reconcile.Interval == 0 {
		c.Reconcile.Interval = time.Minute
	}
	if c.Reconcile.Batch == 0 {
		c.Reconcile.Batch = 100
	}
}

func (c *Config) validate() error {
	if c.Postgres.DSN == "" {
		return fmt.Errorf("postgres.dsn empty")
	}
	if c.Redis.Addr == "" {
		return fmt.Errorf("redis.addr empty")
	}
	// Stripe is intentionally optional; no validation error when absent.
	return nil
}
