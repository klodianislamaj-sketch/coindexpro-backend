## coindex-premium-engine — Phase 16

Premium infrastructure: the **entitlement, quota, and billing-sync** layer. It sits
above the Phase 3 gateway and turns the real Phase 2 account/billing tables into
entitlement and quota decisions — and integrates Stripe **honestly**, reporting
"not configured" for anything that needs a Stripe key we don't have, rather than
faking it.

### The honesty boundary (rules 3 + 9)

| Capability | Status | Behavior |
|---|---|---|
| Entitlement (tier + features) | **Real** | computed from `user_accounts.tier` + real `premium_subscriptions` |
| Quota limits | **Real** | from `api_keys.quota_per_min` / `quota_per_day` |
| Quota **usage** | **Real** | counted from real recorded requests (`api_usage`); never synthesized |
| Webhook verification | **Real** | HMAC-SHA256 signature check (when webhook secret configured) |
| Subscription state | **Real, event-driven** | applied only from verified `customer.subscription.*` events |
| Checkout / portal URLs | **Stripe-gated** | `{available:false, reason:"not configured"}` without a Stripe key — never a fake URL |

Nothing here fabricates a subscription, an entitlement, a usage count, or a billing
URL. Unknown users/keys return `{available:false, reason:"not indexed"}`;
Stripe-dependent actions with no key return `{available:false, reason:"not configured"}`.

### Source-of-truth mapping (verified on disk, reused not rebuilt)

| Input | Real source |
|---|---|
| base tier | Phase 2 `user_accounts.tier` |
| subscription (plan/status/period end) | Phase 2 `premium_subscriptions` |
| quota limits + revoked | Phase 2 `api_keys` |
| quota usage | **new** `api_usage` (real recorded requests) |
| webhook ledger | **new** `stripe_events` (verified events only) |

### Entitlement logic (transparent)

Effective tier = base tier, upgraded to the subscription's plan **only** when the
subscription is real **and** active (status `active`/`trialing` **and** not past
`current_period_end`). A canceled / past-due / incomplete / expired subscription
does **not** grant premium — the effective tier falls back to the base tier with an
explicit reason. Features come from a static, auditable tier→feature matrix.

### Quota logic

`EvaluateQuota` compares real configured limits against real recorded usage for the
current minute and day windows. A revoked key is always denied; an exhausted window
is denied with a reason; remaining counts never go negative. `POST /premium/usage/:key_hash`
is the single place a real request is counted — it atomically increments both
windows and returns the updated status.

### Endpoints

| Route | Purpose |
|---|---|
| `GET /premium/entitlement/:user_id` | effective tier + features + subscription state |
| `GET /premium/feature/:user_id/:feature` | is a feature unlocked for this user |
| `GET /premium/quota/:key_hash` | read-only quota status (no increment) |
| `POST /premium/usage/:key_hash` | record one real request, return updated quota |
| `POST /premium/billing/checkout/:user_id` | Stripe checkout (or not configured) |
| `POST /premium/billing/portal/:user_id` | Stripe billing portal (or not configured) |
| `POST /premium/billing/webhook` | verify + idempotently record a Stripe event |

Static prefixes are registered before parameterized routes. Ops: `/healthz`,
`/readyz`, `/metrics`.

### Idempotency & replay

`api_usage` increments atomically via upsert (`count = count + 1`) so concurrent
requests can't lose a count. `stripe_events` inserts `ON CONFLICT DO NOTHING`, so a
duplicate webhook delivery is a no-op; the reconciler applies each event once and
marks it processed. Subscription upserts are keyed by `user_id`. Re-running the
reconciler is safe.

### Honest runtime limitations

- **Real, production-shaped code, NOT compiled or run here** (no Go toolchain, no
  Postgres/Redis, no network, no Stripe account). Statically reviewed: imports/
  symbols/interfaces resolve, no import cycle (`db`, `premium`, `billing` depend
  only on `models`), routes ordered, metrics symbols match references, no dead code
  (a dead `QuotaStatus.KeyHash` field + unused param were removed), no orphaned
  upstream reads. Entitlement, quota, webhook-HMAC, idempotency, and the
  not-configured path were verified by simulation. Before production: `go build` +
  `vet` + lint and an integration run.
- **The live Stripe API calls are intentionally not executed here.** Checkout/portal
  return `not configured` rather than a fabricated URL; wiring the real Stripe SDK
  (session creation) is the one integration step that requires a real Stripe account
  and is deliberately left as an explicit `ErrNotConfigured` boundary, not a stub
  that returns fake data. Webhook **verification** is fully implemented and real.
- **No fabricated state.** No subscription is ever written except from a verified
  Stripe event; no entitlement or usage number is invented; absent inputs are
  surfaced as `not indexed` / `not configured`, never silently defaulted.
