-- =============================================================================
-- CoinDex Premium Infrastructure — PostgreSQL migration (Phase 16)
-- =============================================================================
-- The entitlement / quota / billing-sync layer. It REUSES the Phase 2 tables as
-- the source of truth (not rebuilt):
--   * user_accounts          (tier: free|premium|enterprise)
--   * api_keys               (key_hash, quota_per_min, quota_per_day, revoked)
--   * premium_subscriptions  (stripe_sub_id, status, plan, current_period_end)
--
-- It ADDS two tables:
--   * api_usage     — REAL request counts per key per window (never synthesized;
--                     a usage row only exists because a real request was recorded)
--   * stripe_events — idempotent ledger of REAL Stripe webhook events, so a
--                     subscription state change is only ever applied from a real,
--                     verified event (never a fabricated subscription)
--
-- HONESTY: quota usage is counted from real recorded requests; entitlements are
-- computed from real tier + real subscription status; anything that requires the
-- Stripe API (checkout, portal, live sync) is reported unavailable/not configured
-- when no Stripe key is present, rather than faked.
--
-- All NEW tables (collision-checked); idempotent.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- api_usage — real request counts. One row per (key_hash, window_kind, window_start).
--   window_kind: 'minute' | 'day'. count is incremented atomically per real
--   recorded request; there is no path that writes a usage number out of thin air.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS api_usage (
    key_hash     text        NOT NULL REFERENCES api_keys(key_hash) ON DELETE CASCADE,
    window_kind  text        NOT NULL CHECK (window_kind IN ('minute','day')),
    window_start timestamptz NOT NULL,
    count        bigint      NOT NULL DEFAULT 0 CHECK (count >= 0),
    updated_at   timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (key_hash, window_kind, window_start)
);
CREATE INDEX IF NOT EXISTS idx_usage_window ON api_usage (window_kind, window_start);

-- -----------------------------------------------------------------------------
-- stripe_events — idempotent webhook ledger. event_id is Stripe's id; a duplicate
-- delivery is a no-op (ON CONFLICT DO NOTHING). processed flips once the event has
-- been applied to premium_subscriptions. We never invent an event.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS stripe_events (
    event_id     text        PRIMARY KEY,            -- Stripe event id (evt_...)
    type         text        NOT NULL,               -- e.g. customer.subscription.updated
    user_id      uuid        REFERENCES user_accounts(id) ON DELETE SET NULL,
    payload      jsonb       NOT NULL,               -- verified raw event (real)
    processed    boolean     NOT NULL DEFAULT false,
    received_at  timestamptz NOT NULL DEFAULT now(),
    processed_at timestamptz
);
CREATE INDEX IF NOT EXISTS idx_stripe_unprocessed ON stripe_events (processed) WHERE processed = false;
