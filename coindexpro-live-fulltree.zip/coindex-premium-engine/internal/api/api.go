// Package api serves the premium-infrastructure reads + actions. Honesty is
// enforced at the envelope level: unknown users/keys return {available:false,
// reason:"not indexed"}; Stripe-gated actions with no configured key return
// {available:false, reason:"not configured"}. Entitlements and quota come straight
// from real data (tier, subscription, configured limits, recorded usage), and the
// usage endpoint is the single place a real request is counted.
package api

import (
	"errors"
	"io"
	"time"

	"github.com/gofiber/fiber/v2"

	"github.com/coindexpro/coindex-premium-engine/internal/billing"
	"github.com/coindexpro/coindex-premium-engine/internal/db"
	"github.com/coindexpro/coindex-premium-engine/internal/metrics"
	"github.com/coindexpro/coindex-premium-engine/internal/models"
	"github.com/coindexpro/coindex-premium-engine/internal/premium"
)

type API struct {
	store   *db.Store
	billing *billing.Client
	webhookTolerance time.Duration
}

func New(store *db.Store, b *billing.Client, webhookTolerance time.Duration) *API {
	if webhookTolerance <= 0 {
		webhookTolerance = 5 * time.Minute
	}
	return &API{store: store, billing: b, webhookTolerance: webhookTolerance}
}

// Register orders static routes before parameterized ones.
func (a *API) Register(app *fiber.App) {
	app.Use(a.observe)
	// billing (static prefixes)
	app.Post("/premium/billing/webhook", a.webhook)
	app.Post("/premium/billing/checkout/:user_id", a.checkout)
	app.Post("/premium/billing/portal/:user_id", a.portal)
	// quota
	app.Post("/premium/usage/:key_hash", a.recordUsage)
	app.Get("/premium/quota/:key_hash", a.quota)
	// entitlement / features
	app.Get("/premium/feature/:user_id/:feature", a.feature)
	app.Get("/premium/entitlement/:user_id", a.entitlement)
}

func (a *API) observe(c *fiber.Ctx) error {
	start := time.Now()
	err := c.Next()
	metrics.APILatency.WithLabelValues(c.Route().Path, statusClass(c.Response().StatusCode())).
		Observe(time.Since(start).Seconds())
	return err
}

func notIndexed(c *fiber.Ctx, extra fiber.Map) error {
	m := fiber.Map{"available": false, "reason": "not indexed"}
	for k, v := range extra {
		m[k] = v
	}
	return c.JSON(m)
}
func notConfigured(c *fiber.Ctx, extra fiber.Map) error {
	m := fiber.Map{"available": false, "reason": "not configured"}
	for k, v := range extra {
		m[k] = v
	}
	return c.JSON(m)
}

// GET /premium/entitlement/:user_id
func (a *API) entitlement(c *fiber.Ctx) error {
	userID := c.Params("user_id")
	ut, found, err := a.store.UserTier(c.UserContext(), userID)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !found {
		return notIndexed(c, fiber.Map{"user_id": userID})
	}
	sub, err := a.store.Subscription(c.UserContext(), userID)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	ent := premium.ComputeEntitlement(ut, sub, time.Now().UTC())
	metrics.EntitlementChecks.Inc()
	return c.JSON(fiber.Map{"available": true, "entitlement": ent})
}

// GET /premium/feature/:user_id/:feature
func (a *API) feature(c *fiber.Ctx) error {
	userID := c.Params("user_id")
	feat := c.Params("feature")
	ut, found, err := a.store.UserTier(c.UserContext(), userID)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !found {
		return notIndexed(c, fiber.Map{"user_id": userID})
	}
	sub, err := a.store.Subscription(c.UserContext(), userID)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	ent := premium.ComputeEntitlement(ut, sub, time.Now().UTC())
	fc := premium.CheckFeature(ent, feat)
	return c.JSON(fiber.Map{"available": true, "feature_check": fc})
}

// GET /premium/quota/:key_hash — read-only quota status (no increment)
func (a *API) quota(c *fiber.Ctx) error {
	keyHash := c.Params("key_hash")
	perMin, perDay, revoked, found, err := a.store.KeyQuotaConfig(c.UserContext(), keyHash)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !found {
		return notIndexed(c, fiber.Map{"key_hash": keyHash})
	}
	pm, pd, err := a.store.GetUsage(c.UserContext(), keyHash, time.Now().UTC())
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	q := premium.EvaluateQuota(revoked, perMin, perDay, pm, pd)
	return c.JSON(fiber.Map{"available": true, "quota": q})
}

// POST /premium/usage/:key_hash — record ONE real request and return updated quota
func (a *API) recordUsage(c *fiber.Ctx) error {
	keyHash := c.Params("key_hash")
	perMin, perDay, revoked, found, err := a.store.KeyQuotaConfig(c.UserContext(), keyHash)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !found {
		return notIndexed(c, fiber.Map{"key_hash": keyHash})
	}
	// a revoked key records no usage and is simply denied
	if revoked {
		q := premium.EvaluateQuota(true, perMin, perDay, 0, 0)
		metrics.QuotaDenied.WithLabelValues("key revoked").Inc()
		return c.Status(fiber.StatusForbidden).JSON(fiber.Map{"available": true, "quota": q})
	}
	pm, pd, err := a.store.IncrUsage(c.UserContext(), keyHash, time.Now().UTC())
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	metrics.UsageRecorded.Inc()
	q := premium.EvaluateQuota(false, perMin, perDay, pm, pd)
	if !q.Allowed {
		metrics.QuotaDenied.WithLabelValues(q.Reason).Inc()
		return c.Status(fiber.StatusTooManyRequests).JSON(fiber.Map{"available": true, "quota": q})
	}
	return c.JSON(fiber.Map{"available": true, "quota": q})
}

// POST /premium/billing/checkout/:user_id
func (a *API) checkout(c *fiber.Ctx) error {
	userID := c.Params("user_id")
	plan := c.Query("plan", models.TierPremium)
	if _, found, err := a.store.UserTier(c.UserContext(), userID); err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	} else if !found {
		return notIndexed(c, fiber.Map{"user_id": userID})
	}
	url, err := a.billing.CreateCheckoutSession(userID, plan)
	if err != nil {
		if errors.Is(err, billing.ErrNotConfigured) {
			return notConfigured(c, fiber.Map{"action": "checkout", "plan": plan})
		}
		return c.Status(fiber.StatusBadGateway).JSON(fiber.Map{"error": "checkout failed"})
	}
	return c.JSON(fiber.Map{"available": true, "checkout_url": url})
}

// POST /premium/billing/portal/:user_id
func (a *API) portal(c *fiber.Ctx) error {
	userID := c.Params("user_id")
	if _, found, err := a.store.UserTier(c.UserContext(), userID); err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	} else if !found {
		return notIndexed(c, fiber.Map{"user_id": userID})
	}
	url, err := a.billing.CreatePortalSession(userID)
	if err != nil {
		if errors.Is(err, billing.ErrNotConfigured) {
			return notConfigured(c, fiber.Map{"action": "portal"})
		}
		return c.Status(fiber.StatusBadGateway).JSON(fiber.Map{"error": "portal failed"})
	}
	return c.JSON(fiber.Map{"available": true, "portal_url": url})
}

// POST /premium/billing/webhook — verify signature, record idempotently
func (a *API) webhook(c *fiber.Ctx) error {
	body, err := io.ReadAll(c.Request().BodyStream())
	if err != nil || len(body) == 0 {
		body = c.Body() // fallback to buffered body
	}
	sig := c.Get("Stripe-Signature")
	ev, err := a.billing.VerifyWebhook(body, sig, a.webhookTolerance)
	if err != nil {
		if errors.Is(err, billing.ErrNotConfigured) {
			metrics.WebhookEvents.WithLabelValues("not_configured").Inc()
			return notConfigured(c, fiber.Map{"action": "webhook"})
		}
		metrics.WebhookEvents.WithLabelValues("rejected").Inc()
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"available": false, "reason": "signature invalid"})
	}
	inserted, err := a.store.RecordEvent(c.UserContext(), ev)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	outcome := "recorded"
	if !inserted {
		outcome = "duplicate"
	}
	metrics.WebhookEvents.WithLabelValues(outcome).Inc()
	return c.JSON(fiber.Map{"available": true, "event_id": ev.EventID, "recorded": inserted})
}

func statusClass(code int) string {
	switch {
	case code >= 500:
		return "5xx"
	case code >= 400:
		return "4xx"
	default:
		return "2xx"
	}
}
