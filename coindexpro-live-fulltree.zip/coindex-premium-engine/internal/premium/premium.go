// Package premium holds the entitlement + quota logic. Every decision is computed
// from REAL data: a user's tier (user_accounts), their subscription status
// (premium_subscriptions), their key's configured limits (api_keys), and their
// recorded usage (api_usage). The feature matrix is static and transparent. There
// is no path that grants a feature or a higher tier without a real basis, and no
// path that invents usage or a subscription.
package premium

import (
	"time"

	"github.com/coindexpro/coindex-premium-engine/internal/models"
)

// FeatureMatrix is the transparent tier -> features mapping. Higher tiers include
// everything lower tiers have. This is the single source of gating truth.
var FeatureMatrix = map[string][]string{
	models.TierFree: {},
	models.TierPremium: {
		models.FeatureRealtimeAlerts,
		models.FeatureAdvancedStrategy,
		models.FeatureExecutionIntel,
		models.FeaturePortfolioSync,
	},
	models.TierEnterprise: {
		models.FeatureRealtimeAlerts,
		models.FeatureAdvancedStrategy,
		models.FeatureExecutionIntel,
		models.FeaturePortfolioSync,
		models.FeatureSocialFirehose,
		models.FeatureDataExport,
		models.FeaturePrioritySupport,
	},
}

// tierRank orders tiers so we can pick the more authoritative one.
var tierRank = map[string]int{models.TierFree: 0, models.TierPremium: 1, models.TierEnterprise: 2}

// ComputeEntitlement derives a user's effective entitlement from real data only.
//
// Rules (all grounded in real values, no fabrication):
//   - Base tier is user_accounts.tier.
//   - A subscription UPGRADES the effective tier to its plan ONLY when it is real
//     AND active (status active/trialing AND not past current_period_end).
//   - A subscription that is canceled/past_due/incomplete/expired does NOT grant
//     premium; the effective tier falls back to the base tier, with a reason.
//   - With no subscription, the effective tier is simply the base tier.
func ComputeEntitlement(ut models.UserTier, sub *models.Subscription, now time.Time) models.Entitlement {
	base := normalizeTier(ut.Tier)
	eff := base
	ent := models.Entitlement{UserID: ut.UserID, BaseTier: base}

	if sub != nil {
		ent.Subscription = sub
		active := subscriptionActive(*sub, now)
		ent.SubscriptionActive = active
		if active {
			planTier := normalizeTier(sub.Plan)
			if tierRank[planTier] > tierRank[eff] {
				eff = planTier // real, active subscription upgrades
			}
		} else {
			ent.Reason = "subscription not active (" + sub.Status + "); using base tier"
		}
	}

	ent.Tier = eff
	ent.Features = featuresFor(eff)
	return ent
}

// subscriptionActive reports whether a REAL subscription currently grants access.
func subscriptionActive(s models.Subscription, now time.Time) bool {
	if s.Status != "active" && s.Status != "trialing" {
		return false
	}
	if s.CurrentPeriodEnd != nil && now.After(*s.CurrentPeriodEnd) {
		return false // real period has ended; do not extend access
	}
	return true
}

// featuresFor returns a copy of the matrix entry for a tier.
func featuresFor(tier string) []string {
	src := FeatureMatrix[tier]
	out := make([]string, len(src))
	copy(out, src)
	if out == nil {
		out = []string{}
	}
	return out
}

// CheckFeature decides whether an entitlement unlocks a feature.
func CheckFeature(ent models.Entitlement, feature string) models.FeatureCheck {
	fc := models.FeatureCheck{UserID: ent.UserID, Feature: feature, Tier: ent.Tier}
	for _, f := range ent.Features {
		if f == feature {
			fc.Allowed = true
			return fc
		}
	}
	fc.Allowed = false
	fc.Reason = "feature not included in tier " + ent.Tier
	return fc
}

// EvaluateQuota computes a key's allowance from REAL configured limits and REAL
// recorded usage. A revoked key is never allowed. Usage values must be real counts
// supplied by the caller (read from api_usage); this function does not invent them.
func EvaluateQuota(revoked bool, perMinLimit, perDayLimit int, perMinUsed, perDayUsed int64) models.QuotaStatus {
	q := models.QuotaStatus{
		Revoked: revoked,
		PerMinLimit: perMinLimit, PerDayLimit: perDayLimit,
		PerMinUsed: perMinUsed, PerDayUsed: perDayUsed,
	}
	q.PerMinRemain = remaining(int64(perMinLimit), perMinUsed)
	q.PerDayRemain = remaining(int64(perDayLimit), perDayUsed)

	switch {
	case revoked:
		q.Allowed = false
		q.Reason = "key revoked"
	case q.PerMinRemain <= 0:
		q.Allowed = false
		q.Reason = "per-minute quota exhausted"
	case q.PerDayRemain <= 0:
		q.Allowed = false
		q.Reason = "per-day quota exhausted"
	default:
		q.Allowed = true
	}
	return q
}

func remaining(limit, used int64) int64 {
	r := limit - used
	if r < 0 {
		return 0
	}
	return r
}

func normalizeTier(t string) string {
	switch t {
	case models.TierPremium, models.TierEnterprise, models.TierFree:
		return t
	default:
		return models.TierFree
	}
}
