package premium

import (
	"testing"
	"time"

	"github.com/coindexpro/coindex-premium-engine/internal/models"
)

func tptr(t time.Time) *time.Time { return &t }

func TestComputeEntitlement_ActivePremiumUpgradesTier(t *testing.T) {
	now := time.Now()
	ut := models.UserTier{UserID: "u1", Tier: models.TierFree}
	sub := &models.Subscription{Plan: models.TierPremium, Status: "active", CurrentPeriodEnd: tptr(now.Add(24 * time.Hour))}
	ent := ComputeEntitlement(ut, sub, now)
	if ent.Tier != models.TierPremium {
		t.Fatalf("active premium sub must upgrade tier to premium, got %q", ent.Tier)
	}
	if len(ent.Features) == 0 {
		t.Fatal("premium tier must unlock features")
	}
}

// A canceled subscription must NOT grant premium; tier falls back to base + reason.
func TestComputeEntitlement_CanceledFallsBackToBase(t *testing.T) {
	now := time.Now()
	ut := models.UserTier{UserID: "u1", Tier: models.TierFree}
	sub := &models.Subscription{Plan: models.TierPremium, Status: "canceled", CurrentPeriodEnd: tptr(now.Add(24 * time.Hour))}
	ent := ComputeEntitlement(ut, sub, now)
	if ent.Tier != models.TierFree {
		t.Fatalf("canceled sub must fall back to base (free), got %q", ent.Tier)
	}
	if ent.Reason == "" {
		t.Fatal("a downgrade must carry an explanatory reason")
	}
}

// An active sub whose period has ended must not extend access.
func TestComputeEntitlement_ExpiredPeriodIsInactive(t *testing.T) {
	now := time.Now()
	ut := models.UserTier{UserID: "u1", Tier: models.TierFree}
	sub := &models.Subscription{Plan: models.TierPremium, Status: "active", CurrentPeriodEnd: tptr(now.Add(-1 * time.Hour))}
	ent := ComputeEntitlement(ut, sub, now)
	if ent.Tier != models.TierFree {
		t.Fatalf("expired period must not grant premium, got %q", ent.Tier)
	}
	if ent.SubscriptionActive {
		t.Fatal("expired subscription must be inactive")
	}
}

func TestComputeEntitlement_NoSubscriptionUsesBaseTier(t *testing.T) {
	now := time.Now()
	ent := ComputeEntitlement(models.UserTier{UserID: "u1", Tier: models.TierEnterprise}, nil, now)
	if ent.Tier != models.TierEnterprise {
		t.Fatalf("no sub: effective tier must equal base, got %q", ent.Tier)
	}
}

func TestEvaluateQuota_RevokedDenied(t *testing.T) {
	q := EvaluateQuota(true, 60, 10000, 0, 0)
	if q.Allowed {
		t.Fatal("revoked key must be denied")
	}
}

func TestEvaluateQuota_ExhaustionDenied(t *testing.T) {
	if EvaluateQuota(false, 60, 10000, 60, 500).Allowed {
		t.Fatal("per-minute exhausted must be denied")
	}
	if EvaluateQuota(false, 60, 10000, 5, 10000).Allowed {
		t.Fatal("per-day exhausted must be denied")
	}
}

func TestEvaluateQuota_RemainingNeverNegative(t *testing.T) {
	q := EvaluateQuota(false, 60, 10000, 100, 99999)
	if q.PerMinRemain < 0 || q.PerDayRemain < 0 {
		t.Fatalf("remaining must clamp at 0, got min=%d day=%d", q.PerMinRemain, q.PerDayRemain)
	}
}

func TestEvaluateQuota_UnderLimitAllowed(t *testing.T) {
	if !EvaluateQuota(false, 60, 10000, 10, 500).Allowed {
		t.Fatal("under both limits must be allowed")
	}
}
