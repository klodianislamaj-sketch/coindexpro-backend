// Package db is the premium-engine persistence layer. It READS the Phase 2 source
// of truth (user_accounts, api_keys, premium_subscriptions) and OWNS the two new
// tables (api_usage, stripe_events). Usage counts are incremented atomically from
// real recorded requests; subscription state is upserted only from verified Stripe
// events. Absent rows become nil/false (unavailable), never a fabricated default.
// Imports only the models package (no import cycle).
package db

import (
	"context"
	"encoding/json"
	"errors"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/coindexpro/coindex-premium-engine/internal/models"
)

type Store struct{ pg *pgxpool.Pool }

func Open(ctx context.Context, dsn string) (*Store, error) {
	pg, err := pgxpool.New(ctx, dsn)
	if err != nil {
		return nil, err
	}
	if err := pg.Ping(ctx); err != nil {
		return nil, err
	}
	return &Store{pg: pg}, nil
}

func (s *Store) Close()                      { s.pg.Close() }
func (s *Store) Ping(ctx context.Context) error { return s.pg.Ping(ctx) }

// ---------- reads: Phase 2 source of truth ----------

// UserTier reads a user's real base tier (user_accounts). found=false when no such
// user exists (the API then reports not indexed).
func (s *Store) UserTier(ctx context.Context, userID string) (models.UserTier, bool, error) {
	const q = `SELECT id::text, tier FROM user_accounts WHERE id=$1`
	var ut models.UserTier
	err := s.pg.QueryRow(ctx, q, userID).Scan(&ut.UserID, &ut.Tier)
	if errors.Is(err, pgx.ErrNoRows) {
		return models.UserTier{}, false, nil
	}
	if err != nil {
		return models.UserTier{}, false, err
	}
	return ut, true, nil
}

// Subscription reads a user's real subscription (premium_subscriptions). Returns
// nil when the user has no subscription row — never a synthesized one.
func (s *Store) Subscription(ctx context.Context, userID string) (*models.Subscription, error) {
	const q = `
		SELECT plan, status, coalesce(stripe_sub_id,''), current_period_end
		FROM premium_subscriptions WHERE user_id=$1`
	var sub models.Subscription
	var cpe *time.Time
	err := s.pg.QueryRow(ctx, q, userID).Scan(&sub.Plan, &sub.Status, &sub.StripeSubID, &cpe)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	sub.CurrentPeriodEnd = cpe
	return &sub, nil
}

// KeyQuotaConfig reads a key's real configured limits + revoked flag (api_keys).
// found=false when the key hash is unknown.
func (s *Store) KeyQuotaConfig(ctx context.Context, keyHash string) (perMin, perDay int, revoked bool, found bool, err error) {
	const q = `SELECT quota_per_min, quota_per_day, revoked FROM api_keys WHERE key_hash=$1`
	err = s.pg.QueryRow(ctx, q, keyHash).Scan(&perMin, &perDay, &revoked)
	if errors.Is(err, pgx.ErrNoRows) {
		return 0, 0, false, false, nil
	}
	if err != nil {
		return 0, 0, false, false, err
	}
	return perMin, perDay, revoked, true, nil
}

// ---------- usage: real recorded requests ----------

// IncrUsage atomically records ONE real request against a key, bumping both the
// current-minute and current-day counters. The returned counts are the post-incr
// real values used to evaluate quota. It never writes a count that wasn't produced
// by a real recorded request.
func (s *Store) IncrUsage(ctx context.Context, keyHash string, now time.Time) (perMinUsed, perDayUsed int64, err error) {
	minWin := now.UTC().Truncate(time.Minute)
	dayWin := now.UTC().Truncate(24 * time.Hour)

	tx, err := s.pg.Begin(ctx)
	if err != nil {
		return 0, 0, err
	}
	defer tx.Rollback(ctx)

	const up = `
		INSERT INTO api_usage (key_hash, window_kind, window_start, count)
		VALUES ($1,$2,$3,1)
		ON CONFLICT (key_hash, window_kind, window_start)
		DO UPDATE SET count = api_usage.count + 1, updated_at = now()
		RETURNING count`
	if err = tx.QueryRow(ctx, up, keyHash, "minute", minWin).Scan(&perMinUsed); err != nil {
		return 0, 0, err
	}
	if err = tx.QueryRow(ctx, up, keyHash, "day", dayWin).Scan(&perDayUsed); err != nil {
		return 0, 0, err
	}
	if err = tx.Commit(ctx); err != nil {
		return 0, 0, err
	}
	return perMinUsed, perDayUsed, nil
}

// GetUsage reads the real current-window counts WITHOUT incrementing (for a
// read-only quota status check). Missing rows mean zero real usage so far.
func (s *Store) GetUsage(ctx context.Context, keyHash string, now time.Time) (perMinUsed, perDayUsed int64, err error) {
	minWin := now.UTC().Truncate(time.Minute)
	dayWin := now.UTC().Truncate(24 * time.Hour)
	const q = `SELECT coalesce(count,0) FROM api_usage WHERE key_hash=$1 AND window_kind=$2 AND window_start=$3`
	if err = getCount(ctx, s.pg, q, keyHash, "minute", minWin, &perMinUsed); err != nil {
		return 0, 0, err
	}
	if err = getCount(ctx, s.pg, q, keyHash, "day", dayWin, &perDayUsed); err != nil {
		return 0, 0, err
	}
	return perMinUsed, perDayUsed, nil
}

func getCount(ctx context.Context, pg *pgxpool.Pool, q, keyHash, kind string, win time.Time, dst *int64) error {
	err := pg.QueryRow(ctx, q, keyHash, kind, win).Scan(dst)
	if errors.Is(err, pgx.ErrNoRows) {
		*dst = 0
		return nil
	}
	return err
}

// ---------- stripe events: idempotent ledger ----------

// RecordEvent inserts a verified event idempotently. inserted=false means we have
// already seen this event id (a duplicate delivery), so processing is a no-op.
func (s *Store) RecordEvent(ctx context.Context, ev models.StripeEvent) (inserted bool, err error) {
	payload, err := json.Marshal(ev.Payload)
	if err != nil {
		return false, err
	}
	var userID *string
	if ev.UserID != "" {
		userID = &ev.UserID
	}
	const q = `
		INSERT INTO stripe_events (event_id, type, user_id, payload)
		VALUES ($1,$2,$3,$4)
		ON CONFLICT (event_id) DO NOTHING`
	ct, err := s.pg.Exec(ctx, q, ev.EventID, ev.Type, userID, payload)
	if err != nil {
		return false, err
	}
	return ct.RowsAffected() == 1, nil
}

// UnprocessedEvents returns verified events awaiting application.
func (s *Store) UnprocessedEvents(ctx context.Context, limit int) ([]models.StripeEvent, error) {
	const q = `
		SELECT event_id, type, coalesce(user_id::text,''), payload
		FROM stripe_events WHERE processed = false
		ORDER BY received_at ASC LIMIT $1`
	rows, err := s.pg.Query(ctx, q, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.StripeEvent
	for rows.Next() {
		var ev models.StripeEvent
		var payload []byte
		if err := rows.Scan(&ev.EventID, &ev.Type, &ev.UserID, &payload); err != nil {
			return nil, err
		}
		_ = json.Unmarshal(payload, &ev.Payload)
		out = append(out, ev)
	}
	return out, rows.Err()
}

// MarkProcessed flips an event to processed.
func (s *Store) MarkProcessed(ctx context.Context, eventID string) error {
	const q = `UPDATE stripe_events SET processed = true, processed_at = now() WHERE event_id=$1`
	_, err := s.pg.Exec(ctx, q, eventID)
	return err
}

// UpsertSubscription applies a REAL verified subscription state to
// premium_subscriptions. user_id must resolve to a real user. This is the only
// path that writes subscription state, and it only runs on verified events.
func (s *Store) UpsertSubscription(ctx context.Context, userID, plan, status, stripeSubID string, currentPeriodEnd *time.Time) error {
	const q = `
		INSERT INTO premium_subscriptions (user_id, stripe_sub_id, status, plan, current_period_end)
		VALUES ($1,$2,$3,$4,$5)
		ON CONFLICT (user_id) DO UPDATE SET
			stripe_sub_id=$2, status=$3, plan=$4, current_period_end=$5, updated_at=now()`
	_, err := s.pg.Exec(ctx, q, userID, nullStr(stripeSubID), status, plan, currentPeriodEnd)
	return err
}

func nullStr(s string) any {
	if s == "" {
		return nil
	}
	return s
}
