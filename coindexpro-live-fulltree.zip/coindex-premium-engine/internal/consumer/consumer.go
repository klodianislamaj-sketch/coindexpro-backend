// Package consumer drains the verified Stripe event ledger and applies real
// subscription state. It is the only writer of subscription state, and it only
// ever acts on events that were already verified and recorded (stripe_events).
// There is no path that invents a subscription: an event that does not parse to a
// real subscription update is marked processed and skipped.
package consumer

import (
	"context"
	"time"

	"go.uber.org/zap"

	"github.com/coindexpro/coindex-premium-engine/internal/billing"
	"github.com/coindexpro/coindex-premium-engine/internal/metrics"
	"github.com/coindexpro/coindex-premium-engine/internal/models"
)

// Store is the subset of db.Store the reconciler needs.
type Store interface {
	UnprocessedEvents(ctx context.Context, limit int) ([]models.StripeEvent, error)
	MarkProcessed(ctx context.Context, eventID string) error
	UpsertSubscription(ctx context.Context, userID, plan, status, stripeSubID string, currentPeriodEnd *time.Time) error
}

// Reconciler periodically applies verified subscription events.
type Reconciler struct {
	store    Store
	interval time.Duration
	batch    int
	log      *zap.Logger
}

func NewReconciler(store Store, interval time.Duration, batch int, log *zap.Logger) *Reconciler {
	if interval <= 0 {
		interval = time.Minute
	}
	if batch <= 0 {
		batch = 100
	}
	return &Reconciler{store: store, interval: interval, batch: batch, log: log}
}

func (r *Reconciler) Run(ctx context.Context) error {
	t := time.NewTicker(r.interval)
	defer t.Stop()
	r.once(ctx)
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-t.C:
			r.once(ctx)
		}
	}
}

func (r *Reconciler) once(ctx context.Context) {
	events, err := r.store.UnprocessedEvents(ctx, r.batch)
	if err != nil {
		r.log.Warn("load unprocessed stripe events failed", zap.Error(err))
		return
	}
	for _, ev := range events {
		r.apply(ctx, ev)
	}
}

// apply processes one verified event. A subscription lifecycle event updates
// premium_subscriptions from REAL payload values; any other event type (or one
// missing a user mapping) is marked processed without inventing state.
func (r *Reconciler) apply(ctx context.Context, ev models.StripeEvent) {
	up, ok := billing.ParseSubscriptionEvent(ev)
	if !ok {
		// not a subscription event we act on; record as handled.
		if err := r.store.MarkProcessed(ctx, ev.EventID); err != nil {
			r.log.Warn("mark processed failed", zap.String("event", ev.EventID), zap.Error(err))
		}
		metrics.WebhookEvents.WithLabelValues("ignored").Inc()
		return
	}
	if up.UserID == "" || up.Plan == "" {
		// cannot map to a real user/plan; do not fabricate. Leave a clear log and
		// mark processed so we don't loop forever on an unmappable event.
		r.log.Warn("subscription event missing user_id or plan; skipping",
			zap.String("event", ev.EventID), zap.String("sub", up.StripeSubID))
		if err := r.store.MarkProcessed(ctx, ev.EventID); err != nil {
			r.log.Warn("mark processed failed", zap.String("event", ev.EventID), zap.Error(err))
		}
		metrics.WebhookEvents.WithLabelValues("unmappable").Inc()
		return
	}
	if err := r.store.UpsertSubscription(ctx, up.UserID, up.Plan, up.Status, up.StripeSubID, up.CurrentPeriodEnd); err != nil {
		r.log.Warn("apply subscription failed", zap.String("event", ev.EventID), zap.Error(err))
		metrics.DBErrors.Inc()
		return // leave unprocessed for retry next tick
	}
	if err := r.store.MarkProcessed(ctx, ev.EventID); err != nil {
		r.log.Warn("mark processed failed", zap.String("event", ev.EventID), zap.Error(err))
		return
	}
	metrics.SubscriptionsApplied.Inc()
	metrics.WebhookEvents.WithLabelValues("applied").Inc()
}
