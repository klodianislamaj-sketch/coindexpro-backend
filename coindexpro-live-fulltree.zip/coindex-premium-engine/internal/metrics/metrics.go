// Package metrics holds the premium-engine's Prometheus instruments. The symbol
// set matches exactly what the api + consumer reference.
package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	UsageRecorded = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_premium_usage_recorded_total", Help: "Real requests recorded against quotas.",
	})
	QuotaDenied = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_premium_quota_denied_total", Help: "Quota denials by reason.",
	}, []string{"reason"})
	EntitlementChecks = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_premium_entitlement_checks_total", Help: "Entitlement computations served.",
	})
	WebhookEvents = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_premium_webhook_events_total", Help: "Stripe webhook events by outcome.",
	}, []string{"outcome"})
	SubscriptionsApplied = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_premium_subscriptions_applied_total", Help: "Verified subscription state changes applied.",
	})
	APILatency = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name: "coindex_premium_api_seconds", Help: "API latency by route + status.",
		Buckets: prometheus.DefBuckets,
	}, []string{"route", "status"})
	DBErrors = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_premium_db_errors_total", Help: "DB errors.",
	})
)
