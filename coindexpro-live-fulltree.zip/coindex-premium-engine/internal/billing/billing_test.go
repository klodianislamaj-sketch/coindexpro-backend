package billing

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"strconv"
	"testing"
	"time"
)

// sign builds a real Stripe-style signature header for the test payload.
func sign(secret string, ts int64, payload string) string {
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(strconv.FormatInt(ts, 10) + "." + payload))
	return "t=" + strconv.FormatInt(ts, 10) + ",v1=" + hex.EncodeToString(mac.Sum(nil))
}

// A correctly-signed event must verify and parse — exercises the real HMAC path.
func TestVerifyWebhook_ValidSignatureVerifies(t *testing.T) {
	secret := "whsec_test_123"
	c := New("sk_test", secret, nil)
	payload := `{"id":"evt_1","type":"customer.subscription.updated","data":{"object":{}}}`
	ts := time.Now().Unix()
	hdr := sign(secret, ts, payload)

	ev, err := c.VerifyWebhook([]byte(payload), hdr, 5*time.Minute)
	if err != nil {
		t.Fatalf("valid signature must verify, got err=%v", err)
	}
	if ev.EventID != "evt_1" || ev.Type != "customer.subscription.updated" {
		t.Fatalf("parsed event mismatch: %+v", ev)
	}
}

// A tampered signature must be rejected — the core security invariant.
func TestVerifyWebhook_TamperedSignatureRejected(t *testing.T) {
	secret := "whsec_test_123"
	c := New("sk_test", secret, nil)
	payload := `{"id":"evt_1","type":"customer.subscription.updated","data":{"object":{}}}`
	ts := time.Now().Unix()
	hdr := "t=" + strconv.FormatInt(ts, 10) + ",v1=deadbeefdeadbeef" // wrong sig

	_, err := c.VerifyWebhook([]byte(payload), hdr, 5*time.Minute)
	if !errors.Is(err, ErrSignatureInvalid) {
		t.Fatalf("tampered signature must fail with ErrSignatureInvalid, got %v", err)
	}
}

// A payload altered after signing must also fail (signature no longer matches).
func TestVerifyWebhook_AlteredPayloadRejected(t *testing.T) {
	secret := "whsec_test_123"
	c := New("sk_test", secret, nil)
	payload := `{"id":"evt_1","type":"customer.subscription.updated","data":{"object":{}}}`
	ts := time.Now().Unix()
	hdr := sign(secret, ts, payload)

	altered := `{"id":"evt_HACKED","type":"customer.subscription.updated","data":{"object":{}}}`
	if _, err := c.VerifyWebhook([]byte(altered), hdr, 5*time.Minute); err == nil {
		t.Fatal("altered payload must not verify against the original signature")
	}
}

// With no webhook secret configured, verification is not configured (not a pass).
func TestVerifyWebhook_NotConfiguredWithoutSecret(t *testing.T) {
	c := New("sk_test", "", nil)
	_, err := c.VerifyWebhook([]byte("{}"), "t=1,v1=abc", time.Minute)
	if !errors.Is(err, ErrNotConfigured) {
		t.Fatalf("no webhook secret must be ErrNotConfigured, got %v", err)
	}
}

// Checkout without a Stripe key returns ErrNotConfigured — never a fake URL.
func TestCreateCheckout_NotConfiguredWithoutKey(t *testing.T) {
	c := New("", "", map[string]string{"premium": "price_x"})
	url, err := c.CreateCheckoutSession("u1", "premium")
	if !errors.Is(err, ErrNotConfigured) {
		t.Fatalf("no secret key must be ErrNotConfigured, got %v", err)
	}
	if url != "" {
		t.Fatalf("must not return a fabricated URL, got %q", url)
	}
}
