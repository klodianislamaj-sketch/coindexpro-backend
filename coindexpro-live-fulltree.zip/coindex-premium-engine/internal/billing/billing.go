// Package billing is a thin Stripe wrapper. It is deliberately honest about the
// boundary between logic we can run and actions that require a live Stripe account:
// when no Stripe secret key is configured, billing actions (checkout, portal,
// live sync) return ErrNotConfigured so the API can report {available:false,
// reason:"not configured"} — they never return a fabricated URL or a made-up
// subscription. Webhook signature verification is real (HMAC-SHA256 over the
// signed payload), and a subscription state change is only ever derived from a
// verified event, never invented.
package billing

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/coindexpro/coindex-premium-engine/internal/models"
)

// ErrNotConfigured is returned by any action that needs a real Stripe key when
// none is configured. The API maps this to the not-configured envelope.
var ErrNotConfigured = errors.New("stripe not configured")

// ErrSignatureInvalid is returned when a webhook signature does not verify.
var ErrSignatureInvalid = errors.New("stripe webhook signature invalid")

// Client wraps the Stripe configuration. A zero/empty SecretKey means billing
// actions are unavailable (not configured) rather than faked.
type Client struct {
	secretKey     string
	webhookSecret string
	priceIDs      map[string]string // plan -> Stripe price id (for checkout)
	now           func() time.Time
}

// New builds a billing client. Empty secretKey is allowed and simply means
// Configured() is false.
func New(secretKey, webhookSecret string, priceIDs map[string]string) *Client {
	return &Client{
		secretKey:     secretKey,
		webhookSecret: webhookSecret,
		priceIDs:      priceIDs,
		now:           time.Now,
	}
}

// Configured reports whether a real Stripe secret key is present.
func (c *Client) Configured() bool { return strings.TrimSpace(c.secretKey) != "" }

// WebhookConfigured reports whether webhook signature verification is possible.
func (c *Client) WebhookConfigured() bool { return strings.TrimSpace(c.webhookSecret) != "" }

// CreateCheckoutSession returns a Stripe Checkout URL for a plan. Without a real
// key (or a known price id for the plan) it returns ErrNotConfigured — never a
// placeholder URL.
func (c *Client) CreateCheckoutSession(userID, plan string) (string, error) {
	if !c.Configured() {
		return "", ErrNotConfigured
	}
	if _, ok := c.priceIDs[plan]; !ok {
		return "", fmt.Errorf("%w: no price configured for plan %q", ErrNotConfigured, plan)
	}
	// A real implementation calls the Stripe API here with c.secretKey and returns
	// the session URL. We do not synthesize a URL when that call cannot be made.
	return "", fmt.Errorf("%w: live Stripe checkout call not executed in this environment", ErrNotConfigured)
}

// CreatePortalSession returns a Stripe billing-portal URL. Same honesty rule.
func (c *Client) CreatePortalSession(userID string) (string, error) {
	if !c.Configured() {
		return "", ErrNotConfigured
	}
	return "", fmt.Errorf("%w: live Stripe portal call not executed in this environment", ErrNotConfigured)
}

// VerifyWebhook verifies a Stripe webhook signature header against the raw payload
// using the configured webhook secret (HMAC-SHA256, as Stripe does). It returns
// the parsed event only when the signature is valid and recent. Without a webhook
// secret it returns ErrNotConfigured (we never accept an unverified event).
func (c *Client) VerifyWebhook(payload []byte, sigHeader string, tolerance time.Duration) (models.StripeEvent, error) {
	if !c.WebhookConfigured() {
		return models.StripeEvent{}, ErrNotConfigured
	}
	ts, sigs, err := parseSigHeader(sigHeader)
	if err != nil {
		return models.StripeEvent{}, err
	}
	if tolerance > 0 {
		eventTime := time.Unix(ts, 0)
		if c.now().Sub(eventTime) > tolerance {
			return models.StripeEvent{}, fmt.Errorf("%w: timestamp outside tolerance", ErrSignatureInvalid)
		}
	}
	signedPayload := strconv.FormatInt(ts, 10) + "." + string(payload)
	expected := hmacSHA256(c.webhookSecret, signedPayload)
	ok := false
	for _, s := range sigs {
		if hmac.Equal([]byte(s), []byte(expected)) {
			ok = true
			break
		}
	}
	if !ok {
		return models.StripeEvent{}, ErrSignatureInvalid
	}

	var raw struct {
		ID   string         `json:"id"`
		Type string         `json:"type"`
		Data map[string]any `json:"data"`
	}
	if err := json.Unmarshal(payload, &raw); err != nil {
		return models.StripeEvent{}, fmt.Errorf("decode event: %w", err)
	}
	if raw.ID == "" || raw.Type == "" {
		return models.StripeEvent{}, errors.New("event missing id or type")
	}
	return models.StripeEvent{EventID: raw.ID, Type: raw.Type, Payload: raw.Data}, nil
}

// SubscriptionUpdate is the real subscription state extracted from a verified
// customer.subscription.* event. ok=false means the event is not a subscription
// lifecycle event we apply.
type SubscriptionUpdate struct {
	UserID           string
	StripeSubID      string
	Status           string
	Plan             string
	CurrentPeriodEnd *time.Time
}

// ParseSubscriptionEvent extracts subscription state from a verified event. It
// only returns ok=true for customer.subscription.{created,updated,deleted}. The
// values come straight from the real event payload; nothing is defaulted.
func ParseSubscriptionEvent(ev models.StripeEvent) (SubscriptionUpdate, bool) {
	switch ev.Type {
	case "customer.subscription.created",
		"customer.subscription.updated",
		"customer.subscription.deleted":
	default:
		return SubscriptionUpdate{}, false
	}

	obj, _ := ev.Payload["object"].(map[string]any)
	if obj == nil {
		return SubscriptionUpdate{}, false
	}
	var up SubscriptionUpdate
	up.StripeSubID, _ = obj["id"].(string)
	up.Status, _ = obj["status"].(string)
	// canceled events may arrive as type deleted with status active; honor type.
	if ev.Type == "customer.subscription.deleted" {
		up.Status = "canceled"
	}
	// plan: derive from items[].price.metadata.plan or top-level metadata.plan.
	up.Plan = extractPlan(obj)
	// user mapping: metadata.user_id (set when the checkout session was created).
	if md, ok := obj["metadata"].(map[string]any); ok {
		up.UserID, _ = md["user_id"].(string)
	}
	if up.UserID == "" {
		up.UserID = ev.UserID
	}
	// current_period_end is a unix timestamp (real).
	if cpe, ok := toUnix(obj["current_period_end"]); ok {
		t := time.Unix(cpe, 0).UTC()
		up.CurrentPeriodEnd = &t
	}
	if up.StripeSubID == "" || up.Status == "" {
		return SubscriptionUpdate{}, false
	}
	return up, true
}

func extractPlan(obj map[string]any) string {
	if md, ok := obj["metadata"].(map[string]any); ok {
		if p, ok := md["plan"].(string); ok && p != "" {
			return p
		}
	}
	// items.data[0].price.metadata.plan
	if items, ok := obj["items"].(map[string]any); ok {
		if data, ok := items["data"].([]any); ok && len(data) > 0 {
			if first, ok := data[0].(map[string]any); ok {
				if price, ok := first["price"].(map[string]any); ok {
					if md, ok := price["metadata"].(map[string]any); ok {
						if p, ok := md["plan"].(string); ok {
							return p
						}
					}
				}
			}
		}
	}
	return ""
}

// parseSigHeader parses Stripe's "t=...,v1=...,v1=..." signature header.
func parseSigHeader(h string) (ts int64, sigs []string, err error) {
	if strings.TrimSpace(h) == "" {
		return 0, nil, fmt.Errorf("%w: empty signature header", ErrSignatureInvalid)
	}
	for _, part := range strings.Split(h, ",") {
		kv := strings.SplitN(strings.TrimSpace(part), "=", 2)
		if len(kv) != 2 {
			continue
		}
		switch kv[0] {
		case "t":
			ts, err = strconv.ParseInt(kv[1], 10, 64)
			if err != nil {
				return 0, nil, fmt.Errorf("%w: bad timestamp", ErrSignatureInvalid)
			}
		case "v1":
			sigs = append(sigs, kv[1])
		}
	}
	if ts == 0 || len(sigs) == 0 {
		return 0, nil, fmt.Errorf("%w: missing t or v1", ErrSignatureInvalid)
	}
	return ts, sigs, nil
}

func hmacSHA256(secret, payload string) string {
	m := hmac.New(sha256.New, []byte(secret))
	m.Write([]byte(payload))
	return hex.EncodeToString(m.Sum(nil))
}

func toUnix(v any) (int64, bool) {
	switch n := v.(type) {
	case float64:
		return int64(n), true
	case int64:
		return n, true
	case json.Number:
		i, err := n.Int64()
		return i, err == nil
	}
	return 0, false
}
