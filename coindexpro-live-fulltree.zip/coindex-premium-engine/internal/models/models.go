// Package models holds the premium-engine's shared domain types. The honesty
// contract is structural: an Entitlement is computed only from a user's REAL tier
// (user_accounts) and REAL subscription status (premium_subscriptions); a
// QuotaStatus reports REAL configured limits (api_keys) against REAL recorded
// usage (api_usage). Subscription fields are pointers that stay nil when there is
// no real subscription, so a missing/unconfigured billing state is never filled
// with a fabricated "active" plan.
package models

import "time"

// Tiers (aligned with Phase 2 user_accounts.tier and the Phase 3 gateway).
const (
	TierFree       = "free"
	TierPremium    = "premium"
	TierEnterprise = "enterprise"
)

// Features are capability flags gated by tier. They are derived from a static,
// transparent tier->feature matrix (FeatureMatrix), not from guesswork.
const (
	FeatureRealtimeAlerts   = "realtime_alerts"
	FeatureAdvancedStrategy = "advanced_strategy"
	FeatureExecutionIntel   = "execution_intel"
	FeaturePortfolioSync    = "portfolio_sync"
	FeatureSocialFirehose   = "social_firehose"
	FeatureDataExport       = "data_export"
	FeaturePrioritySupport  = "priority_support"
)

// Subscription is the REAL billing state (from premium_subscriptions). All fields
// reflect a real Stripe-synced row; absence => the user has no subscription.
type Subscription struct {
	Plan             string     `json:"plan"`
	Status           string     `json:"status"`            // active|trialing|past_due|canceled|incomplete
	StripeSubID      string     `json:"stripe_sub_id,omitempty"`
	CurrentPeriodEnd *time.Time `json:"current_period_end,omitempty"`
}

// Entitlement is what a user is actually entitled to, computed from real data.
type Entitlement struct {
	UserID       string        `json:"user_id"`
	Tier         string        `json:"tier"`               // effective tier
	BaseTier     string        `json:"base_tier"`          // user_accounts.tier
	Features     []string      `json:"features"`           // unlocked features for the effective tier
	Subscription *Subscription `json:"subscription,omitempty"` // nil when none exists
	// SubscriptionActive is true only when a real subscription is in an active
	// state AND not past its period end; false otherwise (including no subscription).
	SubscriptionActive bool   `json:"subscription_active"`
	Reason             string `json:"reason,omitempty"` // explains a downgrade/absence
}

// QuotaStatus is a key's REAL configured limits vs REAL recorded usage.
type QuotaStatus struct {
	Revoked      bool   `json:"revoked"`
	PerMinLimit  int    `json:"per_min_limit"`
	PerDayLimit  int    `json:"per_day_limit"`
	PerMinUsed   int64  `json:"per_min_used"`
	PerDayUsed   int64  `json:"per_day_used"`
	PerMinRemain int64  `json:"per_min_remaining"`
	PerDayRemain int64  `json:"per_day_remaining"`
	Allowed      bool   `json:"allowed"` // false if revoked or either window exhausted
	Reason       string `json:"reason,omitempty"`
}

// FeatureCheck is the result of asking "can this user use feature X".
type FeatureCheck struct {
	UserID  string `json:"user_id"`
	Feature string `json:"feature"`
	Allowed bool   `json:"allowed"`
	Tier    string `json:"tier"`
	Reason  string `json:"reason,omitempty"`
}

// StripeEvent is a verified webhook event recorded for idempotent processing.
type StripeEvent struct {
	EventID string         `json:"event_id"`
	Type    string         `json:"type"`
	UserID  string         `json:"user_id,omitempty"`
	Payload map[string]any `json:"payload"`
}

// UserTier bundles the real identity bits needed to compute an entitlement.
type UserTier struct {
	UserID string
	Tier   string
}
