// Command premium-engine is the Phase 16 entrypoint. It serves the entitlement /
// quota / billing-sync layer: entitlements computed from real tier + real
// subscription, quota from real limits + real recorded usage, and Stripe-gated
// actions that report "not configured" when no Stripe key is present rather than
// being faked. Verified webhook events are recorded idempotently and applied to
// subscription state by the reconciler.
package main

import (
	"context"
	"errors"
	"flag"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/compress"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"github.com/redis/go-redis/v9"
	"go.uber.org/zap"

	"github.com/coindexpro/coindex-premium-engine/config"
	"github.com/coindexpro/coindex-premium-engine/internal/api"
	"github.com/coindexpro/coindex-premium-engine/internal/billing"
	"github.com/coindexpro/coindex-premium-engine/internal/cache"
	"github.com/coindexpro/coindex-premium-engine/internal/consumer"
	"github.com/coindexpro/coindex-premium-engine/internal/db"
)

func main() {
	cfgPath := flag.String("config", "config/config.yaml", "config path")
	flag.Parse()

	cfg, err := config.Load(*cfgPath)
	if err != nil {
		panic(err)
	}
	log, _ := zap.NewProduction()
	defer func() { _ = log.Sync() }()

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	store, err := db.Open(ctx, cfg.Postgres.DSN)
	if err != nil {
		log.Fatal("db open failed", zap.Error(err))
	}
	defer store.Close()

	c := cache.New(cfg.Redis.Addr, cfg.Redis.CacheTTL)
	if err := c.Ping(ctx); err != nil {
		log.Fatal("redis ping failed", zap.Error(err))
	}
	defer func() { _ = c.Close() }()
	rdb := redis.NewClient(&redis.Options{Addr: cfg.Redis.Addr})
	defer func() { _ = rdb.Close() }()

	// Fail-fast: the Stripe secrets are required for this service to operate
	// securely. Validate at startup (before any server starts) rather than relying
	// only on the runtime ErrNotConfigured guard. Missing values are reported BY
	// NAME ONLY — the values themselves are never logged.
	var missingSecrets []string
	if strings.TrimSpace(cfg.Stripe.SecretKey) == "" {
		missingSecrets = append(missingSecrets, "STRIPE_SECRET_KEY")
	}
	if strings.TrimSpace(cfg.Stripe.WebhookSecret) == "" {
		missingSecrets = append(missingSecrets, "STRIPE_WEBHOOK_SECRET")
	}
	if len(missingSecrets) > 0 {
		log.Fatal("missing required secrets at startup",
			zap.Strings("missing", missingSecrets))
	}

	bill := billing.New(cfg.Stripe.SecretKey, cfg.Stripe.WebhookSecret, cfg.Stripe.PriceIDs)
	log.Info("starting premium-engine",
		zap.Bool("stripe_configured", bill.Configured()),
		zap.Bool("webhook_configured", bill.WebhookConfigured()))

	if cfg.Reconcile.Enabled {
		rec := consumer.NewReconciler(store, cfg.Reconcile.Interval, cfg.Reconcile.Batch, log)
		go func() {
			if err := rec.Run(ctx); err != nil && !errors.Is(err, context.Canceled) {
				log.Error("reconciler stopped", zap.Error(err))
			}
		}()
	}

	app := fiber.New(fiber.Config{AppName: "coindex-premium-engine"})
	app.Use(compress.New())
	api.New(store, bill, cfg.Stripe.WebhookTolerance).Register(app)
	go func() {
		log.Info("api listening", zap.String("addr", cfg.Server.APIAddr))
		if err := app.Listen(cfg.Server.APIAddr); err != nil {
			log.Error("api stopped", zap.Error(err))
		}
	}()

	go serveOps(cfg.Server.MetricsAddr, store, rdb, log)

	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
	<-sig
	log.Info("shutting down")
	cancel()
	sc, scCancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer scCancel()
	_ = app.ShutdownWithContext(sc)
}

func serveOps(addr string, store *db.Store, rdb *redis.Client, log *zap.Logger) {
	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ok"))
	})
	mux.HandleFunc("/readyz", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), 3*time.Second)
		defer cancel()
		if err := store.Ping(ctx); err != nil {
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte("db down"))
			return
		}
		if err := rdb.Ping(ctx).Err(); err != nil {
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte("redis down"))
			return
		}
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ready"))
	})
	mux.Handle("/metrics", promhttp.Handler())
	srv := &http.Server{Addr: addr, Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Error("ops server failed", zap.Error(err))
	}
}
