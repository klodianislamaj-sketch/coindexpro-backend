#!/usr/bin/env bash
# check-postgres.sh — required Postgres schema objects exist (real tables from
# coindex-db/migrations/postgres + graph schema). Runs psql inside an ephemeral pod
# against the in-cluster postgres Service.
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"; source "$DIR/lib-verify.sh"
require_cluster
fail=0

# real public tables (Phase 2 core)
REQUIRED_TABLES=(token_registry token_clones wallet_labels wallet_label_history
  user_accounts api_keys premium_subscriptions alerts alert_fires watchlists)
# real graph-schema tables (Phase 2 graph)
REQUIRED_GRAPH=(graph.wallet_nodes graph.token_nodes graph.clusters
  graph.wallet_edges graph.wallet_token_edges)

psql_q() { # psql_q <sql> -> prints result
  kubectl run pg-$RANDOM -n "$NS" --rm -i --restart=Never --image=postgres:16-alpine \
    --env PGPASSWORD="$(kubectl -n "$NS" get secret coindex-secrets -o jsonpath='{.data.CLICKHOUSE_PASSWORD}' | base64 -d)" \
    --command -- psql -tAq -h postgres.coindex.svc.cluster.local -U coindex -d coindex -c "$1" 2>/dev/null | tail -1
}

log "== required tables (public) =="
for t in "${REQUIRED_TABLES[@]}"; do
  r=$(psql_q "SELECT to_regclass('public.$t') IS NOT NULL;")
  [ "$r" = "t" ] && ok "table public.$t exists" || { bad "table public.$t MISSING"; fail=1; }
done

log "== required tables (graph schema) =="
for t in "${REQUIRED_GRAPH[@]}"; do
  r=$(psql_q "SELECT to_regclass('$t') IS NOT NULL;")
  [ "$r" = "t" ] && ok "table $t exists" || { bad "table $t MISSING"; fail=1; }
done

log "== indexes present (spot-check unique constraints from real schema) =="
r=$(psql_q "SELECT count(*) FROM pg_indexes WHERE schemaname='public';")
[ "${r:-0}" -gt 0 ] && ok "public schema has $r index(es)" || { bad "no indexes in public schema"; fail=1; }

# NOTE: row-count expectations are reported, NOT asserted green — an empty table on
# a fresh deploy is a real, honest state (unavailable upstream), not a failure.
log "== row-count observability (reported, not asserted) =="
for t in token_registry user_accounts; do
  c=$(psql_q "SELECT count(*) FROM $t;")
  log "  $t row count: ${c:-?}"
done

exit $([ $fail -eq 0 ] && echo $EXIT_PASS || echo $EXIT_FAIL)
