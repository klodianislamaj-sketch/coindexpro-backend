#!/usr/bin/env bash
# restore-clickhouse.sh — RESTORE the coindex DB from an S3 backup, then verify
# expected tables exist and (optionally) row counts match a manifest. Fails on mismatch.
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"; source "$DIR/lib-backup.sh"
require_env CHHOST CHUSER CHPASSWORD CHDATABASE BACKUP_S3_BUCKET
require_cmd clickhouse-client
NAME="${1:?usage: restore-clickhouse.sh <backup-name.zip>}"

ch_q() { clickhouse-client --host "$CHHOST" --user "$CHUSER" --password "$CHPASSWORD" -q "$1"; }

log "RESTORE DATABASE $CHDATABASE FROM S3 $NAME"
SQL="RESTORE DATABASE \`$CHDATABASE\` FROM S3('${BACKUP_S3_ENDPOINT:-https://s3.amazonaws.com}/$BACKUP_S3_BUCKET/clickhouse/$NAME')"
ch_q "$SQL" || { bad "ClickHouse RESTORE failed"; exit "$EXIT_FAIL"; }

# verify expected tables present (real schema objects)
REQUIRED=(swaps lp_events transfers token_mints wallet_trades wallet_positions token_metrics smart_money_events)
for t in "${REQUIRED[@]}"; do
  r="$(ch_q "EXISTS TABLE $CHDATABASE.$t")"
  [ "$r" = "1" ] || { bad "table $CHDATABASE.$t missing after restore"; exit "$EXIT_FAIL"; }
done
ok "clickhouse schema verified (${#REQUIRED[@]} tables)"

# row-count diff vs manifest if provided
if [ -n "${MANIFEST:-}" ] && [ -f "$MANIFEST" ]; then
  while IFS=$'\t' read -r tbl want; do
    [ -z "$tbl" ] && continue
    got="$(ch_q "SELECT count() FROM $CHDATABASE.$tbl")"
    [ "$got" = "$want" ] || { bad "row-count mismatch $tbl: want $want got $got"; exit "$EXIT_FAIL"; }
  done < "$MANIFEST"
  ok "row-count diff matched manifest"
fi
ok "clickhouse restore VERIFIED"
