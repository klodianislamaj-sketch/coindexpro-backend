#!/usr/bin/env bash
# verify-migration-order.sh — naming / order / version consistency for every REAL
# migration file. Complements verify-migrations.sh (which checks SQL validity).
#
# Per migration DIRECTORY (e.g. coindex-db/migrations/postgres):
#   * each file must be named NNN_name.sql (3+ digit zero-padded version prefix)
#   * version numbers must be unique within the directory (no duplicate NNN)
#   * version numbers must start at 001 and be contiguous (no gaps)
#
# Fails (exit 1) on any malformed name, duplicate version, or gap.
set -uo pipefail

ROOT="${1:-.}"
fail=0

# collect unique migration directories
mapfile -t dirs < <(find "$ROOT" -type d -path '*/migrations/*' | sort -u)
# also include direct */migrations children that hold .sql
mapfile -t more < <(find "$ROOT" -type f -path '*/migrations/*.sql' -printf '%h\n' | sort -u)
dirs=("${dirs[@]}" "${more[@]}")
# dedupe
mapfile -t dirs < <(printf '%s\n' "${dirs[@]}" | sort -u)

checked_dirs=0
for dir in "${dirs[@]}"; do
  mapfile -t files < <(find "$dir" -maxdepth 1 -type f -name '*.sql' | sort)
  [ "${#files[@]}" -eq 0 ] && continue
  checked_dirs=$((checked_dirs + 1))
  rel="${dir#"$ROOT"/}"
  echo "== $rel =="

  versions=()
  for f in "${files[@]}"; do
    base=$(basename "$f")
    if [[ ! "$base" =~ ^[0-9]{3,}_[A-Za-z0-9._-]+\.sql$ ]]; then
      echo "  FAIL  $base : does not match NNN_name.sql"; fail=1; continue
    fi
    ver="${base%%_*}"
    versions+=("$ver")
    echo "  OK    $base (version $ver)"
  done

  # duplicate detection
  dups=$(printf '%s\n' "${versions[@]}" | sort | uniq -d)
  if [ -n "$dups" ]; then
    echo "  FAIL  duplicate version(s): $(echo "$dups" | tr '\n' ' ')"; fail=1
  fi

  # contiguity from 001
  mapfile -t sorted < <(printf '%s\n' "${versions[@]}" | sort -u)
  expected=1
  for v in "${sorted[@]}"; do
    n=$((10#$v))
    if [ "$n" -ne "$expected" ]; then
      echo "  FAIL  version gap: expected $(printf '%03d' "$expected"), found $v"; fail=1
    fi
    expected=$((expected + 1))
  done
done

echo "----"
echo "Checked $checked_dirs migration director(ies)."
if [ "$fail" -ne 0 ]; then
  echo "Migration order/version verification FAILED." >&2
  exit 1
fi
echo "Migration order/version verification PASSED."
