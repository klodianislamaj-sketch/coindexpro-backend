#!/usr/bin/env bash
# restore-timescale.sh — schema-first restore, then RE-ATTACH hypertables and verify
# they are hypertables again (not plain tables). Fails on mismatch.
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"; source "$DIR/lib-backup.sh"
require_env TSHOST TSUSER TSPASSWORD TSDATABASE
require_cmd pg_restore psql
DUMP="${1:?usage: restore-timescale.sh <dump-file>}"
[ -f "$DUMP" ] || { bad "dump not found: $DUMP"; exit "$EXIT_FAIL"; }
[ -f "$DUMP.sha256" ] && { verify_checksum "$DUMP" || { bad "checksum mismatch"; exit "$EXIT_FAIL"; }; ok "artifact checksum verified"; }

ts_q() { PGPASSWORD="$TSPASSWORD" psql -tAq -h "$TSHOST" -U "$TSUSER" -d "$TSDATABASE" -c "$1"; }

log "ensuring timescaledb extension"
ts_q "CREATE EXTENSION IF NOT EXISTS timescaledb;" >/dev/null

log "restoring SCHEMA first"
PGPASSWORD="$TSPASSWORD" pg_restore --schema-only --no-owner -h "$TSHOST" -U "$TSUSER" -d "$TSDATABASE" "$DUMP" \
  || { bad "schema restore failed"; exit "$EXIT_FAIL"; }

# re-attach hypertables (idempotent; migrate_data moves any rows restored as plain)
HYPERTABLES=(liquidity_history trust_history whale_history sector_history)
log "restoring DATA"
PGPASSWORD="$TSPASSWORD" pg_restore --data-only --no-owner --disable-triggers -h "$TSHOST" -U "$TSUSER" -d "$TSDATABASE" "$DUMP" \
  || { bad "data restore failed"; exit "$EXIT_FAIL"; }

for h in "${HYPERTABLES[@]}"; do
  # verify it is a hypertable
  r="$(ts_q "SELECT count(*) FROM timescaledb_information.hypertables WHERE hypertable_name='$h';")"
  [ "${r:-0}" -ge 1 ] || { bad "$h is not a hypertable after restore"; exit "$EXIT_FAIL"; }
done
ok "timescale restore VERIFIED (${#HYPERTABLES[@]} hypertables re-attached)"
