#!/usr/bin/env bash
# lib-backup.sh — shared helpers for CoinDex backup/restore scripts.
# Fail-fast on missing creds (by NAME only), checksum every artifact, upload to an
# S3-compatible destination from env, and prune by retention age. No secret value is
# ever printed. Nothing here fabricates a successful backup: every step's real exit
# code propagates.

set -uo pipefail
export EXIT_OK=0 EXIT_FAIL=1 EXIT_UNAVAILABLE=3

log()  { printf '%s\n' "$*"; }
ok()   { printf '  PASS  %s\n' "$*"; }
bad()  { printf '  FAIL  %s\n' "$*"; }
unav() { printf '  UNAVAILABLE  %s\n' "$*"; }

# require_env NAME... — fail-fast if any env var is empty. Lists missing BY NAME.
require_env() {
  local missing=()
  for n in "$@"; do
    [ -n "${!n:-}" ] || missing+=("$n")
  done
  if [ "${#missing[@]}" -gt 0 ]; then
    bad "missing required env (not set): ${missing[*]}"
    exit "$EXIT_FAIL"
  fi
}

# require_cmd CMD... — UNAVAILABLE if a needed CLI is absent.
require_cmd() {
  for c in "$@"; do
    command -v "$c" >/dev/null 2>&1 || { unav "$c not installed"; exit "$EXIT_UNAVAILABLE"; }
  done
}

# checksum FILE -> writes FILE.sha256, prints the digest
checksum() {
  local f="$1"
  sha256sum "$f" | awk '{print $1}' > "$f.sha256"
  cat "$f.sha256"
}

# verify_checksum FILE -> 0 if FILE matches FILE.sha256
verify_checksum() {
  local f="$1"
  [ -f "$f.sha256" ] || { bad "no checksum sidecar for $f"; return 1; }
  echo "$(cat "$f.sha256")  $f" | sha256sum -c - >/dev/null 2>&1
}

# s3_put LOCAL REMOTE_KEY — upload to the S3-compatible destination.
# Requires BACKUP_S3_BUCKET; honors optional BACKUP_S3_ENDPOINT (MinIO/R2/etc).
s3_put() {
  local local_f="$1" key="$2"
  require_cmd aws
  local endpoint_args=()
  [ -n "${BACKUP_S3_ENDPOINT:-}" ] && endpoint_args=(--endpoint-url "$BACKUP_S3_ENDPOINT")
  aws "${endpoint_args[@]}" s3 cp "$local_f" "s3://$BACKUP_S3_BUCKET/$key" --only-show-errors
}

# prune_local DIR GLOB DAYS — delete local artifacts older than DAYS (retention).
prune_local() {
  local dir="$1" glob="$2" days="$3"
  find "$dir" -name "$glob" -type f -mtime "+$days" -print -delete 2>/dev/null || true
}

# stamp — UTC timestamp for artifact names
stamp() { date -u +%Y%m%dT%H%M%SZ; }

# in-cluster run helper (when executed from a CronJob the clients are local;
# when run by an operator, exec into the target pod). Scripts pick the path.
