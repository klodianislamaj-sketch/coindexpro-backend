#!/usr/bin/env bash
# list-services.sh — single source of truth for which services exist.
#
# A "Go service" is any coindex-* directory containing a go.mod (independently
# buildable module). A "migration-only" module has migrations but no go.mod
# (currently just coindex-db). Lists are derived from the real repo layout, so
# adding a service requires no edits here.
#
# Modes:
#   --go              newline list of Go service dirs
#   --migrations-only newline list of migration-only dirs
#   --json            JSON array of Go service dirs (for GH Actions matrix)
set -euo pipefail

ROOT="${ROOT:-.}"
mode="${1:---go}"

go_services() {
  for d in "$ROOT"/coindex-*/; do
    [ -f "${d}go.mod" ] && basename "$d"
  done | sort
}

migration_only() {
  for d in "$ROOT"/coindex-*/; do
    [ -d "${d}migrations" ] && [ ! -f "${d}go.mod" ] && basename "$d"
  done | sort
}

case "$mode" in
  --go)               go_services ;;
  --migrations-only)  migration_only ;;
  --json)
    printf '['
    first=1
    while IFS= read -r s; do
      [ -z "$s" ] && continue
      [ $first -eq 1 ] && first=0 || printf ','
      printf '"%s"' "$s"
    done < <(go_services)
    printf ']\n'
    ;;
  *)
    echo "usage: $0 [--go|--migrations-only|--json]" >&2
    exit 2
    ;;
esac
