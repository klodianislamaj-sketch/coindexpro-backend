#!/usr/bin/env bash
# report-test-coverage.sh — canonical, HONEST coverage reporter.
#
# For every Go service it runs `go test ./... -coverprofile=coverage.out` and
# inspects the real output for Go's "[no test files]" marker. It writes a machine
# inventory to ci/test-inventory.json with explicit services_with_tests /
# services_without_tests arrays, and reports behavioral coverage truthfully — it
# never fabricates a passing/covered result for a service that has no tests.
#
# Exit behavior:
#   * a real test FAILURE in an existing test  -> exit 1
#   * services with NO tests                   -> reported, run does not fail
#     (absence is the truth to surface, not a reason to fake green)
set -uo pipefail

ROOT="${ROOT:-.}"
OUT_DIR="$ROOT/ci"
OUT_JSON="$OUT_DIR/test-inventory.json"
mkdir -p "$OUT_DIR"

mapfile -t services < <("$ROOT/scripts/list-services.sh" --go)

with=()        # services that contain >=1 *_test.go AND whose tests ran
without=()     # services with zero *_test.go
failed=()      # services whose existing tests failed
fail=0

echo "== Coverage report =="
for s in "${services[@]}"; do
  dir="$ROOT/$s"
  ntest=$(find "$dir" -name '*_test.go' 2>/dev/null | wc -l | tr -d ' ')

  if [ "$ntest" -eq 0 ]; then
    echo "NO TESTS    $s"
    without+=("$s")
    continue
  fi

  echo "RUN         $s (go test ./... -coverprofile=coverage.out)"
  if out=$( cd "$dir" && go test ./... -coverprofile=coverage.out 2>&1 ); then
    # even with a coverprofile, a module can still print "[no test files]" for
    # packages without tests; only count as "with tests" because *_test.go exist.
    with+=("$s")
    if grep -q "\[no test files\]" <<<"$out"; then
      echo "  note: some packages report [no test files]"
    fi
  else
    echo "$out" | sed 's/^/    /'
    echo "FAIL        $s : existing tests failed"
    failed+=("$s")
    fail=1
  fi
done

# --- emit ci/test-inventory.json (explicit, machine-readable, honest) --------
json_arr() { # prints a JSON array from args
  local first=1; printf '['
  for x in "$@"; do [ $first -eq 1 ] && first=0 || printf ','; printf '"%s"' "$x"; done
  printf ']'
}

total=${#services[@]}
nwith=${#with[@]}
nwithout=${#without[@]}
# behavioral coverage: with zero test files across the fleet this is honestly 0.
beh=0
if [ "$total" -gt 0 ] && [ "$nwith" -gt 0 ]; then
  # we still do not claim a percentage from line coverage here; behavioral
  # coverage is reported as the share of services that actually exercise code.
  beh=$(awk "BEGIN{printf \"%.1f\", ($nwith/$total)*100}")
fi

{
  printf '{\n'
  printf '  "generated_by": "scripts/report-test-coverage.sh",\n'
  printf '  "services_total": %d,\n' "$total"
  printf '  "services_with_tests": %s,\n' "$(json_arr "${with[@]:-}")"
  printf '  "services_without_tests": %s,\n' "$(json_arr "${without[@]:-}")"
  printf '  "services_failed": %s,\n' "$(json_arr "${failed[@]:-}")"
  printf '  "counts": { "with_tests": %d, "without_tests": %d, "failed": %d },\n' "$nwith" "$nwithout" "${#failed[@]}"
  printf '  "behavioral_coverage_percent": %s,\n' "$beh"
  printf '  "note": "go test passes structurally but provides zero behavioral validation until test files are added"\n'
  printf '}\n'
} > "$OUT_JSON"

echo "----"
echo "Total: $total | with tests: $nwith | without tests: $nwithout | failed: ${#failed[@]}"
echo "Behavioral coverage: ${beh}% (share of services that execute any test)"
echo "Wrote $OUT_JSON"

if [ "$fail" -ne 0 ]; then
  echo "Coverage report FAILED (existing tests failed)." >&2
  exit 1
fi
echo "go test passes structurally but provides zero behavioral validation until test files are added."
