#!/usr/bin/env bash
# backup-redis.sh — Redis is a CACHE (allkeys-lru). We do NOT treat it as a durable
# backup; we VERIFY RDB persistence health so recovery-by-rewarm is viable. Honest:
# this reports RDB health, it is not a data-of-record backup.
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"; source "$DIR/lib-backup.sh"
require_env REDISHOST
require_cmd redis-cli

log "checking Redis persistence health on $REDISHOST"
# trigger a background save and confirm it succeeds
LASTSAVE_BEFORE="$(redis-cli -h "$REDISHOST" LASTSAVE 2>/dev/null)" || { bad "redis unreachable"; exit "$EXIT_FAIL"; }
redis-cli -h "$REDISHOST" BGSAVE >/dev/null 2>&1 || { bad "BGSAVE rejected"; exit "$EXIT_FAIL"; }
sleep 3
LASTSAVE_AFTER="$(redis-cli -h "$REDISHOST" LASTSAVE 2>/dev/null)"
PERSIST_ERR="$(redis-cli -h "$REDISHOST" INFO persistence 2>/dev/null | grep -E 'rdb_last_bgsave_status|aof_last_write_status')"
log "  $PERSIST_ERR"
if echo "$PERSIST_ERR" | grep -q 'status:ok'; then
  ok "redis RDB persistence healthy (lastsave $LASTSAVE_BEFORE -> $LASTSAVE_AFTER)"
  log "  NOTE: Redis is a cache; source of truth is Postgres/ClickHouse. No data-of-record restore."
else
  bad "redis RDB persistence NOT healthy"; exit "$EXIT_FAIL"
fi
