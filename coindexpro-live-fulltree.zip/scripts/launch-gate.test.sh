#!/usr/bin/env bash
# launch-gate.test.sh — behavioral test for scripts/launch-gate.sh exit mapping.
# It crafts real artifacts/phase21-report.json contents and asserts the real exit
# codes: GO->0, UNAVAILABLE->78 (staged), FAIL/missing->1 (halt). It sets
# LAUNCH_GATE_REUSE_REPORT=true so the gate reads the crafted report instead of
# running the full cluster harness.
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
GATE="$ROOT/scripts/launch-gate.sh"
ART="$ROOT/artifacts"; REPORT="$ART/phase21-report.json"
mkdir -p "$ART"
pass=0; fail=0
saved=""
[ -f "$REPORT" ] && saved="$(cat "$REPORT")"   # preserve any existing report

restore() { [ -n "$saved" ] && printf '%s' "$saved" > "$REPORT" || rm -f "$REPORT"; }
trap restore EXIT

run_case() { # run_case <name> <expected_exit>
  LAUNCH_GATE_REUSE_REPORT=true "$GATE" >/dev/null 2>&1
  local got=$?
  if [ "$got" -eq "$2" ]; then echo "  PASS  $1 (exit $got)"; pass=$((pass+1))
  else echo "  FAIL  $1 (want $2, got $got)"; fail=$((fail+1)); fi
}

echo "== launch-gate exit-code mapping =="

# 1. missing report -> gate regenerates via harness. In an env with no cluster the
#    harness writes an env-unavailable report, so the honest result is 78 (staged),
#    NOT a fabricated pass. (A missing report is never silently a GO.)
rm -f "$REPORT"
run_case "missing report -> regenerate -> staged/halt (never GO=0)" 78

# 2. environment unavailable -> 78 (staged)
cat > "$REPORT" <<'JSON'
{"environment_available":false,"stages":{},"launch_recommendation":"NO-GO"}
JSON
run_case "env unavailable -> staged(78)" 78

# 3. a FAIL stage -> 1 (halt)
cat > "$REPORT" <<'JSON'
{"environment_available":true,"stages":{"rollout":"PASS","health":"FAIL"},"launch_recommendation":"GO"}
JSON
run_case "fail stage -> halt" 1

# 4. recommendation not GO -> 1
cat > "$REPORT" <<'JSON'
{"environment_available":true,"stages":{"rollout":"PASS"},"launch_recommendation":"NO-GO"}
JSON
run_case "non-GO recommendation -> halt" 1

# 5. all green + GO -> 0
cat > "$REPORT" <<'JSON'
{"environment_available":true,"stages":{"rollout":"PASS","health":"PASS"},"launch_recommendation":"GO"}
JSON
run_case "all pass + GO -> 0" 0

echo "----"
echo "launch-gate tests: $pass passed, $fail failed"
[ "$fail" -eq 0 ]
