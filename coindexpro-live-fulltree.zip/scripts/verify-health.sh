#!/usr/bin/env bash
# verify-health.sh — probe the REAL /healthz, /readyz, /metrics of every service.
# Uses kubectl exec into each pod (or a probe pod) and curls the real probe port.
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"; source "$DIR/lib-verify.sh"
require_cluster
fail=0

probe() { # probe <svc> <port> <path> <expect_code>
  local svc="$1" port="$2" path="$3" want="${4:-200}"
  local url="http://$svc.$NS.svc.cluster.local:$port$path"
  local code
  code=$(kubectl run hp-$RANDOM -n "$NS" --rm -i --restart=Never --image=curlimages/curl:8.8.0 \
        --command -- curl -s -o /dev/null -m 5 -w '%{http_code}' "$url" 2>/dev/null | tail -1)
  if [ "$code" = "$want" ]; then ok "$svc$path -> $code"; else bad "$svc$path -> ${code:-no-response} (want $want)"; fail=1; fi
}

for s in "${APP_SERVICES[@]}"; do
  probe "$s" "${PROBE_PORT[$s]}" /healthz 200
  probe "$s" "${PROBE_PORT[$s]}" /readyz 200
  probe "$s" "${METRICS_PORT[$s]}" /metrics 200
done

exit $([ $fail -eq 0 ] && echo $EXIT_PASS || echo $EXIT_FAIL)
