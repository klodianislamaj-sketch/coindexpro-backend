#!/usr/bin/env bash
# verify-migrations.sh — validates every REAL migration file on disk.
#
# This does not connect to a database (CI has none by default); it performs static
# checks against the actual .sql files:
#   * the file exists and is non-empty
#   * it ends with a statement terminator (';' on the last non-comment line)
#   * Postgres/Timescale DDL uses idempotent guards (IF NOT EXISTS / OR REPLACE),
#     which the migration-runner relies on for safe re-apply
#
# It enumerates migrations by scanning the repo, so a newly added migration is
# automatically covered. Exit non-zero on any failure.
set -euo pipefail

ROOT="${1:-.}"
fail=0
count=0

mapfile -t migrations < <(find "$ROOT" -type f -path '*/migrations/*.sql' | sort)

if [ "${#migrations[@]}" -eq 0 ]; then
  echo "ERROR: no migration files found under $ROOT" >&2
  exit 1
fi

echo "Found ${#migrations[@]} migration file(s)."
for m in "${migrations[@]}"; do
  count=$((count + 1))
  rel="${m#"$ROOT"/}"

  # non-empty
  if [ ! -s "$m" ]; then
    echo "FAIL  $rel : file is empty"; fail=1; continue
  fi

  # last non-comment, non-blank line must end with ';'
  last=$(grep -vE '^\s*(--.*)?$' "$m" | tail -1 || true)
  if [[ "$last" != *";" ]]; then
    echo "FAIL  $rel : last statement does not end with ';'"; fail=1; continue
  fi

  # idempotency guard for Postgres/Timescale. Forward-only migration runners
  # (golang-migrate) apply each version exactly once, so a baseline schema may use
  # bare CREATE TABLE legitimately. We therefore WARN (not fail) when IF NOT EXISTS
  # is absent, so re-runnability gaps are visible without breaking on the
  # conventional initial migration. Genuinely broken SQL is still caught above.
  case "$rel" in
    */postgres/*|*/timescale/*)
      if grep -qiE 'CREATE +TABLE' "$m" && ! grep -qiE 'CREATE +TABLE +IF +NOT +EXISTS' "$m"; then
        echo "WARN  $rel : CREATE TABLE without IF NOT EXISTS (forward-only baseline?)"
        echo "OK    $rel"
        continue
      fi
      ;;
  esac

  echo "OK    $rel"
done

echo "----"
echo "Checked $count migration(s)."
if [ "$fail" -ne 0 ]; then
  echo "Migration verification FAILED." >&2
  exit 1
fi
echo "Migration verification PASSED."
