#!/usr/bin/env bash
# lib-verify.sh — shared helpers for the Phase 21 verification harness.
#
# The single most important function here is require_cluster(): every check script
# sources this lib and calls it first. If there is no reachable Kubernetes cluster
# (or kubectl is absent), the script exits with status 3 = ENVIRONMENT UNAVAILABLE.
# This is NOT a pass and NOT a fail — it is the honest "could not verify" state, so
# nothing is ever reported green by default.

# Exit codes (consumed by phase21-run.sh):
#   0 = PASS        (check ran, all assertions held)
#   1 = FAIL        (check ran, an assertion failed)
#   3 = UNAVAILABLE (no cluster / prerequisite missing — could not verify)
export EXIT_PASS=0 EXIT_FAIL=1 EXIT_UNAVAILABLE=3

NS="${COINDEX_NS:-coindex}"

# real app + infra names (from the Phase 20 manifests)
APP_SERVICES=(alert-engine api contract-analyzer enricher execution-engine flow-engine
  graph-engine indexer-evm label-engine portfolio-engine premium-engine provider-trust
  replay-engine social-engine status-engine strategy-engine wallet-profiler)
INFRA_STATEFULSETS=(postgres timescale clickhouse redis kafka)
MIGRATION_JOBS=(migrate-postgres migrate-timescale migrate-clickhouse)

# probe ports: indexer-evm serves /healthz,/readyz on 8080 + /metrics on 9100;
# every other service serves probes+metrics on its ops port (91xx).
declare -gA PROBE_PORT=(
  [indexer-evm]=8080 [enricher]=9102 [api]=9101 [provider-trust]=9103
  [wallet-profiler]=9104 [label-engine]=9105 [contract-analyzer]=9106
  [graph-engine]=9107 [alert-engine]=9108 [flow-engine]=9109 [social-engine]=9110
  [strategy-engine]=9111 [execution-engine]=9112 [portfolio-engine]=9113
  [premium-engine]=9114 [replay-engine]=9115 [status-engine]=9116)
declare -gA METRICS_PORT=(
  [indexer-evm]=9100 [enricher]=9102 [api]=9101 [provider-trust]=9103
  [wallet-profiler]=9104 [label-engine]=9105 [contract-analyzer]=9106
  [graph-engine]=9107 [alert-engine]=9108 [flow-engine]=9109 [social-engine]=9110
  [strategy-engine]=9111 [execution-engine]=9112 [portfolio-engine]=9113
  [premium-engine]=9114 [replay-engine]=9115 [status-engine]=9116)

log()  { printf '%s\n' "$*"; }
ok()   { printf '  \033[32mPASS\033[0m  %s\n' "$*"; }
bad()  { printf '  \033[31mFAIL\033[0m  %s\n' "$*"; }
unav() { printf '  \033[33mUNAVAILABLE\033[0m  %s\n' "$*"; }

# require_cluster: honest gate. Returns 3 (UNAVAILABLE) if no cluster is reachable.
require_cluster() {
  if ! command -v kubectl >/dev/null 2>&1; then
    unav "kubectl not installed — cannot verify a live cluster"
    exit "$EXIT_UNAVAILABLE"
  fi
  if ! kubectl cluster-info >/dev/null 2>&1; then
    unav "no reachable Kubernetes cluster (kubectl cluster-info failed)"
    exit "$EXIT_UNAVAILABLE"
  fi
  if ! kubectl get ns "$NS" >/dev/null 2>&1; then
    unav "namespace '$NS' not found — nothing deployed to verify"
    exit "$EXIT_UNAVAILABLE"
  fi
}

# require_cmd CMD — exit UNAVAILABLE if a needed CLI is missing.
require_cmd() {
  command -v "$1" >/dev/null 2>&1 || { unav "$1 not installed — cannot run this check"; exit "$EXIT_UNAVAILABLE"; }
}

# run a command inside a fresh pod (for db/kafka clients) against the in-cluster svc.
krun() { # krun <image> <name> -- <cmd...>
  local image="$1" name="$2"; shift 2; [ "$1" = "--" ] && shift
  kubectl run "$name-$RANDOM" -n "$NS" --rm -i --restart=Never --image="$image" --command -- "$@"
}
