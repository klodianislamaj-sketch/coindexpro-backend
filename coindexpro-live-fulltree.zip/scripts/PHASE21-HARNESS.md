# Phase 21A — Production Verification Harness

Executable verification harness for a **live** CoinDex deployment. It produces real
results when run against a real cluster, and honestly reports `UNAVAILABLE` /
`NO-GO` when no cluster is reachable. **It never emits green by default.**

## Exit-code contract (every check script)
- `0` = PASS — check ran, all assertions held
- `1` = FAIL — check ran, an assertion failed
- `3` = UNAVAILABLE — no cluster / missing prerequisite (could-not-verify, not a pass)

## Run everything
```bash
# against your cluster (kubectl context already pointing at it)
COINDEX_NS=coindex ./scripts/phase21-run.sh                 # rollout→…→launch-check
RUN_LOAD=true  ./scripts/phase21-run.sh                     # also run k6 load
RUN_CHAOS=true ./scripts/phase21-run.sh                     # also run chaos (DESTRUCTIVE)
```
Artifacts are written to `artifacts/`:
`phase21-report.json`, `data-integrity.json`, `performance.json`, `failure-matrix.json`.

## Individual checks
| Script | Verifies (real) |
|---|---|
| `verify-rollout.sh` | every Deployment/StatefulSet/HPA exists and is rolled out |
| `verify-health.sh` | real `/healthz` `/readyz` `/metrics` per service (indexer probes :8080) |
| `verify-service-graph.sh` | every Service has ready endpoints (selector resolves Pods) |
| `verify-migration-jobs.sh` | the in-cluster migration Jobs succeeded |
| `check-postgres.sh` | real core + graph tables + indexes exist |
| `check-timescale.sh` | timescaledb extension + real hypertables exist |
| `check-clickhouse.sh` | real `coindex.*` tables exist |
| `check-redis.sh` | Redis PING → PONG |
| `check-kafka.sh` | topics (`raw.*`, `raw.dlq`, `enrich.dlq`), groups, lag, DLQ depth |
| `replay-verify.sh` | deterministic run_id idempotency, checkpoint monotonicity, no dup writes |

Load: `load/k6-{api,strategy,execution,status}.js` (real routes, p50/p95/p99 + error-rate thresholds).
Chaos: `chaos/{postgres,kafka,redis}-failure.yaml`, `pod-kill.yaml`, `network-partition.yaml`, `rpc-timeout.yaml`
(LitmusChaos + k8s-native; each carries an honest-degradation probe asserting the
system reports the failure, not false-green).

## Prerequisites on the runner
`kubectl` (cluster context), and for load `k6`; chaos manifests need LitmusChaos
installed (`litmus-admin` SA) or a `chaos-runner` ServiceAccount with scale/patch on
statefulsets. `replay-verify.sh` needs `REPLAY_TOKEN=0x...` (a real token with
indexed trades) — otherwise it honestly reports UNAVAILABLE (not indexed).

## Honesty guarantees (verified)
Run in an environment with no cluster, the full runner exits `3` and every artifact
records `environment_available:false`, all stages `UNAVAILABLE`, `load_executed:false`,
`chaos_executed:false`, `launch_recommendation:NO-GO`. No synthetic latency,
throughput, or green status is ever written.
