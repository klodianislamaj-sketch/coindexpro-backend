#!/usr/bin/env bash
# backup-timescale.sh — pg_dump of the Timescale DB. Timescale hypertables dump as
# regular tables in -Fc; restore re-attaches them via create_hypertable (see restore).
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"; source "$DIR/lib-backup.sh"
require_env TSHOST TSUSER TSPASSWORD TSDATABASE BACKUP_S3_BUCKET
require_cmd pg_dump aws
OUT="${BACKUP_DIR:-/backups}/timescale"; mkdir -p "$OUT"
TS="$(stamp)"; FILE="$OUT/timescale-$TSDATABASE-$TS.dump"

log "pg_dump (timescale) -> $FILE"
if ! PGPASSWORD="$TSPASSWORD" pg_dump -Fc -h "$TSHOST" -U "$TSUSER" -d "$TSDATABASE" -f "$FILE"; then
  bad "pg_dump (timescale) failed — NO backup produced"; exit "$EXIT_FAIL"
fi
[ -s "$FILE" ] || { bad "dump is empty"; exit "$EXIT_FAIL"; }
DIGEST="$(checksum "$FILE")"; log "sha256=$DIGEST"
s3_put "$FILE" "timescale/$(basename "$FILE")" || { bad "S3 upload failed"; exit "$EXIT_FAIL"; }
s3_put "$FILE.sha256" "timescale/$(basename "$FILE").sha256" || true
prune_local "$OUT" "timescale-*.dump" "${RETENTION_DAYS:-14}"
ok "timescale backup complete: $(basename "$FILE")"
