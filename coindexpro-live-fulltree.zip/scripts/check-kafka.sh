#!/usr/bin/env bash
# check-kafka.sh — required topics exist, consumer groups attached, lag below
# threshold, DLQ depth visible. Uses kafka CLI tools inside an ephemeral pod
# against the in-cluster kafka Service. Real topics from the indexer/enricher config:
#   raw.<chain> (topic_prefix=raw), raw.dlq, enrich.dlq
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"; source "$DIR/lib-verify.sh"
require_cluster
fail=0
LAG_THRESHOLD="${KAFKA_LAG_THRESHOLD:-10000}"
BOOT="kafka.coindex.svc.cluster.local:9092"
IMG="bitnami/kafka:3.7"

kcmd() { kubectl run kf-$RANDOM -n "$NS" --rm -i --restart=Never --image="$IMG" --command -- "$@" 2>/dev/null; }

log "== topics present =="
TOPICS=$(kcmd kafka-topics.sh --bootstrap-server "$BOOT" --list | tr -d '\r')
if [ -z "$TOPICS" ]; then bad "could not list topics (broker unreachable?)"; exit $EXIT_FAIL; fi
# at least the DLQ topics must exist; raw.* are created by the indexer per chain
for t in raw.dlq enrich.dlq; do
  echo "$TOPICS" | grep -qx "$t" && ok "topic $t exists" || { bad "topic $t MISSING"; fail=1; }
done
echo "$TOPICS" | grep -q '^raw\.' && ok "raw.* chain topics present" || { bad "no raw.* topics (indexer not producing)"; fail=1; }

log "== consumer groups attached + lag =="
GROUPS=$(kcmd kafka-consumer-groups.sh --bootstrap-server "$BOOT" --list | tr -d '\r')
if [ -z "$GROUPS" ]; then bad "no consumer groups attached"; fail=1; else
  while IFS= read -r g; do
    [ -z "$g" ] && continue
    # sum LAG column across partitions for this group
    lag=$(kcmd kafka-consumer-groups.sh --bootstrap-server "$BOOT" --describe --group "$g" \
          | awk 'NR>1 && $6 ~ /^[0-9]+$/ {s+=$6} END{print s+0}')
    if [ "$lag" -le "$LAG_THRESHOLD" ]; then ok "group $g lag=$lag (<= $LAG_THRESHOLD)"; else bad "group $g lag=$lag (> $LAG_THRESHOLD)"; fail=1; fi
  done <<< "$GROUPS"
fi

log "== DLQ depth (visible, reported) =="
for t in raw.dlq enrich.dlq; do
  depth=$(kcmd kafka-run-class.sh kafka.tools.GetOffsetShell --bootstrap-server "$BOOT" --topic "$t" \
          | awk -F: '{s+=$3} END{print s+0}')
  log "  $t depth: ${depth:-?}"
done

exit $([ $fail -eq 0 ] && echo $EXIT_PASS || echo $EXIT_FAIL)
