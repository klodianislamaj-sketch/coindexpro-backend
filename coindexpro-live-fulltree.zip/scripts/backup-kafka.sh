#!/usr/bin/env bash
# backup-kafka.sh — Kafka carries transient streams; the durable record lands in
# ClickHouse via the indexer. We snapshot TOPIC METADATA + CONFIG + OFFSETS so topics
# can be recreated. Honest: this is NOT a full message backup; replay comes from
# re-indexing.
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"; source "$DIR/lib-backup.sh"
require_env KAFKA_BOOTSTRAP BACKUP_S3_BUCKET
require_cmd kafka-topics.sh aws
OUT="${BACKUP_DIR:-/backups}/kafka"; mkdir -p "$OUT"
TS="$(stamp)"; SNAP="$OUT/kafka-metadata-$TS.txt"

log "snapshotting Kafka topic metadata + configs"
{
  echo "# topics"
  kafka-topics.sh --bootstrap-server "$KAFKA_BOOTSTRAP" --describe 2>/dev/null
  echo "# consumer-groups"
  kafka-consumer-groups.sh --bootstrap-server "$KAFKA_BOOTSTRAP" --list 2>/dev/null
} > "$SNAP"
[ -s "$SNAP" ] || { bad "metadata snapshot empty (broker unreachable?)"; exit "$EXIT_FAIL"; }
checksum "$SNAP" >/dev/null
s3_put "$SNAP" "kafka/$(basename "$SNAP")" || { bad "S3 upload failed"; exit "$EXIT_FAIL"; }
s3_put "$SNAP.sha256" "kafka/$(basename "$SNAP").sha256" || true
prune_local "$OUT" "kafka-metadata-*.txt" "${RETENTION_DAYS:-30}"
ok "kafka metadata snapshot complete: $(basename "$SNAP")"
