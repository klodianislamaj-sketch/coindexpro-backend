#!/usr/bin/env bash
# verify-rollout.sh — every Deployment/StatefulSet/Job from k8s/ exists and is rolled out.
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"; source "$DIR/lib-verify.sh"
require_cluster
fail=0

log "== Deployments (17 app) =="
for s in "${APP_SERVICES[@]}"; do
  if ! kubectl -n "$NS" get deploy "$s" >/dev/null 2>&1; then
    bad "deployment/$s MISSING"; fail=1; continue
  fi
  if kubectl -n "$NS" rollout status deploy/"$s" --timeout=60s >/dev/null 2>&1; then
    ok "deployment/$s rolled out"
  else
    bad "deployment/$s NOT rolled out (replicas not available)"; fail=1
  fi
done

log "== StatefulSets (5 infra) =="
for s in "${INFRA_STATEFULSETS[@]}"; do
  if ! kubectl -n "$NS" get statefulset "$s" >/dev/null 2>&1; then
    bad "statefulset/$s MISSING"; fail=1; continue
  fi
  if kubectl -n "$NS" rollout status statefulset/"$s" --timeout=120s >/dev/null 2>&1; then
    ok "statefulset/$s ready"
  else
    bad "statefulset/$s NOT ready"; fail=1
  fi
done

log "== HPAs / PDBs present =="
for s in "${APP_SERVICES[@]}"; do
  case "$s" in indexer-evm|status-engine) continue;; esac  # intentionally no HPA
  kubectl -n "$NS" get hpa "$s" >/dev/null 2>&1 && ok "hpa/$s" || { bad "hpa/$s MISSING"; fail=1; }
done

exit $([ $fail -eq 0 ] && echo $EXIT_PASS || echo $EXIT_FAIL)
