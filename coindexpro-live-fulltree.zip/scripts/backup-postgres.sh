#!/usr/bin/env bash
# backup-postgres.sh — logical pg_dump (-Fc) of the core Postgres DB to S3, with
# checksum + retention. Fail-fast on missing creds; never embeds secrets.
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"; source "$DIR/lib-backup.sh"
require_env PGHOST PGUSER PGPASSWORD PGDATABASE BACKUP_S3_BUCKET
require_cmd pg_dump aws
OUT="${BACKUP_DIR:-/backups}/postgres"; mkdir -p "$OUT"
TS="$(stamp)"; FILE="$OUT/postgres-$PGDATABASE-$TS.dump"

log "pg_dump -> $FILE"
# -Fc = custom compressed format (restorable with pg_restore, schema-first capable)
if ! PGPASSWORD="$PGPASSWORD" pg_dump -Fc -h "$PGHOST" -U "$PGUSER" -d "$PGDATABASE" -f "$FILE"; then
  bad "pg_dump failed — NO backup produced"; exit "$EXIT_FAIL"
fi
[ -s "$FILE" ] || { bad "dump is empty"; exit "$EXIT_FAIL"; }
DIGEST="$(checksum "$FILE")"; log "sha256=$DIGEST"
s3_put "$FILE" "postgres/$(basename "$FILE")" || { bad "S3 upload failed"; exit "$EXIT_FAIL"; }
s3_put "$FILE.sha256" "postgres/$(basename "$FILE").sha256" || true
prune_local "$OUT" "postgres-*.dump" "${RETENTION_DAYS:-14}"
ok "postgres backup complete: $(basename "$FILE")"
