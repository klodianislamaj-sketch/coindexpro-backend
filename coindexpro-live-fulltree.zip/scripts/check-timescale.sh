#!/usr/bin/env bash
# check-timescale.sh — required Timescale hypertables exist (real create_hypertable
# targets from the timescale migrations).
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"; source "$DIR/lib-verify.sh"
require_cluster
fail=0

REQUIRED_HYPERTABLES=(liquidity_history trust_history whale_history sector_history)

ts_q() {
  kubectl run ts-$RANDOM -n "$NS" --rm -i --restart=Never --image=postgres:16-alpine \
    --env PGPASSWORD="$(kubectl -n "$NS" get secret coindex-secrets -o jsonpath='{.data.CLICKHOUSE_PASSWORD}' | base64 -d)" \
    --command -- psql -tAq -h timescale.coindex.svc.cluster.local -U coindex -d coindex -c "$1" 2>/dev/null | tail -1
}

log "== timescaledb extension =="
r=$(ts_q "SELECT count(*) FROM pg_extension WHERE extname='timescaledb';")
[ "${r:-0}" -ge 1 ] && ok "timescaledb extension installed" || { bad "timescaledb extension MISSING"; fail=1; }

log "== required hypertables =="
for h in "${REQUIRED_HYPERTABLES[@]}"; do
  # timescaledb_information.hypertables lists real hypertables
  r=$(ts_q "SELECT count(*) FROM timescaledb_information.hypertables WHERE hypertable_name='$h';")
  [ "${r:-0}" -ge 1 ] && ok "hypertable $h exists" || { bad "hypertable $h MISSING (not a hypertable)"; fail=1; }
done

exit $([ $fail -eq 0 ] && echo $EXIT_PASS || echo $EXIT_FAIL)
