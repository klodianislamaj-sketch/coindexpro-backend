#!/usr/bin/env bash
# phase21-run.sh — orchestrates the full production verification sequence and emits
# the artifact JSONs. It NEVER fabricates results:
#   * each stage runs a real script; its real exit code maps to PASS/FAIL/UNAVAILABLE
#   * if there is no cluster, every stage is UNAVAILABLE and the final report says
#     environment_available=false with launch_recommendation=NO-GO (cannot verify)
#   * artifacts are written from observed stage results only — no green-by-default
#
# Exit-code contract from each stage (see lib-verify.sh): 0=PASS 1=FAIL 3=UNAVAILABLE.
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$DIR/.." && pwd)"
source "$DIR/lib-verify.sh"
ART="$ROOT/artifacts"; mkdir -p "$ART"

CHAOS="${RUN_CHAOS:-false}"   # chaos is opt-in (destructive); off by default
LOAD="${RUN_LOAD:-false}"     # load needs k6 + real endpoints; opt-in

# stage registry: name|script|args
STAGES=(
  "rollout|verify-rollout.sh|"
  "health|verify-health.sh|"
  "service_graph|verify-service-graph.sh|"
  "migrations|verify-migration-jobs.sh|"
  "postgres|check-postgres.sh|"
  "timescale|check-timescale.sh|"
  "clickhouse|check-clickhouse.sh|"
  "redis|check-redis.sh|"
  "kafka|check-kafka.sh|"
  "replay|replay-verify.sh|"
)

declare -A RESULT
declare -A DETAIL
overall_blockers=()
any_ran=false

code_to_status() {
  case "$1" in 0) echo PASS;; 1) echo FAIL;; 3) echo UNAVAILABLE;; *) echo ERROR;; esac
}

# Pre-flight: is there a cluster at all? Determines whether anything can be verified.
ENV_AVAILABLE=true
if ! command -v kubectl >/dev/null 2>&1 || ! kubectl cluster-info >/dev/null 2>&1 \
   || ! kubectl get ns "$NS" >/dev/null 2>&1; then
  ENV_AVAILABLE=false
fi

log "==================================================================="
log " CoinDex Phase 21 — Production Verification Run"
log " namespace=$NS  environment_available=$ENV_AVAILABLE  chaos=$CHAOS  load=$LOAD"
log "==================================================================="

for entry in "${STAGES[@]}"; do
  IFS='|' read -r name script args <<< "$entry"
  log ""
  log ">>> STAGE: $name ($script)"
  if [ ! -x "$DIR/$script" ]; then
    RESULT[$name]=UNAVAILABLE; DETAIL[$name]="script missing"; continue
  fi
  # shellcheck disable=SC2086
  "$DIR/$script" $args
  rc=$?
  st=$(code_to_status "$rc")
  RESULT[$name]=$st
  [ "$st" = "PASS" ] || [ "$st" = "FAIL" ] && any_ran=true
  [ "$st" = "FAIL" ] && overall_blockers+=("$name failed")
done

# --- optional load stage (only if explicitly enabled AND k6 present) ---------
PERF_STATUS=SKIPPED
if [ "$LOAD" = "true" ]; then
  if command -v k6 >/dev/null 2>&1 && [ "$ENV_AVAILABLE" = "true" ]; then
    PERF_STATUS=RAN
    for prof in api strategy execution status; do
      log ">>> LOAD: k6-$prof"
      k6 run "$ROOT/load/k6-$prof.js" || overall_blockers+=("load:$prof threshold breach")
    done
  else
    PERF_STATUS=UNAVAILABLE   # k6 missing or no cluster — honest, not green
  fi
fi

# --- optional chaos stage (destructive; only if explicitly enabled) ----------
CHAOS_STATUS=SKIPPED
if [ "$CHAOS" = "true" ]; then
  if [ "$ENV_AVAILABLE" = "true" ]; then
    CHAOS_STATUS=RAN
    for c in postgres-failure kafka-failure redis-failure pod-kill network-partition rpc-timeout; do
      log ">>> CHAOS: $c"
      kubectl apply -f "$ROOT/chaos/$c.yaml" || overall_blockers+=("chaos:$c apply failed")
    done
  else
    CHAOS_STATUS=UNAVAILABLE
  fi
fi

# --- launch-check (only meaningful against a live status-engine) -------------
LAUNCH=UNAVAILABLE
if [ "$ENV_AVAILABLE" = "true" ]; then
  code=$(kubectl run lc-$RANDOM -n "$NS" --rm -i --restart=Never --image=curlimages/curl:8.8.0 \
         --command -- curl -s -o /dev/null -m 8 -w '%{http_code}' \
         http://status-engine.coindex.svc.cluster.local:8104/launch-check 2>/dev/null | tail -1)
  case "$code" in
    200) LAUNCH=PASS;;
    503) LAUNCH=FAIL; overall_blockers+=("launch-check: not all services up");;
    *)   LAUNCH=UNAVAILABLE;;
  esac
fi

# --- decide overall recommendation (honest) ----------------------------------
if [ "$ENV_AVAILABLE" != "true" ]; then
  RECO="NO-GO"; REASON="environment unavailable — no cluster to verify"
elif [ "${#overall_blockers[@]}" -gt 0 ]; then
  RECO="NO-GO"; REASON="${#overall_blockers[@]} blocker(s)"
elif [ "$LAUNCH" = "PASS" ]; then
  RECO="GO"; REASON="all stages passed and launch-check green"
else
  RECO="NO-GO"; REASON="launch-check not green"
fi

# --- emit artifacts (from observed results only) -----------------------------
emit_kv_json() { # builds {"k":"v",...} from RESULT map
  local first=1; printf '{'
  for k in "${!RESULT[@]}"; do
    [ $first -eq 1 ] && first=0 || printf ','
    printf '"%s":"%s"' "$k" "${RESULT[$k]}"
  done
  printf '}'
}
blockers_json() {
  local first=1; printf '['
  for b in "${overall_blockers[@]:-}"; do
    [ -z "$b" ] && continue
    [ $first -eq 1 ] && first=0 || printf ','
    printf '"%s"' "$b"
  done; printf ']'
}

cat > "$ART/phase21-report.json" <<JSON
{
  "phase": "21-production-verification",
  "namespace": "$NS",
  "environment_available": $ENV_AVAILABLE,
  "stages": $(emit_kv_json),
  "load": "$PERF_STATUS",
  "chaos": "$CHAOS_STATUS",
  "launch_check": "$LAUNCH",
  "blockers": $(blockers_json),
  "launch_recommendation": "$RECO",
  "reason": "$REASON",
  "note": "results reflect only checks that actually ran; UNAVAILABLE means could-not-verify, never a pass"
}
JSON

# data-integrity matrix (db/kafka/replay stages)
cat > "$ART/data-integrity.json" <<JSON
{
  "environment_available": $ENV_AVAILABLE,
  "postgres":   "${RESULT[postgres]:-UNAVAILABLE}",
  "timescale":  "${RESULT[timescale]:-UNAVAILABLE}",
  "clickhouse": "${RESULT[clickhouse]:-UNAVAILABLE}",
  "kafka":      "${RESULT[kafka]:-UNAVAILABLE}",
  "replay":     "${RESULT[replay]:-UNAVAILABLE}"
}
JSON

# failure matrix (chaos outcomes; UNAVAILABLE unless chaos actually ran)
cat > "$ART/failure-matrix.json" <<JSON
{
  "environment_available": $ENV_AVAILABLE,
  "chaos_executed": $( [ "$CHAOS_STATUS" = "RAN" ] && echo true || echo false ),
  "experiments": {
    "postgres_failure":  "${CHAOS_STATUS}",
    "kafka_failure":     "${CHAOS_STATUS}",
    "redis_failure":     "${CHAOS_STATUS}",
    "pod_kill":          "${CHAOS_STATUS}",
    "network_partition": "${CHAOS_STATUS}",
    "rpc_timeout":       "${CHAOS_STATUS}"
  },
  "note": "honest degradation assertions live in each chaos manifest probe; this matrix records execution status only"
}
JSON

# performance matrix (UNAVAILABLE unless k6 ran; real numbers come from artifacts/perf-*.json)
cat > "$ART/performance.json" <<JSON
{
  "environment_available": $ENV_AVAILABLE,
  "load_executed": $( [ "$PERF_STATUS" = "RAN" ] && echo true || echo false ),
  "profiles": {
    "api":       "${PERF_STATUS}",
    "strategy":  "${PERF_STATUS}",
    "execution": "${PERF_STATUS}",
    "status":    "${PERF_STATUS}"
  },
  "note": "p50/p95/p99 + throughput are written to artifacts/perf-<profile>.json by k6 when load actually runs; no synthetic numbers are emitted here"
}
JSON

log ""
log "==================================================================="
log " RESULT: $RECO  ($REASON)"
log " artifacts: phase21-report.json performance.json failure-matrix.json data-integrity.json"
log "==================================================================="

# exit code: 0 only on GO; 2 = NO-GO blockers; 3 = environment unavailable
if [ "$ENV_AVAILABLE" != "true" ]; then exit 3; fi
[ "$RECO" = "GO" ] && exit 0 || exit 2
