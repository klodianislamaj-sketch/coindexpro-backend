#!/usr/bin/env bash
# check-redis.sh — Redis reachable (PING) and accepting commands.
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"; source "$DIR/lib-verify.sh"
require_cluster
r=$(kubectl run rd-$RANDOM -n "$NS" --rm -i --restart=Never --image=redis:7-alpine \
     --command -- redis-cli -h redis.coindex.svc.cluster.local ping 2>/dev/null | tr -d '\r' | tail -1)
[ "$r" = "PONG" ] && { ok "redis PING -> PONG"; exit $EXIT_PASS; } || { bad "redis unreachable (no PONG)"; exit $EXIT_FAIL; }
