#!/usr/bin/env bash
# verify-service-graph.sh — every Service has endpoints (its selector resolves Pods).
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"; source "$DIR/lib-verify.sh"
require_cluster
fail=0

for s in "${APP_SERVICES[@]}" "${INFRA_STATEFULSETS[@]}"; do
  if ! kubectl -n "$NS" get svc "$s" >/dev/null 2>&1; then
    bad "service/$s MISSING"; fail=1; continue
  fi
  # a Service with no ready endpoints means its selector matches no ready Pod
  eps=$(kubectl -n "$NS" get endpoints "$s" -o jsonpath='{.subsets[*].addresses[*].ip}' 2>/dev/null | wc -w)
  if [ "$eps" -gt 0 ]; then ok "service/$s has $eps endpoint(s)"; else bad "service/$s has NO ready endpoints"; fail=1; fi
done

exit $([ $fail -eq 0 ] && echo $EXIT_PASS || echo $EXIT_FAIL)
