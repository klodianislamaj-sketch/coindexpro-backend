#!/usr/bin/env bash
# launch-gate.sh — the canonical production launch gate. It guarantees a decision is
# made ONLY from a real verification report, never defaulting to pass.
#
# Behavior:
#   * if no report exists yet, it runs the real harness (scripts/phase21-run.sh)
#   * it then reads artifacts/phase21-report.json and maps to an exit code:
#       GO            -> 0   (cutover eligible)
#       UNAVAILABLE   -> 78  (could-not-verify: stay staged, do NOT cut over)
#       FAIL/missing  -> 1   (halt)
#   A missing or unparseable report is treated as FAIL — never a pass.
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$DIR/.." && pwd)"
REPORT="$ROOT/artifacts/phase21-report.json"

EXIT_GO=0 EXIT_HALT=1 EXIT_STAGED=78

# Run the harness if we don't already have a fresh report this invocation.
if [ "${LAUNCH_GATE_REUSE_REPORT:-false}" != "true" ] || [ ! -f "$REPORT" ]; then
  "$DIR/phase21-run.sh" || true   # its own exit is captured via the report below
fi

if [ ! -f "$REPORT" ]; then
  echo "launch-gate: phase21-report.json missing — FAIL (no default pass)" >&2
  exit "$EXIT_HALT"
fi

# Prefer jq; fall back to grep so the gate works on a minimal runner.
read_field() {
  local key="$1"
  if command -v jq >/dev/null 2>&1; then
    jq -r ".$key" "$REPORT" 2>/dev/null
  else
    grep -oE "\"$key\"[ ]*:[ ]*\"?[A-Za-z_-]+\"?" "$REPORT" | head -1 | sed -E 's/.*: *"?([A-Za-z_-]+)"?/\1/'
  fi
}

ENV_OK=$(read_field environment_available)
RECO=$(read_field launch_recommendation)

# count FAIL stages (jq path; grep fallback counts the token)
if command -v jq >/dev/null 2>&1; then
  FAILS=$(jq -r '[.stages[] | select(. == "FAIL")] | length' "$REPORT" 2>/dev/null)
else
  FAILS=$(grep -o '"FAIL"' "$REPORT" | wc -l | tr -d ' ')
fi

echo "launch-gate: environment_available=$ENV_OK recommendation=$RECO fail_stages=${FAILS:-?}"

if [ "$ENV_OK" != "true" ]; then
  echo "launch-gate: UNAVAILABLE — deployment stays STAGED, no traffic cutover" >&2
  exit "$EXIT_STAGED"
fi
if [ "${FAILS:-0}" -gt 0 ] || [ "$RECO" != "GO" ]; then
  echo "launch-gate: FAIL — deployment HALTED" >&2
  exit "$EXIT_HALT"
fi
echo "launch-gate: GO — production verification passed, cutover eligible"
exit "$EXIT_GO"
