#!/usr/bin/env bash
# restore-postgres.sh — restore a pg_dump (-Fc) SCHEMA-FIRST, then verify integrity:
# expected core tables present, migration checksum matches, and row counts are sane.
# FAILS on any mismatch. Never reports success without verification.
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"; source "$DIR/lib-backup.sh"
require_env PGHOST PGUSER PGPASSWORD PGDATABASE
require_cmd pg_restore psql
DUMP="${1:?usage: restore-postgres.sh <dump-file>}"
[ -f "$DUMP" ] || { bad "dump not found: $DUMP"; exit "$EXIT_FAIL"; }

# 0. verify the artifact checksum before trusting it
if [ -f "$DUMP.sha256" ]; then
  verify_checksum "$DUMP" || { bad "checksum mismatch on $DUMP — refusing restore"; exit "$EXIT_FAIL"; }
  ok "artifact checksum verified"
else
  log "  (no checksum sidecar; proceeding but cannot verify artifact integrity)"
fi

psql_q() { PGPASSWORD="$PGPASSWORD" psql -tAq -h "$PGHOST" -U "$PGUSER" -d "$PGDATABASE" -c "$1"; }

# 1. SCHEMA FIRST: restore only the schema (no data), so structure exists before rows
log "restoring SCHEMA first"
PGPASSWORD="$PGPASSWORD" pg_restore --schema-only --no-owner -h "$PGHOST" -U "$PGUSER" -d "$PGDATABASE" "$DUMP" \
  || { bad "schema restore failed"; exit "$EXIT_FAIL"; }

# 2. verify expected core tables exist (real schema objects)
REQUIRED=(token_registry token_clones wallet_labels user_accounts api_keys premium_subscriptions alerts watchlists portfolios)
for t in "${REQUIRED[@]}"; do
  r="$(psql_q "SELECT to_regclass('public.$t') IS NOT NULL;")"
  [ "$r" = "t" ] || { bad "expected table $t missing after schema restore"; exit "$EXIT_FAIL"; }
done
ok "schema verified (${#REQUIRED[@]} core tables present)"

# 3. DATA next
log "restoring DATA"
PGPASSWORD="$PGPASSWORD" pg_restore --data-only --no-owner --disable-triggers -h "$PGHOST" -U "$PGUSER" -d "$PGDATABASE" "$DUMP" \
  || { bad "data restore failed"; exit "$EXIT_FAIL"; }

# 4. row-count sanity + optional diff vs an expected snapshot (EXPECTED_COUNTS=table:count,...)
if [ -n "${EXPECTED_COUNTS:-}" ]; then
  IFS=',' read -ra pairs <<< "$EXPECTED_COUNTS"
  for p in "${pairs[@]}"; do
    tbl="${p%%:*}"; want="${p##*:}"
    got="$(psql_q "SELECT count(*) FROM $tbl;")"
    [ "$got" = "$want" ] || { bad "row-count mismatch $tbl: want $want got $got"; exit "$EXIT_FAIL"; }
  done
  ok "row-count diff matched EXPECTED_COUNTS"
else
  log "  (no EXPECTED_COUNTS provided; reporting observed counts, not asserting)"
  for t in token_registry user_accounts; do log "    $t = $(psql_q "SELECT count(*) FROM $t;")"; done
fi

# 5. migration checksum continuity (if a checksums file is mounted)
if [ -n "${MIGRATION_CHECKSUMS:-}" ] && [ -f "$MIGRATION_CHECKSUMS" ]; then
  sha256sum -c "$MIGRATION_CHECKSUMS" >/dev/null 2>&1 \
    && ok "migration checksums verified" \
    || { bad "migration checksum mismatch"; exit "$EXIT_FAIL"; }
fi
ok "postgres restore VERIFIED"
