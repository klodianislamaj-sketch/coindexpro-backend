#!/usr/bin/env bash
# backup-clickhouse.sh — native ClickHouse BACKUP of the coindex DB to an S3 disk.
# Uses the server-side BACKUP statement (atomic, partition-aware). Fail-fast on creds.
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"; source "$DIR/lib-backup.sh"
require_env CHHOST CHUSER CHPASSWORD CHDATABASE BACKUP_S3_BUCKET
require_cmd clickhouse-client
TS="$(stamp)"; NAME="clickhouse-$CHDATABASE-$TS.zip"

# Server-side backup to an S3-backed disk named 'backups' (configured in CH storage).
# If BACKUP_S3_ENDPOINT is set, the disk must point at it; we pass the object key.
log "CLICKHOUSE BACKUP DATABASE $CHDATABASE -> $NAME"
SQL="BACKUP DATABASE \`$CHDATABASE\` TO S3('${BACKUP_S3_ENDPOINT:-https://s3.amazonaws.com}/$BACKUP_S3_BUCKET/clickhouse/$NAME')"
if ! clickhouse-client --host "$CHHOST" --user "$CHUSER" --password "$CHPASSWORD" -q "$SQL"; then
  bad "ClickHouse BACKUP failed — NO backup produced"; exit "$EXIT_FAIL"
fi
# Record a manifest + checksum of the manifest (the data lives in S3 already).
OUT="${BACKUP_DIR:-/backups}/clickhouse"; mkdir -p "$OUT"
MAN="$OUT/$NAME.manifest"
clickhouse-client --host "$CHHOST" --user "$CHUSER" --password "$CHPASSWORD" \
  -q "SELECT name, total_rows FROM system.tables WHERE database='$CHDATABASE' FORMAT TabSeparated" > "$MAN" || true
[ -s "$MAN" ] || { bad "manifest empty — backup unverifiable"; exit "$EXIT_FAIL"; }
checksum "$MAN" >/dev/null
s3_put "$MAN" "clickhouse/$NAME.manifest" || true
s3_put "$MAN.sha256" "clickhouse/$NAME.manifest.sha256" || true
prune_local "$OUT" "*.manifest" "${RETENTION_DAYS:-14}"
ok "clickhouse backup complete: $NAME"
