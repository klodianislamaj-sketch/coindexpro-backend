#!/usr/bin/env bash
# verify-dependencies.sh — aggregator over the real Phase 21A dependency checks.
# It does NOT reimplement any check; it invokes the existing scripts and rolls up
# their honest exit codes:
#   any UNAVAILABLE (3) and no FAIL -> 3 (could-not-verify)
#   any FAIL (1)                    -> 1
#   all PASS                        -> 0
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"; source "$DIR/lib-verify.sh"

CHECKS=(check-postgres.sh check-timescale.sh check-clickhouse.sh check-redis.sh check-kafka.sh)

saw_fail=0
saw_unavail=0
for c in "${CHECKS[@]}"; do
  log ""
  log ">>> dependency: $c"
  if [ ! -x "$DIR/$c" ]; then unav "$c missing"; saw_unavail=1; continue; fi
  "$DIR/$c"
  case $? in
    0) ;;                      # PASS
    1) saw_fail=1 ;;           # FAIL
    3) saw_unavail=1 ;;        # UNAVAILABLE
    *) saw_fail=1 ;;
  esac
done

if [ "$saw_fail" -eq 1 ]; then exit "$EXIT_FAIL"; fi
if [ "$saw_unavail" -eq 1 ]; then exit "$EXIT_UNAVAILABLE"; fi
exit "$EXIT_PASS"
