#!/usr/bin/env bash
# check-clickhouse.sh — required ClickHouse tables exist (real coindex.* tables).
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"; source "$DIR/lib-verify.sh"
require_cluster
fail=0

REQUIRED_CH=(swaps lp_events transfers token_mints wallet_trades wallet_positions
  token_metrics smart_money_events)

ch_q() {
  kubectl run ch-$RANDOM -n "$NS" --rm -i --restart=Never --image=clickhouse/clickhouse-server:24.3-alpine \
    --env CHPW="$(kubectl -n "$NS" get secret coindex-secrets -o jsonpath='{.data.CLICKHOUSE_PASSWORD}' | base64 -d)" \
    --command -- clickhouse-client --host clickhouse.coindex.svc.cluster.local --port 9000 \
    --user coindex --password "$CHPW" -q "$1" 2>/dev/null | tail -1
}

log "== required tables in db 'coindex' =="
for t in "${REQUIRED_CH[@]}"; do
  r=$(ch_q "EXISTS TABLE coindex.$t")
  [ "$r" = "1" ] && ok "table coindex.$t exists" || { bad "table coindex.$t MISSING"; fail=1; }
done

log "== row-count observability (reported, not asserted green) =="
for t in swaps wallet_trades; do
  c=$(ch_q "SELECT count() FROM coindex.$t")
  log "  coindex.$t row count: ${c:-?}"
done

exit $([ $fail -eq 0 ] && echo $EXIT_PASS || echo $EXIT_FAIL)
