#!/usr/bin/env bash
# replay-verify.sh — replay a bounded block range and verify idempotency + checkpoint
# monotonicity + no duplicate writes. Drives the REAL replay-engine + reads REAL
# ClickHouse counts. Honest by construction: it asserts equality before/after a
# re-run; if the replay engine isn't reachable it reports UNAVAILABLE, not green.
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"; source "$DIR/lib-verify.sh"
require_cluster
fail=0

CHAIN="${REPLAY_CHAIN:-eth}"
TOKEN="${REPLAY_TOKEN:?set REPLAY_TOKEN to a real 0x token address}"
REPLAY_SVC="replay-engine.$NS.svc.cluster.local:8103"

http() { kubectl run rv-$RANDOM -n "$NS" --rm -i --restart=Never --image=curlimages/curl:8.8.0 \
         --command -- curl -s -m 20 "$@" 2>/dev/null | tail -1; }
ch_q() { kubectl run rc-$RANDOM -n "$NS" --rm -i --restart=Never --image=clickhouse/clickhouse-server:24.3-alpine \
         --env CHPW="$(kubectl -n "$NS" get secret coindex-secrets -o jsonpath='{.data.CLICKHOUSE_PASSWORD}' | base64 -d)" \
         --command -- clickhouse-client --host clickhouse.coindex.svc.cluster.local --user coindex --password "$CHPW" -q "$1" 2>/dev/null | tail -1; }

log "== run 1: deterministic backtest over real prices =="
R1=$(http -X POST "http://$REPLAY_SVC/replay/backtest/$CHAIN/$TOKEN")
echo "  response(1): $R1"
ID1=$(echo "$R1" | grep -oE '"run_id":"[^"]+"' | head -1 | cut -d'"' -f4)
AVAIL=$(echo "$R1" | grep -oE '"available":(true|false)' | head -1)
if [ "$AVAIL" = '"available":false' ]; then
  unav "replay reports not indexed (no real priced trades for $TOKEN) — cannot verify replay determinism without real data"
  exit $EXIT_UNAVAILABLE
fi

log "== run 2: identical inputs must yield identical deterministic run_id (idempotency) =="
R2=$(http -X POST "http://$REPLAY_SVC/replay/backtest/$CHAIN/$TOKEN")
ID2=$(echo "$R2" | grep -oE '"run_id":"[^"]+"' | head -1 | cut -d'"' -f4)
if [ -n "$ID1" ] && [ "$ID1" = "$ID2" ]; then ok "idempotent run_id stable: $ID1"; else bad "run_id changed across identical runs ($ID1 != $ID2)"; fail=1; fi

log "== indexer checkpoint monotonicity (real metric) =="
C1=$(http "http://indexer-evm.$NS.svc.cluster.local:9100/metrics" | grep -oE 'coindex_index_head_block[^ ]* [0-9]+' | awk '{print $2}' | sort -n | tail -1)
sleep 5
C2=$(http "http://indexer-evm.$NS.svc.cluster.local:9100/metrics" | grep -oE 'coindex_index_head_block[^ ]* [0-9]+' | awk '{print $2}' | sort -n | tail -1)
if [ -n "$C1" ] && [ -n "$C2" ] && [ "$C2" -ge "$C1" ]; then ok "checkpoint monotonic: $C1 -> $C2"; else bad "checkpoint regressed or unavailable ($C1 -> $C2)"; fail=1; fi

log "== no duplicate writes (ReplacingMergeTree dedupe: count == uniq) =="
TOTAL=$(ch_q "SELECT count() FROM coindex.swaps")
UNIQ=$(ch_q "SELECT count() FROM (SELECT DISTINCT chain,tx_hash,log_index FROM coindex.swaps)")
if [ -n "$TOTAL" ] && [ "$TOTAL" = "$UNIQ" ]; then ok "no duplicate swaps (count=$TOTAL == uniq=$UNIQ)"; else bad "duplicate rows: count=$TOTAL uniq=$UNIQ"; fail=1; fi

exit $([ $fail -eq 0 ] && echo $EXIT_PASS || echo $EXIT_FAIL)
