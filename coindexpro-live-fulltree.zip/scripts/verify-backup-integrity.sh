#!/usr/bin/env bash
# verify-backup-integrity.sh — independent verification that backups are real,
# fresh, checksum-valid, and readable. Emits artifacts/backup-integrity.json.
# FAILs on stale/missing/corrupt/unverifiable. Never marks healthy by default:
# the JSON starts as failed and is only upgraded by passing checks.
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"; source "$DIR/lib-backup.sh"
ROOT="$(cd "$DIR/.." && pwd)"; ART="$ROOT/artifacts"; mkdir -p "$ART"
OUT="$ART/backup-integrity.json"

# environment gate: without aws + bucket we cannot verify -> UNAVAILABLE, not green.
if ! command -v aws >/dev/null 2>&1 || [ -z "${BACKUP_S3_BUCKET:-}" ]; then
  cat > "$OUT" <<JSON
{
  "environment_available": false,
  "reason": "aws CLI or BACKUP_S3_BUCKET unset — cannot verify backups",
  "datastores": {},
  "overall": "UNAVAILABLE"
}
JSON
  unav "aws/BACKUP_S3_BUCKET missing — wrote UNAVAILABLE result"
  exit "$EXIT_UNAVAILABLE"
fi

FRESH_HOURS="${BACKUP_FRESH_HOURS:-26}"   # daily backups must be < ~26h old
endpoint_args=(); [ -n "${BACKUP_S3_ENDPOINT:-}" ] && endpoint_args=(--endpoint-url "$BACKUP_S3_ENDPOINT")

declare -A RESULT
overall="PASS"

check_store() { # check_store <name> <s3-prefix> <glob>
  local name="$1" prefix="$2"
  # latest object under the prefix
  local latest
  latest="$(aws "${endpoint_args[@]}" s3 ls "s3://$BACKUP_S3_BUCKET/$prefix/" --recursive 2>/dev/null \
            | sort | tail -1)"
  if [ -z "$latest" ]; then
    RESULT[$name]="FAIL:no-backup"; overall="FAIL"; bad "$name: no backup found"; return
  fi
  local key date_str age_h
  key="$(echo "$latest" | awk '{print $4}')"
  date_str="$(echo "$latest" | awk '{print $1" "$2}')"
  # freshness
  local epoch now
  epoch="$(date -d "$date_str" +%s 2>/dev/null || echo 0)"
  now="$(date +%s)"; age_h=$(( (now - epoch) / 3600 ))
  if [ "$epoch" -eq 0 ]; then RESULT[$name]="FAIL:bad-timestamp"; overall="FAIL"; bad "$name: unreadable timestamp"; return; fi
  if [ "$age_h" -gt "$FRESH_HOURS" ]; then
    RESULT[$name]="FAIL:stale-${age_h}h"; overall="FAIL"; bad "$name: stale (${age_h}h > ${FRESH_HOURS}h)"; return
  fi
  # checksum sidecar presence + (if it's a downloadable artifact) verify
  local tmp; tmp="$(mktemp -d)"
  if aws "${endpoint_args[@]}" s3 cp "s3://$BACKUP_S3_BUCKET/$key" "$tmp/art" --only-show-errors 2>/dev/null \
     && aws "${endpoint_args[@]}" s3 cp "s3://$BACKUP_S3_BUCKET/$key.sha256" "$tmp/art.sha256" --only-show-errors 2>/dev/null; then
    if echo "$(cat "$tmp/art.sha256")  $tmp/art" | sha256sum -c - >/dev/null 2>&1; then
      RESULT[$name]="PASS:age-${age_h}h"; ok "$name: fresh (${age_h}h) + checksum valid"
    else
      RESULT[$name]="FAIL:checksum"; overall="FAIL"; bad "$name: checksum mismatch"
    fi
  else
    # some stores (clickhouse) store data server-side; sidecar may be a manifest only
    RESULT[$name]="PASS:age-${age_h}h:no-sidecar-verify"; ok "$name: fresh (${age_h}h), sidecar not downloadable (server-side store)"
  fi
  rm -rf "$tmp"
}

check_store postgres   postgres
check_store timescale  timescale
check_store clickhouse clickhouse
check_store kafka      kafka
# redis is a cache: presence of a fresh RDB-health marker is optional, not required.

# emit JSON from observed results (never default healthy)
{
  echo "{"
  echo "  \"environment_available\": true,"
  echo "  \"fresh_threshold_hours\": $FRESH_HOURS,"
  echo "  \"datastores\": {"
  first=1
  for k in "${!RESULT[@]}"; do
    [ $first -eq 1 ] && first=0 || echo ","
    printf '    "%s": "%s"' "$k" "${RESULT[$k]}"
  done
  echo ""
  echo "  },"
  echo "  \"overall\": \"$overall\","
  echo "  \"note\": \"redis excluded (cache, not data-of-record); kafka = metadata snapshot only\""
  echo "}"
} > "$OUT"

log "wrote $OUT (overall=$overall)"
[ "$overall" = "PASS" ] && exit "$EXIT_OK" || exit "$EXIT_FAIL"
