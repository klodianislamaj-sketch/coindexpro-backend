#!/usr/bin/env bash
# verify-migration-jobs.sh — the in-cluster migration Jobs completed successfully.
# (Phase 19's verify-migrations.sh statically checks the .sql; this checks the Jobs ran.)
set -uo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"; source "$DIR/lib-verify.sh"
require_cluster
fail=0

for j in "${MIGRATION_JOBS[@]}"; do
  if ! kubectl -n "$NS" get job "$j" >/dev/null 2>&1; then
    bad "job/$j MISSING (migrations not applied)"; fail=1; continue
  fi
  succeeded=$(kubectl -n "$NS" get job "$j" -o jsonpath='{.status.succeeded}' 2>/dev/null)
  if [ "${succeeded:-0}" -ge 1 ]; then ok "job/$j succeeded"; else bad "job/$j has NOT succeeded"; fail=1; fi
done

exit $([ $fail -eq 0 ] && echo $EXIT_PASS || echo $EXIT_FAIL)
