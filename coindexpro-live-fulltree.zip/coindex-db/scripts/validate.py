#!/usr/bin/env python3
"""
CoinDex DB — static migration validator.

No database engine is available in this environment, so this performs STRUCTURAL
verification only (it does NOT prove the SQL executes on a live server). It
checks the things that are checkable from the text: balanced parens/quotes,
statement structure, that every required table is defined, that Postgres FKs
reference a table that exists, and that every ClickHouse event table carries the
reorg-safe + dedupe discipline (block_number, ReplacingMergeTree, PARTITION BY,
ORDER BY ending in the idempotency key). Honest by construction: it reports what
it verified and stays silent on what it cannot (runtime behaviour).
"""
import re, sys, glob, os

ROOT = os.path.join(os.path.dirname(__file__), "..", "migrations")

REQUIRED = {
    "clickhouse": ["swaps","transfers","lp_events","token_mints",
                   "wallet_trades","wallet_positions","token_metrics","smart_money_events"],
    "timescale":  ["candles_1m","candles_5m","candles_15m","candles_1h","candles_4h",
                   "liquidity_history","trust_history","whale_history","sector_history"],
    "postgres":   ["token_registry","wallet_labels","user_accounts","alerts",
                   "watchlists","portfolios","premium_subscriptions"],
    "graph":      ["wallet_nodes","token_nodes","wallet_edges"],
}

def read(engine):
    files = sorted(glob.glob(os.path.join(ROOT, engine, "*.sql")))
    return "".join(open(f).read() for f in files), files

def strip_comments(sql):
    out = []
    for l in sql.splitlines():
        # remove inline "-- ..." comments (these can contain ';')
        idx = l.find("--")
        if idx >= 0:
            l = l[:idx]
        out.append(l)
    return "\n".join(out)

def check_balance(sql, label, errs):
    body = strip_comments(sql)
    # parens
    if body.count("(") != body.count(")"):
        errs.append(f"[{label}] unbalanced parens: {body.count('(')} '(' vs {body.count(')')} ')'")
    # single quotes (string literals) must be even outside of $$ blocks
    no_dollar = re.sub(r"\$\$.*?\$\$", "", body, flags=re.S)
    if no_dollar.count("'") % 2 != 0:
        errs.append(f"[{label}] odd number of single-quotes (unterminated string?)")

def tables_defined(sql):
    # CREATE TABLE [IF NOT EXISTS] [schema.]name
    return set(re.findall(r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(?:[a-z_]+\.)?([a-z_0-9]+)", sql, re.I))

def matviews_defined(sql):
    return set(re.findall(r"CREATE\s+MATERIALIZED\s+VIEW\s+(?:IF\s+NOT\s+EXISTS\s+)?(?:[a-z_]+\.)?([a-z_0-9]+)", sql, re.I))

def main():
    overall_ok = True
    print("="*70)
    print("CoinDex DB — static migration validation")
    print("="*70)

    all_sql = {}
    for engine in REQUIRED:
        sql, files = read(engine)
        all_sql[engine] = sql
        errs = []
        print(f"\n### {engine}  ({len(files)} file(s))")
        for f in files:
            check_balance(open(f).read(), os.path.basename(f), errs)

        defined = tables_defined(sql) | matviews_defined(sql)
        missing = [t for t in REQUIRED[engine] if t not in defined]
        if missing:
            errs.append(f"missing required tables: {missing}")
        else:
            print(f"  ✓ all {len(REQUIRED[engine])} required tables/views defined")

        # ClickHouse-specific discipline
        if engine == "clickhouse":
            ck_clean = strip_comments(sql)  # comments contain ';' — strip first
            # split into statements and index CREATE TABLE statements by table name
            stmts = {}
            for st in ck_clean.split(";"):
                m = re.search(r"CREATE TABLE\s+(?:IF NOT EXISTS\s+)?coindex\.([a-z_0-9]+)", st, re.I)
                if m:
                    stmts[m.group(1).lower()] = st
            event_tables = ["swaps","transfers","lp_events","token_mints",
                            "wallet_trades","smart_money_events"]
            ck_ok = True
            for t in event_tables:
                seg = stmts.get(t, "")
                if "ReplacingMergeTree" not in seg:
                    errs.append(f"{t}: not ReplacingMergeTree (dedupe)"); ck_ok = False
                if "PARTITION BY" not in seg:
                    errs.append(f"{t}: no PARTITION BY"); ck_ok = False
                if "block_number" not in seg:
                    errs.append(f"{t}: no block_number (reorg-safety)"); ck_ok = False
                if "tx_hash" not in seg:
                    errs.append(f"{t}: ORDER BY missing tx_hash"); ck_ok = False
                if t != "smart_money_events" and "log_index" not in seg:
                    errs.append(f"{t}: ORDER BY missing log_index"); ck_ok = False
            if ck_ok:
                print("  ✓ event tables: ReplacingMergeTree + PARTITION BY + block_number + tx/log key")
            for t in ["wallet_positions","token_metrics"]:
                if "ReplacingMergeTree(" in stmts.get(t, ""):
                    print(f"  ✓ {t}: ReplacingMergeTree(version) snapshot dedupe")
                else:
                    errs.append(f"{t}: expected versioned ReplacingMergeTree")
            # TTL strategy present on event tables
            ttl_count = sum(1 for t in event_tables if "TTL" in stmts.get(t, ""))
            print(f"  ✓ TTL strategy on {ttl_count}/{len(event_tables)} event tables")

        # Timescale-specific: hypertables + continuous aggregates + retention
        if engine == "timescale":
            # 5 hypertables expected: candles_1m base + 4 history tables.
            # (5m/15m/1h/4h are continuous aggregates, not hypertables.)
            if sql.count("create_hypertable") < 5:
                errs.append("expected ≥5 create_hypertable calls (candles_1m + 4 history)")
            else:
                print(f"  ✓ {sql.count('create_hypertable')} hypertables (candles_1m + history)")
            if sql.count("timescaledb.continuous") < 4:
                errs.append("expected 4 continuous aggregates (5m/15m/1h/4h)")
            else:
                print("  ✓ 4 continuous aggregates (5m/15m/1h/4h)")
            if "add_retention_policy" not in sql:
                errs.append("no retention policies")
            else:
                print(f"  ✓ {sql.count('add_retention_policy')} retention policies")

        # Postgres-specific: FK targets must exist; constraints present
        if engine in ("postgres","graph"):
            defs = tables_defined(sql)
            fks = re.findall(r"REFERENCES\s+(?:[a-z_]+\.)?([a-z_0-9]+)\s*\(", sql, re.I)
            unresolved = sorted(set(fk for fk in fks if fk not in defs))
            # graph may FK into postgres core; allow known external targets
            external_ok = {"user_accounts","token_registry"}
            unresolved = [u for u in unresolved if u not in external_ok]
            if unresolved:
                errs.append(f"unresolved FK targets: {unresolved}")
            else:
                print(f"  ✓ all {len(fks)} FK references resolve")
            if engine == "postgres":
                checks = sql.count("CHECK (")
                idx = sql.count("CREATE INDEX")
                print(f"  ✓ {checks} CHECK constraints, {idx} indexes")

        if engine == "graph":
            if "RECURSIVE" not in sql.upper():
                errs.append("no recursive traversal (influence support)")
            else:
                print("  ✓ recursive neighbor traversal present")
            if "influence" not in sql:
                errs.append("no influence scoring")
            else:
                print("  ✓ influence iteration function present")

        if errs:
            overall_ok = False
            print(f"  ✗ {len(errs)} issue(s):")
            for e in errs:
                print(f"      - {e}")
        else:
            print(f"  PASS")

    print("\n" + "="*70)
    print("RESULT:", "PASS — all structural checks green" if overall_ok else "FAIL — see issues above")
    print("="*70)
    sys.exit(0 if overall_ok else 1)

if __name__ == "__main__":
    main()
