#!/usr/bin/env bash
# CoinDex DB migration runner. Applies migrations in order to each engine.
# Requires the target engines to be reachable; reads connection info from env.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "== ClickHouse =="
for f in "$HERE"/migrations/clickhouse/*.sql; do
  echo "  applying $(basename "$f")"
  clickhouse-client --host "${CLICKHOUSE_HOST:-localhost}" \
    --user "${CLICKHOUSE_USER:-coindex}" --password "${CLICKHOUSE_PASSWORD:-coindex}" \
    --multiquery < "$f"
done

echo "== TimescaleDB =="
for f in "$HERE"/migrations/timescale/*.sql; do
  echo "  applying $(basename "$f")"
  psql "${TIMESCALE_DSN:?set TIMESCALE_DSN}" -v ON_ERROR_STOP=1 -f "$f"
done

echo "== PostgreSQL =="
for f in "$HERE"/migrations/postgres/*.sql; do
  echo "  applying $(basename "$f")"
  psql "${POSTGRES_DSN:?set POSTGRES_DSN}" -v ON_ERROR_STOP=1 -f "$f"
done

echo "== Graph (PostgreSQL property graph) =="
for f in "$HERE"/migrations/graph/*.sql; do
  echo "  applying $(basename "$f")"
  psql "${POSTGRES_DSN:?set POSTGRES_DSN}" -v ON_ERROR_STOP=1 -f "$f"
done

echo "All migrations applied."
