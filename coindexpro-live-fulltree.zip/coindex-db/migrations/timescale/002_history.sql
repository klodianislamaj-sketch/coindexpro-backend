-- =============================================================================
-- CoinDex TimescaleDB migration 002 — history hypertables
-- =============================================================================
-- Time-series histories that power charts and alerts (trust drops, whale flow,
-- sector rotation). Each is a hypertable with chunking + retention sized to its
-- access pattern. Written by the respective engines from REAL data only.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- liquidity_history  (per-pool liquidity over time)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS liquidity_history (
    chain        text        NOT NULL,
    pool_address text        NOT NULL,
    ts           timestamptz NOT NULL,
    liq_usd      numeric     NOT NULL,
    reserve0     numeric,
    reserve1     numeric,
    PRIMARY KEY (chain, pool_address, ts)
);
SELECT create_hypertable('liquidity_history', 'ts',
    chunk_time_interval => INTERVAL '1 day', if_not_exists => TRUE);
CREATE INDEX IF NOT EXISTS idx_liqhist_pool
    ON liquidity_history (chain, pool_address, ts DESC);
SELECT add_retention_policy('liquidity_history', INTERVAL '365 days', if_not_exists => TRUE);

-- -----------------------------------------------------------------------------
-- trust_history  (token trust score over time; drives trust-drop alerts)
-- factors jsonb keeps the explainable breakdown alongside the score.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS trust_history (
    chain      text        NOT NULL,
    token      text        NOT NULL,
    ts         timestamptz NOT NULL,
    trust      integer     NOT NULL,
    confidence text        NOT NULL,
    factors    jsonb,
    PRIMARY KEY (chain, token, ts)
);
SELECT create_hypertable('trust_history', 'ts',
    chunk_time_interval => INTERVAL '7 days', if_not_exists => TRUE);
CREATE INDEX IF NOT EXISTS idx_trusthist_token
    ON trust_history (chain, token, ts DESC);
SELECT add_retention_policy('trust_history', INTERVAL '730 days', if_not_exists => TRUE);

-- -----------------------------------------------------------------------------
-- whale_history  (large prints over time; per-wallet and per-token access)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS whale_history (
    chain   text        NOT NULL,
    wallet  text        NOT NULL,
    ts      timestamptz NOT NULL,
    token   text        NOT NULL,
    side    text        NOT NULL,
    usd     numeric     NOT NULL,
    tx_hash text        NOT NULL,
    PRIMARY KEY (chain, wallet, ts, tx_hash)
);
SELECT create_hypertable('whale_history', 'ts',
    chunk_time_interval => INTERVAL '1 day', if_not_exists => TRUE);
CREATE INDEX IF NOT EXISTS idx_whalehist_token ON whale_history (chain, token, ts DESC);
CREATE INDEX IF NOT EXISTS idx_whalehist_wallet ON whale_history (chain, wallet, ts DESC);
SELECT add_retention_policy('whale_history', INTERVAL '365 days', if_not_exists => TRUE);

-- -----------------------------------------------------------------------------
-- sector_history  (aggregate flow per sector over time)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sector_history (
    sector      text        NOT NULL,
    ts          timestamptz NOT NULL,
    inflow_usd  numeric     NOT NULL DEFAULT 0,
    outflow_usd numeric     NOT NULL DEFAULT 0,
    volume_usd  numeric     NOT NULL DEFAULT 0,
    net_usd     numeric GENERATED ALWAYS AS (inflow_usd - outflow_usd) STORED,
    PRIMARY KEY (sector, ts)
);
SELECT create_hypertable('sector_history', 'ts',
    chunk_time_interval => INTERVAL '1 day', if_not_exists => TRUE);
SELECT add_retention_policy('sector_history', INTERVAL '365 days', if_not_exists => TRUE);
