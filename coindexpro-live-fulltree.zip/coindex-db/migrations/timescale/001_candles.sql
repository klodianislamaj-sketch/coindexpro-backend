-- =============================================================================
-- CoinDex TimescaleDB migration 001 — candles
-- =============================================================================
-- candles_1m is the only WRITTEN candle table (populated by the enricher from
-- enriched swaps). 5m/15m/1h/4h are CONTINUOUS AGGREGATES maintained
-- automatically by Timescale — no duplicate write path, always consistent with
-- the 1m base. Retention drops raw 1m after 90 days while rollups persist.
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS timescaledb;

-- -----------------------------------------------------------------------------
-- candles_1m  (base hypertable)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS candles_1m (
    chain        text        NOT NULL,
    pool_address text        NOT NULL,
    bucket       timestamptz NOT NULL,
    open         numeric     NOT NULL,
    high         numeric     NOT NULL,
    low          numeric     NOT NULL,
    close        numeric     NOT NULL,
    volume_usd   numeric     NOT NULL DEFAULT 0,
    trades       integer     NOT NULL DEFAULT 0,
    PRIMARY KEY (chain, pool_address, bucket)
);

SELECT create_hypertable('candles_1m', 'bucket',
    chunk_time_interval => INTERVAL '1 day',
    if_not_exists => TRUE);

-- Index for the dominant read: one pool's candles over a time range.
CREATE INDEX IF NOT EXISTS idx_candles1m_pool_time
    ON candles_1m (chain, pool_address, bucket DESC);

-- -----------------------------------------------------------------------------
-- Continuous aggregates: 5m, 15m, 1h, 4h — all derived from candles_1m.
-- materialized_only=false lets reads combine materialized history with the
-- newest (not-yet-materialized) 1m rows, so the latest candle is never missing.
-- -----------------------------------------------------------------------------
CREATE MATERIALIZED VIEW IF NOT EXISTS candles_5m
WITH (timescaledb.continuous, timescaledb.materialized_only = false) AS
SELECT chain, pool_address,
       time_bucket(INTERVAL '5 minutes', bucket) AS bucket,
       first(open, bucket)  AS open,
       max(high)            AS high,
       min(low)             AS low,
       last(close, bucket)  AS close,
       sum(volume_usd)      AS volume_usd,
       sum(trades)          AS trades
FROM candles_1m
GROUP BY chain, pool_address, time_bucket(INTERVAL '5 minutes', bucket)
WITH NO DATA;

CREATE MATERIALIZED VIEW IF NOT EXISTS candles_15m
WITH (timescaledb.continuous, timescaledb.materialized_only = false) AS
SELECT chain, pool_address,
       time_bucket(INTERVAL '15 minutes', bucket) AS bucket,
       first(open, bucket) AS open, max(high) AS high,
       min(low) AS low, last(close, bucket) AS close,
       sum(volume_usd) AS volume_usd, sum(trades) AS trades
FROM candles_1m
GROUP BY chain, pool_address, time_bucket(INTERVAL '15 minutes', bucket)
WITH NO DATA;

CREATE MATERIALIZED VIEW IF NOT EXISTS candles_1h
WITH (timescaledb.continuous, timescaledb.materialized_only = false) AS
SELECT chain, pool_address,
       time_bucket(INTERVAL '1 hour', bucket) AS bucket,
       first(open, bucket) AS open, max(high) AS high,
       min(low) AS low, last(close, bucket) AS close,
       sum(volume_usd) AS volume_usd, sum(trades) AS trades
FROM candles_1m
GROUP BY chain, pool_address, time_bucket(INTERVAL '1 hour', bucket)
WITH NO DATA;

CREATE MATERIALIZED VIEW IF NOT EXISTS candles_4h
WITH (timescaledb.continuous, timescaledb.materialized_only = false) AS
SELECT chain, pool_address,
       time_bucket(INTERVAL '4 hours', bucket) AS bucket,
       first(open, bucket) AS open, max(high) AS high,
       min(low) AS low, last(close, bucket) AS close,
       sum(volume_usd) AS volume_usd, sum(trades) AS trades
FROM candles_1m
GROUP BY chain, pool_address, time_bucket(INTERVAL '4 hours', bucket)
WITH NO DATA;

-- -----------------------------------------------------------------------------
-- Refresh policies: keep aggregates current without manual refresh.
-- start_offset bounds the work window; end_offset avoids the still-filling bucket.
-- -----------------------------------------------------------------------------
SELECT add_continuous_aggregate_policy('candles_5m',
    start_offset => INTERVAL '1 hour',  end_offset => INTERVAL '5 minutes',
    schedule_interval => INTERVAL '5 minutes', if_not_exists => TRUE);
SELECT add_continuous_aggregate_policy('candles_15m',
    start_offset => INTERVAL '3 hours', end_offset => INTERVAL '15 minutes',
    schedule_interval => INTERVAL '15 minutes', if_not_exists => TRUE);
SELECT add_continuous_aggregate_policy('candles_1h',
    start_offset => INTERVAL '12 hours', end_offset => INTERVAL '1 hour',
    schedule_interval => INTERVAL '1 hour', if_not_exists => TRUE);
SELECT add_continuous_aggregate_policy('candles_4h',
    start_offset => INTERVAL '2 days', end_offset => INTERVAL '4 hours',
    schedule_interval => INTERVAL '4 hours', if_not_exists => TRUE);

-- -----------------------------------------------------------------------------
-- Retention + compression: drop raw 1m after 90 days (rollups persist);
-- compress chunks older than 7 days to cut storage.
-- -----------------------------------------------------------------------------
ALTER TABLE candles_1m SET (
    timescaledb.compress,
    timescaledb.compress_segmentby = 'chain, pool_address');
SELECT add_compression_policy('candles_1m', INTERVAL '7 days', if_not_exists => TRUE);
SELECT add_retention_policy('candles_1m', INTERVAL '90 days', if_not_exists => TRUE);
