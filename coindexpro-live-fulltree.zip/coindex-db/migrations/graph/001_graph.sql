-- =============================================================================
-- CoinDex Graph schema migration 001 — wallet relationship graph
-- =============================================================================
-- Deployable TODAY on PostgreSQL as an adjacency-list property graph. This is
-- the MVP target from the architecture doc (§3.4 / R.2). It supports the exact
-- relationships requested (co-buy, co-sell, funding, cluster) plus influence
-- traversal via recursive CTEs. At Nansen-class scale this migrates to a native
-- property graph (Neo4j) — the Cypher equivalent is included as a comment block
-- at the end so the model is unambiguous — but nothing here REQUIRES Neo4j to
-- run, which is why it ships as real Postgres DDL.
--
-- Design for graph query optimization:
--   * Directed edges stored once with (src) and (dst) indexed independently so
--     out-traversal and in-traversal are both index-only.
--   * edge_type partitions the adjacency so co-buy / funding walks don't scan
--     unrelated edges (partial indexes per hot edge_type).
--   * weight + last_seen on every edge so traversals can prune weak/old links.
--   * influence is precomputed (PageRank-style job) and stored on the node, so
--     read-time ranking is an index scan, not a graph computation.
-- =============================================================================

CREATE SCHEMA IF NOT EXISTS graph;

-- -----------------------------------------------------------------------------
-- wallet_nodes
-- -----------------------------------------------------------------------------
CREATE TABLE graph.wallet_nodes (
    chain         text NOT NULL,
    address       text NOT NULL CHECK (address = lower(address)),
    first_seen    timestamptz,
    last_seen     timestamptz,
    trade_count   bigint  NOT NULL DEFAULT 0,
    cluster_id    bigint,                         -- assigned by cluster job (nullable until run)
    influence     numeric NOT NULL DEFAULT 0,     -- precomputed PageRank-style score
    PRIMARY KEY (chain, address)
);
-- rank wallets by influence within a chain (top-influencers query)
CREATE INDEX idx_wnode_influence ON graph.wallet_nodes (chain, influence DESC);
-- membership lookups for a cluster
CREATE INDEX idx_wnode_cluster   ON graph.wallet_nodes (cluster_id) WHERE cluster_id IS NOT NULL;

-- -----------------------------------------------------------------------------
-- token_nodes
-- -----------------------------------------------------------------------------
CREATE TABLE graph.token_nodes (
    chain       text NOT NULL,
    address     text NOT NULL CHECK (address = lower(address)),
    symbol      text,
    sector      text,
    first_seen  timestamptz,
    PRIMARY KEY (chain, address)
);
CREATE INDEX idx_tnode_sector ON graph.token_nodes (sector) WHERE sector IS NOT NULL;

-- -----------------------------------------------------------------------------
-- clusters  (a detected group of coordinated wallets)
-- -----------------------------------------------------------------------------
CREATE TABLE graph.clusters (
    id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    chain       text NOT NULL,
    size        integer NOT NULL DEFAULT 0,
    strength    numeric NOT NULL DEFAULT 0,        -- aggregate edge weight / cohesion
    influence   numeric NOT NULL DEFAULT 0,        -- cluster-level influence
    detected_at timestamptz NOT NULL DEFAULT now(),
    method      text NOT NULL                      -- e.g. 'co_buy_v1' (provenance, never guessed)
);
CREATE INDEX idx_cluster_chain ON graph.clusters (chain, influence DESC);

-- -----------------------------------------------------------------------------
-- wallet_edges  (directed relationships between wallets)
-- One physical table for all wallet→wallet edge types keeps traversal joins
-- uniform; partial indexes give each hot edge_type its own fast path.
-- -----------------------------------------------------------------------------
CREATE TABLE graph.wallet_edges (
    chain     text NOT NULL,
    src       text NOT NULL CHECK (src = lower(src)),
    dst       text NOT NULL CHECK (dst = lower(dst)),
    edge_type text NOT NULL CHECK (edge_type IN ('co_buy','co_sell','funded','cluster')),
    weight    numeric NOT NULL DEFAULT 1,          -- shared-token count or funding USD
    shared_tokens integer NOT NULL DEFAULT 0,
    first_seen timestamptz,
    last_seen  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (chain, src, dst, edge_type),
    CONSTRAINT chk_no_self_edge CHECK (src <> dst)
);
-- out-traversal (neighbors of src) per edge type
CREATE INDEX idx_wedge_src_cobuy  ON graph.wallet_edges (chain, src, weight DESC) WHERE edge_type = 'co_buy';
CREATE INDEX idx_wedge_src_cosell ON graph.wallet_edges (chain, src, weight DESC) WHERE edge_type = 'co_sell';
CREATE INDEX idx_wedge_src_funded ON graph.wallet_edges (chain, src, weight DESC) WHERE edge_type = 'funded';
-- in-traversal (who points at dst) — funding sources, etc.
CREATE INDEX idx_wedge_dst        ON graph.wallet_edges (chain, dst, edge_type);

-- -----------------------------------------------------------------------------
-- wallet_token_edges  (wallet→token TRADED edge; co-buy/co-sell derive from this)
-- -----------------------------------------------------------------------------
CREATE TABLE graph.wallet_token_edges (
    chain      text NOT NULL,
    wallet     text NOT NULL CHECK (wallet = lower(wallet)),
    token      text NOT NULL CHECK (token = lower(token)),
    buys       integer NOT NULL DEFAULT 0,
    sells      integer NOT NULL DEFAULT 0,
    usd_total  numeric NOT NULL DEFAULT 0,
    last_seen  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (chain, wallet, token)
);
CREATE INDEX idx_wtedge_token ON graph.wallet_token_edges (chain, token);

-- =============================================================================
-- Influence traversal support
-- =============================================================================
-- 1) Bounded N-hop neighborhood from a seed wallet over a chosen edge type.
--    Recursive CTE with a depth cap + visited-set via array; index-backed by the
--    per-edge-type partial indexes above. Used for cluster expansion + "who is
--    connected to this wallet" without precomputed clusters.
CREATE OR REPLACE FUNCTION graph.neighbors(
    p_chain text, p_seed text, p_edge_type text, p_max_depth int DEFAULT 2)
RETURNS TABLE (address text, depth int, path_weight numeric) AS $$
WITH RECURSIVE walk AS (
    SELECT e.dst AS address, 1 AS depth, e.weight AS path_weight,
           ARRAY[e.src, e.dst] AS visited
    FROM graph.wallet_edges e
    WHERE e.chain = p_chain AND e.src = lower(p_seed) AND e.edge_type = p_edge_type
  UNION ALL
    SELECT e.dst, w.depth + 1, w.path_weight + e.weight, w.visited || e.dst
    FROM walk w
    JOIN graph.wallet_edges e
      ON e.chain = p_chain AND e.src = w.address AND e.edge_type = p_edge_type
    WHERE w.depth < p_max_depth
      AND NOT e.dst = ANY(w.visited)             -- cycle guard
)
SELECT address, min(depth) AS depth, max(path_weight) AS path_weight
FROM walk GROUP BY address;
$$ LANGUAGE sql STABLE;

-- 2) Iterative PageRank-style influence (one iteration as a set-based UPDATE).
--    The cluster/influence JOB calls this repeatedly until convergence; storing
--    the result on wallet_nodes.influence keeps read-time ranking O(index scan).
--    Damping 0.85 over the 'funded' + 'co_buy' edge set.
CREATE OR REPLACE FUNCTION graph.influence_iteration(p_chain text, p_damping numeric DEFAULT 0.85)
RETURNS void AS $$
BEGIN
    WITH outdeg AS (
        SELECT src, sum(weight) AS w_out
        FROM graph.wallet_edges
        WHERE chain = p_chain AND edge_type IN ('funded','co_buy')
        GROUP BY src
    ),
    contrib AS (
        SELECT e.dst AS address,
               sum(n.influence * (e.weight / NULLIF(o.w_out, 0))) AS rank_in
        FROM graph.wallet_edges e
        JOIN graph.wallet_nodes n ON n.chain = e.chain AND n.address = e.src
        JOIN outdeg o ON o.src = e.src
        WHERE e.chain = p_chain AND e.edge_type IN ('funded','co_buy')
        GROUP BY e.dst
    )
    UPDATE graph.wallet_nodes n
    SET influence = (1 - p_damping) + p_damping * COALESCE(c.rank_in, 0)
    FROM contrib c
    WHERE n.chain = p_chain AND n.address = c.address;
END;
$$ LANGUAGE plpgsql;

-- =============================================================================
-- Neo4j (scale target) equivalent — reference only, NOT executed by this migration:
--   (:Wallet {chain,address,influence,cluster_id})
--   (:Token  {chain,address,sector})
--   (:Wallet)-[:CO_BUY  {weight,shared_tokens,last_seen}]->(:Wallet)
--   (:Wallet)-[:CO_SELL {weight,shared_tokens,last_seen}]->(:Wallet)
--   (:Wallet)-[:FUNDED  {amount_usd,tx,ts}]->(:Wallet)
--   (:Wallet)-[:TRADED  {buys,sells,usd}]->(:Token)
--   influence via GDS PageRank on FUNDED+CO_BUY; clusters via Louvain/WCC.
-- =============================================================================
