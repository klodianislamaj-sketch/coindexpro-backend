-- =============================================================================
-- CoinDex ClickHouse migration 002 — derived / enriched tables
-- =============================================================================
-- These are written by downstream jobs (enricher, wallet-engine, token-intel,
-- smart-money), NOT the raw indexer. They still follow the same dedupe + reorg
-- + partition discipline so a reorg or a job re-run is idempotent.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- wallet_trades  (swaps attributed to a wallet, with USD — built by enricher)
-- Read pattern: "all trades for wallet X" and "all trades of token T" → wallet
-- leads the ORDER BY; a token bloom index supports the secondary access path.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS coindex.wallet_trades
(
    chain        LowCardinality(String),
    wallet       String,
    token        String,
    block_number UInt64,
    block_time   DateTime64(3, 'UTC'),
    tx_hash      FixedString(66),
    log_index    UInt32,
    side         Enum8('buy' = 1, 'sell' = 2),
    qty          String,                        -- raw token qty as decimal string
    price_usd    Decimal64(18),
    usd          Decimal64(2),
    dex          LowCardinality(String),
    INDEX idx_token token TYPE bloom_filter(0.01) GRANULARITY 4
)
ENGINE = ReplacingMergeTree
PARTITION BY toYYYYMM(block_time)
ORDER BY (chain, wallet, token, block_time, tx_hash, log_index)
TTL toDateTime(block_time) + INTERVAL 24 MONTH
SETTINGS index_granularity = 8192;

-- -----------------------------------------------------------------------------
-- wallet_positions  (current open position + realized PnL per wallet/token)
-- Updated by the FIFO cost-basis job. ReplacingMergeTree(updated_at) keeps the
-- latest snapshot per (chain, wallet, token). No history here — that is the
-- wallet_trades table. PnL is computed from real fills, never estimated.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS coindex.wallet_positions
(
    chain          LowCardinality(String),
    wallet         String,
    token          String,
    qty_open       String,                      -- remaining open qty (decimal str)
    cost_basis_usd Decimal64(2),                -- USD cost of the open qty (FIFO)
    realized_usd   Decimal64(2),                -- realized PnL to date
    avg_entry_usd  Decimal64(18),
    first_buy      DateTime64(3, 'UTC'),
    last_action    DateTime64(3, 'UTC'),
    updated_at     DateTime64(3, 'UTC'),
    INDEX idx_token token TYPE bloom_filter(0.01) GRANULARITY 4
)
ENGINE = ReplacingMergeTree(updated_at)
ORDER BY (chain, wallet, token)
SETTINGS index_granularity = 8192;

-- -----------------------------------------------------------------------------
-- token_metrics  (rolling per-token aggregates; one row per token per sample)
-- Built by the token-intel job. ReplacingMergeTree(ts) so re-samples overwrite.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS coindex.token_metrics
(
    chain               LowCardinality(String),
    token               String,
    ts                  DateTime64(3, 'UTC'),
    holders             UInt64,
    top10_concentration Decimal32(4),           -- 0..1 share held by top 10
    dev_concentration   Decimal32(4),
    liq_usd             Decimal64(2),
    vol24h_usd          Decimal64(2),
    volatility          Decimal32(6),           -- stdev of returns over window
    holder_growth_24h   Int64
)
ENGINE = ReplacingMergeTree(ts)
PARTITION BY toYYYYMM(ts)
ORDER BY (chain, token, ts)
TTL toDateTime(ts) + INTERVAL 24 MONTH
SETTINGS index_granularity = 8192;

-- -----------------------------------------------------------------------------
-- smart_money_events  (emitted when a high-conviction wallet acts — Phase 6)
-- conviction + reason are stored so the score is explainable downstream.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS coindex.smart_money_events
(
    chain        LowCardinality(String),
    wallet       String,
    token        String,
    block_number UInt64,
    block_time   DateTime64(3, 'UTC'),
    tx_hash      FixedString(66),
    side         Enum8('buy' = 1, 'sell' = 2),
    usd          Decimal64(2),
    conviction   UInt8,                          -- 0..100, transparent formula
    reason       String,                         -- e.g. "repeat_buyer;multi_chain"
    INDEX idx_wallet wallet TYPE bloom_filter(0.01) GRANULARITY 4,
    INDEX idx_token  token  TYPE bloom_filter(0.01) GRANULARITY 4
)
ENGINE = ReplacingMergeTree
PARTITION BY toYYYYMM(block_time)
ORDER BY (chain, wallet, block_time, tx_hash)
TTL toDateTime(block_time) + INTERVAL 24 MONTH
SETTINGS index_granularity = 8192;

-- -----------------------------------------------------------------------------
-- Read-time exactness helpers (documented, not executed here):
--   * For positions/metrics, prefer `... FINAL` or argMax(col, updated_at)
--     to collapse un-merged duplicates deterministically.
--   * Reorg rollback (any event table): run the indexer's
--     ALTER TABLE <t> DELETE WHERE chain = ? AND block_number >= <fork>;
-- -----------------------------------------------------------------------------
