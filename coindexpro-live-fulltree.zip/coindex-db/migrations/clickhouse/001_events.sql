-- =============================================================================
-- CoinDex ClickHouse migration 001 — raw event tables
-- =============================================================================
-- Design principles applied to every table:
--   * Dedupe:   ReplacingMergeTree with the natural idempotency key
--               (chain, tx_hash, log_index) in the ORDER BY. At-least-once
--               writes from the indexer collapse to one row on background merge.
--               FINAL or argMax() is used at read time where exactness matters.
--   * Partition: monthly (toYYYYMM(block_time)) so reorg-range deletes,
--               retention drops, and time-bounded scans touch few parts.
--   * Reorg:    every event table carries block_number so a reorg rollback is
--               ALTER TABLE ... DELETE WHERE chain=? AND block_number>=fork.
--   * Indexing: bloom_filter data-skipping indexes on high-cardinality columns
--               that are filtered but not the leading ORDER BY key (wallet,
--               token), turning point lookups into part-pruned scans.
--   * TTL:      raw events expire after a hot window; ClickHouse moves/drops by
--               partition. Derived/rollup tables keep longer (set per table).
-- =============================================================================

CREATE DATABASE IF NOT EXISTS coindex;

-- -----------------------------------------------------------------------------
-- swaps
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS coindex.swaps
(
    chain         LowCardinality(String),
    block_number  UInt64,
    block_time    DateTime64(3, 'UTC'),
    tx_hash       FixedString(66),
    log_index     UInt32,
    pool_address  String,
    token_in      String,
    token_out     String,
    wallet        String,
    amount_in     String,                       -- raw uint256 as decimal string
    amount_out    String,
    amount_usd    Decimal64(2) DEFAULT 0,       -- filled by enricher; 0 = not priced
    price_usd     Decimal64(18) DEFAULT 0,
    side          Enum8('unknown' = 0, 'buy' = 1, 'sell' = 2) DEFAULT 'unknown',
    dex           LowCardinality(String),
    INDEX idx_wallet wallet TYPE bloom_filter(0.01) GRANULARITY 4,
    INDEX idx_pool   pool_address TYPE bloom_filter(0.01) GRANULARITY 4
)
ENGINE = ReplacingMergeTree
PARTITION BY toYYYYMM(block_time)
ORDER BY (chain, token_in, block_time, tx_hash, log_index)
TTL toDateTime(block_time) + INTERVAL 18 MONTH
SETTINGS index_granularity = 8192;

-- -----------------------------------------------------------------------------
-- transfers  (ERC20 Transfer logs; drives holder tracking + funding graph)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS coindex.transfers
(
    chain         LowCardinality(String),
    block_number  UInt64,
    block_time    DateTime64(3, 'UTC'),
    tx_hash       FixedString(66),
    log_index     UInt32,
    token         String,
    from_addr     String,
    to_addr       String,
    amount        String,
    INDEX idx_from from_addr TYPE bloom_filter(0.01) GRANULARITY 4,
    INDEX idx_to   to_addr   TYPE bloom_filter(0.01) GRANULARITY 4
)
ENGINE = ReplacingMergeTree
PARTITION BY toYYYYMM(block_time)
ORDER BY (chain, token, block_time, tx_hash, log_index)
TTL toDateTime(block_time) + INTERVAL 12 MONTH
SETTINGS index_granularity = 8192;

-- -----------------------------------------------------------------------------
-- lp_events  (Mint/Burn = liquidity add/remove)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS coindex.lp_events
(
    chain         LowCardinality(String),
    block_number  UInt64,
    block_time    DateTime64(3, 'UTC'),
    tx_hash       FixedString(66),
    log_index     UInt32,
    pool_address  String,
    provider      String,
    kind          Enum8('add' = 1, 'remove' = 2),
    amount0       String,
    amount1       String,
    amount_usd    Decimal64(2) DEFAULT 0,       -- enricher-filled
    INDEX idx_pool pool_address TYPE bloom_filter(0.01) GRANULARITY 4
)
ENGINE = ReplacingMergeTree
PARTITION BY toYYYYMM(block_time)
ORDER BY (chain, pool_address, block_time, tx_hash, log_index)
TTL toDateTime(block_time) + INTERVAL 18 MONTH
SETTINGS index_granularity = 8192;

-- -----------------------------------------------------------------------------
-- token_mints  (Transfer from 0x0 = mint; separated for supply tracking)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS coindex.token_mints
(
    chain         LowCardinality(String),
    block_number  UInt64,
    block_time    DateTime64(3, 'UTC'),
    tx_hash       FixedString(66),
    log_index     UInt32,
    token         String,
    to_addr       String,
    amount        String,
    INDEX idx_token token TYPE bloom_filter(0.01) GRANULARITY 4
)
ENGINE = ReplacingMergeTree
PARTITION BY toYYYYMM(block_time)
ORDER BY (chain, token, block_time, tx_hash, log_index)
TTL toDateTime(block_time) + INTERVAL 24 MONTH
SETTINGS index_granularity = 8192;
