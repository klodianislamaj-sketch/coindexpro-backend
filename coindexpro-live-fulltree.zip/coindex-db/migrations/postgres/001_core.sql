-- =============================================================================
-- CoinDex PostgreSQL migration 001 — relational truth
-- =============================================================================
-- Strong constraints + referential integrity. This is the system of record for
-- registry, labels, users, billing, alerts. Anti-fabrication rules are encoded
-- as constraints (e.g. a wallet label MUST carry a source and a confidence).
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;     -- gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS pg_trgm;       -- trigram search on symbols/names

-- -----------------------------------------------------------------------------
-- token_registry  (canonical tokens; official flag is earned, never assumed)
-- -----------------------------------------------------------------------------
CREATE TABLE token_registry (
    id            bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    chain         text    NOT NULL,
    address       text    NOT NULL,
    symbol        text,
    name          text,
    decimals      smallint CHECK (decimals BETWEEN 0 AND 36),
    is_official   boolean NOT NULL DEFAULT false,
    website       text,
    socials       jsonb   NOT NULL DEFAULT '{}'::jsonb,
    aliases       text[]  NOT NULL DEFAULT '{}',
    created_block bigint,
    created_at    timestamptz,
    indexed_at    timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_token UNIQUE (chain, address),
    CONSTRAINT chk_addr_lower CHECK (address = lower(address))
);
CREATE INDEX idx_token_symbol      ON token_registry (symbol);
CREATE INDEX idx_token_symbol_trgm ON token_registry USING gin (symbol gin_trgm_ops);
CREATE INDEX idx_token_name_trgm   ON token_registry USING gin (name gin_trgm_ops);

-- scam-clone linkage: an impostor points at the token it imitates
CREATE TABLE token_clones (
    clone_id    bigint NOT NULL REFERENCES token_registry(id) ON DELETE CASCADE,
    imitates_id bigint NOT NULL REFERENCES token_registry(id) ON DELETE CASCADE,
    evidence    jsonb  NOT NULL,
    confidence  numeric NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    PRIMARY KEY (clone_id, imitates_id),
    CONSTRAINT chk_not_self CHECK (clone_id <> imitates_id)
);

-- -----------------------------------------------------------------------------
-- wallet_labels  (anti-fabrication: source + confidence are NOT NULL)
-- -----------------------------------------------------------------------------
CREATE TABLE wallet_labels (
    id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    chain      text NOT NULL,
    address    text NOT NULL CHECK (address = lower(address)),
    label_type text NOT NULL CHECK (label_type IN
        ('exchange','market_maker','dev','sniper','insider','vc',
         'smart_money','bridge','cex_hot','team','lp_provider','treasury')),
    entity     text,
    source     text    NOT NULL,                  -- 'manual:<analyst>' | 'auto:<rule>' | 'vendor:<name>'
    confidence numeric NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    evidence   jsonb   NOT NULL DEFAULT '{}'::jsonb,
    active     boolean NOT NULL DEFAULT true,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_label UNIQUE (chain, address, label_type, source)
);
CREATE INDEX idx_label_addr ON wallet_labels (chain, address) WHERE active;
CREATE INDEX idx_label_type ON wallet_labels (label_type) WHERE active;

-- label history: every change is appended (provenance + conflict resolution)
CREATE TABLE wallet_label_history (
    id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    label_id   bigint REFERENCES wallet_labels(id) ON DELETE SET NULL,
    chain      text NOT NULL,
    address    text NOT NULL,
    action     text NOT NULL CHECK (action IN ('add','update','revoke','conflict')),
    payload    jsonb NOT NULL,
    actor      text NOT NULL,                      -- who/what made the change
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_labelhist_addr ON wallet_label_history (chain, address, created_at DESC);

-- -----------------------------------------------------------------------------
-- user_accounts
-- -----------------------------------------------------------------------------
CREATE TABLE user_accounts (
    id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    email      text UNIQUE NOT NULL CHECK (position('@' in email) > 1),
    tier       text NOT NULL DEFAULT 'free' CHECK (tier IN ('free','premium','enterprise')),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE api_keys (
    key_hash      text PRIMARY KEY,               -- store hash, never the raw key
    user_id       uuid NOT NULL REFERENCES user_accounts(id) ON DELETE CASCADE,
    label         text,
    quota_per_min integer NOT NULL DEFAULT 60  CHECK (quota_per_min  > 0),
    quota_per_day integer NOT NULL DEFAULT 10000 CHECK (quota_per_day > 0),
    revoked       boolean NOT NULL DEFAULT false,
    created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_apikey_user ON api_keys (user_id) WHERE NOT revoked;

-- -----------------------------------------------------------------------------
-- premium_subscriptions
-- -----------------------------------------------------------------------------
CREATE TABLE premium_subscriptions (
    user_id            uuid PRIMARY KEY REFERENCES user_accounts(id) ON DELETE CASCADE,
    stripe_sub_id      text UNIQUE,
    status             text NOT NULL CHECK (status IN
        ('active','trialing','past_due','canceled','incomplete')),
    plan               text NOT NULL CHECK (plan IN ('premium','enterprise')),
    current_period_end timestamptz,
    created_at         timestamptz NOT NULL DEFAULT now(),
    updated_at         timestamptz NOT NULL DEFAULT now()
);

-- -----------------------------------------------------------------------------
-- alerts  (user-defined rules; fire history kept separately)
-- -----------------------------------------------------------------------------
CREATE TABLE alerts (
    id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id    uuid NOT NULL REFERENCES user_accounts(id) ON DELETE CASCADE,
    kind       text NOT NULL CHECK (kind IN
        ('price','liquidity','volume','whale_buy','whale_sell','dev_sell',
         'trust_drop','risk_change','unlock','smart_money','holder_change')),
    target     jsonb   NOT NULL,                  -- {chain, token?, threshold?, ...}
    channels   jsonb   NOT NULL,                  -- [{type:'telegram', dest:'...'}]
    enabled    boolean NOT NULL DEFAULT true,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_alerts_user ON alerts (user_id) WHERE enabled;
CREATE INDEX idx_alerts_kind ON alerts (kind) WHERE enabled;

CREATE TABLE alert_fires (
    id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    alert_id   bigint NOT NULL REFERENCES alerts(id) ON DELETE CASCADE,
    fired_at   timestamptz NOT NULL DEFAULT now(),
    payload    jsonb NOT NULL,
    dedupe_key text NOT NULL,                     -- cooldown/dedupe enforcement
    CONSTRAINT uq_fire_dedupe UNIQUE (alert_id, dedupe_key)
);
CREATE INDEX idx_firehist_alert ON alert_fires (alert_id, fired_at DESC);

-- -----------------------------------------------------------------------------
-- watchlists
-- -----------------------------------------------------------------------------
CREATE TABLE watchlists (
    id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id    uuid NOT NULL REFERENCES user_accounts(id) ON DELETE CASCADE,
    name       text NOT NULL,
    items      jsonb NOT NULL DEFAULT '[]'::jsonb,  -- [{chain,address,kind}]
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_watchlist_name UNIQUE (user_id, name)
);
CREATE INDEX idx_watchlist_user ON watchlists (user_id);

-- -----------------------------------------------------------------------------
-- portfolios  (positions DERIVED from indexed history; never estimated)
-- -----------------------------------------------------------------------------
CREATE TABLE portfolios (
    id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id    uuid NOT NULL REFERENCES user_accounts(id) ON DELETE CASCADE,
    chain      text NOT NULL,
    wallet     text NOT NULL CHECK (wallet = lower(wallet)),
    synced_at  timestamptz,
    sync_state text NOT NULL DEFAULT 'unsynced'
        CHECK (sync_state IN ('unsynced','syncing','synced','error')),
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_portfolio UNIQUE (user_id, chain, wallet)
);
CREATE INDEX idx_portfolio_user ON portfolios (user_id);

-- updated_at trigger for mutable tables
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated  BEFORE UPDATE ON user_accounts
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_subs_updated   BEFORE UPDATE ON premium_subscriptions
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
