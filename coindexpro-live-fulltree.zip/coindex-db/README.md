# coindex-db — Phase 2 database layer

Real, deployable SQL migrations for CoinDex Pro's storage tier. Four engines,
each chosen per workload. **No pseudo-schema** — every file is executable DDL.

## Layout

```
migrations/
  clickhouse/   001_events.sql      swaps, transfers, lp_events, token_mints
                002_derived.sql     wallet_trades, wallet_positions, token_metrics, smart_money_events
  timescale/    001_candles.sql     candles_1m hypertable + 5m/15m/1h/4h continuous aggregates
                002_history.sql     liquidity_history, trust_history, whale_history, sector_history
  postgres/     001_core.sql        token_registry, wallet_labels, user_accounts, alerts,
                                    watchlists, portfolios, premium_subscriptions (+ api_keys, fires, clones)
  graph/        001_graph.sql       wallet/token nodes, co-buy/co-sell/funding/cluster edges,
                                    recursive neighbor traversal + PageRank-style influence
scripts/
  migrate.sh    ordered runner (clickhouse-client / psql)
  validate.py   static structural validator (no engine required)
```

## Deploy

```bash
# ClickHouse
export CLICKHOUSE_HOST=... CLICKHOUSE_USER=... CLICKHOUSE_PASSWORD=...
# TimescaleDB (Postgres + timescaledb extension)
export TIMESCALE_DSN="postgres://user:pass@host:5432/coindex_ts"
# PostgreSQL (relational + graph)
export POSTGRES_DSN="postgres://user:pass@host:5432/coindex"

scripts/migrate.sh
```

## Design highlights

- **ClickHouse** — `ReplacingMergeTree` keyed on `(chain, …, tx_hash, log_index)` makes at-least-once writes idempotent; monthly `PARTITION BY toYYYYMM(block_time)`; `block_number` on every event table so a reorg rollback is `ALTER TABLE … DELETE WHERE chain=? AND block_number>=fork`; bloom-filter skip indexes on wallet/pool/token; per-table `TTL`.
- **TimescaleDB** — `candles_1m` is the only written candle table; 5m/15m/1h/4h are **continuous aggregates** (always consistent, no duplicate write path) with refresh policies; compression + 90-day retention on raw 1m; history hypertables with per-table retention.
- **PostgreSQL** — full referential integrity, `CHECK` constraints encoding anti-fabrication rules (a `wallet_labels` row **must** carry `source` + `confidence`; portfolio positions are derived, never estimated), `pg_trgm` search indexes, `updated_at` triggers.
- **Graph** — deployable today as a Postgres adjacency property-graph; per-edge-type partial indexes for fast out/in traversal; recursive-CTE neighbor expansion with a cycle guard; iterative PageRank-style `influence` stored on the node so read-time ranking is an index scan. Neo4j Cypher equivalent included as a comment for the scale target.

## Honest status

- **These migrations are written to be deployable but have NOT been executed here** — this environment has no ClickHouse / Postgres / Timescale engine and no network to install one. Verification was therefore **static/structural** (`scripts/validate.py`): required tables present, parens/quotes balanced, FK targets resolve, ClickHouse dedupe/partition/reorg/TTL discipline present, Timescale hypertables + continuous aggregates + retention present, graph traversal + influence present. All green.
- **Before production:** run `scripts/migrate.sh` against real engines, confirm the `timescaledb` extension version supports `materialized_only=false` aggregates (TimescaleDB ≥ 2.x), and load-test write throughput + the influence job at expected volume. Static validation cannot prove runtime behaviour — only that the DDL is structurally sound.
- **No API and no service layer** are included, by design — this phase is database-only.
