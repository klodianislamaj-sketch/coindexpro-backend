# coindex-label-engine — Phase 7

Attaches **provable** labels to wallets/contracts. The non-negotiable rule:
every label carries `source`, `confidence`, and `proof`. A label without proof is
rejected at import and never stored; a wallet with no proven label returns
`{available:false}`. No invented labels, no heuristic-only labels.

## Label classes

`exchange`, `exchange_deposit`, `bridge`, `lp_locker`, `dev`, `sniper`,
`mev_bot`, `multisig`, `dao_treasury` — enforced by both the importer's class
gate and the DB CHECK.

## Schema (extends Phase 2 — does not rebuild it)

- **`label_sources`** *(new)* — registry of where labels come from: `name`,
  `kind` (csv|json|partner_feed|onchain|manual), `trust_tier` (1–5), and an
  optional ed25519 `public_key` for signed feeds.
- **`wallet_labels`** *(Phase 2 table, extended)* — adds `proof jsonb` +
  `source_id` FK, plus a CHECK that **engine labels must carry non-empty proof**
  (`source_id IS NULL OR (proof IS NOT NULL AND proof <> '{}')`). Phase 2 rows
  are untouched. The class CHECK is widened to the Phase 7 set.
- **`label_history`** *(view)* — onto the existing `wallet_label_history`, so the
  documented Phase 7 name resolves without duplicating data.

The migration is idempotent (`IF [NOT] EXISTS`, `DROP CONSTRAINT IF EXISTS`) and
non-destructive. Apply it **after** the Phase 2 Postgres migrations.

## API

| Endpoint | Behaviour |
|---|---|
| `GET /labels/:chain/:address` | All proven labels + a `resolved` primary (confidence × trust tier). `{available:false}` if none. |
| `GET /labels/:chain/:address/history` | Change history from the history view. |
| `POST /labels/import?format=csv\|json\|feed` | Auth-gated (`X-Import-Key`). Imports labels; returns `{imported, accepted, rejected[]}`. |

### Import formats

- **CSV** — header `chain,address,class,entity,confidence,proof` (proof = a JSON
  object string, **required**). `?source=<name>&trust_tier=1..5`.
- **JSON** — array of `{chain,address,class,entity,confidence,proof}` (proof
  **required**). `?source=<name>&trust_tier=1..5`.
- **Signed partner feed** — `?format=feed&partner=<name>`. Body is
  `{partner, signature, payload}` where `signature` is a hex **Ed25519**
  signature over the exact `payload` bytes. The signature is verified against the
  partner's configured public key **before any write**; the verified signature is
  recorded into every label's proof. An unverifiable feed imports **zero** labels.

Every accepted label passes `Validate()` (source + confidence∈[0,1] + non-empty
proof + known class + lower-case 0x address). Rejected rows are returned
explicitly — nothing is silently coerced.

## Folder tree

```
cmd/label-engine/main.go           wiring, API, ops server, graceful shutdown
config/{config.go, config.yaml}
internal/
  labels/labels.go                 classes, types, Validate(), Resolve()
  verify/verify.go                 real ed25519 signed-feed verification
  importer/importer.go             CSV/JSON/feed parsing + per-row proof gate
  db/db.go                         source registry + label upsert (proof) + history + reads
  api/api.go                       3 endpoints + import auth + format dispatch
  metrics/metrics.go
migrations/postgres/001_labels.sql
Dockerfile · docker-compose.yml · README.md
```

## Run

```bash
export LABEL_ENGINE_PG_DSN=... REDIS_ADDR=... IMPORT_API_KEY=...
export PARTNER_CHAINALYSIS_PUBKEY=<ed25519-hex>   # for signed feeds
# apply migrations/postgres/001_labels.sql AFTER Phase 2 migrations
docker compose up --build
# API: http://localhost:8093   ops: http://localhost:9105/healthz /readyz /metrics
```

## Honest status

- **Real, production-shaped code, NOT compiled or run here** (no Go toolchain, no
  Postgres/Redis in the authoring environment). Static-reviewed: imports/symbols/
  signatures resolve, route ordering correct (`/history` before `/:address`),
  `c.QueryInt` is valid Fiber v2. The Ed25519 verification uses Go's stdlib
  `crypto/ed25519`; size/verify invariants confirmed. Before production:
  `go build` + `vet` + lint, signature round-trip tests, and an integration run.
- **This engine does not *derive* labels from heuristics.** It ingests labels
  from attributable sources (imports, signed feeds) that supply their own proof.
  An `onchain` source kind exists in the schema for future verifiable on-chain
  derivations (e.g. bytecode-match multisig detection), but **only** labels that
  arrive with concrete proof are ever written — there is no heuristic shortcut.
- **Proof is enforced in three places**: the importer's `Validate()` gate, the
  code path that always sets `source_id` + `proof` together, and the DB
  `chk_proof_required` CHECK. A label cannot reach storage without proof.
