-- =============================================================================
-- CoinDex Label Engine — PostgreSQL migration (Phase 7)
-- =============================================================================
-- EXTENDS the Phase 2 wallet_labels table (the source of truth) rather than
-- rebuilding it. Adds:
--   * label_sources       registry of where labels come from (+ partner keys)
--   * wallet_labels.proof  mandatory evidence for engine-created labels
--   * wallet_labels.source_id  FK into label_sources
--   * widened label_type set for the Phase 7 classes
--   * label_history       a view onto the existing wallet_label_history
-- Strict rule enforced in-schema: an engine-created label (source_id set) MUST
-- carry non-empty proof. Labels without proof cannot be inserted.
-- All statements are idempotent (IF [NOT] EXISTS) so this is safe to re-run and
-- does not destroy Phase 2 data.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- label_sources — every place a label can come from
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS label_sources (
    id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name        text NOT NULL UNIQUE,             -- 'partner:chainalysis' | 'analyst:alice' | 'import:csv:2026-06'
    kind        text NOT NULL CHECK (kind IN ('csv','json','partner_feed','onchain','manual')),
    trust_tier  smallint NOT NULL CHECK (trust_tier BETWEEN 1 AND 5),  -- 5 = highest
    public_key  text,                              -- ed25519 pubkey (hex) for partner_feed signature checks
    active      boolean NOT NULL DEFAULT true,
    created_at  timestamptz NOT NULL DEFAULT now()
);

-- -----------------------------------------------------------------------------
-- Extend wallet_labels (Phase 2 source of truth)
-- -----------------------------------------------------------------------------
ALTER TABLE wallet_labels ADD COLUMN IF NOT EXISTS proof     jsonb;
ALTER TABLE wallet_labels ADD COLUMN IF NOT EXISTS source_id bigint REFERENCES label_sources(id);

-- proof is mandatory + non-empty for engine-created labels (source_id present).
-- Phase 2 rows (source_id NULL) are unaffected, so this is non-destructive.
ALTER TABLE wallet_labels DROP CONSTRAINT IF EXISTS chk_proof_required;
ALTER TABLE wallet_labels ADD CONSTRAINT chk_proof_required
    CHECK (source_id IS NULL OR (proof IS NOT NULL AND proof <> '{}'::jsonb));

-- Widen the allowed label classes to the Phase 7 set (superset of Phase 2).
ALTER TABLE wallet_labels DROP CONSTRAINT IF EXISTS wallet_labels_label_type_check;
ALTER TABLE wallet_labels ADD CONSTRAINT wallet_labels_label_type_check
    CHECK (label_type IN (
        -- Phase 2 classes (preserved)
        'exchange','market_maker','dev','sniper','insider','vc',
        'smart_money','bridge','cex_hot','team','lp_provider','treasury',
        -- Phase 7 additions
        'exchange_deposit','lp_locker','mev_bot','multisig','dao_treasury'
    ));

-- Index to serve GET /labels/:chain/:address fast (active labels for an address).
CREATE INDEX IF NOT EXISTS idx_wallet_labels_lookup
    ON wallet_labels (chain, address) WHERE active;
CREATE INDEX IF NOT EXISTS idx_wallet_labels_source ON wallet_labels (source_id);

-- -----------------------------------------------------------------------------
-- label_history — view over the existing Phase 2 wallet_label_history so the
-- Phase 7 API can read history under the documented name without duplicating data.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW label_history AS
    SELECT id, label_id, chain, address, action, payload, actor, created_at
    FROM wallet_label_history;
