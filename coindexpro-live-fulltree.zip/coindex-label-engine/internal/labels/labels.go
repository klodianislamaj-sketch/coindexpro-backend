// Package labels defines the canonical label classes, the core types, and the
// proof/conflict rules. The central invariant: a Label is only valid if it has a
// source, a confidence in [0,1], and non-empty proof. Anything failing that is
// rejected — never stored, never served.
package labels

import (
	"errors"
	"strings"
)

// Class is a canonical label class. Only these may be applied.
type Class string

const (
	ClassExchange        Class = "exchange"
	ClassExchangeDeposit Class = "exchange_deposit"
	ClassBridge          Class = "bridge"
	ClassLPLocker        Class = "lp_locker"
	ClassDev             Class = "dev"
	ClassSniper          Class = "sniper"
	ClassMEVBot          Class = "mev_bot"
	ClassMultisig        Class = "multisig"
	ClassDAOTreasury     Class = "dao_treasury"
)

// allowed is the Phase 7 class set (the import/derive surface). The DB CHECK is
// a superset that also preserves Phase 2 classes; this gate is what the engine
// itself will write.
var allowed = map[Class]bool{
	ClassExchange: true, ClassExchangeDeposit: true, ClassBridge: true,
	ClassLPLocker: true, ClassDev: true, ClassSniper: true,
	ClassMEVBot: true, ClassMultisig: true, ClassDAOTreasury: true,
}

func ValidClass(c string) (Class, bool) {
	cl := Class(strings.ToLower(strings.TrimSpace(c)))
	return cl, allowed[cl]
}

// Source describes where a label came from.
type Source struct {
	ID        int64  `json:"id"`
	Name      string `json:"name"`
	Kind      string `json:"kind"`       // csv|json|partner_feed|onchain|manual
	TrustTier int    `json:"trust_tier"` // 1..5
	PublicKey string `json:"-"`          // never serialized
}

// Label is one attributed, proven label.
type Label struct {
	Chain      string         `json:"chain"`
	Address    string         `json:"address"`
	Class      Class          `json:"class"`
	Entity     string         `json:"entity,omitempty"`
	SourceName string         `json:"source"`
	SourceID   int64          `json:"-"`
	TrustTier  int            `json:"trust_tier"`
	Confidence float64        `json:"confidence"`
	Proof      map[string]any `json:"proof"`
}

var (
	ErrNoSource     = errors.New("label has no source")
	ErrBadConfidence = errors.New("confidence must be in [0,1]")
	ErrNoProof      = errors.New("label has no proof")
	ErrBadClass     = errors.New("unknown label class")
	ErrBadAddress   = errors.New("invalid address")
)

// Validate enforces the strict rule: source + confidence + non-empty proof, a
// known class, and a lower-case 0x address. Returns the first failure.
func (l *Label) Validate() error {
	if _, ok := allowed[l.Class]; !ok {
		return ErrBadClass
	}
	if strings.TrimSpace(l.SourceName) == "" {
		return ErrNoSource
	}
	if l.Confidence < 0 || l.Confidence > 1 {
		return ErrBadConfidence
	}
	if len(l.Proof) == 0 {
		return ErrNoProof
	}
	if !isAddr(l.Address) {
		return ErrBadAddress
	}
	return nil
}

func isAddr(a string) bool {
	if len(a) != 42 || !strings.HasPrefix(a, "0x") {
		return false
	}
	for _, c := range a[2:] {
		if !((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F')) {
			return false
		}
	}
	return true
}

// Resolve picks the primary label among several for one address by
// score = confidence * (trust_tier / 5). Ties break toward higher confidence.
// Returns ok=false when there are no labels (caller returns unavailable).
func Resolve(labels []Label) (Label, bool) {
	if len(labels) == 0 {
		return Label{}, false
	}
	best := labels[0]
	bestScore := score(best)
	for _, l := range labels[1:] {
		if s := score(l); s > bestScore || (s == bestScore && l.Confidence > best.Confidence) {
			best, bestScore = l, s
		}
	}
	return best, true
}

func score(l Label) float64 {
	tier := l.TrustTier
	if tier < 1 {
		tier = 1
	}
	if tier > 5 {
		tier = 5
	}
	return l.Confidence * (float64(tier) / 5.0)
}
