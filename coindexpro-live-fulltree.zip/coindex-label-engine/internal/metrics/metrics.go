// Package metrics holds the label-engine's Prometheus instruments.
package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	LabelsImported = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_le_labels_imported_total", Help: "Labels imported by source kind.",
	}, []string{"kind"})

	LabelsRejected = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_le_labels_rejected_total", Help: "Labels rejected by reason.",
	}, []string{"reason"})

	FeedVerifyFailures = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_le_feed_verify_failures_total", Help: "Signed-feed signature verification failures.",
	})

	LabelLookups = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_le_lookups_total", Help: "Label lookups by result.",
	}, []string{"result"}) // hit | unavailable | error

	APILatency = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name: "coindex_le_api_seconds", Help: "API latency by route + status.",
		Buckets: prometheus.DefBuckets,
	}, []string{"route", "status"})

	DBErrors = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_le_db_errors_total", Help: "DB errors.",
	})
)
