// Package config loads label-engine configuration from YAML with ${ENV} expansion.
package config

import (
	"fmt"
	"os"
	"time"

	"gopkg.in/yaml.v3"
)

type Config struct {
	Server   ServerConfig   `yaml:"server"`
	Postgres PostgresConfig `yaml:"postgres"`
	Redis    RedisConfig    `yaml:"redis"`
	Auth     AuthConfig     `yaml:"auth"`
	Partners []Partner      `yaml:"partners"`
	Cache    CacheConfig    `yaml:"cache"`
	Log      LogConfig      `yaml:"log"`
}

type ServerConfig struct {
	APIAddr     string `yaml:"api_addr"`
	MetricsAddr string `yaml:"metrics_addr"`
	MaxImportBytes int `yaml:"max_import_bytes"`
}
type PostgresConfig struct {
	DSN string `yaml:"dsn"`
}
type RedisConfig struct {
	Addr string `yaml:"addr"`
}
type AuthConfig struct {
	ImportAPIKey string `yaml:"import_api_key"` // required to call POST /labels/import
}
// Partner is a signed-feed partner: name + ed25519 public key (hex) + trust tier.
type Partner struct {
	Name      string `yaml:"name"`
	PublicKey string `yaml:"public_key"`
	TrustTier int    `yaml:"trust_tier"`
}
type CacheConfig struct {
	TTL time.Duration `yaml:"ttl"`
}
type LogConfig struct {
	Level string `yaml:"level"`
}

func Load(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}
	var c Config
	if err := yaml.Unmarshal([]byte(os.Expand(string(raw), os.Getenv)), &c); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}
	c.defaults()
	return &c, c.validate()
}

func (c *Config) defaults() {
	if c.Server.APIAddr == "" {
		c.Server.APIAddr = ":8093"
	}
	if c.Server.MetricsAddr == "" {
		c.Server.MetricsAddr = ":9105"
	}
	if c.Server.MaxImportBytes == 0 {
		c.Server.MaxImportBytes = 8 << 20 // 8MB
	}
	if c.Cache.TTL == 0 {
		c.Cache.TTL = 60 * time.Second
	}
}

func (c *Config) validate() error {
	if c.Postgres.DSN == "" {
		return fmt.Errorf("postgres.dsn empty")
	}
	if c.Redis.Addr == "" {
		return fmt.Errorf("redis.addr empty")
	}
	if c.Auth.ImportAPIKey == "" {
		return fmt.Errorf("auth.import_api_key empty (required to protect import)")
	}
	return nil
}

// Partner returns the configured partner by name.
func (c *Config) Partner(name string) (Partner, bool) {
	for _, p := range c.Partners {
		if p.Name == name {
			return p, true
		}
	}
	return Partner{}, false
}
