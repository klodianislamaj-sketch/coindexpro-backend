// Package db persists labels to the (Phase 2, Phase 7-extended) wallet_labels
// table and records every change to wallet_label_history. It refuses to write a
// label without proof: the chk_proof_required CHECK is the last line of defense,
// and the code path always sets source_id + proof together.
package db

import (
	"context"
	"encoding/json"
	"errors"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/coindexpro/coindex-label-engine/internal/labels"
)

type Store struct{ pool *pgxpool.Pool }

func Open(ctx context.Context, dsn string) (*Store, error) {
	pool, err := pgxpool.New(ctx, dsn)
	if err != nil {
		return nil, err
	}
	if err := pool.Ping(ctx); err != nil {
		return nil, err
	}
	return &Store{pool: pool}, nil
}

func (s *Store) Close()                      { s.pool.Close() }
func (s *Store) Ping(ctx context.Context) error { return s.pool.Ping(ctx) }

// UpsertSource ensures a label_sources row exists and returns its id + trust tier.
func (s *Store) UpsertSource(ctx context.Context, name, kind string, tier int, pubKey string) (int64, error) {
	const q = `
		INSERT INTO label_sources (name, kind, trust_tier, public_key)
		VALUES ($1,$2,$3,$4)
		ON CONFLICT (name) DO UPDATE SET kind=$2, trust_tier=$3,
			public_key=COALESCE(NULLIF($4,''), label_sources.public_key)
		RETURNING id`
	var id int64
	err := s.pool.QueryRow(ctx, q, name, kind, tier, pubKey).Scan(&id)
	return id, err
}

// Source returns a source by name (ok=false if absent).
func (s *Store) Source(ctx context.Context, name string) (labels.Source, bool, error) {
	const q = `SELECT id, name, kind, trust_tier, COALESCE(public_key,'') FROM label_sources WHERE name=$1 AND active`
	var src labels.Source
	err := s.pool.QueryRow(ctx, q, name).Scan(&src.ID, &src.Name, &src.Kind, &src.TrustTier, &src.PublicKey)
	if errors.Is(err, pgx.ErrNoRows) {
		return labels.Source{}, false, nil
	}
	return src, err == nil, err
}

// Import writes a batch of validated labels (all carrying proof) and appends a
// history row per label, in one transaction. sourceID must reference the source.
func (s *Store) Import(ctx context.Context, sourceID int64, ls []labels.Label) (int64, error) {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return 0, err
	}
	defer tx.Rollback(ctx)

	var n int64
	for _, l := range ls {
		proofJSON, _ := json.Marshal(l.Proof)
		// upsert into wallet_labels; uniqueness is (chain,address,label_type,source)
		const up = `
			INSERT INTO wallet_labels (chain, address, label_type, entity, source, confidence, evidence, proof, source_id, active)
			VALUES ($1,$2,$3,$4,$5,$6,$7,$7,$8,true)
			ON CONFLICT (chain, address, label_type, source) DO UPDATE SET
				entity=$4, confidence=$6, evidence=$7, proof=$7, source_id=$8, active=true
			RETURNING id`
		var labelID int64
		if err := tx.QueryRow(ctx, up, l.Chain, l.Address, string(l.Class), l.Entity,
			l.SourceName, l.Confidence, proofJSON, sourceID).Scan(&labelID); err != nil {
			return n, err
		}
		// history append
		hist, _ := json.Marshal(map[string]any{
			"class": l.Class, "confidence": l.Confidence, "source": l.SourceName, "proof": l.Proof,
		})
		const h = `
			INSERT INTO wallet_label_history (label_id, chain, address, action, payload, actor)
			VALUES ($1,$2,$3,'add',$4,$5)`
		if _, err := tx.Exec(ctx, h, labelID, l.Chain, l.Address, hist, l.SourceName); err != nil {
			return n, err
		}
		n++
	}
	if err := tx.Commit(ctx); err != nil {
		return 0, err
	}
	return n, nil
}

// Labels returns active labels for an address — only rows that carry proof
// (source_id IS NOT NULL AND proof present), so the API never serves an
// unproven label.
func (s *Store) Labels(ctx context.Context, chain, address string) ([]labels.Label, error) {
	const q = `
		SELECT wl.label_type, COALESCE(wl.entity,''), wl.source, wl.confidence, wl.proof,
		       COALESCE(ls.trust_tier, 1)
		FROM wallet_labels wl
		LEFT JOIN label_sources ls ON ls.id = wl.source_id
		WHERE wl.chain=$1 AND wl.address=$2 AND wl.active
		  AND wl.source_id IS NOT NULL AND wl.proof IS NOT NULL AND wl.proof <> '{}'::jsonb
		ORDER BY wl.confidence DESC`
	rows, err := s.pool.Query(ctx, q, chain, address)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []labels.Label
	for rows.Next() {
		var l labels.Label
		var class string
		var proofJSON []byte
		if err := rows.Scan(&class, &l.Entity, &l.SourceName, &l.Confidence, &proofJSON, &l.TrustTier); err != nil {
			return nil, err
		}
		l.Chain, l.Address, l.Class = chain, address, labels.Class(class)
		_ = json.Unmarshal(proofJSON, &l.Proof)
		out = append(out, l)
	}
	return out, rows.Err()
}

// History returns the change history for an address (from the label_history view).
func (s *Store) History(ctx context.Context, chain, address string, limit int) ([]map[string]any, error) {
	const q = `
		SELECT action, payload, actor, created_at
		FROM label_history WHERE chain=$1 AND address=$2
		ORDER BY created_at DESC LIMIT $3`
	rows, err := s.pool.Query(ctx, q, chain, address, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []map[string]any
	for rows.Next() {
		var action, actor string
		var payload []byte
		var ts time.Time
		if err := rows.Scan(&action, &payload, &actor, &ts); err != nil {
			return nil, err
		}
		var p any
		_ = json.Unmarshal(payload, &p)
		out = append(out, map[string]any{"action": action, "payload": p, "actor": actor, "at": ts})
	}
	return out, rows.Err()
}
