// Package importer parses the three import formats (CSV, JSON, signed partner
// feed) into validated Labels. Every produced Label carries proof; rows without
// source/confidence/proof are rejected and reported, never silently coerced. For
// signed feeds the Ed25519 signature is verified and recorded as proof — an
// unverifiable feed yields zero labels.
package importer

import (
	"encoding/csv"
	"encoding/json"
	"errors"
	"fmt"
	"strconv"
	"strings"

	"github.com/coindexpro/coindex-label-engine/internal/labels"
	"github.com/coindexpro/coindex-label-engine/internal/verify"
)

// Result reports what was accepted and rejected so callers never assume success.
type Result struct {
	Accepted []labels.Label `json:"-"`
	RejectedRows []RejectedRow `json:"rejected"`
	AcceptedCount int `json:"accepted"`
}

type RejectedRow struct {
	Row    int    `json:"row"`
	Reason string `json:"reason"`
}

// jsonLabel is the wire shape for JSON + feed entries.
type jsonLabel struct {
	Chain      string         `json:"chain"`
	Address    string         `json:"address"`
	Class      string         `json:"class"`
	Entity     string         `json:"entity"`
	Confidence float64        `json:"confidence"`
	Proof      map[string]any `json:"proof"`
}

// ParseCSV expects a header: chain,address,class,entity,confidence,proof
// where proof is a JSON object string (proof is REQUIRED and must be non-empty).
func ParseCSV(body []byte, sourceName string, tier int) (Result, error) {
	r := csv.NewReader(strings.NewReader(string(body)))
	records, err := r.ReadAll()
	if err != nil {
		return Result{}, fmt.Errorf("csv parse: %w", err)
	}
	if len(records) < 2 {
		return Result{}, errors.New("csv has no data rows")
	}
	header := index(records[0])
	need := []string{"chain", "address", "class", "confidence", "proof"}
	for _, h := range need {
		if _, ok := header[h]; !ok {
			return Result{}, fmt.Errorf("csv missing required column %q", h)
		}
	}
	var res Result
	for i, rec := range records[1:] {
		conf, _ := strconv.ParseFloat(get(rec, header, "confidence"), 64)
		var proof map[string]any
		if p := get(rec, header, "proof"); p != "" {
			_ = json.Unmarshal([]byte(p), &proof)
		}
		l := labels.Label{
			Chain:      strings.ToLower(get(rec, header, "chain")),
			Address:    strings.ToLower(get(rec, header, "address")),
			Entity:     get(rec, header, "entity"),
			SourceName: sourceName,
			TrustTier:  tier,
			Confidence: conf,
			Proof:      proof,
		}
		if cl, ok := labels.ValidClass(get(rec, header, "class")); ok {
			l.Class = cl
		}
		appendValidated(&res, i+2, l)
	}
	return res, nil
}

// ParseJSON expects an array of jsonLabel. proof is REQUIRED per entry.
func ParseJSON(body []byte, sourceName string, tier int) (Result, error) {
	var entries []jsonLabel
	if err := json.Unmarshal(body, &entries); err != nil {
		return Result{}, fmt.Errorf("json parse: %w", err)
	}
	var res Result
	for i, e := range entries {
		l := toLabel(e, sourceName, tier)
		appendValidated(&res, i+1, l)
	}
	return res, nil
}

// SignedFeed is the envelope for a signed partner feed: a canonical payload of
// labels plus a detached Ed25519 signature over the exact payload bytes.
type SignedFeed struct {
	Partner   string      `json:"partner"`
	Signature string      `json:"signature"` // hex ed25519 over Payload (raw bytes)
	Payload   json.RawMessage `json:"payload"` // JSON array of jsonLabel
}

// ParseSignedFeed verifies the signature against pubKeyHex, then parses the
// payload. The verified signature + partner are recorded into each label's proof
// so the cryptographic provenance travels with the label. Verification failure
// returns an error and ZERO labels.
func ParseSignedFeed(body []byte, partnerName, pubKeyHex string, tier int) (Result, error) {
	var feed SignedFeed
	if err := json.Unmarshal(body, &feed); err != nil {
		return Result{}, fmt.Errorf("feed envelope parse: %w", err)
	}
	if feed.Partner != partnerName {
		return Result{}, fmt.Errorf("feed partner %q does not match source %q", feed.Partner, partnerName)
	}
	if err := verify.Verify(pubKeyHex, feed.Signature, feed.Payload); err != nil {
		return Result{}, fmt.Errorf("feed signature: %w", err)
	}
	var entries []jsonLabel
	if err := json.Unmarshal(feed.Payload, &entries); err != nil {
		return Result{}, fmt.Errorf("feed payload parse: %w", err)
	}
	var res Result
	for i, e := range entries {
		l := toLabel(e, "partner:"+partnerName, tier)
		// attach the cryptographic proof of provenance to every label
		if l.Proof == nil {
			l.Proof = map[string]any{}
		}
		l.Proof["signed_by"] = partnerName
		l.Proof["signature"] = feed.Signature
		l.Proof["verification"] = "ed25519"
		appendValidated(&res, i+1, l)
	}
	return res, nil
}

func toLabel(e jsonLabel, sourceName string, tier int) labels.Label {
	l := labels.Label{
		Chain:      strings.ToLower(e.Chain),
		Address:    strings.ToLower(e.Address),
		Entity:     e.Entity,
		SourceName: sourceName,
		TrustTier:  tier,
		Confidence: e.Confidence,
		Proof:      e.Proof,
	}
	if cl, ok := labels.ValidClass(e.Class); ok {
		l.Class = cl
	}
	return l
}

// appendValidated runs the strict Validate gate; invalid rows are reported, not stored.
func appendValidated(res *Result, row int, l labels.Label) {
	if err := l.Validate(); err != nil {
		res.RejectedRows = append(res.RejectedRows, RejectedRow{Row: row, Reason: err.Error()})
		return
	}
	res.Accepted = append(res.Accepted, l)
	res.AcceptedCount++
}

func index(header []string) map[string]int {
	m := map[string]int{}
	for i, h := range header {
		m[strings.ToLower(strings.TrimSpace(h))] = i
	}
	return m
}
func get(rec []string, header map[string]int, col string) string {
	if i, ok := header[col]; ok && i < len(rec) {
		return strings.TrimSpace(rec[i])
	}
	return ""
}
