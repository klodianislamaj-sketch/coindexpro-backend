// Package verify performs real Ed25519 signature verification for signed partner
// feeds. A partner feed is only accepted if its signature verifies against the
// partner's configured public key; the verified signature becomes part of every
// label's proof. There is no "trust me" path — an unverifiable feed is rejected.
package verify

import (
	"crypto/ed25519"
	"encoding/hex"
	"errors"
)

var (
	ErrNoKey       = errors.New("partner has no public key configured")
	ErrBadKey      = errors.New("partner public key is not valid ed25519 hex")
	ErrBadSig      = errors.New("signature is not valid hex")
	ErrSigMismatch = errors.New("signature does not verify against partner key")
)

// Verify checks that sigHex is a valid Ed25519 signature over payload using the
// partner's pubKeyHex. payload must be the EXACT bytes that were signed (the
// caller passes the canonical feed body). Returns nil on success.
func Verify(pubKeyHex, sigHex string, payload []byte) error {
	if pubKeyHex == "" {
		return ErrNoKey
	}
	pub, err := hex.DecodeString(pubKeyHex)
	if err != nil || len(pub) != ed25519.PublicKeySize {
		return ErrBadKey
	}
	sig, err := hex.DecodeString(sigHex)
	if err != nil || len(sig) != ed25519.SignatureSize {
		return ErrBadSig
	}
	if !ed25519.Verify(ed25519.PublicKey(pub), payload, sig) {
		return ErrSigMismatch
	}
	return nil
}
