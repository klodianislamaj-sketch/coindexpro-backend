// Package api serves the label endpoints. Reads return only proven labels; if a
// wallet has none, the response is {available:false}. The import endpoint is
// auth-gated and dispatches by format, verifying signed feeds before any write.
package api

import (
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/redis/go-redis/v9"

	"github.com/coindexpro/coindex-label-engine/internal/config"
	"github.com/coindexpro/coindex-label-engine/internal/db"
	"github.com/coindexpro/coindex-label-engine/internal/importer"
	"github.com/coindexpro/coindex-label-engine/internal/labels"
	"github.com/coindexpro/coindex-label-engine/internal/metrics"
)

type API struct {
	store *db.Store
	cfg   *config.Config
	rdb   *redis.Client
}

func New(store *db.Store, cfg *config.Config, rdb *redis.Client) *API {
	return &API{store: store, cfg: cfg, rdb: rdb}
}

func (a *API) Register(app *fiber.App) {
	app.Use(a.observe)
	app.Get("/labels/:chain/:address/history", a.history)
	app.Get("/labels/:chain/:address", a.get)
	app.Post("/labels/import", a.requireImportKey, a.importLabels)
}

func (a *API) observe(c *fiber.Ctx) error {
	start := time.Now()
	err := c.Next()
	metrics.APILatency.WithLabelValues(c.Route().Path, statusClass(c.Response().StatusCode())).
		Observe(time.Since(start).Seconds())
	return err
}

var (
	evmAddr    = regexp.MustCompile(`^0x[0-9a-fA-F]{40}$`)
	validChain = map[string]bool{
		"ethereum": true, "bsc": true, "base": true,
		"arbitrum": true, "polygon": true, "pulsechain": true,
	}
)

func parseParams(c *fiber.Ctx) (chain, addr string, ok bool) {
	chain = strings.ToLower(c.Params("chain"))
	addr = strings.ToLower(c.Params("address"))
	if !validChain[chain] || !evmAddr.MatchString(addr) {
		return "", "", false
	}
	return chain, addr, true
}

// GET /labels/:chain/:address
func (a *API) get(c *fiber.Ctx) error {
	chain, addr, ok := parseParams(c)
	if !ok {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid chain or address"})
	}
	ls, err := a.store.Labels(c.UserContext(), chain, addr)
	if err != nil {
		metrics.DBErrors.Inc()
		metrics.LabelLookups.WithLabelValues("error").Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(ls) == 0 {
		metrics.LabelLookups.WithLabelValues("unavailable").Inc()
		return c.JSON(fiber.Map{"chain": chain, "address": addr, "available": false, "reason": "not configured"})
	}
	resolved, _ := labels.Resolve(ls)
	metrics.LabelLookups.WithLabelValues("hit").Inc()
	return c.JSON(fiber.Map{
		"chain": chain, "address": addr, "available": true,
		"resolved": resolved, // primary by confidence × trust tier
		"labels":   ls,        // every proven label with its source + proof
	})
}

// GET /labels/:chain/:address/history
func (a *API) history(c *fiber.Ctx) error {
	chain, addr, ok := parseParams(c)
	if !ok {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "invalid chain or address"})
	}
	limit := 100
	if v, err := strconv.Atoi(c.Query("limit")); err == nil && v > 0 && v <= 500 {
		limit = v
	}
	h, err := a.store.History(c.UserContext(), chain, addr, limit)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(h) == 0 {
		return c.JSON(fiber.Map{"chain": chain, "address": addr, "available": false, "reason": "no history"})
	}
	return c.JSON(fiber.Map{"chain": chain, "address": addr, "available": true, "history": h})
}

// requireImportKey gates the import endpoint with the configured admin key.
func (a *API) requireImportKey(c *fiber.Ctx) error {
	if c.Get("X-Import-Key") != a.cfg.Auth.ImportAPIKey {
		return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{"error": "unauthorized"})
	}
	return c.Next()
}

// POST /labels/import?format=csv|json|feed&source=<name>&partner=<name>
// Body is the CSV/JSON/feed payload. Every accepted label carries proof; rows
// without source/confidence/proof are rejected and reported.
func (a *API) importLabels(c *fiber.Ctx) error {
	if len(c.Body()) > a.cfg.Server.MaxImportBytes {
		return c.Status(fiber.StatusRequestEntityTooLarge).JSON(fiber.Map{"error": "import too large"})
	}
	format := c.Query("format")
	ctx := c.UserContext()

	var res importer.Result
	var sourceName, sourceKind string
	var tier int

	switch format {
	case "csv":
		sourceName = c.Query("source")
		if sourceName == "" {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "source required"})
		}
		sourceKind, tier = "csv", clampTier(c.QueryInt("trust_tier", 2))
		r, err := importer.ParseCSV(c.Body(), sourceName, tier)
		if err != nil {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": err.Error()})
		}
		res = r
	case "json":
		sourceName = c.Query("source")
		if sourceName == "" {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "source required"})
		}
		sourceKind, tier = "json", clampTier(c.QueryInt("trust_tier", 2))
		r, err := importer.ParseJSON(c.Body(), sourceName, tier)
		if err != nil {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": err.Error()})
		}
		res = r
	case "feed":
		partnerName := c.Query("partner")
		p, ok := a.cfg.Partner(partnerName)
		if !ok {
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "unknown partner"})
		}
		sourceName, sourceKind, tier = "partner:"+partnerName, "partner_feed", clampTier(p.TrustTier)
		r, err := importer.ParseSignedFeed(c.Body(), partnerName, p.PublicKey, tier)
		if err != nil {
			metrics.FeedVerifyFailures.Inc()
			return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": err.Error()})
		}
		res = r
	default:
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": "format must be csv|json|feed"})
	}

	for _, rj := range res.RejectedRows {
		metrics.LabelsRejected.WithLabelValues(rj.Reason).Inc()
	}

	var imported int64
	if res.AcceptedCount > 0 {
		srcID, err := a.store.UpsertSource(ctx, sourceName, sourceKind, tier, partnerKey(a.cfg, format, c.Query("partner")))
		if err != nil {
			metrics.DBErrors.Inc()
			return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "source upsert failed"})
		}
		n, err := a.store.Import(ctx, srcID, res.Accepted)
		if err != nil {
			metrics.DBErrors.Inc()
			return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "import write failed"})
		}
		imported = n
		metrics.LabelsImported.WithLabelValues(sourceKind).Add(float64(n))
		// invalidate cached lookups for imported addresses
		for _, l := range res.Accepted {
			_ = a.rdb.Del(ctx, "label:"+l.Chain+":"+l.Address).Err()
		}
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"imported": imported,
		"accepted": res.AcceptedCount,
		"rejected": res.RejectedRows, // explicit: nothing was silently coerced
	})
}

func partnerKey(cfg *config.Config, format, partner string) string {
	if format != "feed" {
		return ""
	}
	if p, ok := cfg.Partner(partner); ok {
		return p.PublicKey
	}
	return ""
}

func clampTier(t int) int {
	if t < 1 {
		return 1
	}
	if t > 5 {
		return 5
	}
	return t
}

func statusClass(code int) string {
	switch {
	case code >= 500:
		return "5xx"
	case code >= 400:
		return "4xx"
	default:
		return "2xx"
	}
}
