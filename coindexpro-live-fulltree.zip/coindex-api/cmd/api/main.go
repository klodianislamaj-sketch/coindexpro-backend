// Command api is the coindex-api entrypoint. It builds the Fiber app, wires
// middleware (request-id, recover, observe, auth, premium, rate-limit, CORS,
// gzip), registers every route over the Phase 2 stores, and serves a separate
// metrics/health listener. Reads only — one source of truth per subsystem.
package main

import (
	"context"
	"errors"
	"flag"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/compress"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"go.uber.org/zap"

	"github.com/coindexpro/coindex-api/config"
	"github.com/coindexpro/coindex-api/internal/auth"
	"github.com/coindexpro/coindex-api/internal/cache"
	"github.com/coindexpro/coindex-api/internal/dbpool"
	"github.com/coindexpro/coindex-api/internal/graph"
	"github.com/coindexpro/coindex-api/internal/handlers"
	"github.com/coindexpro/coindex-api/internal/middleware"
	"github.com/coindexpro/coindex-api/internal/premium"
	"github.com/coindexpro/coindex-api/internal/repositories"
	"github.com/coindexpro/coindex-api/internal/security"
	"github.com/coindexpro/coindex-api/internal/services"
)

func main() {
	cfgPath := flag.String("config", "config/config.yaml", "config path")
	flag.Parse()

	cfg, err := config.Load(*cfgPath)
	if err != nil {
		panic(err)
	}
	log, _ := zap.NewProduction()
	defer func() { _ = log.Sync() }()

	rootCtx, cancel := context.WithCancel(context.Background())
	defer cancel()

	pool, err := dbpool.Open(rootCtx, cfg)
	if err != nil {
		log.Fatal("db pool open failed", zap.Error(err))
	}
	defer pool.Close()

	// Repositories → services → handlers.
	svc := services.New(cfg,
		cache.NewSWR(pool.Redis),
		repositories.NewClickHouse(pool.CH),
		repositories.NewTimescale(pool.Timescale),
		repositories.NewPostgres(pool.PG),
		graph.New(pool.PG),
	)
	h := handlers.New(svc)
	authn := auth.New(cfg.Auth.JWTSecret, cfg.Auth.AdminAPIKey, pool.PG)
	gate := premium.New(cfg.Premium)

	// Fail-fast on missing critical secrets — never start serving insecure.
	if err := security.RequireSecrets("JWT_SECRET", "ADMIN_API_KEY", "POSTGRES_DSN"); err != nil {
		log.Fatal("startup secret validation failed", zap.Error(err))
	}
	// Async append-only security audit sink (real actor identity only).
	auditor := security.NewAuditor(pool.PG, log)

	app := fiber.New(fiber.Config{
		AppName:      "coindex-api",
		ReadTimeout:  cfg.Server.ReadTimeout,
		WriteTimeout: cfg.Server.WriteTimeout,
		ErrorHandler: func(c *fiber.Ctx, err error) error {
			return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
		},
	})

	// Global middleware chain (order matters).
	app.Use(middleware.RequestID())
	app.Use(middleware.Recover(log))
	app.Use(security.SecurityHeaders()) // CSP/HSTS/X-Frame/X-Content-Type/Referrer
	app.Use(middleware.Observe())
	app.Use(cors.New(cors.Config{AllowOrigins: orDefault(cfg.Server.CORSOrigins, "*")}))
	app.Use(compress.New(compress.Config{Level: compress.LevelDefault})) // gzip
	app.Use(security.PerIPRateLimit(pool.Redis, security.IPLimits{})) // per-IP burst+sustained
	app.Use(middleware.Auth(authn))
	app.Use(middleware.Premium(gate))
	app.Use(middleware.RateLimit(pool.Redis, cfg.RateLimit))

	registerRoutes(app, h, auditor)

	// Separate health/metrics listener (never rate-limited / auth-gated).
	go serveOps(cfg, pool, log)

	// Start API server.
	go func() {
		log.Info("api listening", zap.String("addr", cfg.Server.Addr))
		if err := app.Listen(cfg.Server.Addr); err != nil {
			log.Error("api server stopped", zap.Error(err))
		}
	}()

	// Graceful shutdown.
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
	<-sig
	log.Info("shutting down")
	shutdownCtx, sc := context.WithTimeout(context.Background(), cfg.Server.ShutdownTimeout)
	defer sc()
	_ = app.ShutdownWithContext(shutdownCtx)
}

func registerRoutes(app *fiber.App, h *handlers.Handlers, aud *security.Auditor) {
	// MARKET
	app.Get("/markets/trending", h.Trending)
	app.Get("/markets/gainers", h.Gainers)
	app.Get("/markets/losers", h.Losers)
	app.Get("/markets/new-pairs", h.NewPairs)
	app.Get("/markets/sectors", h.Sectors)

	// TOKEN
	app.Get("/token/:chain/:address", h.Token)
	app.Get("/token/:chain/:address/history", h.TokenHistory)
	app.Get("/token/:chain/:address/liquidity", h.TokenLiquidity)
	app.Get("/token/:chain/:address/risk", h.TokenRisk)
	app.Get("/token/:chain/:address/holders", h.TokenHolders)

	// WHALE (premium)
	app.Get("/whales/live", h.WhalesLive)
	app.Get("/whales/wallet/:address", h.WhalesWallet)
	app.Get("/whales/clusters", h.WhalesClusters)
	app.Get("/whales/smart-money", h.WhalesSmartMoney)

	// WALLET (premium)
	app.Get("/wallet/:address/profile", h.WalletProfile)
	app.Get("/wallet/:address/trades", h.WalletTrades)
	app.Get("/wallet/:address/performance", h.WalletPerformance)

	// FLOW (premium)
	app.Get("/flows/exchanges", h.FlowsExchanges)
	app.Get("/flows/bridges", h.FlowsBridges)
	app.Get("/flows/stablecoins", h.FlowsStablecoins)

	// SOCIAL (premium)
	app.Get("/social/:token", h.Social)
	app.Get("/sentiment/:token", h.Sentiment)

	// USER mutations: explicit deny-by-default role enforcement (premium/admin) +
	// append-only audit on every privileged write. Reads stay on the global gate.
	mutate := []string{security.RolePremium, security.RoleAdmin}
	app.Get("/watchlists", h.GetWatchlists)
	app.Post("/watchlists", security.RequireRole(aud, mutate...), security.AuditMutation(aud, "watchlist.create"), h.CreateWatchlist)
	app.Delete("/watchlists/:id", security.RequireRole(aud, mutate...), security.AuditMutation(aud, "watchlist.delete"), h.DeleteWatchlist)

	app.Get("/portfolio", h.GetPortfolio)
	app.Post("/portfolio/sync", security.RequireRole(aud, mutate...), security.AuditMutation(aud, "portfolio.sync"), h.SyncPortfolio)

	app.Get("/alerts", h.GetAlerts)
	app.Post("/alerts", security.RequireRole(aud, mutate...), security.AuditMutation(aud, "alert.create"), h.CreateAlert)
	app.Delete("/alerts/:id", security.RequireRole(aud, mutate...), security.AuditMutation(aud, "alert.delete"), h.DeleteAlert)
}

// serveOps runs /healthz, /readyz, /metrics on a separate port.
func serveOps(cfg *config.Config, pool *dbpool.Pool, log *zap.Logger) {
	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ok"))
	})
	mux.HandleFunc("/readyz", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), 3*time.Second)
		defer cancel()
		if err := pool.Ready(ctx); err != nil {
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte(err.Error()))
			return
		}
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ready"))
	})
	mux.Handle("/metrics", promhttp.Handler())
	srv := &http.Server{Addr: cfg.Server.MetricsAddr, Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Error("ops server failed", zap.Error(err))
	}
}

func orDefault(v, d string) string {
	if v == "" {
		return d
	}
	return v
}
