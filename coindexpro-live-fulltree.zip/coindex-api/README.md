# coindex-api — Phase 3 read API

Production-grade read API (Go + Fiber) over the Phase 2 database layer. The
frontend (Phase 16) will consume only this API; the backend is the single source
of truth. **No fabricated data** — endpoints with no real source return
`{"available": false, "reason": "..."}`.

## Source-of-truth map

| Domain | Store | Tables |
|---|---|---|
| whales / smart-money / wallet trades / positions / token metrics / new pairs | ClickHouse | `smart_money_events`, `wallet_trades`, `wallet_positions`, `token_metrics`, `new_pairs` |
| candles (1m–4h) / liquidity / trust / sector history | TimescaleDB | `candles_*`, `liquidity_history`, `trust_history`, `sector_history` |
| token registry / labels / users / watchlists / portfolios / alerts | PostgreSQL | `token_registry`, `wallet_labels`, `user_accounts`, `watchlists`, `portfolios`, `alerts` |
| clusters / influence | Postgres graph schema | `graph.wallet_edges`, `graph.wallet_nodes` |

## Endpoints

Market: `/markets/{trending,gainers,losers,new-pairs,sectors}`
Token: `/token/:chain/:address[/history|/liquidity|/risk|/holders]`
Whale (premium): `/whales/{live,wallet/:address,clusters,smart-money}`
Wallet (premium): `/wallet/:address/{profile,trades,performance}`
Flow (premium): `/flows/{exchanges,bridges,stablecoins}`
Social (premium): `/social/:token`, `/sentiment/:token`
User: `/watchlists` (GET/POST/DELETE), `/portfolio` (+`/sync`), `/alerts` (GET/POST/DELETE)
Ops (separate port): `/healthz`, `/readyz`, `/metrics`

## Run

```bash
# Phase 2 DBs must be migrated and reachable.
export CLICKHOUSE_ADDR=... CLICKHOUSE_USER=... CLICKHOUSE_PASSWORD=...
export TIMESCALE_DSN=... POSTGRES_DSN=... REDIS_ADDR=...
export JWT_SECRET=... ADMIN_API_KEY=...
docker compose up --build
# API:     http://localhost:8090
# ops:     http://localhost:9101/healthz  /readyz  /metrics
```

## Cross-cutting behaviour

- **Cache:** Redis SWR with per-domain TTLs (markets 10s, token 20s, whales 5s, clusters 30s, wallets 15s, flows 20s); hot-key singleflight refresh; prefix invalidation. Redis down → degrades to direct DB reads, never errors.
- **Auth:** JWT (`Authorization: Bearer`) or API key (`X-API-Key`); tiers free/premium/admin. Wallet-signature path is a labelled stub that refuses rather than fake-authenticates.
- **Premium gate:** `/whales`, `/wallet`, `/flows`, `/social`, `/sentiment`, `/portfolio`, `/alerts` → 402 for free tier.
- **Rate limit:** Redis fixed-window per tier (free 60/min, premium 300/min, admin unlimited).
- **Production:** graceful shutdown, query timeouts, per-store circuit breakers, structured logs (zap), request IDs, panic recovery, CORS, gzip, strict input validation (chain/address allowlists; timeframe allowlist → no SQL injection).

## Honest status

- **Real, production-shaped code, NOT compiled or run here** (no Go toolchain / no live DBs in the authoring environment). Static-reviewed for import/symbol/signature consistency. Before production: `go build` + `go vet` + `golangci-lint`, plus an integration run against the Phase 2 stores with seeded data.
- **Endpoints that return `available:false` by design today** (no real source yet, per the no-fabrication rule): `/token/:/:/risk` (needs Phase 8 contract analysis), `/flows/*` (needs Phase 7 labels + Phase 11 flow engine), `/social/:token` + `/sentiment/:token` (needs Phase 12 API keys), `/markets/losers` (token_metrics has no 24h-delta column yet). These are honest "not configured" responses, not stubs pretending to be live.
- **Wallet performance** returns realized PnL from indexed `wallet_positions` (real fills); unrealized PnL is left `null` with a note until the enricher price-join is wired — never estimated.
- **No service layer beyond reads** — this is the read API only, as specified.
