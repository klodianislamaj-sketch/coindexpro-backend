-- =============================================================================
-- CoinDex Security Audit — PostgreSQL migration (Phase 23)
-- =============================================================================
-- An APPEND-ONLY audit trail of security-relevant events: who (real actor from the
-- authenticated identity), what action, on what target, the result, and when. The
-- actor is taken from the resolved auth identity — never fabricated. A rule
-- blocks UPDATE/DELETE so the trail cannot be rewritten.
--
-- NEW table (collision-checked: no security_events exists); idempotent.
-- =============================================================================

CREATE TABLE IF NOT EXISTS security_events (
    id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    occurred_at timestamptz NOT NULL DEFAULT now(),
    actor_id    text        NOT NULL,                 -- resolved identity (user uuid / "admin" / "anonymous")
    actor_tier  text        NOT NULL,                 -- free|premium|admin|service|anonymous
    actor_source text       NOT NULL,                 -- jwt|apikey|anonymous
    action      text        NOT NULL,                 -- e.g. auth.denied, route.access, mutation.create
    target      text        NOT NULL,                 -- route / resource acted upon
    result      text        NOT NULL CHECK (result IN ('allow','deny','error')),
    ip          inet,                                 -- real client IP (best-effort, may be NULL)
    request_id  text,                                 -- correlates with request logs
    detail      jsonb       NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS idx_secevents_actor ON security_events (actor_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_secevents_action ON security_events (action, occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_secevents_deny ON security_events (result, occurred_at DESC) WHERE result = 'deny';

-- Append-only enforcement: reject UPDATE and DELETE so the audit trail is immutable.
CREATE OR REPLACE FUNCTION security_events_append_only() RETURNS trigger AS $$
BEGIN
    RAISE EXCEPTION 'security_events is append-only (% blocked)', TG_OP;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_security_events_no_mutate ON security_events;
CREATE TRIGGER trg_security_events_no_mutate
    BEFORE UPDATE OR DELETE ON security_events
    FOR EACH ROW EXECUTE FUNCTION security_events_append_only();
