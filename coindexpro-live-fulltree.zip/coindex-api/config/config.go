// Package config loads API configuration from YAML with ${ENV} expansion.
package config

import (
	"fmt"
	"os"
	"time"

	"gopkg.in/yaml.v3"
)

type Config struct {
	Server     ServerConfig            `yaml:"server"`
	ClickHouse ClickHouseConfig        `yaml:"clickhouse"`
	Timescale  PostgresConfig          `yaml:"timescale"`
	Postgres   PostgresConfig          `yaml:"postgres"`
	Redis      RedisConfig             `yaml:"redis"`
	Auth       AuthConfig              `yaml:"auth"`
	RateLimit  map[string]int          `yaml:"rate_limit"`  // tier -> req/min (0 = unlimited)
	CacheTTL   map[string]int          `yaml:"cache_ttl"`   // key -> seconds
	Premium    []string                `yaml:"premium_prefixes"`
	Log        LogConfig               `yaml:"log"`
}

type ServerConfig struct {
	Addr            string        `yaml:"addr"`
	MetricsAddr     string        `yaml:"metrics_addr"`
	ReadTimeout     time.Duration `yaml:"read_timeout"`
	WriteTimeout    time.Duration `yaml:"write_timeout"`
	ShutdownTimeout time.Duration `yaml:"shutdown_timeout"`
	QueryTimeout    time.Duration `yaml:"query_timeout"`
	CORSOrigins     string        `yaml:"cors_origins"`
}

type ClickHouseConfig struct {
	Addrs    []string `yaml:"addrs"`
	Database string   `yaml:"database"`
	Username string   `yaml:"username"`
	Password string   `yaml:"password"`
}

type PostgresConfig struct {
	DSN string `yaml:"dsn"`
}

type RedisConfig struct {
	Addr string `yaml:"addr"`
}

type AuthConfig struct {
	JWTSecret      string `yaml:"jwt_secret"`
	AdminAPIKey    string `yaml:"admin_api_key"` // hashed in real deploy
	EnableWalletSig bool  `yaml:"enable_wallet_sig"`
}

type LogConfig struct {
	Level string `yaml:"level"`
}

func Load(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}
	expanded := os.Expand(string(raw), os.Getenv)
	var c Config
	if err := yaml.Unmarshal([]byte(expanded), &c); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}
	c.defaults()
	return &c, c.validate()
}

func (c *Config) defaults() {
	if c.Server.Addr == "" {
		c.Server.Addr = ":8090"
	}
	if c.Server.MetricsAddr == "" {
		c.Server.MetricsAddr = ":9101"
	}
	if c.Server.QueryTimeout == 0 {
		c.Server.QueryTimeout = 5 * time.Second
	}
	if c.Server.ShutdownTimeout == 0 {
		c.Server.ShutdownTimeout = 15 * time.Second
	}
	if c.RateLimit == nil {
		c.RateLimit = map[string]int{"free": 60, "premium": 300, "admin": 0}
	}
	if c.CacheTTL == nil {
		c.CacheTTL = map[string]int{
			"markets": 10, "token": 20, "whales": 5,
			"clusters": 30, "wallets": 15, "flows": 20,
		}
	}
	if len(c.Premium) == 0 {
		c.Premium = []string{"/whales", "/wallet", "/flows", "/social", "/sentiment", "/portfolio", "/alerts"}
	}
}

func (c *Config) validate() error {
	if len(c.ClickHouse.Addrs) == 0 {
		return fmt.Errorf("clickhouse.addrs empty")
	}
	if c.Postgres.DSN == "" {
		return fmt.Errorf("postgres.dsn empty")
	}
	if c.Auth.JWTSecret == "" {
		return fmt.Errorf("auth.jwt_secret empty")
	}
	return nil
}

// TTL returns the configured cache TTL for a key, defaulting to 10s.
func (c *Config) TTL(key string) time.Duration {
	if s, ok := c.CacheTTL[key]; ok {
		return time.Duration(s) * time.Second
	}
	return 10 * time.Second
}
