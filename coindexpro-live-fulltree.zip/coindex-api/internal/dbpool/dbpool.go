// Package dbpool opens and holds the database connections the API reads from.
// One source of truth per store: ClickHouse (events/derived), Timescale
// (time-series), Postgres (relational + graph schema).
package dbpool

import (
	"context"
	"fmt"

	"github.com/ClickHouse/clickhouse-go/v2"
	"github.com/ClickHouse/clickhouse-go/v2/lib/driver"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/redis/go-redis/v9"

	"github.com/coindexpro/coindex-api/config"
)

type Pool struct {
	CH        driver.Conn
	Timescale *pgxpool.Pool
	PG        *pgxpool.Pool   // also hosts the graph schema
	Redis     *redis.Client
}

func Open(ctx context.Context, c *config.Config) (*Pool, error) {
	ch, err := clickhouse.Open(&clickhouse.Options{
		Addr: c.ClickHouse.Addrs,
		Auth: clickhouse.Auth{
			Database: c.ClickHouse.Database,
			Username: c.ClickHouse.Username,
			Password: c.ClickHouse.Password,
		},
	})
	if err != nil {
		return nil, fmt.Errorf("clickhouse open: %w", err)
	}
	if err := ch.Ping(ctx); err != nil {
		return nil, fmt.Errorf("clickhouse ping: %w", err)
	}

	ts, err := pgxpool.New(ctx, c.Timescale.DSN)
	if err != nil {
		return nil, fmt.Errorf("timescale open: %w", err)
	}
	pg, err := pgxpool.New(ctx, c.Postgres.DSN)
	if err != nil {
		return nil, fmt.Errorf("postgres open: %w", err)
	}

	rdb := redis.NewClient(&redis.Options{Addr: c.Redis.Addr})
	if err := rdb.Ping(ctx).Err(); err != nil {
		return nil, fmt.Errorf("redis ping: %w", err)
	}

	return &Pool{CH: ch, Timescale: ts, PG: pg, Redis: rdb}, nil
}

// Ready reports whether every backing store responds (drives /readyz).
func (p *Pool) Ready(ctx context.Context) error {
	if err := p.CH.Ping(ctx); err != nil {
		return fmt.Errorf("clickhouse: %w", err)
	}
	if err := p.Timescale.Ping(ctx); err != nil {
		return fmt.Errorf("timescale: %w", err)
	}
	if err := p.PG.Ping(ctx); err != nil {
		return fmt.Errorf("postgres: %w", err)
	}
	if err := p.Redis.Ping(ctx).Err(); err != nil {
		return fmt.Errorf("redis: %w", err)
	}
	return nil
}

func (p *Pool) Close() {
	_ = p.CH.Close()
	p.Timescale.Close()
	p.PG.Close()
	_ = p.Redis.Close()
}
