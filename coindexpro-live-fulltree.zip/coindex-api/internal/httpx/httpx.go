// Package httpx holds HTTP response helpers and a simple circuit breaker used
// to wrap database calls so a struggling store fails fast instead of piling up.
package httpx

import (
	"errors"
	"sync"
	"time"

	"github.com/gofiber/fiber/v2"

	"github.com/coindexpro/coindex-api/internal/metrics"
)

// OK writes a 200 JSON body.
func OK(c *fiber.Ctx, body any) error { return c.Status(fiber.StatusOK).JSON(body) }

// Unavailable writes the standard not-indexed/not-configured envelope (200, so
// clients treat it as a valid "no data" answer rather than an error).
func Unavailable(c *fiber.Ctx, reason string) error {
	return c.Status(fiber.StatusOK).JSON(fiber.Map{"available": false, "reason": reason})
}

// BadRequest / etc. standard error envelopes.
func BadRequest(c *fiber.Ctx, msg string) error {
	return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": msg, "request_id": rid(c)})
}
func NotFound(c *fiber.Ctx) error {
	return c.Status(fiber.StatusNotFound).JSON(fiber.Map{"error": "not found", "request_id": rid(c)})
}
func Unauthorized(c *fiber.Ctx) error {
	return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{"error": "unauthorized", "request_id": rid(c)})
}
func PaymentRequired(c *fiber.Ctx) error {
	return c.Status(fiber.StatusPaymentRequired).JSON(fiber.Map{
		"error": "premium tier required", "request_id": rid(c)})
}
func TooMany(c *fiber.Ctx) error {
	return c.Status(fiber.StatusTooManyRequests).JSON(fiber.Map{"error": "rate limit exceeded", "request_id": rid(c)})
}
func ServerError(c *fiber.Ctx, route string) error {
	metrics.ErrorsTotal.WithLabelValues(route).Inc()
	return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
		"error": "internal error", "request_id": rid(c)})
}

func rid(c *fiber.Ctx) string {
	if v, ok := c.Locals("request_id").(string); ok {
		return v
	}
	return ""
}

// --- Circuit breaker ---

var ErrCircuitOpen = errors.New("circuit open")

type Breaker struct {
	mu          sync.Mutex
	store       string
	failures    int
	threshold   int
	openUntil   time.Time
	cooldown    time.Duration
}

func NewBreaker(store string, threshold int, cooldown time.Duration) *Breaker {
	return &Breaker{store: store, threshold: threshold, cooldown: cooldown}
}

// Do runs fn unless the breaker is open; trips after `threshold` consecutive
// failures and resets on the first success after cooldown.
func (b *Breaker) Do(fn func() error) error {
	b.mu.Lock()
	if time.Now().Before(b.openUntil) {
		b.mu.Unlock()
		return ErrCircuitOpen
	}
	b.mu.Unlock()

	err := fn()

	b.mu.Lock()
	defer b.mu.Unlock()
	if err != nil {
		b.failures++
		if b.failures >= b.threshold {
			b.openUntil = time.Now().Add(b.cooldown)
			metrics.CircuitOpen.WithLabelValues(b.store).Set(1)
		}
		return err
	}
	b.failures = 0
	metrics.CircuitOpen.WithLabelValues(b.store).Set(0)
	return nil
}
