// Package middleware wires cross-cutting request concerns onto Fiber.
package middleware

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
	"github.com/redis/go-redis/v9"
	"go.uber.org/zap"

	"github.com/coindexpro/coindex-api/internal/auth"
	"github.com/coindexpro/coindex-api/internal/httpx"
	"github.com/coindexpro/coindex-api/internal/metrics"
	"github.com/coindexpro/coindex-api/internal/premium"
)

// RequestID assigns a request id (honoring an inbound X-Request-ID) and echoes it.
func RequestID() fiber.Handler {
	return func(c *fiber.Ctx) error {
		id := c.Get("X-Request-ID")
		if id == "" {
			id = uuid.NewString()
		}
		c.Locals("request_id", id)
		c.Set("X-Request-ID", id)
		return c.Next()
	}
}

// Recover catches panics so a single bad handler never crashes the server.
func Recover(log *zap.Logger) fiber.Handler {
	return func(c *fiber.Ctx) (err error) {
		defer func() {
			if r := recover(); r != nil {
				log.Error("panic recovered", zap.Any("panic", r), zap.String("path", c.Path()))
				err = httpx.ServerError(c, c.Route().Path)
			}
		}()
		return c.Next()
	}
}

// Observe records latency + status per route.
func Observe() fiber.Handler {
	return func(c *fiber.Ctx) error {
		start := time.Now()
		err := c.Next()
		route := c.Route().Path
		status := fmt.Sprintf("%d", c.Response().StatusCode())
		metrics.RequestLatency.WithLabelValues(route, status).Observe(time.Since(start).Seconds())
		metrics.RequestsTotal.WithLabelValues(route, status).Inc()
		return err
	}
}

// Auth resolves identity from Authorization: Bearer <jwt> or X-API-Key. Missing
// credentials yield an anonymous free identity (public routes still work).
func Auth(a *auth.Authenticator) fiber.Handler {
	return func(c *fiber.Ctx) error {
		ctx, cancel := context.WithTimeout(c.UserContext(), 2*time.Second)
		defer cancel()

		if key := c.Get("X-API-Key"); key != "" {
			id, err := a.FromAPIKey(ctx, key)
			if err == nil {
				c.Locals("identity", id)
				return c.Next()
			}
			return httpx.Unauthorized(c)
		}
		if h := c.Get("Authorization"); strings.HasPrefix(h, "Bearer ") {
			id, err := a.FromJWT(strings.TrimPrefix(h, "Bearer "))
			if err == nil {
				c.Locals("identity", id)
				return c.Next()
			}
			return httpx.Unauthorized(c)
		}
		c.Locals("identity", auth.Identity{Tier: auth.TierFree, Source: "anonymous"})
		return c.Next()
	}
}

// Premium gates configured prefixes to premium/admin tiers.
func Premium(g *premium.Gate) fiber.Handler {
	return func(c *fiber.Ctx) error {
		if !g.Requires(c.Path()) {
			return c.Next()
		}
		id, _ := c.Locals("identity").(auth.Identity)
		if !g.Allowed(id.Tier) {
			return httpx.PaymentRequired(c)
		}
		return c.Next()
	}
}

// RateLimit enforces a per-tier per-minute budget using a Redis fixed-window
// counter keyed by identity (user id, API key owner, or client IP for anon).
func RateLimit(rdb *redis.Client, perMinute map[string]int) fiber.Handler {
	return func(c *fiber.Ctx) error {
		id, _ := c.Locals("identity").(auth.Identity)
		limit := perMinute[string(id.Tier)]
		if limit == 0 { // 0 = unlimited (admin)
			return c.Next()
		}
		subject := id.UserID
		if subject == "" {
			subject = c.IP()
		}
		window := time.Now().Unix() / 60
		key := fmt.Sprintf("rl:%s:%d", subject, window)

		ctx, cancel := context.WithTimeout(c.UserContext(), time.Second)
		defer cancel()
		n, err := rdb.Incr(ctx, key).Result()
		if err == nil && n == 1 {
			rdb.Expire(ctx, key, 70*time.Second)
		}
		if err == nil && n > int64(limit) {
			metrics.RateLimitViolations.WithLabelValues(string(id.Tier)).Inc()
			c.Set("Retry-After", "60")
			return httpx.TooMany(c)
		}
		return c.Next()
	}
}
