// Package services holds business logic: it composes repositories, applies the
// SWR cache with per-domain TTLs, and enforces the source-of-truth + no-fabricate
// rules (returning ok=false when a real source has no data).
package services

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/coindexpro/coindex-api/config"
	"github.com/coindexpro/coindex-api/internal/cache"
	"github.com/coindexpro/coindex-api/internal/graph"
	"github.com/coindexpro/coindex-api/internal/httpx"
	"github.com/coindexpro/coindex-api/internal/models"
	"github.com/coindexpro/coindex-api/internal/repositories"
)

type Services struct {
	cfg   *config.Config
	cache *cache.SWR
	ch    *repositories.ClickHouse
	ts    *repositories.Timescale
	pg    *repositories.Postgres
	graph *graph.Repo

	chBreaker *httpx.Breaker
	tsBreaker *httpx.Breaker
	pgBreaker *httpx.Breaker
}

func New(cfg *config.Config, c *cache.SWR, ch *repositories.ClickHouse, ts *repositories.Timescale,
	pg *repositories.Postgres, g *graph.Repo) *Services {
	return &Services{
		cfg: cfg, cache: c, ch: ch, ts: ts, pg: pg, graph: g,
		chBreaker: httpx.NewBreaker("clickhouse", 5, 10*time.Second),
		tsBreaker: httpx.NewBreaker("timescale", 5, 10*time.Second),
		pgBreaker: httpx.NewBreaker("postgres", 5, 10*time.Second),
	}
}

// cached runs a loader through the SWR cache under a key + TTL bucket.
func (s *Services) cached(ctx context.Context, key, ttlBucket string, load cache.Loader) (json.RawMessage, error) {
	return s.cache.Get(ctx, key, s.cfg.TTL(ttlBucket), load)
}

// ---- MARKET ----

func (s *Services) Trending(ctx context.Context, limit int) (json.RawMessage, error) {
	return s.cached(ctx, fmt.Sprintf("mkt:trending:%d", limit), "markets", func(ctx context.Context) (any, error) {
		var res []models.TokenProfile
		err := s.chBreaker.Do(func() error {
			r, e := s.ch.TrendingByVolume(ctx, limit)
			res = r
			return e
		})
		if err != nil {
			return nil, err
		}
		return models.Page[models.TokenProfile]{Items: res, Limit: limit, HasMore: len(res) == limit}, nil
	})
}

func (s *Services) NewPairs(ctx context.Context, limit int) (json.RawMessage, error) {
	return s.cached(ctx, fmt.Sprintf("mkt:newpairs:%d", limit), "markets", func(ctx context.Context) (any, error) {
		var res []models.NewPair
		err := s.chBreaker.Do(func() error { r, e := s.ch.NewPairs(ctx, limit); res = r; return e })
		if err != nil {
			return nil, err
		}
		return models.Page[models.NewPair]{Items: res, Limit: limit, HasMore: len(res) == limit}, nil
	})
}

func (s *Services) Sectors(ctx context.Context) (json.RawMessage, error) {
	return s.cached(ctx, "mkt:sectors", "markets", func(ctx context.Context) (any, error) {
		var res []models.SectorFlow
		err := s.tsBreaker.Do(func() error {
			r, e := s.ts.SectorFlows(ctx, time.Now().Add(-24*time.Hour))
			res = r
			return e
		})
		if err != nil {
			return nil, err
		}
		return models.Page[models.SectorFlow]{Items: res, Limit: len(res)}, nil
	})
}

// ---- TOKEN ----

// TokenProfile merges registry (Postgres) + latest metrics (ClickHouse). If the
// token is in neither, ok=false → handler returns unavailable.
func (s *Services) TokenProfile(ctx context.Context, chain, address string) (json.RawMessage, bool, error) {
	key := fmt.Sprintf("tok:%s:%s", chain, address)
	var found bool
	data, err := s.cached(ctx, key, "token", func(ctx context.Context) (any, error) {
		prof, ok, e := s.pg.TokenRegistry(ctx, chain, address)
		if e != nil {
			return nil, e
		}
		holders, top10, liq, vol, mok, me := s.ch.TokenMetrics(ctx, chain, address)
		if me != nil {
			return nil, me
		}
		if !ok && !mok {
			found = false
			return models.NotIndexed(), nil
		}
		found = true
		if !ok { // metrics exist but no registry row
			prof = models.TokenProfile{Chain: chain, Address: address, Source: "clickhouse:token_metrics"}
		}
		if mok {
			prof.Holders, prof.Top10Conc, prof.LiqUSD, prof.Vol24hUSD = &holders, &top10, &liq, &vol
		}
		return prof, nil
	})
	return data, found, err
}

func (s *Services) TokenHistory(ctx context.Context, chain, pool, tf string, limit int) (json.RawMessage, bool, error) {
	key := fmt.Sprintf("tok:hist:%s:%s:%s:%d", chain, pool, tf, limit)
	var has bool
	data, err := s.cached(ctx, key, "token", func(ctx context.Context) (any, error) {
		candles, ok, e := s.ts.Candles(ctx, chain, pool, tf, time.Now().Add(-90*24*time.Hour), time.Now(), limit)
		if e != nil {
			return nil, e
		}
		has = ok
		if !ok {
			return models.NotIndexed(), nil
		}
		return models.Page[models.Candle]{Items: candles, Limit: limit, HasMore: len(candles) == limit}, nil
	})
	return data, has, err
}

func (s *Services) TokenLiquidity(ctx context.Context, chain, pool string, limit int) (json.RawMessage, error) {
	key := fmt.Sprintf("tok:liq:%s:%s:%d", chain, pool, limit)
	return s.cached(ctx, key, "token", func(ctx context.Context) (any, error) {
		rows, e := s.ts.LiquidityHistory(ctx, chain, pool, limit)
		if e != nil {
			return nil, e
		}
		if len(rows) == 0 {
			return models.NotIndexed(), nil
		}
		return map[string]any{"items": rows}, nil
	})
}

func (s *Services) TokenRisk(ctx context.Context, chain, address string) (json.RawMessage, error) {
	// Risk requires the contract-analysis source (GoPlus/analyzer), which is a
	// later phase. Until that table is populated, return unavailable — never a
	// heuristic-only "verified" label.
	key := fmt.Sprintf("tok:risk:%s:%s", chain, address)
	return s.cached(ctx, key, "token", func(ctx context.Context) (any, error) {
		return models.Reason("risk engine not configured (Phase 8 — requires contract analysis source)"), nil
	})
}

func (s *Services) TokenHolders(ctx context.Context, chain, address string) (json.RawMessage, error) {
	// Holder breakdown requires a holder-snapshot index. token_metrics carries
	// aggregate concentration; full holder lists are not indexed yet.
	key := fmt.Sprintf("tok:holders:%s:%s", chain, address)
	return s.cached(ctx, key, "token", func(ctx context.Context) (any, error) {
		h, top10, _, _, ok, e := s.ch.TokenMetrics(ctx, chain, address)
		if e != nil {
			return nil, e
		}
		if !ok {
			return models.NotIndexed(), nil
		}
		return map[string]any{
			"holders": h, "top10_concentration": top10,
			"note": "aggregate from token_metrics; per-holder list not indexed",
		}, nil
	})
}

// ---- WHALE ----

func (s *Services) LiveWhales(ctx context.Context, minUSD float64, limit int) (json.RawMessage, error) {
	key := fmt.Sprintf("whale:live:%.0f:%d", minUSD, limit)
	return s.cached(ctx, key, "whales", func(ctx context.Context) (any, error) {
		var res []models.WhalePrint
		err := s.chBreaker.Do(func() error { r, e := s.ch.LiveWhales(ctx, minUSD, limit); res = r; return e })
		if err != nil {
			return nil, err
		}
		return models.Page[models.WhalePrint]{Items: res, Limit: limit, HasMore: len(res) == limit}, nil
	})
}

func (s *Services) SmartMoney(ctx context.Context, minConv uint8, limit int) (json.RawMessage, error) {
	key := fmt.Sprintf("whale:sm:%d:%d", minConv, limit)
	return s.cached(ctx, key, "whales", func(ctx context.Context) (any, error) {
		var res []models.SmartMoneyEvent
		err := s.chBreaker.Do(func() error { r, e := s.ch.SmartMoney(ctx, minConv, limit); res = r; return e })
		if err != nil {
			return nil, err
		}
		return models.Page[models.SmartMoneyEvent]{Items: res, Limit: limit, HasMore: len(res) == limit}, nil
	})
}

func (s *Services) Clusters(ctx context.Context, chain, edgeType string, limit int) (json.RawMessage, error) {
	key := fmt.Sprintf("whale:clusters:%s:%s:%d", chain, edgeType, limit)
	return s.cached(ctx, key, "clusters", func(ctx context.Context) (any, error) {
		var res []models.ClusterEdge
		err := s.pgBreaker.Do(func() error { r, e := s.graph.Clusters(ctx, chain, edgeType, limit); res = r; return e })
		if err != nil {
			return nil, err
		}
		return models.Page[models.ClusterEdge]{Items: res, Limit: limit, HasMore: len(res) == limit}, nil
	})
}

// ---- WALLET ----

func (s *Services) WalletProfile(ctx context.Context, address string) (json.RawMessage, error) {
	key := fmt.Sprintf("wallet:profile:%s", address)
	return s.cached(ctx, key, "wallets", func(ctx context.Context) (any, error) {
		labels, e := s.pg.Labels(ctx, "ethereum", address) // labels are chain-scoped; profile aggregates
		if e != nil {
			return nil, e
		}
		perf, ok, pe := s.ch.WalletPerformance(ctx, address)
		if pe != nil {
			return nil, pe
		}
		out := map[string]any{"address": address, "labels": labels}
		if ok {
			out["performance"] = perf
		} else {
			out["performance"] = models.NotIndexed()
		}
		return out, nil
	})
}

func (s *Services) WalletTrades(ctx context.Context, address string, limit, offset int) (json.RawMessage, error) {
	key := fmt.Sprintf("wallet:trades:%s:%d:%d", address, limit, offset)
	return s.cached(ctx, key, "wallets", func(ctx context.Context) (any, error) {
		var res []models.WalletTrade
		err := s.chBreaker.Do(func() error { r, e := s.ch.WalletTrades(ctx, address, limit, offset); res = r; return e })
		if err != nil {
			return nil, err
		}
		if len(res) == 0 {
			return models.NotIndexed(), nil
		}
		return models.Page[models.WalletTrade]{Items: res, Limit: limit, Offset: offset, HasMore: len(res) == limit}, nil
	})
}

func (s *Services) WalletPerformance(ctx context.Context, address string) (json.RawMessage, error) {
	key := fmt.Sprintf("wallet:perf:%s", address)
	return s.cached(ctx, key, "wallets", func(ctx context.Context) (any, error) {
		perf, ok, e := s.ch.WalletPerformance(ctx, address)
		if e != nil {
			return nil, e
		}
		if !ok {
			return models.NotIndexed(), nil
		}
		return perf, nil
	})
}

// ---- FLOWS ----  (require labeled exchange/bridge addresses)

func (s *Services) Flows(ctx context.Context, kind string) (json.RawMessage, error) {
	// Exchange/bridge/stablecoin flows require a labeled-address registry
	// (Phase 7 labels + Phase 11 flow engine). Without labels we cannot
	// attribute a transfer to an exchange/bridge, so we return unavailable
	// rather than guessing.
	key := fmt.Sprintf("flows:%s", kind)
	return s.cached(ctx, key, "flows", func(ctx context.Context) (any, error) {
		return models.Reason("flow engine not configured (requires labeled exchange/bridge addresses — Phase 7/11)"), nil
	})
}

// ---- SOCIAL ----  (require external API source)

func (s *Services) Social(ctx context.Context, token string) (json.RawMessage, error) {
	return s.cached(ctx, "social:"+token, "markets", func(ctx context.Context) (any, error) {
		return models.Reason("social engine not configured (requires X/Reddit/Telegram/Discord API keys — Phase 12)"), nil
	})
}

func (s *Services) Sentiment(ctx context.Context, token string) (json.RawMessage, error) {
	return s.cached(ctx, "sentiment:"+token, "markets", func(ctx context.Context) (any, error) {
		return models.Reason("sentiment engine not configured (requires social source — Phase 12)"), nil
	})
}

// ---- USER (no cache; per-user, mutating) ----

func (s *Services) Watchlists(ctx context.Context, userID string) (any, error) {
	return s.pg.Watchlists(ctx, userID)
}
func (s *Services) CreateWatchlist(ctx context.Context, userID, name string, items []models.WatchlistItem) (int64, error) {
	return s.pg.CreateWatchlist(ctx, userID, name, items)
}
func (s *Services) DeleteWatchlist(ctx context.Context, userID string, id int64) error {
	return s.pg.DeleteWatchlist(ctx, userID, id)
}
func (s *Services) Portfolios(ctx context.Context, userID string) (any, error) {
	return s.pg.Portfolios(ctx, userID)
}
func (s *Services) SyncPortfolio(ctx context.Context, userID, chain, wallet string) error {
	return s.pg.RequestPortfolioSync(ctx, userID, chain, wallet)
}
func (s *Services) Alerts(ctx context.Context, userID string) (any, error) {
	return s.pg.Alerts(ctx, userID)
}
func (s *Services) CreateAlert(ctx context.Context, userID, kind string, target map[string]any, channels []map[string]any) (int64, error) {
	return s.pg.CreateAlert(ctx, userID, kind, target, channels)
}
func (s *Services) DeleteAlert(ctx context.Context, userID string, id int64) error {
	return s.pg.DeleteAlert(ctx, userID, id)
}
