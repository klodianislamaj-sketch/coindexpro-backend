// Package premium enforces tier-gated route access. Premium prefixes are
// configured; free callers hitting them get 402 (payment required) with the
// standard envelope, never silently-degraded fake data.
package premium

import (
	"strings"

	"github.com/coindexpro/coindex-api/internal/auth"
)

type Gate struct{ prefixes []string }

func New(prefixes []string) *Gate { return &Gate{prefixes: prefixes} }

// Requires reports whether a path is premium-gated.
func (g *Gate) Requires(path string) bool {
	for _, p := range g.prefixes {
		if strings.HasPrefix(path, p) {
			return true
		}
	}
	return false
}

// Allowed reports whether the tier may access a premium route.
func (g *Gate) Allowed(t auth.Tier) bool {
	return t == auth.TierPremium || t == auth.TierAdmin
}
