package auth

import (
	"crypto/sha256"
	"encoding/hex"
)

// HashKey returns the hex sha256 of an API key. Only the hash is ever stored or
// compared against the api_keys table; the raw key is never persisted or logged.
func HashKey(key string) string {
	sum := sha256.Sum256([]byte(key))
	return hex.EncodeToString(sum[:])
}
