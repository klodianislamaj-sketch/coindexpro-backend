// Package auth resolves the caller's identity and tier from a JWT or API key.
// Tiers: free, premium, admin. The wallet-signature path is a clearly-labelled
// stub: it validates shape but does NOT assert a verified identity until real
// signature verification is wired (it never grants elevated access).
package auth

import (
	"context"
	"errors"
	"strings"

	"github.com/golang-jwt/jwt/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

type Tier string

const (
	TierFree    Tier = "free"
	TierPremium Tier = "premium"
	TierAdmin   Tier = "admin"
)

type Identity struct {
	UserID string
	Tier   Tier
	Source string // "jwt" | "apikey" | "anonymous"
}

type Authenticator struct {
	jwtSecret   []byte
	adminAPIKey string
	pg          *pgxpool.Pool
}

func New(jwtSecret, adminAPIKey string, pg *pgxpool.Pool) *Authenticator {
	return &Authenticator{jwtSecret: []byte(jwtSecret), adminAPIKey: adminAPIKey, pg: pg}
}

var ErrUnauthorized = errors.New("unauthorized")

// FromJWT validates a bearer token and returns the identity + tier claim.
func (a *Authenticator) FromJWT(tokenStr string) (Identity, error) {
	tok, err := jwt.Parse(tokenStr, func(t *jwt.Token) (any, error) {
		if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, ErrUnauthorized
		}
		return a.jwtSecret, nil
	})
	if err != nil || !tok.Valid {
		return Identity{}, ErrUnauthorized
	}
	claims, ok := tok.Claims.(jwt.MapClaims)
	if !ok {
		return Identity{}, ErrUnauthorized
	}
	uid, _ := claims["sub"].(string)
	tier, _ := claims["tier"].(string)
	if uid == "" {
		return Identity{}, ErrUnauthorized
	}
	return Identity{UserID: uid, Tier: normalizeTier(tier), Source: "jwt"}, nil
}

// FromAPIKey resolves an API key. The admin key is matched directly; user keys
// are looked up by hash in Postgres (api_keys table), returning the owner's tier.
func (a *Authenticator) FromAPIKey(ctx context.Context, key string) (Identity, error) {
	if key != "" && key == a.adminAPIKey {
		return Identity{UserID: "admin", Tier: TierAdmin, Source: "apikey"}, nil
	}
	hash := HashKey(key)
	const q = `
		SELECT k.user_id, u.tier
		FROM api_keys k JOIN user_accounts u ON u.id = k.user_id
		WHERE k.key_hash = $1 AND NOT k.revoked`
	var uid, tier string
	if err := a.pg.QueryRow(ctx, q, hash).Scan(&uid, &tier); err != nil {
		return Identity{}, ErrUnauthorized
	}
	return Identity{UserID: uid, Tier: normalizeTier(tier), Source: "apikey"}, nil
}

// FromWalletSignature — STUB. Real EIP-191/4361 (SIWE) verification is not yet
// wired; this returns unauthorized rather than granting access, so it can never
// be a fake-live elevation. Shape-checks only.
func (a *Authenticator) FromWalletSignature(addr, sig, nonce string) (Identity, error) {
	if !strings.HasPrefix(addr, "0x") || sig == "" || nonce == "" {
		return Identity{}, ErrUnauthorized
	}
	// Intentionally NOT returning a verified identity: signature verification
	// must be implemented before this path can authenticate anyone.
	return Identity{}, errors.New("wallet signature auth not yet enabled")
}

func normalizeTier(t string) Tier {
	switch Tier(strings.ToLower(t)) {
	case TierAdmin:
		return TierAdmin
	case TierPremium:
		return TierPremium
	default:
		return TierFree
	}
}
