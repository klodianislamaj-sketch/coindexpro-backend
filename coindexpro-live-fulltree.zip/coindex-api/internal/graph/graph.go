// Package graph reads the Postgres property-graph schema (graph.wallet_nodes,
// graph.wallet_edges) for clusters and influence traversal.
package graph

import (
	"context"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/coindexpro/coindex-api/internal/metrics"
	"github.com/coindexpro/coindex-api/internal/models"
)

type Repo struct{ db *pgxpool.Pool }

func New(db *pgxpool.Pool) *Repo { return &Repo{db: db} }

func timed(op string) func() {
	t := time.Now()
	return func() { metrics.DBQuery.WithLabelValues("graph", op).Observe(time.Since(t).Seconds()) }
}

// Clusters returns the strongest wallet-wallet edges of a given type.
func (r *Repo) Clusters(ctx context.Context, chain, edgeType string, limit int) ([]models.ClusterEdge, error) {
	defer timed("clusters")()
	const q = `
		SELECT chain, src, dst, edge_type, weight, shared_tokens
		FROM graph.wallet_edges
		WHERE chain = $1 AND edge_type = $2
		ORDER BY weight DESC
		LIMIT $3`
	rows, err := r.db.Query(ctx, q, chain, edgeType, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.ClusterEdge
	for rows.Next() {
		var e models.ClusterEdge
		if err := rows.Scan(&e.Chain, &e.Src, &e.Dst, &e.EdgeType, &e.Weight, &e.SharedTokens); err != nil {
			return nil, err
		}
		out = append(out, e)
	}
	return out, rows.Err()
}

// Neighbors runs the bounded recursive traversal defined in the graph schema
// (graph.neighbors function) — real influence/relationship expansion.
func (r *Repo) Neighbors(ctx context.Context, chain, seed, edgeType string, depth int) ([]map[string]any, error) {
	defer timed("neighbors")()
	const q = `SELECT address, depth, path_weight FROM graph.neighbors($1, $2, $3, $4)`
	rows, err := r.db.Query(ctx, q, chain, seed, edgeType, depth)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []map[string]any
	for rows.Next() {
		var addr string
		var d int
		var w float64
		if err := rows.Scan(&addr, &d, &w); err != nil {
			return nil, err
		}
		out = append(out, map[string]any{"address": addr, "depth": d, "path_weight": w})
	}
	return out, rows.Err()
}

// TopInfluence returns the highest-influence wallets (precomputed score).
func (r *Repo) TopInfluence(ctx context.Context, chain string, limit int) ([]map[string]any, error) {
	defer timed("top_influence")()
	const q = `
		SELECT address, influence, cluster_id
		FROM graph.wallet_nodes
		WHERE chain = $1
		ORDER BY influence DESC
		LIMIT $2`
	rows, err := r.db.Query(ctx, q, chain, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []map[string]any
	for rows.Next() {
		var addr string
		var inf float64
		var cluster *int64
		if err := rows.Scan(&addr, &inf, &cluster); err != nil {
			return nil, err
		}
		out = append(out, map[string]any{"address": addr, "influence": inf, "cluster_id": cluster})
	}
	return out, rows.Err()
}
