// Package models defines API DTOs and the standard response envelopes.
package models

import "time"

// Unavailable is the MANDATORY shape for any data that has no real source.
// Per the no-fabrication rule, handlers return this instead of estimating.
type Unavailable struct {
	Available bool   `json:"available"`
	Reason    string `json:"reason"`
}

func NotIndexed() Unavailable    { return Unavailable{Available: false, Reason: "not indexed"} }
func NotConfigured() Unavailable { return Unavailable{Available: false, Reason: "not configured"} }
func Reason(r string) Unavailable { return Unavailable{Available: false, Reason: r} }

// Page wraps a list with pagination metadata.
type Page[T any] struct {
	Items   []T  `json:"items"`
	Limit   int  `json:"limit"`
	Offset  int  `json:"offset"`
	HasMore bool `json:"has_more"`
}

// --- domain DTOs (shapes returned by handlers) ---

type TokenProfile struct {
	Chain       string    `json:"chain"`
	Address     string    `json:"address"`
	Symbol      string    `json:"symbol,omitempty"`
	Name        string    `json:"name,omitempty"`
	Decimals    int       `json:"decimals,omitempty"`
	IsOfficial  bool      `json:"is_official"`
	Holders     *uint64   `json:"holders,omitempty"`       // nil = not indexed
	LiqUSD      *float64  `json:"liq_usd,omitempty"`
	Vol24hUSD   *float64  `json:"vol24h_usd,omitempty"`
	Top10Conc   *float64  `json:"top10_concentration,omitempty"`
	UpdatedAt   time.Time `json:"updated_at,omitempty"`
	Source      string    `json:"source"`
}

type Candle struct {
	Bucket    time.Time `json:"t"`
	Open      float64   `json:"o"`
	High      float64   `json:"h"`
	Low       float64   `json:"l"`
	Close     float64   `json:"c"`
	VolumeUSD float64   `json:"v"`
	Trades    int       `json:"n"`
}

type WhalePrint struct {
	Chain     string    `json:"chain"`
	Wallet    string    `json:"wallet"`
	Token     string    `json:"token"`
	Side      string    `json:"side"`
	USD       float64   `json:"usd"`
	TxHash    string    `json:"tx_hash"`
	BlockTime time.Time `json:"block_time"`
}

type WalletTrade struct {
	Chain     string    `json:"chain"`
	Token     string    `json:"token"`
	Side      string    `json:"side"`
	Qty       string    `json:"qty"`
	PriceUSD  float64   `json:"price_usd"`
	USD       float64   `json:"usd"`
	BlockTime time.Time `json:"block_time"`
	TxHash    string    `json:"tx_hash"`
}

// WalletPerformance is computed ONLY from indexed wallet_positions (real fills).
// All fields are pointers: nil means "not derivable from indexed history",
// rendered as unavailable rather than a fabricated zero.
type WalletPerformance struct {
	Chain         string   `json:"chain"`
	Wallet        string   `json:"wallet"`
	RealizedUSD   *float64 `json:"realized_pnl_usd,omitempty"`
	UnrealizedUSD *float64 `json:"unrealized_pnl_usd,omitempty"`
	OpenPositions *int     `json:"open_positions,omitempty"`
	Note          string   `json:"note,omitempty"`
}

type SmartMoneyEvent struct {
	Chain      string    `json:"chain"`
	Wallet     string    `json:"wallet"`
	Token      string    `json:"token"`
	Side       string    `json:"side"`
	USD        float64   `json:"usd"`
	Conviction int       `json:"conviction"`
	Reason     string    `json:"reason"`
	BlockTime  time.Time `json:"block_time"`
}

type ClusterEdge struct {
	Chain        string  `json:"chain"`
	Src          string  `json:"src"`
	Dst          string  `json:"dst"`
	EdgeType     string  `json:"edge_type"`
	Weight       float64 `json:"weight"`
	SharedTokens int     `json:"shared_tokens"`
}

type NewPair struct {
	Chain     string    `json:"chain"`
	Pool      string    `json:"pool"`
	Token0    string    `json:"token0"`
	Token1    string    `json:"token1"`
	DEX       string    `json:"dex"`
	BlockTime time.Time `json:"block_time"`
}

type SectorFlow struct {
	Sector     string    `json:"sector"`
	InflowUSD  float64   `json:"inflow_usd"`
	OutflowUSD float64   `json:"outflow_usd"`
	NetUSD     float64   `json:"net_usd"`
	VolumeUSD  float64   `json:"volume_usd"`
	TS         time.Time `json:"ts"`
}

type Watchlist struct {
	ID    int64           `json:"id"`
	Name  string          `json:"name"`
	Items []WatchlistItem `json:"items"`
}
type WatchlistItem struct {
	Chain   string `json:"chain"`
	Address string `json:"address"`
	Kind    string `json:"kind"`
}

type Alert struct {
	ID       int64                  `json:"id"`
	Kind     string                 `json:"kind"`
	Target   map[string]any         `json:"target"`
	Channels []map[string]any       `json:"channels"`
	Enabled  bool                   `json:"enabled"`
}
