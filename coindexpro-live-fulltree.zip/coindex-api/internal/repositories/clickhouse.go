// Package repositories holds all SQL access. Each method maps to exactly one
// source-of-truth table. No method fabricates: if a query returns no rows, the
// caller decides whether that is an empty list or an "unavailable" response.
package repositories

import (
	"context"
	"time"

	"github.com/ClickHouse/clickhouse-go/v2/lib/driver"

	"github.com/coindexpro/coindex-api/internal/metrics"
	"github.com/coindexpro/coindex-api/internal/models"
)

type ClickHouse struct{ conn driver.Conn }

func NewClickHouse(conn driver.Conn) *ClickHouse { return &ClickHouse{conn: conn} }

func timed(store, op string) func() {
	t := time.Now()
	return func() { metrics.DBQuery.WithLabelValues(store, op).Observe(time.Since(t).Seconds()) }
}

// LiveWhales returns recent large prints from smart_money_events/whale source.
// Reads from smart_money_events (already USD-priced) ordered by time.
func (c *ClickHouse) LiveWhales(ctx context.Context, minUSD float64, limit int) ([]models.WhalePrint, error) {
	defer timed("clickhouse", "live_whales")()
	const q = `
		SELECT chain, wallet, token, side, usd, tx_hash, block_time
		FROM coindex.smart_money_events
		WHERE usd >= ?
		ORDER BY block_time DESC
		LIMIT ?`
	rows, err := c.conn.Query(ctx, q, minUSD, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.WhalePrint
	for rows.Next() {
		var w models.WhalePrint
		var side string
		if err := rows.Scan(&w.Chain, &w.Wallet, &w.Token, &side, &w.USD, &w.TxHash, &w.BlockTime); err != nil {
			return nil, err
		}
		w.Side = side
		out = append(out, w)
	}
	return out, rows.Err()
}

// SmartMoney returns recent high-conviction events.
func (c *ClickHouse) SmartMoney(ctx context.Context, minConviction uint8, limit int) ([]models.SmartMoneyEvent, error) {
	defer timed("clickhouse", "smart_money")()
	const q = `
		SELECT chain, wallet, token, side, usd, conviction, reason, block_time
		FROM coindex.smart_money_events
		WHERE conviction >= ?
		ORDER BY block_time DESC
		LIMIT ?`
	rows, err := c.conn.Query(ctx, q, minConviction, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.SmartMoneyEvent
	for rows.Next() {
		var e models.SmartMoneyEvent
		var side string
		var conv uint8
		if err := rows.Scan(&e.Chain, &e.Wallet, &e.Token, &side, &e.USD, &conv, &e.Reason, &e.BlockTime); err != nil {
			return nil, err
		}
		e.Side, e.Conviction = side, int(conv)
		out = append(out, e)
	}
	return out, rows.Err()
}

// WalletTrades returns a wallet's real indexed trades.
func (c *ClickHouse) WalletTrades(ctx context.Context, wallet string, limit, offset int) ([]models.WalletTrade, error) {
	defer timed("clickhouse", "wallet_trades")()
	const q = `
		SELECT chain, token, side, qty, price_usd, usd, block_time, tx_hash
		FROM coindex.wallet_trades
		WHERE wallet = ?
		ORDER BY block_time DESC
		LIMIT ? OFFSET ?`
	rows, err := c.conn.Query(ctx, q, wallet, limit, offset)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.WalletTrade
	for rows.Next() {
		var t models.WalletTrade
		var side string
		if err := rows.Scan(&t.Chain, &t.Token, &side, &t.Qty, &t.PriceUSD, &t.USD, &t.BlockTime, &t.TxHash); err != nil {
			return nil, err
		}
		t.Side = side
		out = append(out, t)
	}
	return out, rows.Err()
}

// WalletPerformance aggregates realized/unrealized PnL from wallet_positions —
// REAL fills only. Returns ok=false when the wallet has no indexed positions
// (so the handler returns "unavailable", never a fabricated zero).
func (c *ClickHouse) WalletPerformance(ctx context.Context, wallet string) (models.WalletPerformance, bool, error) {
	defer timed("clickhouse", "wallet_perf")()
	const q = `
		SELECT any(chain),
		       sum(realized_usd) AS realized,
		       count() AS positions
		FROM coindex.wallet_positions FINAL
		WHERE wallet = ?`
	var chain string
	var realized float64
	var positions uint64
	if err := c.conn.QueryRow(ctx, q, wallet).Scan(&chain, &realized, &positions); err != nil {
		return models.WalletPerformance{}, false, err
	}
	if positions == 0 {
		return models.WalletPerformance{}, false, nil
	}
	pos := int(positions)
	perf := models.WalletPerformance{
		Chain: chain, Wallet: wallet,
		RealizedUSD: &realized, OpenPositions: &pos,
		// Unrealized requires a live price join (enricher); left nil until that
		// source is wired, rather than estimated here.
		Note: "unrealized PnL requires live price feed (enricher); realized is from indexed fills",
	}
	return perf, true, nil
}

// TokenMetrics returns the latest metrics row for a token (or ok=false).
func (c *ClickHouse) TokenMetrics(ctx context.Context, chain, token string) (holders uint64, top10, liq, vol float64, ok bool, err error) {
	defer timed("clickhouse", "token_metrics")()
	const q = `
		SELECT holders, top10_concentration, liq_usd, vol24h_usd
		FROM coindex.token_metrics FINAL
		WHERE chain = ? AND token = ?
		ORDER BY ts DESC LIMIT 1`
	e := c.conn.QueryRow(ctx, q, chain, token).Scan(&holders, &top10, &liq, &vol)
	if e != nil {
		// no row → not indexed; report ok=false without error
		return 0, 0, 0, 0, false, nil
	}
	return holders, top10, liq, vol, true, nil
}

// NewPairs returns recently-created pairs across chains.
func (c *ClickHouse) NewPairs(ctx context.Context, limit int) ([]models.NewPair, error) {
	defer timed("clickhouse", "new_pairs")()
	const q = `
		SELECT chain, pool_address, token0, token1, dex, block_time
		FROM coindex.new_pairs
		ORDER BY block_time DESC
		LIMIT ?`
	rows, err := c.conn.Query(ctx, q, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.NewPair
	for rows.Next() {
		var p models.NewPair
		if err := rows.Scan(&p.Chain, &p.Pool, &p.Token0, &p.Token1, &p.DEX, &p.BlockTime); err != nil {
			return nil, err
		}
		out = append(out, p)
	}
	return out, rows.Err()
}

// Trending/Gainers/Losers derive from token_metrics volume/derived deltas.
// Returns rows ordered by 24h volume as the "trending" proxy (real metric).
func (c *ClickHouse) TrendingByVolume(ctx context.Context, limit int) ([]models.TokenProfile, error) {
	defer timed("clickhouse", "trending")()
	const q = `
		SELECT chain, token, holders, top10_concentration, liq_usd, vol24h_usd
		FROM coindex.token_metrics FINAL
		ORDER BY vol24h_usd DESC
		LIMIT ?`
	rows, err := c.conn.Query(ctx, q, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.TokenProfile
	for rows.Next() {
		var p models.TokenProfile
		var holders uint64
		var top10, liq, vol float64
		if err := rows.Scan(&p.Chain, &p.Address, &holders, &top10, &liq, &vol); err != nil {
			return nil, err
		}
		p.Holders, p.Top10Conc, p.LiqUSD, p.Vol24hUSD = &holders, &top10, &liq, &vol
		p.Source = "clickhouse:token_metrics"
		out = append(out, p)
	}
	return out, rows.Err()
}
