package repositories

import (
	"context"
	"encoding/json"
	"errors"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/coindexpro/coindex-api/internal/models"
)

type Postgres struct{ db *pgxpool.Pool }

func NewPostgres(db *pgxpool.Pool) *Postgres { return &Postgres{db: db} }

var ErrNotFound = errors.New("not found")

// TokenRegistry returns registry fields for a token (ok=false if not present).
func (p *Postgres) TokenRegistry(ctx context.Context, chain, address string) (models.TokenProfile, bool, error) {
	defer timed("postgres", "token_registry")()
	const q = `
		SELECT chain, address, coalesce(symbol,''), coalesce(name,''),
		       coalesce(decimals,0), is_official
		FROM token_registry WHERE chain = $1 AND address = $2`
	var t models.TokenProfile
	err := p.db.QueryRow(ctx, q, chain, address).Scan(
		&t.Chain, &t.Address, &t.Symbol, &t.Name, &t.Decimals, &t.IsOfficial)
	if errors.Is(err, pgx.ErrNoRows) {
		return models.TokenProfile{}, false, nil
	}
	if err != nil {
		return models.TokenProfile{}, false, err
	}
	t.Source = "postgres:token_registry"
	return t, true, nil
}

// Labels returns active labels for an address (empty slice = unlabeled; never invented).
func (p *Postgres) Labels(ctx context.Context, chain, address string) ([]map[string]any, error) {
	defer timed("postgres", "labels")()
	const q = `
		SELECT label_type, coalesce(entity,''), source, confidence
		FROM wallet_labels
		WHERE chain = $1 AND address = $2 AND active
		ORDER BY confidence DESC`
	rows, err := p.db.Query(ctx, q, chain, address)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []map[string]any
	for rows.Next() {
		var lt, entity, source string
		var conf float64
		if err := rows.Scan(&lt, &entity, &source, &conf); err != nil {
			return nil, err
		}
		out = append(out, map[string]any{"label": lt, "entity": entity, "source": source, "confidence": conf})
	}
	return out, rows.Err()
}

// --- Watchlists ---

func (p *Postgres) Watchlists(ctx context.Context, userID string) ([]models.Watchlist, error) {
	defer timed("postgres", "watchlists")()
	const q = `SELECT id, name, items FROM watchlists WHERE user_id = $1 ORDER BY created_at`
	rows, err := p.db.Query(ctx, q, userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.Watchlist
	for rows.Next() {
		var w models.Watchlist
		var items []byte
		if err := rows.Scan(&w.ID, &w.Name, &items); err != nil {
			return nil, err
		}
		_ = json.Unmarshal(items, &w.Items)
		out = append(out, w)
	}
	return out, rows.Err()
}

func (p *Postgres) CreateWatchlist(ctx context.Context, userID, name string, items []models.WatchlistItem) (int64, error) {
	defer timed("postgres", "create_watchlist")()
	itemsJSON, _ := json.Marshal(items)
	const q = `INSERT INTO watchlists (user_id, name, items) VALUES ($1,$2,$3) RETURNING id`
	var id int64
	err := p.db.QueryRow(ctx, q, userID, name, itemsJSON).Scan(&id)
	return id, err
}

func (p *Postgres) DeleteWatchlist(ctx context.Context, userID string, id int64) error {
	defer timed("postgres", "delete_watchlist")()
	ct, err := p.db.Exec(ctx, `DELETE FROM watchlists WHERE id = $1 AND user_id = $2`, id, userID)
	if err != nil {
		return err
	}
	if ct.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}

// --- Portfolios ---

func (p *Postgres) Portfolios(ctx context.Context, userID string) ([]map[string]any, error) {
	defer timed("postgres", "portfolios")()
	const q = `SELECT chain, wallet, sync_state, synced_at FROM portfolios WHERE user_id = $1`
	rows, err := p.db.Query(ctx, q, userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []map[string]any
	for rows.Next() {
		var chain, wallet, state string
		var syncedAt *string
		if err := rows.Scan(&chain, &wallet, &state, &syncedAt); err != nil {
			return nil, err
		}
		out = append(out, map[string]any{"chain": chain, "wallet": wallet, "sync_state": state, "synced_at": syncedAt})
	}
	return out, rows.Err()
}

// RequestPortfolioSync records a sync request. Actual sync is a background job
// (out of scope for the read API); this only enqueues state, never fakes holdings.
func (p *Postgres) RequestPortfolioSync(ctx context.Context, userID, chain, wallet string) error {
	defer timed("postgres", "portfolio_sync")()
	const q = `
		INSERT INTO portfolios (user_id, chain, wallet, sync_state)
		VALUES ($1,$2,$3,'syncing')
		ON CONFLICT (user_id, chain, wallet) DO UPDATE SET sync_state = 'syncing'`
	_, err := p.db.Exec(ctx, q, userID, chain, wallet)
	return err
}

// --- Alerts ---

func (p *Postgres) Alerts(ctx context.Context, userID string) ([]models.Alert, error) {
	defer timed("postgres", "alerts")()
	const q = `SELECT id, kind, target, channels, enabled FROM alerts WHERE user_id = $1 ORDER BY created_at DESC`
	rows, err := p.db.Query(ctx, q, userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.Alert
	for rows.Next() {
		var a models.Alert
		var target, channels []byte
		if err := rows.Scan(&a.ID, &a.Kind, &target, &channels, &a.Enabled); err != nil {
			return nil, err
		}
		_ = json.Unmarshal(target, &a.Target)
		_ = json.Unmarshal(channels, &a.Channels)
		out = append(out, a)
	}
	return out, rows.Err()
}

func (p *Postgres) CreateAlert(ctx context.Context, userID, kind string, target map[string]any, channels []map[string]any) (int64, error) {
	defer timed("postgres", "create_alert")()
	tj, _ := json.Marshal(target)
	cj, _ := json.Marshal(channels)
	const q = `INSERT INTO alerts (user_id, kind, target, channels) VALUES ($1,$2,$3,$4) RETURNING id`
	var id int64
	err := p.db.QueryRow(ctx, q, userID, kind, tj, cj).Scan(&id)
	return id, err
}

func (p *Postgres) DeleteAlert(ctx context.Context, userID string, id int64) error {
	defer timed("postgres", "delete_alert")()
	ct, err := p.db.Exec(ctx, `DELETE FROM alerts WHERE id = $1 AND user_id = $2`, id, userID)
	if err != nil {
		return err
	}
	if ct.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}
