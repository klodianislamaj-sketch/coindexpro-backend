package repositories

import (
	"context"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/coindexpro/coindex-api/internal/models"
)

type Timescale struct{ db *pgxpool.Pool }

func NewTimescale(db *pgxpool.Pool) *Timescale { return &Timescale{db: db} }

// validTimeframes maps the API timeframe param to the real table/view name.
// This is also an allowlist — only these strings can reach the query, so the
// table name is never built from raw user input (SQL-injection safe).
var validTimeframes = map[string]string{
	"1m": "candles_1m", "5m": "candles_5m", "15m": "candles_15m",
	"1h": "candles_1h", "4h": "candles_4h",
}

func (t *Timescale) Candles(ctx context.Context, chain, pool, timeframe string, from, to time.Time, limit int) ([]models.Candle, bool, error) {
	defer timed("timescale", "candles")()
	table, ok := validTimeframes[timeframe]
	if !ok {
		return nil, false, fmt.Errorf("invalid timeframe")
	}
	// table is from the allowlist above, not user input → safe to interpolate.
	q := fmt.Sprintf(`
		SELECT bucket, open, high, low, close, volume_usd, trades
		FROM %s
		WHERE chain = $1 AND pool_address = $2 AND bucket BETWEEN $3 AND $4
		ORDER BY bucket DESC
		LIMIT $5`, table)
	rows, err := t.db.Query(ctx, q, chain, pool, from, to, limit)
	if err != nil {
		return nil, false, err
	}
	defer rows.Close()
	var out []models.Candle
	for rows.Next() {
		var c models.Candle
		if err := rows.Scan(&c.Bucket, &c.Open, &c.High, &c.Low, &c.Close, &c.VolumeUSD, &c.Trades); err != nil {
			return nil, false, err
		}
		out = append(out, c)
	}
	return out, len(out) > 0, rows.Err()
}

func (t *Timescale) LiquidityHistory(ctx context.Context, chain, pool string, limit int) ([]map[string]any, error) {
	defer timed("timescale", "liquidity_history")()
	const q = `
		SELECT ts, liq_usd FROM liquidity_history
		WHERE chain = $1 AND pool_address = $2
		ORDER BY ts DESC LIMIT $3`
	rows, err := t.db.Query(ctx, q, chain, pool, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []map[string]any
	for rows.Next() {
		var ts time.Time
		var liq float64
		if err := rows.Scan(&ts, &liq); err != nil {
			return nil, err
		}
		out = append(out, map[string]any{"ts": ts, "liq_usd": liq})
	}
	return out, rows.Err()
}

func (t *Timescale) SectorFlows(ctx context.Context, since time.Time) ([]models.SectorFlow, error) {
	defer timed("timescale", "sector_flows")()
	const q = `
		SELECT sector, sum(inflow_usd), sum(outflow_usd),
		       sum(inflow_usd) - sum(outflow_usd), sum(volume_usd), max(ts)
		FROM sector_history
		WHERE ts >= $1
		GROUP BY sector
		ORDER BY sum(volume_usd) DESC`
	rows, err := t.db.Query(ctx, q, since)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.SectorFlow
	for rows.Next() {
		var s models.SectorFlow
		if err := rows.Scan(&s.Sector, &s.InflowUSD, &s.OutflowUSD, &s.NetUSD, &s.VolumeUSD, &s.TS); err != nil {
			return nil, err
		}
		out = append(out, s)
	}
	return out, rows.Err()
}

// TrustHistory returns the trust-score series for a token (real, source-backed).
func (t *Timescale) TrustHistory(ctx context.Context, chain, token string, limit int) ([]map[string]any, error) {
	defer timed("timescale", "trust_history")()
	const q = `
		SELECT ts, trust, confidence FROM trust_history
		WHERE chain = $1 AND token = $2
		ORDER BY ts DESC LIMIT $3`
	rows, err := t.db.Query(ctx, q, chain, token, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []map[string]any
	for rows.Next() {
		var ts time.Time
		var trust int
		var conf string
		if err := rows.Scan(&ts, &trust, &conf); err != nil {
			return nil, err
		}
		out = append(out, map[string]any{"ts": ts, "trust": trust, "confidence": conf})
	}
	return out, rows.Err()
}
