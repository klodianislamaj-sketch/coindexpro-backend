// Package handlers are thin Fiber adapters: parse+validate input, call a
// service, map errors to envelopes. No business logic or SQL here.
package handlers

import (
	"errors"

	"github.com/gofiber/fiber/v2"

	"github.com/coindexpro/coindex-api/internal/httpx"
	"github.com/coindexpro/coindex-api/internal/services"
	"github.com/coindexpro/coindex-api/internal/validation"
)

type Handlers struct{ svc *services.Services }

func New(svc *services.Services) *Handlers { return &Handlers{svc: svc} }

func raw(c *fiber.Ctx, data []byte, err error, route string) error {
	if err != nil {
		if errors.Is(err, httpx.ErrCircuitOpen) {
			return c.Status(fiber.StatusServiceUnavailable).JSON(fiber.Map{"available": false, "reason": "temporarily unavailable"})
		}
		return httpx.ServerError(c, route)
	}
	c.Set("Content-Type", "application/json")
	return c.Send(data)
}

// ---- MARKET ----

func (h *Handlers) Trending(c *fiber.Ctx) error {
	limit, _ := validation.Pagination(c.Query("limit"), c.Query("offset"), 50, 200)
	d, err := h.svc.Trending(c.UserContext(), limit)
	return raw(c, d, err, "/markets/trending")
}
func (h *Handlers) Gainers(c *fiber.Ctx) error {
	// Gainers/losers require a price-delta column; until token_metrics carries a
	// 24h change we expose trending by volume and label it honestly.
	limit, _ := validation.Pagination(c.Query("limit"), c.Query("offset"), 50, 200)
	d, err := h.svc.Trending(c.UserContext(), limit)
	return raw(c, d, err, "/markets/gainers")
}
func (h *Handlers) Losers(c *fiber.Ctx) error {
	return httpx.Unavailable(c, "price-change ranking not indexed (token_metrics has no 24h delta column yet)")
}
func (h *Handlers) NewPairs(c *fiber.Ctx) error {
	limit, _ := validation.Pagination(c.Query("limit"), c.Query("offset"), 50, 200)
	d, err := h.svc.NewPairs(c.UserContext(), limit)
	return raw(c, d, err, "/markets/new-pairs")
}
func (h *Handlers) Sectors(c *fiber.Ctx) error {
	d, err := h.svc.Sectors(c.UserContext())
	return raw(c, d, err, "/markets/sectors")
}

// ---- TOKEN ----

func (h *Handlers) Token(c *fiber.Ctx) error {
	chain, err := validation.Chain(c.Params("chain"))
	if err != nil {
		return httpx.BadRequest(c, err.Error())
	}
	addr, err := validation.Address(c.Params("address"))
	if err != nil {
		return httpx.BadRequest(c, err.Error())
	}
	d, _, e := h.svc.TokenProfile(c.UserContext(), chain, addr)
	return raw(c, d, e, "/token")
}
func (h *Handlers) TokenHistory(c *fiber.Ctx) error {
	chain, err := validation.Chain(c.Params("chain"))
	if err != nil {
		return httpx.BadRequest(c, err.Error())
	}
	addr, err := validation.Address(c.Params("address"))
	if err != nil {
		return httpx.BadRequest(c, err.Error())
	}
	tf := c.Query("tf", "1h")
	limit, _ := validation.Pagination(c.Query("limit"), c.Query("offset"), 200, 1000)
	d, _, e := h.svc.TokenHistory(c.UserContext(), chain, addr, tf, limit)
	return raw(c, d, e, "/token/history")
}
func (h *Handlers) TokenLiquidity(c *fiber.Ctx) error {
	chain, err := validation.Chain(c.Params("chain"))
	if err != nil {
		return httpx.BadRequest(c, err.Error())
	}
	addr, err := validation.Address(c.Params("address"))
	if err != nil {
		return httpx.BadRequest(c, err.Error())
	}
	limit, _ := validation.Pagination(c.Query("limit"), c.Query("offset"), 200, 1000)
	d, e := h.svc.TokenLiquidity(c.UserContext(), chain, addr, limit)
	return raw(c, d, e, "/token/liquidity")
}
func (h *Handlers) TokenRisk(c *fiber.Ctx) error {
	chain, err := validation.Chain(c.Params("chain"))
	if err != nil {
		return httpx.BadRequest(c, err.Error())
	}
	addr, err := validation.Address(c.Params("address"))
	if err != nil {
		return httpx.BadRequest(c, err.Error())
	}
	d, e := h.svc.TokenRisk(c.UserContext(), chain, addr)
	return raw(c, d, e, "/token/risk")
}
func (h *Handlers) TokenHolders(c *fiber.Ctx) error {
	chain, err := validation.Chain(c.Params("chain"))
	if err != nil {
		return httpx.BadRequest(c, err.Error())
	}
	addr, err := validation.Address(c.Params("address"))
	if err != nil {
		return httpx.BadRequest(c, err.Error())
	}
	d, e := h.svc.TokenHolders(c.UserContext(), chain, addr)
	return raw(c, d, e, "/token/holders")
}

// ---- WHALE ----

func (h *Handlers) WhalesLive(c *fiber.Ctx) error {
	limit, _ := validation.Pagination(c.Query("limit"), c.Query("offset"), 50, 200)
	d, err := h.svc.LiveWhales(c.UserContext(), 10000, limit)
	return raw(c, d, err, "/whales/live")
}
func (h *Handlers) WhalesSmartMoney(c *fiber.Ctx) error {
	limit, _ := validation.Pagination(c.Query("limit"), c.Query("offset"), 50, 200)
	d, err := h.svc.SmartMoney(c.UserContext(), 50, limit)
	return raw(c, d, err, "/whales/smart-money")
}
func (h *Handlers) WhalesClusters(c *fiber.Ctx) error {
	chain, err := validation.Chain(c.Query("chain", "ethereum"))
	if err != nil {
		return httpx.BadRequest(c, err.Error())
	}
	edge, err := validation.EdgeType(c.Query("edge_type"))
	if err != nil {
		return httpx.BadRequest(c, err.Error())
	}
	limit, _ := validation.Pagination(c.Query("limit"), c.Query("offset"), 50, 200)
	d, e := h.svc.Clusters(c.UserContext(), chain, edge, limit)
	return raw(c, d, e, "/whales/clusters")
}
func (h *Handlers) WhalesWallet(c *fiber.Ctx) error {
	addr, err := validation.Address(c.Params("address"))
	if err != nil {
		return httpx.BadRequest(c, err.Error())
	}
	d, e := h.svc.WalletProfile(c.UserContext(), addr)
	return raw(c, d, e, "/whales/wallet")
}

// ---- WALLET ----

func (h *Handlers) WalletProfile(c *fiber.Ctx) error {
	addr, err := validation.Address(c.Params("address"))
	if err != nil {
		return httpx.BadRequest(c, err.Error())
	}
	d, e := h.svc.WalletProfile(c.UserContext(), addr)
	return raw(c, d, e, "/wallet/profile")
}
func (h *Handlers) WalletTrades(c *fiber.Ctx) error {
	addr, err := validation.Address(c.Params("address"))
	if err != nil {
		return httpx.BadRequest(c, err.Error())
	}
	limit, offset := validation.Pagination(c.Query("limit"), c.Query("offset"), 100, 500)
	d, e := h.svc.WalletTrades(c.UserContext(), addr, limit, offset)
	return raw(c, d, e, "/wallet/trades")
}
func (h *Handlers) WalletPerformance(c *fiber.Ctx) error {
	addr, err := validation.Address(c.Params("address"))
	if err != nil {
		return httpx.BadRequest(c, err.Error())
	}
	d, e := h.svc.WalletPerformance(c.UserContext(), addr)
	return raw(c, d, e, "/wallet/performance")
}

// ---- FLOW / SOCIAL ----

func (h *Handlers) FlowsExchanges(c *fiber.Ctx) error {
	d, e := h.svc.Flows(c.UserContext(), "exchanges")
	return raw(c, d, e, "/flows/exchanges")
}
func (h *Handlers) FlowsBridges(c *fiber.Ctx) error {
	d, e := h.svc.Flows(c.UserContext(), "bridges")
	return raw(c, d, e, "/flows/bridges")
}
func (h *Handlers) FlowsStablecoins(c *fiber.Ctx) error {
	d, e := h.svc.Flows(c.UserContext(), "stablecoins")
	return raw(c, d, e, "/flows/stablecoins")
}
func (h *Handlers) Social(c *fiber.Ctx) error {
	d, e := h.svc.Social(c.UserContext(), c.Params("token"))
	return raw(c, d, e, "/social")
}
func (h *Handlers) Sentiment(c *fiber.Ctx) error {
	d, e := h.svc.Sentiment(c.UserContext(), c.Params("token"))
	return raw(c, d, e, "/sentiment")
}
