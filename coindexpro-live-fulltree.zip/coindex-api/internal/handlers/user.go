package handlers

import (
	"strconv"

	"github.com/gofiber/fiber/v2"

	"github.com/coindexpro/coindex-api/internal/auth"
	"github.com/coindexpro/coindex-api/internal/httpx"
	"github.com/coindexpro/coindex-api/internal/models"
	"github.com/coindexpro/coindex-api/internal/repositories"
	"github.com/coindexpro/coindex-api/internal/validation"
)

func identity(c *fiber.Ctx) auth.Identity {
	id, _ := c.Locals("identity").(auth.Identity)
	return id
}

// ---- WATCHLISTS ----

func (h *Handlers) GetWatchlists(c *fiber.Ctx) error {
	id := identity(c)
	if id.UserID == "" {
		return httpx.Unauthorized(c)
	}
	out, err := h.svc.Watchlists(c.UserContext(), id.UserID)
	if err != nil {
		return httpx.ServerError(c, "/watchlists")
	}
	return httpx.OK(c, fiber.Map{"items": out})
}

func (h *Handlers) CreateWatchlist(c *fiber.Ctx) error {
	id := identity(c)
	if id.UserID == "" {
		return httpx.Unauthorized(c)
	}
	var body struct {
		Name  string                 `json:"name"`
		Items []models.WatchlistItem `json:"items"`
	}
	if err := c.BodyParser(&body); err != nil || body.Name == "" {
		return httpx.BadRequest(c, "name required")
	}
	newID, err := h.svc.CreateWatchlist(c.UserContext(), id.UserID, body.Name, body.Items)
	if err != nil {
		return httpx.ServerError(c, "/watchlists")
	}
	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": newID})
}

func (h *Handlers) DeleteWatchlist(c *fiber.Ctx) error {
	id := identity(c)
	if id.UserID == "" {
		return httpx.Unauthorized(c)
	}
	wid, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return httpx.BadRequest(c, "invalid id")
	}
	if err := h.svc.DeleteWatchlist(c.UserContext(), id.UserID, wid); err != nil {
		if err == repositories.ErrNotFound {
			return httpx.NotFound(c)
		}
		return httpx.ServerError(c, "/watchlists")
	}
	return httpx.OK(c, fiber.Map{"deleted": wid})
}

// ---- PORTFOLIO ----

func (h *Handlers) GetPortfolio(c *fiber.Ctx) error {
	id := identity(c)
	if id.UserID == "" {
		return httpx.Unauthorized(c)
	}
	out, err := h.svc.Portfolios(c.UserContext(), id.UserID)
	if err != nil {
		return httpx.ServerError(c, "/portfolio")
	}
	return httpx.OK(c, fiber.Map{"items": out})
}

func (h *Handlers) SyncPortfolio(c *fiber.Ctx) error {
	id := identity(c)
	if id.UserID == "" {
		return httpx.Unauthorized(c)
	}
	var body struct{ Chain, Wallet string }
	if err := c.BodyParser(&body); err != nil {
		return httpx.BadRequest(c, "chain and wallet required")
	}
	chain, err := validation.Chain(body.Chain)
	if err != nil {
		return httpx.BadRequest(c, err.Error())
	}
	wallet, err := validation.Address(body.Wallet)
	if err != nil {
		return httpx.BadRequest(c, err.Error())
	}
	if err := h.svc.SyncPortfolio(c.UserContext(), id.UserID, chain, wallet); err != nil {
		return httpx.ServerError(c, "/portfolio/sync")
	}
	// Honest: sync is enqueued; holdings/PnL appear only once the background
	// sync job derives them from indexed history. No fake holdings returned now.
	return c.Status(fiber.StatusAccepted).JSON(fiber.Map{
		"status": "syncing",
		"note":   "holdings derive from indexed history once sync completes; none are estimated",
	})
}

// ---- ALERTS ----

func (h *Handlers) GetAlerts(c *fiber.Ctx) error {
	id := identity(c)
	if id.UserID == "" {
		return httpx.Unauthorized(c)
	}
	out, err := h.svc.Alerts(c.UserContext(), id.UserID)
	if err != nil {
		return httpx.ServerError(c, "/alerts")
	}
	return httpx.OK(c, fiber.Map{"items": out})
}

func (h *Handlers) CreateAlert(c *fiber.Ctx) error {
	id := identity(c)
	if id.UserID == "" {
		return httpx.Unauthorized(c)
	}
	var body struct {
		Kind     string           `json:"kind"`
		Target   map[string]any   `json:"target"`
		Channels []map[string]any `json:"channels"`
	}
	if err := c.BodyParser(&body); err != nil || body.Kind == "" {
		return httpx.BadRequest(c, "kind required")
	}
	newID, err := h.svc.CreateAlert(c.UserContext(), id.UserID, body.Kind, body.Target, body.Channels)
	if err != nil {
		return httpx.ServerError(c, "/alerts")
	}
	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": newID})
}

func (h *Handlers) DeleteAlert(c *fiber.Ctx) error {
	id := identity(c)
	if id.UserID == "" {
		return httpx.Unauthorized(c)
	}
	aid, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return httpx.BadRequest(c, "invalid id")
	}
	if err := h.svc.DeleteAlert(c.UserContext(), id.UserID, aid); err != nil {
		if err == repositories.ErrNotFound {
			return httpx.NotFound(c)
		}
		return httpx.ServerError(c, "/alerts")
	}
	return httpx.OK(c, fiber.Map{"deleted": aid})
}
