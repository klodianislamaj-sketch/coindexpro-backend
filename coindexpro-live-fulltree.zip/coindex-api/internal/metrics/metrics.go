// Package metrics holds the API's Prometheus instruments.
package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	RequestLatency = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name: "coindex_api_request_seconds", Help: "Request latency by route + status.",
		Buckets: prometheus.DefBuckets,
	}, []string{"route", "status"})

	RequestsTotal = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_api_requests_total", Help: "Requests by route + status.",
	}, []string{"route", "status"})

	ErrorsTotal = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_api_errors_total", Help: "Handler errors by route.",
	}, []string{"route"})

	DBQuery = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name: "coindex_api_db_query_seconds", Help: "DB query latency by store.",
		Buckets: prometheus.DefBuckets,
	}, []string{"store", "op"})

	CacheHits   = promauto.NewCounter(prometheus.CounterOpts{Name: "coindex_api_cache_hits_total", Help: "Cache hits."})
	CacheMisses = promauto.NewCounter(prometheus.CounterOpts{Name: "coindex_api_cache_misses_total", Help: "Cache misses."})
	CacheErrors = promauto.NewCounter(prometheus.CounterOpts{Name: "coindex_api_cache_errors_total", Help: "Cache errors."})

	RateLimitViolations = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_api_ratelimit_violations_total", Help: "Rate-limit rejections by tier.",
	}, []string{"tier"})

	CircuitOpen = promauto.NewGaugeVec(prometheus.GaugeOpts{
		Name: "coindex_api_circuit_open", Help: "1 when a store circuit breaker is open.",
	}, []string{"store"})

	// ProviderTrust is surfaced from the consensus/provider-trust telemetry.
	ProviderTrust = promauto.NewGaugeVec(prometheus.GaugeOpts{
		Name: "coindex_api_provider_trust", Help: "Provider trust weight (0..1).",
	}, []string{"provider"})
)
