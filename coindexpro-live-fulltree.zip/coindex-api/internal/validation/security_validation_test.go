package validation

import (
	"testing"
	"time"
)

func TestTimeRange_RejectsInvertedAndMalformed(t *testing.T) {
	_, _, err := TimeRange("2025-01-02T00:00:00Z", "2025-01-01T00:00:00Z", 0, false)
	if err == nil {
		t.Fatal("inverted range must be rejected (fail-closed)")
	}
	if _, _, err := TimeRange("not-a-time", "2025-01-01T00:00:00Z", 0, false); err == nil {
		t.Fatal("malformed from must be rejected")
	}
}

func TestTimeRange_RejectsOverMaxSpan(t *testing.T) {
	_, _, err := TimeRange("2025-01-01T00:00:00Z", "2025-12-31T00:00:00Z", 24*time.Hour, false)
	if err == nil {
		t.Fatal("range exceeding maxSpan must be rejected")
	}
}

func TestTimeRange_AcceptsValid(t *testing.T) {
	from, to, err := TimeRange("2025-01-01T00:00:00Z", "2025-01-01T06:00:00Z", 24*time.Hour, false)
	if err != nil {
		t.Fatalf("valid range must pass, got %v", err)
	}
	if !to.After(from) {
		t.Fatal("parsed range must be ordered")
	}
}

func TestTimeRange_EmptyOnlyWhenAllowed(t *testing.T) {
	if _, _, err := TimeRange("", "", false, false); err == nil {
		t.Fatal("empty range without allowEmpty must be rejected")
	}
	if _, _, err := TimeRange("", "", 0, true); err != nil {
		t.Fatalf("empty range with allowEmpty must pass, got %v", err)
	}
}

func TestPaginationStrict_RejectsBadInputNotSilentClamp(t *testing.T) {
	if _, _, err := PaginationStrict("abc", "0", 100); err == nil {
		t.Fatal("non-numeric limit must error, not clamp")
	}
	if _, _, err := PaginationStrict("999999", "0", 100); err == nil {
		t.Fatal("limit over max must error")
	}
	if _, _, err := PaginationStrict("-5", "0", 100); err == nil {
		t.Fatal("negative-looking (non-numeric '-') must error")
	}
}

func TestPaginationStrict_AcceptsValid(t *testing.T) {
	limit, offset, err := PaginationStrict("50", "100", 100)
	if err != nil {
		t.Fatalf("valid pagination must pass, got %v", err)
	}
	if limit != 50 || offset != 100 {
		t.Fatalf("parsed wrong: limit=%d offset=%d", limit, offset)
	}
}

func TestPaginationStrict_EmptyDefaultsToMin(t *testing.T) {
	limit, offset, err := PaginationStrict("", "", 100)
	if err != nil || limit != 1 || offset != 0 {
		t.Fatalf("empty should default to min limit=1 offset=0, got %d/%d err=%v", limit, offset, err)
	}
}
