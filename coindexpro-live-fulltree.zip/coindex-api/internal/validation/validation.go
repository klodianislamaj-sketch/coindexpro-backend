// Package validation provides strict input validators. Anything that reaches a
// query is validated here first; table/timeframe names are always allowlisted,
// never built from raw input.
package validation

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
)

var (
	evmAddr   = regexp.MustCompile(`^0x[0-9a-fA-F]{40}$`)
	txHash    = regexp.MustCompile(`^0x[0-9a-fA-F]{64}$`)
	validChain = map[string]bool{
		"ethereum": true, "bsc": true, "base": true,
		"arbitrum": true, "polygon": true, "pulsechain": true,
	}
)

func Chain(s string) (string, error) {
	s = strings.ToLower(s)
	if !validChain[s] {
		return "", fmt.Errorf("unsupported chain %q", s)
	}
	return s, nil
}

func Address(s string) (string, error) {
	if !evmAddr.MatchString(s) {
		return "", fmt.Errorf("invalid address")
	}
	return strings.ToLower(s), nil
}

func TxHash(s string) (string, error) {
	if !txHash.MatchString(s) {
		return "", fmt.Errorf("invalid tx hash")
	}
	return strings.ToLower(s), nil
}

// Pagination clamps limit/offset to safe bounds (query-cost guard).
func Pagination(limitStr, offsetStr string, defLimit, maxLimit int) (limit, offset int) {
	limit = defLimit
	if v, err := strconv.Atoi(limitStr); err == nil && v > 0 {
		limit = v
	}
	if limit > maxLimit {
		limit = maxLimit
	}
	if v, err := strconv.Atoi(offsetStr); err == nil && v >= 0 {
		offset = v
	}
	return
}

var validEdgeType = map[string]bool{"co_buy": true, "co_sell": true, "funded": true, "cluster": true}

func EdgeType(s string) (string, error) {
	if s == "" {
		return "co_buy", nil
	}
	if !validEdgeType[s] {
		return "", fmt.Errorf("invalid edge_type")
	}
	return s, nil
}
