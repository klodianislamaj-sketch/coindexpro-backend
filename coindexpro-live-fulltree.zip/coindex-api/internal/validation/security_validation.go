package validation

import (
	"errors"
	"time"
)

// ErrInvalidTimeRange is returned when a time range is malformed or inverted.
var ErrInvalidTimeRange = errors.New("invalid time range")

// TimeRange parses [from,to] RFC3339 timestamps FAIL-CLOSED: any parse error, an
// inverted range, or a range exceeding maxSpan is rejected rather than coerced.
// Empty strings are allowed only when allowEmpty is set (caller opts in).
func TimeRange(fromStr, toStr string, maxSpan time.Duration, allowEmpty bool) (from, to time.Time, err error) {
	if fromStr == "" && toStr == "" {
		if allowEmpty {
			return time.Time{}, time.Time{}, nil
		}
		return from, to, ErrInvalidTimeRange
	}
	from, err = time.Parse(time.RFC3339, fromStr)
	if err != nil {
		return from, to, ErrInvalidTimeRange
	}
	to, err = time.Parse(time.RFC3339, toStr)
	if err != nil {
		return from, to, ErrInvalidTimeRange
	}
	if !to.After(from) {
		return from, to, ErrInvalidTimeRange
	}
	if maxSpan > 0 && to.Sub(from) > maxSpan {
		return from, to, ErrInvalidTimeRange
	}
	return from, to, nil
}

// PaginationStrict is the fail-closed variant: an unparseable or out-of-bounds
// limit/offset is an ERROR, not a silent clamp. Use on paths where a bad page
// param should be rejected rather than quietly corrected.
func PaginationStrict(limitStr, offsetStr string, maxLimit int) (limit, offset int, err error) {
	limit, err = atoiBounded(limitStr, 1, maxLimit)
	if err != nil {
		return 0, 0, err
	}
	offset, err = atoiBounded(offsetStr, 0, 1_000_000)
	if err != nil {
		return 0, 0, err
	}
	return limit, offset, nil
}

func atoiBounded(s string, lo, hi int) (int, error) {
	if s == "" {
		return lo, nil
	}
	n := 0
	for _, r := range s {
		if r < '0' || r > '9' {
			return 0, errors.New("non-numeric pagination param")
		}
		n = n*10 + int(r-'0')
		if n > hi {
			return 0, errors.New("pagination param out of range")
		}
	}
	if n < lo {
		return 0, errors.New("pagination param below minimum")
	}
	return n, nil
}
