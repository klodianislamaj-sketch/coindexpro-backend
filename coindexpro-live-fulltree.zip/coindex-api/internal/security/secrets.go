package security

import (
	"fmt"
	"os"
	"sort"
	"strings"
)

// RequireSecrets enforces FAIL-FAST startup: if any critical secret env var is
// missing or empty, it returns an error listing exactly which (by name only —
// never the value). Call this in main() before serving; a missing critical secret
// must stop the process, not run insecure.
func RequireSecrets(names ...string) error {
	var missing []string
	for _, n := range names {
		if strings.TrimSpace(os.Getenv(n)) == "" {
			missing = append(missing, n)
		}
	}
	if len(missing) > 0 {
		sort.Strings(missing)
		return fmt.Errorf("missing required secrets: %s", strings.Join(missing, ", "))
	}
	return nil
}

// WeakSecret flags obviously-insecure secret values (empty, too short, or a known
// placeholder) WITHOUT logging the value. Returns a reason or "" if acceptable.
func WeakSecret(name, value string) string {
	v := strings.TrimSpace(value)
	switch {
	case v == "":
		return name + ": empty"
	case len(v) < 16:
		return name + ": too short (<16 chars)"
	case isPlaceholder(v):
		return name + ": placeholder value"
	}
	return ""
}

func isPlaceholder(v string) bool {
	low := strings.ToLower(v)
	for _, p := range []string{"changeme", "placeholder", "example", "test", "secret", "password", "xxx"} {
		if low == p || strings.Contains(low, "change-me") || strings.Contains(low, "replace") {
			return true
		}
	}
	return false
}
