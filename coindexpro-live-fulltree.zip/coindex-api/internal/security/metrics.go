package security

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

// Abuse-control metrics (real counters; surfaced on /metrics).
var (
	AbuseBlocked = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_api_abuse_blocked_total",
		Help: "Per-IP rate-limit blocks by window (burst|sustained).",
	}, []string{"window"})
	AbuseFailOpen = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_api_abuse_failopen_total",
		Help: "Per-IP limiter failed open due to Redis error.",
	})
	AuthDenied = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_api_auth_denied_total",
		Help: "Deny-by-default role rejections by tier.",
	}, []string{"tier"})
	// AuditEvents counts security audit events by disposition: written|dropped|error.
	AuditEvents = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_api_audit_events_total",
		Help: "Security audit events by disposition (written|dropped|error).",
	}, []string{"disposition"})
)
