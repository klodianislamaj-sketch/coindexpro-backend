// Package security: HTTP middleware for deny-by-default role enforcement, security
// headers, and per-IP abuse control. These compose with the existing Phase 3
// Auth/Premium/RateLimit middleware; they do not replace it. Every privileged
// decision is audited with the REAL resolved identity.
package security

import (
	"context"
	"fmt"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/redis/go-redis/v9"

	"github.com/coindexpro/coindex-api/internal/auth"
)

// Role constants mirror the real auth tiers plus a service role for internal callers.
const (
	RoleAnonymous = "anonymous"
	RoleUser      = "free"
	RolePremium   = "premium"
	RoleAdmin     = "admin"
	RoleService   = "service"
)

func identityOf(c *fiber.Ctx) auth.Identity {
	id, _ := c.Locals("identity").(auth.Identity)
	return id
}
func ridOf(c *fiber.Ctx) string {
	r, _ := c.Locals("request_id").(string)
	return r
}

// RequireRole is DENY-BY-DEFAULT: the request is rejected unless the resolved
// identity's tier is in the allowed set. Anonymous never satisfies a role
// requirement. Every decision (allow or deny) is audited with the real actor.
func RequireRole(aud *Auditor, allowed ...string) fiber.Handler {
	allow := make(map[string]bool, len(allowed))
	for _, r := range allowed {
		allow[r] = true
	}
	return func(c *fiber.Ctx) error {
		id := identityOf(c)
		tier := string(id.Tier)
		// anonymous / empty identity is never privileged
		denied := id.Source == "anonymous" || id.Source == "" || !allow[tier]
		ev := Event{
			ActorID: id.UserID, ActorTier: tier, ActorSource: id.Source,
			Target: c.Path(), IP: c.IP(), RequestID: ridOf(c),
		}
		if denied {
			ev.Action = "auth.denied"
			ev.Result = "deny"
			ev.Detail = map[string]any{"required": allowed, "method": c.Method()}
			aud.Record(ev)
			AuthDenied.WithLabelValues(nzTier(tier)).Inc()
			return c.Status(fiber.StatusForbidden).
				JSON(fiber.Map{"error": "forbidden", "reason": "insufficient role"})
		}
		ev.Action = "route.access"
		ev.Result = "allow"
		ev.Detail = map[string]any{"method": c.Method()}
		aud.Record(ev)
		return c.Next()
	}
}

// AuditMutation records a privileged write after the handler runs, capturing the
// real actor, target, and result (from the response status). Mount on write routes.
func AuditMutation(aud *Auditor, action string) fiber.Handler {
	return func(c *fiber.Ctx) error {
		err := c.Next()
		id := identityOf(c)
		result := "allow"
		if c.Response().StatusCode() >= 400 {
			result = "error"
		}
		aud.Record(Event{
			ActorID: id.UserID, ActorTier: string(id.Tier), ActorSource: id.Source,
			Action: action, Target: c.Path(), Result: result, IP: c.IP(), RequestID: ridOf(c),
			Detail: map[string]any{"method": c.Method(), "status": c.Response().StatusCode()},
		})
		return err
	}
}

// SecurityHeaders sets defensive response headers on every response.
func SecurityHeaders() fiber.Handler {
	return func(c *fiber.Ctx) error {
		h := c.Response().Header
		h.Set("Content-Security-Policy",
			"default-src 'none'; frame-ancestors 'none'; base-uri 'none'")
		h.Set("Strict-Transport-Security", "max-age=63072000; includeSubDomains; preload")
		h.Set("X-Frame-Options", "DENY")
		h.Set("X-Content-Type-Options", "nosniff")
		h.Set("Referrer-Policy", "no-referrer")
		h.Set("Permissions-Policy", "geolocation=(), microphone=(), camera=()")
		return c.Next()
	}
}

// IPLimits configures the per-IP limiter: a short burst window and a longer
// sustained window. Both are real Redis fixed-window counters.
type IPLimits struct {
	BurstPerSec   int // requests allowed per 1s
	SustainedPerMin int // requests allowed per 60s
}

// PerIPRateLimit enforces per-IP burst + sustained windows ON TOP OF the existing
// per-tier limiter. It returns an honest 429 with Retry-After; it never silently
// drops. Abuse is counted in a metric. Fails OPEN on Redis error (availability >
// over-blocking) but logs it.
func PerIPRateLimit(rdb *redis.Client, lim IPLimits) fiber.Handler {
	if lim.BurstPerSec <= 0 {
		lim.BurstPerSec = 20
	}
	if lim.SustainedPerMin <= 0 {
		lim.SustainedPerMin = 600
	}
	return func(c *fiber.Ctx) error {
		ip := c.IP()
		now := time.Now()
		ctx, cancel := context.WithTimeout(c.UserContext(), time.Second)
		defer cancel()

		over, win, err := exceeded(ctx, rdb, ip, now, lim)
		if err != nil {
			// fail open on infra error, but record it
			AbuseFailOpen.Inc()
			return c.Next()
		}
		if over {
			AbuseBlocked.WithLabelValues(win).Inc()
			c.Set("Retry-After", retryFor(win))
			return c.Status(fiber.StatusTooManyRequests).
				JSON(fiber.Map{"error": "rate limited", "scope": "per-ip", "window": win})
		}
		return c.Next()
	}
}

func exceeded(ctx context.Context, rdb *redis.Client, ip string, now time.Time, lim IPLimits) (bool, string, error) {
	// burst (1s)
	bk := fmt.Sprintf("rlip:b:%s:%d", ip, now.Unix())
	n, err := rdb.Incr(ctx, bk).Result()
	if err != nil {
		return false, "", err
	}
	if n == 1 {
		rdb.Expire(ctx, bk, 2*time.Second)
	}
	if n > int64(lim.BurstPerSec) {
		return true, "burst", nil
	}
	// sustained (60s)
	sk := fmt.Sprintf("rlip:s:%s:%d", ip, now.Unix()/60)
	m, err := rdb.Incr(ctx, sk).Result()
	if err != nil {
		return false, "", err
	}
	if m == 1 {
		rdb.Expire(ctx, sk, 70*time.Second)
	}
	if m > int64(lim.SustainedPerMin) {
		return true, "sustained", nil
	}
	return false, "", nil
}

func retryFor(win string) string {
	if win == "sustained" {
		return "60"
	}
	return "1"
}

func nzTier(t string) string {
	if t == "" {
		return "anonymous"
	}
	return t
}
