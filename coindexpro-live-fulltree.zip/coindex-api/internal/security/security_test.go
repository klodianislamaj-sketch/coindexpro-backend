package security

import (
	"os"
	"strings"
	"testing"
)

func TestRedact_ScrubsSecretShapes(t *testing.T) {
	cases := []string{
		"Authorization: Bearer eyJhbGciOiJIUzI1Ni8.payloadpart.sigpart",
		"key=sk_live_abc123DEF456ghi",
		"hook whsec_supersecretvalue",
		"dsn postgres://user:pass@host:5432/db",
	}
	for _, in := range cases {
		out := Redact(in)
		if strings.Contains(out, "sk_live_abc123") || strings.Contains(out, "supersecretvalue") ||
			strings.Contains(out, "user:pass") || strings.Contains(out, "eyJhbGci") {
			t.Fatalf("secret leaked through Redact: %q -> %q", in, out)
		}
		if !strings.Contains(out, "[REDACTED]") {
			t.Fatalf("expected redaction marker in %q", out)
		}
	}
}

func TestRedactFields_ByKeyAndValue(t *testing.T) {
	in := map[string]any{
		"jwt_secret": "supersecretkey1234",
		"user_id":    "u1",
		"note":       "bearer eyJabc.def.ghi",
	}
	out := RedactFields(in)
	if out["jwt_secret"] != "[REDACTED]" {
		t.Fatalf("secret-named key must be redacted, got %v", out["jwt_secret"])
	}
	if out["user_id"] != "u1" {
		t.Fatalf("non-secret must pass through, got %v", out["user_id"])
	}
	if s, _ := out["note"].(string); strings.Contains(s, "eyJabc") {
		t.Fatalf("secret-shaped value must be redacted in note, got %v", s)
	}
}

func TestRequireSecrets_FailsFastListingMissingByNameOnly(t *testing.T) {
	os.Setenv("SEC_TEST_PRESENT", "value-is-present-and-long")
	os.Unsetenv("SEC_TEST_ABSENT_A")
	os.Unsetenv("SEC_TEST_ABSENT_B")
	err := RequireSecrets("SEC_TEST_PRESENT", "SEC_TEST_ABSENT_A", "SEC_TEST_ABSENT_B")
	if err == nil {
		t.Fatal("missing secrets must produce an error (fail-fast)")
	}
	msg := err.Error()
	if !strings.Contains(msg, "SEC_TEST_ABSENT_A") || !strings.Contains(msg, "SEC_TEST_ABSENT_B") {
		t.Fatalf("error must name the missing secrets, got %q", msg)
	}
	if strings.Contains(msg, "value-is-present-and-long") {
		t.Fatalf("error must NOT contain any secret value, got %q", msg)
	}
}

func TestRequireSecrets_AllPresentOK(t *testing.T) {
	os.Setenv("SEC_TEST_X", "abcdefghijklmnop")
	if err := RequireSecrets("SEC_TEST_X"); err != nil {
		t.Fatalf("present secret must pass, got %v", err)
	}
}

func TestWeakSecret_FlagsWeakNeverLogsValue(t *testing.T) {
	if WeakSecret("JWT", "") == "" {
		t.Fatal("empty must be flagged")
	}
	if WeakSecret("JWT", "short") == "" {
		t.Fatal("too-short must be flagged")
	}
	if WeakSecret("JWT", "changeme") == "" {
		t.Fatal("placeholder must be flagged")
	}
	if r := WeakSecret("JWT", "a-strong-random-32-byte-secret-value"); r != "" {
		t.Fatalf("strong secret must pass, got %q", r)
	}
	// reason must reference the name, never echo the value
	if r := WeakSecret("JWT", "short"); strings.Contains(r, "short") && !strings.Contains(r, "JWT") {
		t.Fatalf("reason should name the secret, not echo value: %q", r)
	}
}
