// Package security provides the audit trail, secret redaction, and the
// deny-by-default helpers used by the API middleware. The audit Auditor records
// REAL actor identity (resolved by auth) into the append-only security_events
// table; it never invents an actor. Redact() scrubs secret-shaped values from any
// string before it can reach a log.
package security

import (
	"context"
	"regexp"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
	"go.uber.org/zap"
)

// Event is one security-relevant occurrence. Actor* fields come from the resolved
// identity; the package does not synthesize them.
type Event struct {
	ActorID     string
	ActorTier   string
	ActorSource string
	Action      string
	Target      string
	Result      string // allow|deny|error
	IP          string
	RequestID   string
	Detail      map[string]any
}

// Auditor persists security events append-only, off the request path.
type Auditor struct {
	pg  *pgxpool.Pool
	ch  chan Event
	log *zap.Logger
}

func NewAuditor(pg *pgxpool.Pool, log *zap.Logger) *Auditor {
	a := &Auditor{pg: pg, ch: make(chan Event, 1024), log: log}
	go a.run()
	return a
}

// Record enqueues an event. Non-blocking: if the buffer is full we drop to a log
// line rather than block the request, and we count it honestly.
func (a *Auditor) Record(e Event) {
	if e.Result == "" {
		e.Result = "allow"
	}
	select {
	case a.ch <- e:
	default:
		AuditEvents.WithLabelValues("dropped").Inc()
		a.log.Warn("security audit buffer full; event logged not persisted",
			zap.String("action", e.Action), zap.String("actor", e.ActorID))
	}
}

func (a *Auditor) run() {
	for e := range a.ch {
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		var ip any
		if e.IP != "" {
			ip = e.IP
		}
		detail := e.Detail
		if detail == nil {
			detail = map[string]any{}
		}
		_, err := a.pg.Exec(ctx, `
			INSERT INTO security_events
				(actor_id, actor_tier, actor_source, action, target, result, ip, request_id, detail)
			VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
			nz(e.ActorID, "anonymous"), nz(e.ActorTier, "anonymous"), nz(e.ActorSource, "anonymous"),
			e.Action, e.Target, e.Result, ip, e.RequestID, detail)
		cancel()
		if err != nil {
			AuditEvents.WithLabelValues("error").Inc()
			a.log.Warn("security audit write failed", zap.Error(err), zap.String("action", e.Action))
		} else {
			AuditEvents.WithLabelValues("written").Inc()
		}
	}
}

func nz(s, d string) string {
	if s == "" {
		return d
	}
	return s
}

// --- secret redaction --------------------------------------------------------

// secretPatterns match common secret shapes so they never reach a log intact.
var secretPatterns = []*regexp.Regexp{
	regexp.MustCompile(`(?i)(bearer\s+)[A-Za-z0-9\-._~+/]+=*`),
	regexp.MustCompile(`(?i)(sk_live_|sk_test_|whsec_|rk_live_)[A-Za-z0-9]+`),
	regexp.MustCompile(`eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+`), // JWTs
	regexp.MustCompile(`(?i)(api[_-]?key|secret|token|password|passwd|pwd)["'\s:=]+[A-Za-z0-9\-._~+/]{6,}=*`),
	regexp.MustCompile(`postgres(?:ql)?://[^\s"']*`), // DSNs (may embed creds)
}

// Redact replaces secret-shaped substrings with a placeholder. It is deliberately
// aggressive: over-redaction is safe, leaking is not.
func Redact(s string) string {
	out := s
	for _, re := range secretPatterns {
		out = re.ReplaceAllString(out, "[REDACTED]")
	}
	return out
}

// RedactFields returns a copy of a map with values redacted by key name + value shape.
func RedactFields(m map[string]any) map[string]any {
	if m == nil {
		return nil
	}
	out := make(map[string]any, len(m))
	for k, v := range m {
		if isSecretKey(k) {
			out[k] = "[REDACTED]"
			continue
		}
		if vs, ok := v.(string); ok {
			out[k] = Redact(vs)
		} else {
			out[k] = v
		}
	}
	return out
}

var secretKeyRe = regexp.MustCompile(`(?i)(secret|token|password|passwd|pwd|api[_-]?key|dsn|bearer|authorization|webhook)`)

func isSecretKey(k string) bool { return secretKeyRe.MatchString(k) }
