// Package tracing provides cross-service correlation without forcing a heavy
// dependency. It propagates the W3C `traceparent` header and `X-Request-ID` across
// service boundaries so a single request can be followed API -> engine in logs and
// (when an OTel collector is added) traces.
//
// HONEST SCOPE: this middleware implements real correlation-ID propagation using
// only stdlib. It does NOT itself export spans to a collector — wiring the full
// OpenTelemetry SDK (TracerProvider + OTLP exporter) is the documented next step in
// observability/TRACING.md. The header format is W3C trace-context compatible, so
// adding the SDK later requires no change to callers.
package tracing

import (
	"crypto/rand"
	"encoding/hex"
	"regexp"

	"github.com/gofiber/fiber/v2"
)

// LocalTraceID / LocalRequestID are the Fiber Locals keys handlers read to attach
// correlation IDs to logs and outbound requests.
const (
	LocalTraceID   = "trace_id"
	LocalRequestID = "request_id"
	HeaderTraceparent = "traceparent"
	HeaderRequestID   = "X-Request-ID"
)

// version "00", 16-byte trace-id, 8-byte span-id, flags "01" (sampled)
var traceparentRe = regexp.MustCompile(`^00-([0-9a-f]{32})-([0-9a-f]{16})-[0-9a-f]{2}$`)

func randHex(n int) string {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		// extremely unlikely; fall back to a fixed-length zero id rather than panic
		return hex.EncodeToString(make([]byte, n))
	}
	return hex.EncodeToString(b)
}

// Middleware ensures every request carries a trace_id + request_id, honoring any
// inbound W3C traceparent / X-Request-ID, and echoes them on the response so the
// next hop and the client can correlate.
func Middleware() fiber.Handler {
	return func(c *fiber.Ctx) error {
		traceID := ""
		if tp := c.Get(HeaderTraceparent); tp != "" {
			if m := traceparentRe.FindStringSubmatch(tp); m != nil {
				traceID = m[1] // reuse the inbound trace id (same trace across hops)
			}
		}
		if traceID == "" {
			traceID = randHex(16) // 32 hex chars
		}
		spanID := randHex(8) // 16 hex chars, new per hop

		reqID := c.Get(HeaderRequestID)
		if reqID == "" {
			reqID = traceID // fall back to trace id so correlation always exists
		}

		c.Locals(LocalTraceID, traceID)
		c.Locals(LocalRequestID, reqID)

		// echo for the next service + the client
		c.Set(HeaderTraceparent, "00-"+traceID+"-"+spanID+"-01")
		c.Set(HeaderRequestID, reqID)

		return c.Next()
	}
}

// Propagate returns the headers an outbound inter-service HTTP call should carry to
// continue the same trace. Handlers use this when calling other engines.
func Propagate(c *fiber.Ctx) map[string]string {
	traceID, _ := c.Locals(LocalTraceID).(string)
	reqID, _ := c.Locals(LocalRequestID).(string)
	if traceID == "" {
		return map[string]string{}
	}
	return map[string]string{
		HeaderTraceparent: "00-" + traceID + "-" + randHex(8) + "-01",
		HeaderRequestID:   reqID,
	}
}
