// Package cache implements a Redis stale-while-revalidate cache with hot-key
// protection. On a hit it returns the cached value immediately; if the value is
// past its soft-TTL it triggers a single background refresh (singleflight per
// key) so a hot key never stampedes the database.
package cache

import (
	"context"
	"encoding/json"
	"errors"
	"sync"
	"time"

	"github.com/redis/go-redis/v9"

	"github.com/coindexpro/coindex-api/internal/metrics"
)

type entry struct {
	Data     json.RawMessage `json:"d"`
	SoftAt   int64           `json:"s"` // unix ns when value becomes stale
	StoredAt int64           `json:"t"`
}

type SWR struct {
	rdb   *redis.Client
	mu    sync.Mutex
	inflight map[string]struct{} // keys currently being refreshed (hot-key guard)
	hardTTL  time.Duration       // absolute key expiry safety net
}

func NewSWR(rdb *redis.Client) *SWR {
	return &SWR{rdb: rdb, inflight: make(map[string]struct{}), hardTTL: 5 * time.Minute}
}

// Loader fetches fresh data from the source of truth.
type Loader func(ctx context.Context) (any, error)

// Get returns cached JSON for key, refreshing per SWR semantics. softTTL is how
// long a value is considered fresh; after that it is served stale once while a
// single background refresh runs.
func (s *SWR) Get(ctx context.Context, key string, softTTL time.Duration, load Loader) (json.RawMessage, error) {
	raw, err := s.rdb.Get(ctx, key).Bytes()
	if err == nil {
		var e entry
		if json.Unmarshal(raw, &e) == nil {
			metrics.CacheHits.Inc()
			if time.Now().UnixNano() > e.SoftAt {
				s.refreshAsync(key, softTTL, load) // stale → revalidate in background
			}
			return e.Data, nil
		}
	} else if !errors.Is(err, redis.Nil) {
		metrics.CacheErrors.Inc()
		// Redis down: fall through to direct load (degrade, don't fail).
	}

	metrics.CacheMisses.Inc()
	// Cache miss: load synchronously and store.
	val, lerr := load(ctx)
	if lerr != nil {
		return nil, lerr
	}
	data, _ := json.Marshal(val)
	s.store(ctx, key, data, softTTL)
	return data, nil
}

func (s *SWR) store(ctx context.Context, key string, data json.RawMessage, softTTL time.Duration) {
	e := entry{Data: data, SoftAt: time.Now().Add(softTTL).UnixNano(), StoredAt: time.Now().UnixNano()}
	b, _ := json.Marshal(e)
	_ = s.rdb.Set(ctx, key, b, s.hardTTL).Err()
}

// refreshAsync runs at most one background refresh per key (hot-key protection).
func (s *SWR) refreshAsync(key string, softTTL time.Duration, load Loader) {
	s.mu.Lock()
	if _, busy := s.inflight[key]; busy {
		s.mu.Unlock()
		return
	}
	s.inflight[key] = struct{}{}
	s.mu.Unlock()

	go func() {
		defer func() {
			s.mu.Lock()
			delete(s.inflight, key)
			s.mu.Unlock()
			recover() // never let a background refresh panic the process
		}()
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		val, err := load(ctx)
		if err != nil {
			metrics.CacheErrors.Inc()
			return // keep serving stale; try again next request
		}
		data, _ := json.Marshal(val)
		s.store(ctx, key, data, softTTL)
	}()
}

// Invalidate removes a key (used on writes that change cached reads).
func (s *SWR) Invalidate(ctx context.Context, key string) error {
	return s.rdb.Del(ctx, key).Err()
}

// InvalidatePrefix removes all keys under a prefix (scan-based, bounded).
func (s *SWR) InvalidatePrefix(ctx context.Context, prefix string) error {
	iter := s.rdb.Scan(ctx, 0, prefix+"*", 200).Iterator()
	for iter.Next(ctx) {
		_ = s.rdb.Del(ctx, iter.Val()).Err()
	}
	return iter.Err()
}
