## coindex-status-engine — Phase 18

Platform health & status engine. It probes the **real** operational endpoints every
CoinDex service already exposes and surfaces an honest, aggregated system status —
the `/status`, `/integrity`, and `/launch-check` seam the architecture calls for
(§10–12). It is the operational layer over the 17 services built in Phases 1–17.

### The honesty core (rules 3 + 9)

Status is computed **only** from real probe outcomes and real scraped metrics:

- An ops endpoint that does not respond is recorded **unreachable** — never assumed
  healthy. `unreachable` is a distinct status from `down` (reachable but `/healthz`
  failed).
- A metric a service does **not** expose yields a finding with `observed: null` and
  a "not indexed" detail — an integrity check is **never** treated as passing on a
  missing metric.
- `probe_coverage` (reachable / configured) is surfaced so a partial view of the
  fleet is never presented as a complete "all green."
- The launch gate passes **only** when every configured service is genuinely `up`.

No synthetic uptime, no fabricated metric values, no default-healthy.

### Source-of-truth mapping (verified on disk)

Every `coindex-*` service exposes the same ops contract, which this engine reads:

| Signal | Real source |
|---|---|
| liveness | real `GET /healthz` (2xx ⇒ healthy) |
| readiness | real `GET /readyz` (already pings the service's own DBs/deps) |
| operational metrics | real `GET /metrics` (Prometheus text), e.g. `coindex_index_lag_blocks`, `coindex_dlq_messages_total`, `coindex_reorgs_total` |
| per-service status | derived **only** from the probe outcomes above |

The metric names scraped are configured (`want_metrics`); only those a service
actually emits are recorded.

### Status derivation (transparent)

```
unreachable   ops endpoint did not respond
down          reachable, but /healthz != 2xx
degraded      healthy, but /readyz != 2xx (or a soft signal breach)
up            healthy AND ready

overall       down      if any service is down/unreachable
              degraded  if any reachable service is degraded
              up        if every configured service is up
```

### Integrity checks

Each check compares a **real scraped metric** for a service against a configured
threshold (`gt`/`lt`). The observed value is stored with every finding, so a
breach is auditable. A check whose metric is absent, or whose service is
unreachable, is recorded as **not passing with `observed: null`** — it is never
silently green.

Default checks (over the indexer's real metrics): `indexer_lag` (`> 100` blocks),
`dlq_growth` (`> 0`), `reorg_storm` (`> 5`).

### Outputs (tables)

`health_snapshots` (one row per service per probe cycle — the observed history),
`service_status` (latest status per service, fast read), `integrity_findings`
(real check results with observed value + threshold).

### API

| Route | Purpose |
|---|---|
| `GET /status` | aggregate system status + per-service statuses + probe_coverage |
| `GET /status/:service` | one service's latest status |
| `GET /status/:service/history` | recent observed snapshots for a service |
| `GET /integrity` | real integrity findings (`?failing=true` for breaches only) |
| `GET /launch-check` | gate: 200 only when every service is up, else 503 + which aren't |

Static routes are registered before parameterized ones. The engine itself exposes
`/healthz`, `/readyz`, `/metrics` on its ops port (it is a normal service too).

### Idempotency & replay

`health_snapshots` inserts are unique per `(service, probed_at)`; `service_status`
upserts per service; findings are append-only with `checked_at`. A probe cycle is a
pure read of live state, so re-running is safe and simply records the next
observation.

### Honest runtime limitations

- **Real, production-shaped code, NOT compiled or run here** (no Go toolchain, no
  Postgres/Redis, no network, no live services to probe). Statically reviewed:
  imports/symbols/interfaces resolve, no import cycle (`status` defines the `Prober`
  and `Sink` interfaces; `probe` and `db` implement them), routes ordered, metrics
  symbols match references, no dead code, no orphaned reads. The status derivation,
  aggregation, integrity checks, Prometheus parsing, and the unreachable/not-indexed
  paths were verified by simulation. Before production: `go build` + `vet` + lint and
  an integration run against the live ops endpoints.
- **Status is observed, not predicted.** It reflects the most recent probe; between
  cycles a service may change state. The probe interval bounds staleness; consumers
  should read `generated_at` / `updated_at`.
- **It reflects what the ops endpoints report.** `/readyz` honesty depends on each
  service's own readiness check (which, by design, pings its real dependencies). The
  status engine does not second-guess a service's self-report; it records it.
- **No fabricated health.** Unreachable services are unreachable; absent metrics are
  not indexed; coverage is a real ratio. Nothing is defaulted to healthy.
