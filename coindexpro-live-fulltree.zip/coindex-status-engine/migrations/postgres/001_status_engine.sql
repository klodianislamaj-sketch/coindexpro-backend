-- =============================================================================
-- CoinDex Platform Health & Status Engine — PostgreSQL migration (Phase 18)
-- =============================================================================
-- Aggregates the REAL operational health of every CoinDex service. It probes the
-- real ops endpoints each service already exposes (/healthz, /readyz, /metrics)
-- and parses the real Prometheus metrics they emit. It stores only observed
-- results — an unreachable service is recorded as unreachable, never as healthy,
-- and a metric a service does not expose is absent (not indexed), never invented.
--
-- Real upstream (verified on disk): every coindex-* service exposes
--   GET /healthz   (liveness)
--   GET /readyz    (readiness — already pings the service's real DBs/deps)
--   GET /metrics   (Prometheus; indexer emits coindex_index_lag_blocks,
--                   coindex_dlq_messages_total, coindex_reorgs_total, etc.)
--
-- All NEW tables (collision-checked: no status/health tables exist); idempotent.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- health_snapshots — one row per (service, probe cycle). Every field is an
-- observed probe result. status is derived ONLY from these real observations.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS health_snapshots (
    id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    service      text        NOT NULL,
    probed_at    timestamptz NOT NULL DEFAULT now(),
    reachable    boolean     NOT NULL,                 -- did the ops endpoint respond at all
    healthy      boolean,                              -- /healthz 200; NULL if unreachable
    ready        boolean,                              -- /readyz 200; NULL if unreachable/unknown
    latency_ms   integer     CHECK (latency_ms IS NULL OR latency_ms >= 0), -- real probe RTT
    status       text        NOT NULL CHECK (status IN ('up','degraded','down','unreachable')),
    -- real scraped signals for this service (only metrics it actually exposes):
    signals      jsonb       NOT NULL DEFAULT '{}'::jsonb,  -- {metric_name: value}
    error        text,                                 -- probe error text when unreachable
    CONSTRAINT uq_health UNIQUE (service, probed_at)
);
CREATE INDEX IF NOT EXISTS idx_health_service ON health_snapshots (service, probed_at DESC);
CREATE INDEX IF NOT EXISTS idx_health_status ON health_snapshots (status, probed_at DESC);

-- -----------------------------------------------------------------------------
-- service_status — latest known status per service (fast read for /status). A
-- projection of the most recent health_snapshot; refreshed each probe cycle.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS service_status (
    service      text        PRIMARY KEY,
    status       text        NOT NULL CHECK (status IN ('up','degraded','down','unreachable')),
    reachable    boolean     NOT NULL,
    healthy      boolean,
    ready        boolean,
    latency_ms   integer,
    signals      jsonb       NOT NULL DEFAULT '{}'::jsonb,
    error        text,
    updated_at   timestamptz NOT NULL DEFAULT now()
);

-- -----------------------------------------------------------------------------
-- integrity_findings — results of REAL cross-service integrity checks (e.g.
-- indexer lag over threshold, DLQ growing). A finding only exists because a real
-- metric crossed a real, configured threshold; the observed value is recorded so
-- the finding is auditable. ok=true means the check ran and passed.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS integrity_findings (
    id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    check_name   text        NOT NULL,
    service      text        NOT NULL,
    ok           boolean     NOT NULL,                 -- did the check pass
    observed     numeric,                              -- the real observed metric value (NULL if not indexed)
    threshold    numeric,                              -- the configured threshold compared against
    detail       text        NOT NULL,
    checked_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_integrity_check ON integrity_findings (check_name, checked_at DESC);
CREATE INDEX IF NOT EXISTS idx_integrity_failing ON integrity_findings (ok, checked_at DESC) WHERE ok = false;
