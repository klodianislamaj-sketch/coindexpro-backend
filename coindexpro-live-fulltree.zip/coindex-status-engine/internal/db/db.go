// Package db is the status-engine persistence layer. It stores REAL probe
// observations (health_snapshots), the latest per-service status (service_status),
// and real integrity findings (integrity_findings), and reads them back for the
// API. It writes only what was observed; there is no path that records a service
// as healthy without a real successful probe. Imports only models (no cycle).
package db

import (
	"context"
	"encoding/json"
	"errors"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/coindexpro/coindex-status-engine/internal/models"
)

type Store struct{ pg *pgxpool.Pool }

func Open(ctx context.Context, dsn string) (*Store, error) {
	pg, err := pgxpool.New(ctx, dsn)
	if err != nil {
		return nil, err
	}
	if err := pg.Ping(ctx); err != nil {
		return nil, err
	}
	return &Store{pg: pg}, nil
}

func (s *Store) Close()                          { s.pg.Close() }
func (s *Store) Ping(ctx context.Context) error  { return s.pg.Ping(ctx) }

// ---------- sink ----------

// SaveSnapshots inserts the observed probe results for this cycle.
func (s *Store) SaveSnapshots(ctx context.Context, results []models.ProbeResult) error {
	if len(results) == 0 {
		return nil
	}
	tx, err := s.pg.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	for _, r := range results {
		sig, _ := json.Marshal(r.Signals)
		const q = `
			INSERT INTO health_snapshots
				(service, probed_at, reachable, healthy, ready, latency_ms, status, signals, error)
			VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
			ON CONFLICT (service, probed_at) DO NOTHING`
		if _, err := tx.Exec(ctx, q, r.Service, r.ProbedAt, r.Reachable, r.Healthy, r.Ready,
			r.LatencyMS, r.Status, sig, nullStr(r.Error)); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

// ReplaceServiceStatus upserts the latest status per service.
func (s *Store) ReplaceServiceStatus(ctx context.Context, statuses []models.ServiceStatus) error {
	tx, err := s.pg.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	for _, st := range statuses {
		sig, _ := json.Marshal(st.Signals)
		const q = `
			INSERT INTO service_status
				(service, status, reachable, healthy, ready, latency_ms, signals, error, updated_at)
			VALUES ($1,$2,$3,$4,$5,$6,$7,$8,now())
			ON CONFLICT (service) DO UPDATE SET
				status=$2, reachable=$3, healthy=$4, ready=$5, latency_ms=$6,
				signals=$7, error=$8, updated_at=now()`
		if _, err := tx.Exec(ctx, q, st.Service, st.Status, st.Reachable, st.Healthy, st.Ready,
			st.LatencyMS, sig, nullStr(st.Error)); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

// SaveFindings inserts integrity-check findings for this cycle.
func (s *Store) SaveFindings(ctx context.Context, findings []models.IntegrityFinding) error {
	if len(findings) == 0 {
		return nil
	}
	tx, err := s.pg.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	for _, f := range findings {
		const q = `
			INSERT INTO integrity_findings (check_name, service, ok, observed, threshold, detail, checked_at)
			VALUES ($1,$2,$3,$4,$5,$6,$7)`
		if _, err := tx.Exec(ctx, q, f.CheckName, f.Service, f.OK, f.Observed, f.Threshold, f.Detail, f.CheckedAt); err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

// ---------- API reads ----------

// LatestStatuses returns the current status of every known service.
func (s *Store) LatestStatuses(ctx context.Context) ([]models.ServiceStatus, error) {
	const q = `
		SELECT service, status, reachable, healthy, ready, latency_ms, signals, coalesce(error,''), updated_at
		FROM service_status ORDER BY service`
	rows, err := s.pg.Query(ctx, q)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanStatuses(rows)
}

// ServiceStatusByName returns one service's latest status.
func (s *Store) ServiceStatusByName(ctx context.Context, name string) (models.ServiceStatus, bool, error) {
	const q = `
		SELECT service, status, reachable, healthy, ready, latency_ms, signals, coalesce(error,''), updated_at
		FROM service_status WHERE service=$1`
	var st models.ServiceStatus
	var sig []byte
	err := s.pg.QueryRow(ctx, q, name).Scan(&st.Service, &st.Status, &st.Reachable, &st.Healthy, &st.Ready,
		&st.LatencyMS, &sig, &st.Error, &st.UpdatedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return models.ServiceStatus{}, false, nil
	}
	if err != nil {
		return models.ServiceStatus{}, false, err
	}
	_ = json.Unmarshal(sig, &st.Signals)
	return st, true, nil
}

// ServiceHistory returns recent snapshots for a service.
func (s *Store) ServiceHistory(ctx context.Context, name string, limit int) ([]models.ProbeResult, error) {
	const q = `
		SELECT service, probed_at, reachable, healthy, ready, latency_ms, status, signals, coalesce(error,'')
		FROM health_snapshots WHERE service=$1 ORDER BY probed_at DESC LIMIT $2`
	rows, err := s.pg.Query(ctx, q, name, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.ProbeResult
	for rows.Next() {
		var r models.ProbeResult
		var sig []byte
		if err := rows.Scan(&r.Service, &r.ProbedAt, &r.Reachable, &r.Healthy, &r.Ready,
			&r.LatencyMS, &r.Status, &sig, &r.Error); err != nil {
			return nil, err
		}
		_ = json.Unmarshal(sig, &r.Signals)
		out = append(out, r)
	}
	return out, rows.Err()
}

// LatestFindings returns the most recent integrity findings (optionally only failing).
func (s *Store) LatestFindings(ctx context.Context, onlyFailing bool, limit int) ([]models.IntegrityFinding, error) {
	q := `
		SELECT check_name, service, ok, observed, threshold, detail, checked_at
		FROM integrity_findings`
	if onlyFailing {
		q += ` WHERE ok = false`
	}
	q += ` ORDER BY checked_at DESC LIMIT $1`
	rows, err := s.pg.Query(ctx, q, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []models.IntegrityFinding
	for rows.Next() {
		var f models.IntegrityFinding
		if err := rows.Scan(&f.CheckName, &f.Service, &f.OK, &f.Observed, &f.Threshold, &f.Detail, &f.CheckedAt); err != nil {
			return nil, err
		}
		out = append(out, f)
	}
	return out, rows.Err()
}

func scanStatuses(rows pgx.Rows) ([]models.ServiceStatus, error) {
	var out []models.ServiceStatus
	for rows.Next() {
		var st models.ServiceStatus
		var sig []byte
		if err := rows.Scan(&st.Service, &st.Status, &st.Reachable, &st.Healthy, &st.Ready,
			&st.LatencyMS, &sig, &st.Error, &st.UpdatedAt); err != nil {
			return nil, err
		}
		_ = json.Unmarshal(sig, &st.Signals)
		out = append(out, st)
	}
	return out, rows.Err()
}

func nullStr(s string) any {
	if s == "" {
		return nil
	}
	return s
}
