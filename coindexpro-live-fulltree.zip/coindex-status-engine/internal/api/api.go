// Package api serves the platform status surface — the /status, /integrity, and
// /launch-check seam the architecture calls for. Every response reflects real
// observed probe data: a service with no stored status is reported not indexed, an
// unreachable service is shown as unreachable, and the launch gate passes only when
// every configured service is genuinely up. Nothing is reported green by default.
package api

import (
	"os"
	"time"

	"github.com/gofiber/fiber/v2"

	"github.com/coindexpro/coindex-status-engine/internal/db"
	"github.com/coindexpro/coindex-status-engine/internal/launchreport"
	"github.com/coindexpro/coindex-status-engine/internal/metrics"
	"github.com/coindexpro/coindex-status-engine/internal/models"
	"github.com/coindexpro/coindex-status-engine/internal/status"
)

type API struct{ store *db.Store }

func New(store *db.Store) *API { return &API{store: store} }

// Register orders static routes before parameterized ones.
func (a *API) Register(app *fiber.App) {
	app.Use(a.observe)
	app.Get("/status", a.systemStatus)
	app.Get("/integrity", a.integrity)
	app.Get("/launch-check", a.launchCheck)
	app.Get("/status/:service/history", a.serviceHistory)
	app.Get("/status/:service", a.serviceStatus)
}

func (a *API) observe(c *fiber.Ctx) error {
	start := time.Now()
	err := c.Next()
	metrics.APILatency.WithLabelValues(c.Route().Path, statusClass(c.Response().StatusCode())).
		Observe(time.Since(start).Seconds())
	return err
}

func notIndexed(c *fiber.Ctx, extra fiber.Map) error {
	m := fiber.Map{"available": false, "reason": "not indexed"}
	for k, v := range extra {
		m[k] = v
	}
	return c.JSON(m)
}

// GET /status — aggregate system status from the latest stored per-service statuses.
func (a *API) systemStatus(c *fiber.Ctx) error {
	statuses, err := a.store.LatestStatuses(c.UserContext())
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(statuses) == 0 {
		// no probe has run yet -> we genuinely have no data, not "all healthy"
		return notIndexed(c, fiber.Map{"detail": "no probe data yet"})
	}
	sys := aggregateStored(statuses)
	return c.JSON(fiber.Map{"available": true, "system": sys})
}

// GET /status/:service
func (a *API) serviceStatus(c *fiber.Ctx) error {
	name := c.Params("service")
	st, found, err := a.store.ServiceStatusByName(c.UserContext(), name)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if !found {
		return notIndexed(c, fiber.Map{"service": name})
	}
	return c.JSON(fiber.Map{"available": true, "service": st})
}

// GET /status/:service/history
func (a *API) serviceHistory(c *fiber.Ctx) error {
	name := c.Params("service")
	limit := c.QueryInt("limit", 100)
	if limit < 1 {
		limit = 1
	}
	if limit > 1000 {
		limit = 1000
	}
	hist, err := a.store.ServiceHistory(c.UserContext(), name, limit)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(hist) == 0 {
		return notIndexed(c, fiber.Map{"service": name})
	}
	return c.JSON(fiber.Map{"available": true, "service": name, "history": hist})
}

// GET /integrity — real cross-service integrity findings.
func (a *API) integrity(c *fiber.Ctx) error {
	onlyFailing := c.QueryBool("failing", false)
	limit := c.QueryInt("limit", 100)
	if limit < 1 {
		limit = 1
	}
	if limit > 1000 {
		limit = 1000
	}
	findings, err := a.store.LatestFindings(c.UserContext(), onlyFailing, limit)
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(findings) == 0 {
		return notIndexed(c, fiber.Map{"detail": "no integrity findings recorded"})
	}
	return c.JSON(fiber.Map{"available": true, "findings": findings})
}

// GET /launch-check — pass only when every configured service is genuinely up.
func (a *API) launchCheck(c *fiber.Ctx) error {
	statuses, err := a.store.LatestStatuses(c.UserContext())
	if err != nil {
		metrics.DBErrors.Inc()
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": "internal error"})
	}
	if len(statuses) == 0 {
		return notIndexed(c, fiber.Map{"detail": "no probe data yet"})
	}
	var notUp []string
	for _, s := range statuses {
		if s.Status != models.StatusUp {
			notUp = append(notUp, s.Service+":"+s.Status)
		}
	}
	pass := len(notUp) == 0

	// Fold in the Phase 21 production-verification verdict (rule 3). The report
	// path is configurable; a missing report is "unavailable" (never healthy).
	reportPath := os.Getenv("PHASE21_REPORT_PATH")
	if reportPath == "" {
		reportPath = "artifacts/phase21-report.json"
	}
	verify := launchreport.Evaluate(reportPath)

	// Record launch-report freshness (age in seconds). Absent report -> large
	// sentinel so staleness is visible and never reported as fresh.
	if fi, statErr := os.Stat(reportPath); statErr == nil {
		metrics.LaunchReportAgeSeconds.Set(time.Since(fi.ModTime()).Seconds())
	} else {
		metrics.LaunchReportAgeSeconds.Set(86400) // 24h sentinel = "no fresh report"
	}

	// Overall is GO only when services are all up AND verification says go.
	overallPass := pass && verify.Verdict == launchreport.VerdictGo
	code := fiber.StatusOK
	if !overallPass {
		code = fiber.StatusServiceUnavailable
	}
	return c.Status(code).JSON(fiber.Map{
		"available": true, "pass": overallPass, "services": len(statuses),
		"not_up": notUp,
		"services_all_up":    pass,
		"verification":       verify.Verdict,
		"verification_reason": verify.Reason,
		"verification_fail_stages": verify.FailCount,
	})
}

// aggregateStored rebuilds the system view from stored statuses (the engine's
// Aggregate works on probe results; here we recompute the same counts from the
// persisted ServiceStatus rows so the API never has to re-probe to answer).
func aggregateStored(statuses []models.ServiceStatus) models.SystemStatus {
	sys := models.SystemStatus{Services: len(statuses), GeneratedAt: time.Now().UTC(), Statuses: statuses}
	reachable := 0
	for _, s := range statuses {
		switch s.Status {
		case models.StatusUp:
			sys.Up++
		case models.StatusDegraded:
			sys.Degraded++
		case models.StatusDown:
			sys.Down++
		case models.StatusUnreachable:
			sys.Unreachable++
		}
		if s.Reachable {
			reachable++
		}
	}
	if sys.Services > 0 {
		sys.ProbeCoverage = float64(reachable) / float64(sys.Services)
	}
	sys.Overall = status.OverallOf(sys)
	return sys
}

func statusClass(code int) string {
	switch {
	case code >= 500:
		return "5xx"
	case code >= 400:
		return "4xx"
	default:
		return "2xx"
	}
}
