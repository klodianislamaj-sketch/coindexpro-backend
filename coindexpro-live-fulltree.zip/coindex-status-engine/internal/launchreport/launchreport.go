// Package launchreport reads the Phase 21 production-verification report
// (artifacts/phase21-report.json) and folds its verdict into /launch-check. It is
// deliberately honest: a missing report is "unavailable" (not healthy), an
// environment-unavailable report is "unverifiable", and any FAIL stage or a
// non-GO recommendation is "blocked". There is no path that defaults to healthy.
package launchreport

import (
	"encoding/json"
	"os"
)

// Verdict is the verification verdict folded into launch-check.
const (
	VerdictGo           = "go"           // report present, env available, recommendation GO, no FAIL
	VerdictBlocked      = "blocked"      // a stage FAILed or recommendation != GO
	VerdictUnverifiable = "unverifiable" // env unavailable — could not verify
	VerdictUnavailable  = "unavailable"  // report missing/unreadable — never treated as healthy
)

// Report is the subset of phase21-report.json that the gate consumes.
type Report struct {
	EnvironmentAvailable bool              `json:"environment_available"`
	Stages               map[string]string `json:"stages"`
	LaunchRecommendation string            `json:"launch_recommendation"`
	LaunchCheck          string            `json:"launch_check"`
	Reason               string            `json:"reason"`
}

// Result is what the API surfaces.
type Result struct {
	Verdict   string `json:"verdict"`
	Present   bool   `json:"report_present"`
	FailCount int    `json:"fail_stages"`
	Reason    string `json:"reason,omitempty"`
}

// Evaluate reads the report at path and maps it to a Result. A missing or
// unparseable file yields VerdictUnavailable (NOT healthy).
func Evaluate(path string) Result {
	b, err := os.ReadFile(path)
	if err != nil {
		return Result{Verdict: VerdictUnavailable, Present: false,
			Reason: "phase21 report not found; production verification has not run"}
	}
	var r Report
	if err := json.Unmarshal(b, &r); err != nil {
		return Result{Verdict: VerdictUnavailable, Present: false,
			Reason: "phase21 report unreadable"}
	}

	fails := 0
	for _, st := range r.Stages {
		if st == "FAIL" {
			fails++
		}
	}

	switch {
	case !r.EnvironmentAvailable:
		return Result{Verdict: VerdictUnverifiable, Present: true, FailCount: fails,
			Reason: orDefault(r.Reason, "environment unavailable — could not verify")}
	case fails > 0 || r.LaunchRecommendation != "GO":
		return Result{Verdict: VerdictBlocked, Present: true, FailCount: fails,
			Reason: orDefault(r.Reason, "verification reported blockers")}
	default:
		return Result{Verdict: VerdictGo, Present: true, FailCount: 0,
			Reason: "production verification passed"}
	}
}

func orDefault(s, d string) string {
	if s == "" {
		return d
	}
	return s
}
