package launchreport

import (
	"os"
	"path/filepath"
	"testing"
)

func writeReport(t *testing.T, body string) string {
	t.Helper()
	p := filepath.Join(t.TempDir(), "phase21-report.json")
	if err := os.WriteFile(p, []byte(body), 0o600); err != nil {
		t.Fatal(err)
	}
	return p
}

// The most important invariant: a missing report is "unavailable", never healthy.
func TestEvaluate_MissingReportIsUnavailableNotHealthy(t *testing.T) {
	r := Evaluate(filepath.Join(t.TempDir(), "does-not-exist.json"))
	if r.Verdict != VerdictUnavailable {
		t.Fatalf("missing report want %q, got %q", VerdictUnavailable, r.Verdict)
	}
	if r.Present {
		t.Fatalf("missing report must not be marked present")
	}
}

func TestEvaluate_UnparseableIsUnavailable(t *testing.T) {
	p := writeReport(t, "{not valid json")
	if got := Evaluate(p).Verdict; got != VerdictUnavailable {
		t.Fatalf("unparseable want %q, got %q", VerdictUnavailable, got)
	}
}

func TestEvaluate_EnvUnavailableIsUnverifiable(t *testing.T) {
	p := writeReport(t, `{"environment_available":false,"stages":{},"launch_recommendation":"NO-GO"}`)
	if got := Evaluate(p).Verdict; got != VerdictUnverifiable {
		t.Fatalf("env unavailable want %q, got %q", VerdictUnverifiable, got)
	}
}

func TestEvaluate_FailStageIsBlocked(t *testing.T) {
	p := writeReport(t, `{"environment_available":true,"stages":{"rollout":"PASS","health":"FAIL"},"launch_recommendation":"GO"}`)
	r := Evaluate(p)
	if r.Verdict != VerdictBlocked {
		t.Fatalf("a FAIL stage want %q, got %q", VerdictBlocked, r.Verdict)
	}
	if r.FailCount != 1 {
		t.Fatalf("fail count want 1, got %d", r.FailCount)
	}
}

func TestEvaluate_NonGoRecommendationIsBlocked(t *testing.T) {
	p := writeReport(t, `{"environment_available":true,"stages":{"rollout":"PASS"},"launch_recommendation":"NO-GO"}`)
	if got := Evaluate(p).Verdict; got != VerdictBlocked {
		t.Fatalf("non-GO want %q, got %q", VerdictBlocked, got)
	}
}

func TestEvaluate_AllPassIsGo(t *testing.T) {
	p := writeReport(t, `{"environment_available":true,"stages":{"rollout":"PASS","health":"PASS"},"launch_recommendation":"GO"}`)
	r := Evaluate(p)
	if r.Verdict != VerdictGo {
		t.Fatalf("all pass want %q, got %q", VerdictGo, r.Verdict)
	}
	if !r.Present || r.FailCount != 0 {
		t.Fatalf("present=%v failcount=%d unexpected", r.Present, r.FailCount)
	}
}
