package probe

import (
	"strings"
	"testing"

	"github.com/coindexpro/coindex-status-engine/internal/models"
)

func bptr(b bool) *bool { return &b }

// parsePrometheus must sum a wanted metric across label sets and ignore unwanted
// metrics + comment/blank lines. This proves the real scrape reduction.
func TestParsePrometheus_SumsAcrossLabelsAndIgnoresUnwanted(t *testing.T) {
	text := `# HELP coindex_dlq_messages_total dlq
# TYPE coindex_dlq_messages_total counter
coindex_dlq_messages_total{chain="eth"} 2
coindex_dlq_messages_total{chain="bsc"} 1
coindex_index_lag_blocks{chain="eth"} 40

other_metric_total 999
`
	want := []string{"coindex_dlq_messages_total", "coindex_index_lag_blocks"}
	got := parsePrometheus(strings.NewReader(text), want)

	if got["coindex_dlq_messages_total"] != 3 {
		t.Fatalf("dlq: want 3 (2+1 across chains), got %v", got["coindex_dlq_messages_total"])
	}
	if got["coindex_index_lag_blocks"] != 40 {
		t.Fatalf("lag: want 40, got %v", got["coindex_index_lag_blocks"])
	}
	if _, present := got["other_metric_total"]; present {
		t.Fatalf("unwanted metric must not be parsed, got %v", got["other_metric_total"])
	}
}

// A metric the service does not expose must simply be absent (not zero-filled),
// so callers can report it not indexed rather than a fabricated 0.
func TestParsePrometheus_AbsentMetricIsAbsentNotZero(t *testing.T) {
	got := parsePrometheus(strings.NewReader("coindex_index_lag_blocks 5\n"),
		[]string{"coindex_reorgs_total"})
	if _, present := got["coindex_reorgs_total"]; present {
		t.Fatalf("absent metric must not appear in result map")
	}
}

// deriveStatus must never report an unreachable service as up.
func TestDeriveStatus_UnreachableNeverUp(t *testing.T) {
	r := models.ProbeResult{Reachable: false}
	if got := deriveStatus(r); got != models.StatusUnreachable {
		t.Fatalf("unreachable: want %q, got %q", models.StatusUnreachable, got)
	}
}

func TestDeriveStatus_Transitions(t *testing.T) {
	cases := []struct {
		name      string
		reachable bool
		healthy   *bool
		ready     *bool
		want      string
	}{
		{"reachable+healthy+ready=up", true, bptr(true), bptr(true), models.StatusUp},
		{"reachable+healthy+notready=degraded", true, bptr(true), bptr(false), models.StatusDegraded},
		{"reachable+unhealthy=down", true, bptr(false), nil, models.StatusDown},
		{"reachable+healthy+readyUnknown=up", true, bptr(true), nil, models.StatusUp},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			r := models.ProbeResult{Reachable: c.reachable, Healthy: c.healthy, Ready: c.ready}
			if got := deriveStatus(r); got != c.want {
				t.Fatalf("want %q, got %q", c.want, got)
			}
		})
	}
}
