// Package probe performs the REAL health probing. It issues actual HTTP requests
// to a service's ops endpoints (/healthz, /readyz, /metrics) and records exactly
// what came back. An endpoint that does not respond yields Reachable=false; it is
// never recorded as healthy. Metrics are parsed from the real Prometheus text
// exposition the service emits — only the metric names requested and actually
// present are returned (a metric a service does not expose is simply absent).
package probe

import (
	"bufio"
	"context"
	"io"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/coindexpro/coindex-status-engine/internal/models"
)

// Prober probes services over HTTP with a bounded timeout.
type Prober struct {
	client      *http.Client
	wantMetrics []string // metric names to scrape (only these are extracted)
}

func New(timeout time.Duration, wantMetrics []string) *Prober {
	if timeout <= 0 {
		timeout = 3 * time.Second
	}
	return &Prober{
		client:      &http.Client{Timeout: timeout},
		wantMetrics: wantMetrics,
	}
}

// Probe probes one service and returns the observed result. The status is derived
// purely from real observations:
//   - endpoint unreachable            -> unreachable
//   - /healthz not 200                -> down
//   - healthy but /readyz not 200     -> degraded
//   - healthy + ready                 -> up
func (p *Prober) Probe(ctx context.Context, t models.ServiceTarget) models.ProbeResult {
	res := models.ProbeResult{
		Service: t.Name, ProbedAt: time.Now().UTC(),
		Signals: map[string]float64{},
	}

	start := time.Now()
	healthy, err := p.check(ctx, t.OpsBase+"/healthz")
	rtt := int(time.Since(start).Milliseconds())

	if err != nil {
		// the ops endpoint did not respond: unreachable. We do NOT guess healthy.
		res.Reachable = false
		res.Status = models.StatusUnreachable
		res.Error = err.Error()
		return res
	}
	res.Reachable = true
	res.LatencyMS = &rtt
	res.Healthy = &healthy

	// readiness (best-effort; a non-200 is a real "not ready", an error leaves nil)
	if ready, err := p.check(ctx, t.OpsBase+"/readyz"); err == nil {
		res.Ready = &ready
	}

	// scrape requested metrics from the real /metrics exposition
	if sig, err := p.scrape(ctx, t.OpsBase+"/metrics"); err == nil {
		res.Signals = sig
	}

	res.Status = deriveStatus(res)
	return res
}

// deriveStatus maps real observations to a status. Only reachable services can be
// up/degraded/down; everything else is unreachable.
func deriveStatus(r models.ProbeResult) string {
	if !r.Reachable {
		return models.StatusUnreachable
	}
	if r.Healthy == nil || !*r.Healthy {
		return models.StatusDown
	}
	if r.Ready != nil && !*r.Ready {
		return models.StatusDegraded
	}
	return models.StatusUp
}

// check does a GET and reports whether it returned 2xx. A transport error is
// returned as an error (=> unreachable / unknown), distinct from a non-2xx (=> a
// real "false" answer from a reachable endpoint).
func (p *Prober) check(ctx context.Context, url string) (bool, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return false, err
	}
	resp, err := p.client.Do(req)
	if err != nil {
		return false, err
	}
	defer resp.Body.Close()
	_, _ = io.Copy(io.Discard, io.LimitReader(resp.Body, 4096))
	return resp.StatusCode >= 200 && resp.StatusCode < 300, nil
}

// scrape fetches /metrics and extracts the requested metric names from the real
// Prometheus text exposition. Only metrics actually present are returned.
func (p *Prober) scrape(ctx context.Context, url string) (map[string]float64, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return nil, err
	}
	resp, err := p.client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return map[string]float64{}, nil
	}
	return parsePrometheus(resp.Body, p.wantMetrics), nil
}

// parsePrometheus extracts wanted metric values from the text exposition format.
// For a wanted name, it sums sample values across label sets (so a counter vec
// becomes a total) — a transparent, deterministic reduction over real samples.
// Lines that are comments, empty, or for unwanted metrics are ignored.
func parsePrometheus(r io.Reader, want []string) map[string]float64 {
	wanted := make(map[string]struct{}, len(want))
	for _, w := range want {
		wanted[w] = struct{}{}
	}
	out := map[string]float64{}
	sc := bufio.NewScanner(r)
	sc.Buffer(make([]byte, 0, 64*1024), 1024*1024)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		// format: metric_name{labels} value   OR   metric_name value
		name := line
		if i := strings.IndexAny(line, "{ "); i >= 0 {
			name = line[:i]
		}
		if _, ok := wanted[name]; !ok {
			continue
		}
		// value is the last whitespace-separated field
		fields := strings.Fields(line)
		if len(fields) < 2 {
			continue
		}
		v, err := strconv.ParseFloat(fields[len(fields)-1], 64)
		if err != nil {
			continue
		}
		out[name] += v
	}
	return out
}
