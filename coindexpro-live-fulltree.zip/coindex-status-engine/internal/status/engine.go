package status

import (
	"context"
	"sync"
	"time"

	"go.uber.org/zap"

	"github.com/coindexpro/coindex-status-engine/internal/metrics"
	"github.com/coindexpro/coindex-status-engine/internal/models"
)

// Prober probes one service (implemented by probe.Prober).
type Prober interface {
	Probe(ctx context.Context, t models.ServiceTarget) models.ProbeResult
}

// Sink persists probe outputs (implemented by db.Store).
type Sink interface {
	SaveSnapshots(ctx context.Context, results []models.ProbeResult) error
	ReplaceServiceStatus(ctx context.Context, statuses []models.ServiceStatus) error
	SaveFindings(ctx context.Context, findings []models.IntegrityFinding) error
}

type Engine struct {
	prober   Prober
	sink     Sink
	targets  []models.ServiceTarget
	checks   []Check
	parallel int
	log      *zap.Logger
}

func NewEngine(prober Prober, sink Sink, targets []models.ServiceTarget, checks []Check, parallel int, log *zap.Logger) *Engine {
	if parallel <= 0 {
		parallel = 8
	}
	return &Engine{prober: prober, sink: sink, targets: targets, checks: checks, parallel: parallel, log: log}
}

// ProbeCycle probes every configured target, persists the observations, evaluates
// integrity checks, and returns the aggregated system status. Every value written
// is a real observation; an unreachable service is stored as unreachable.
func (e *Engine) ProbeCycle(ctx context.Context) (models.SystemStatus, error) {
	now := time.Now().UTC()
	results := e.probeAll(ctx)

	if err := e.sink.SaveSnapshots(ctx, results); err != nil {
		return models.SystemStatus{}, err
	}

	statuses := make([]models.ServiceStatus, 0, len(results))
	byService := make(map[string]models.ProbeResult, len(results))
	for _, r := range results {
		statuses = append(statuses, toStatus(r, now))
		byService[r.Service] = r
		metrics.Probes.WithLabelValues(r.Status).Inc()
		if r.LatencyMS != nil {
			metrics.ProbeLatency.Observe(float64(*r.LatencyMS) / 1000.0)
		}
	}
	if err := e.sink.ReplaceServiceStatus(ctx, statuses); err != nil {
		return models.SystemStatus{}, err
	}

	findings := RunChecks(e.checks, byService, now)
	if len(findings) > 0 {
		if err := e.sink.SaveFindings(ctx, findings); err != nil {
			return models.SystemStatus{}, err
		}
		for _, f := range findings {
			if !f.OK {
				metrics.FailingChecks.Inc()
			}
		}
	}

	sys := Aggregate(results, now)
	metrics.Cycles.Inc()
	metrics.ServicesUp.Set(float64(sys.Up))
	metrics.ServicesUnreachable.Set(float64(sys.Unreachable))
	e.log.Info("probe cycle complete",
		zap.String("overall", sys.Overall), zap.Int("up", sys.Up),
		zap.Int("unreachable", sys.Unreachable), zap.Float64("coverage", sys.ProbeCoverage))
	return sys, nil
}

// probeAll probes targets concurrently with bounded parallelism.
func (e *Engine) probeAll(ctx context.Context) []models.ProbeResult {
	results := make([]models.ProbeResult, len(e.targets))
	sem := make(chan struct{}, e.parallel)
	var wg sync.WaitGroup
	for i, t := range e.targets {
		wg.Add(1)
		go func(i int, t models.ServiceTarget) {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()
			results[i] = e.prober.Probe(ctx, t)
		}(i, t)
	}
	wg.Wait()
	return results
}
