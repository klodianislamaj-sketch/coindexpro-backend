// Package status holds the aggregation + integrity logic. It turns REAL probe
// results into a system status and evaluates REAL metric values against configured
// thresholds. A check whose metric is not exposed by the service is reported as
// "not indexed" (observed nil), never assumed to pass; a status is computed only
// from observed probe outcomes.
package status

import (
	"math"
	"time"

	"github.com/coindexpro/coindex-status-engine/internal/models"
)

// Comparator for an integrity check.
const (
	CmpGreater = "gt" // fail when observed > threshold (e.g. lag, dlq)
	CmpLess    = "lt" // fail when observed < threshold
)

// Check is one integrity check over a real scraped metric.
type Check struct {
	Name      string  `yaml:"name"`
	Service   string  `yaml:"service"`    // which service's signals to read
	Metric    string  `yaml:"metric"`     // real Prometheus metric name
	Cmp       string  `yaml:"cmp"`        // gt|lt
	Threshold float64 `yaml:"threshold"`
}

// RunChecks evaluates each check against the real scraped signals for its service.
// resultsByService maps service -> its latest ProbeResult. A metric that the
// service did not expose yields observed=nil and ok=false with a "not indexed"
// detail — it is never treated as passing.
func RunChecks(checks []Check, resultsByService map[string]models.ProbeResult, now time.Time) []models.IntegrityFinding {
	out := make([]models.IntegrityFinding, 0, len(checks))
	for _, c := range checks {
		f := models.IntegrityFinding{
			CheckName: c.Name, Service: c.Service, CheckedAt: now,
			Threshold: ptr(c.Threshold),
		}
		pr, ok := resultsByService[c.Service]
		if !ok || !pr.Reachable {
			f.OK = false
			f.Detail = "service unreachable; check not evaluated"
			out = append(out, f)
			continue
		}
		val, present := pr.Signals[c.Metric]
		if !present {
			// the real metric is not exposed -> not indexed; do not assume pass
			f.OK = false
			f.Detail = "metric not exposed by service (not indexed)"
			out = append(out, f)
			continue
		}
		f.Observed = ptr(val)
		breached := (c.Cmp == CmpGreater && val > c.Threshold) ||
			(c.Cmp == CmpLess && val < c.Threshold)
		f.OK = !breached
		if breached {
			f.Detail = "threshold breached"
		} else {
			f.Detail = "within threshold"
		}
		out = append(out, f)
	}
	return out
}

// Aggregate builds the system status from real probe results. Overall is:
//   - down      when any service is down/unreachable AND none are up (total outage view is avoided;
//               we report down if at least one core service is down/unreachable)
//   - degraded  when all reachable services are healthy but some are not ready / unreachable
//   - up        when every configured service is up
// probe_coverage = reachable / configured, exposing how much of the fleet we
// actually observed this cycle.
func Aggregate(results []models.ProbeResult, now time.Time) models.SystemStatus {
	s := models.SystemStatus{Services: len(results), GeneratedAt: now}
	reachable := 0
	for _, r := range results {
		switch r.Status {
		case models.StatusUp:
			s.Up++
		case models.StatusDegraded:
			s.Degraded++
		case models.StatusDown:
			s.Down++
		case models.StatusUnreachable:
			s.Unreachable++
		}
		if r.Reachable {
			reachable++
		}
		s.Statuses = append(s.Statuses, toStatus(r, now))
	}
	if s.Services > 0 {
		s.ProbeCoverage = round4(float64(reachable) / float64(s.Services))
	}
	s.Overall = OverallOf(s)
	return s
}

// OverallOf derives the single overall status from the per-status counts. Exported
// so the API can compute the same overall from stored statuses without re-probing.
func OverallOf(s models.SystemStatus) string {
	if s.Services == 0 {
		return models.StatusUnreachable
	}
	if s.Down > 0 || s.Unreachable > 0 {
		return models.StatusDown
	}
	if s.Degraded > 0 {
		return models.StatusDegraded
	}
	return models.StatusUp
}

// toStatus projects a probe result into a stored ServiceStatus.
func toStatus(r models.ProbeResult, now time.Time) models.ServiceStatus {
	return models.ServiceStatus{
		Service: r.Service, Status: r.Status, Reachable: r.Reachable,
		Healthy: r.Healthy, Ready: r.Ready, LatencyMS: r.LatencyMS,
		Signals: r.Signals, Error: r.Error, UpdatedAt: now,
	}
}

func ptr(f float64) *float64    { return &f }
func round4(x float64) float64  { return math.Round(x*10000) / 10000 }
