package status

import (
	"testing"
	"time"

	"github.com/coindexpro/coindex-status-engine/internal/models"
)

func TestRunChecks_BreachDetectedWithObservedValue(t *testing.T) {
	checks := []Check{{Name: "indexer_lag", Service: "indexer-evm", Metric: "coindex_index_lag_blocks", Cmp: CmpGreater, Threshold: 100}}
	results := map[string]models.ProbeResult{
		"indexer-evm": {Service: "indexer-evm", Reachable: true, Signals: map[string]float64{"coindex_index_lag_blocks": 150}},
	}
	f := RunChecks(checks, results, time.Now())
	if len(f) != 1 {
		t.Fatalf("want 1 finding, got %d", len(f))
	}
	if f[0].OK {
		t.Fatalf("lag 150 > 100 must FAIL the check (OK=false)")
	}
	if f[0].Observed == nil || *f[0].Observed != 150 {
		t.Fatalf("observed value must be the real 150, got %v", f[0].Observed)
	}
}

func TestRunChecks_WithinThresholdPasses(t *testing.T) {
	checks := []Check{{Name: "indexer_lag", Service: "indexer-evm", Metric: "coindex_index_lag_blocks", Cmp: CmpGreater, Threshold: 100}}
	results := map[string]models.ProbeResult{
		"indexer-evm": {Service: "indexer-evm", Reachable: true, Signals: map[string]float64{"coindex_index_lag_blocks": 42}},
	}
	f := RunChecks(checks, results, time.Now())
	if !f[0].OK {
		t.Fatalf("lag 42 <= 100 must PASS")
	}
}

// A metric the service does not expose must yield observed=nil and OK=false
// ("not indexed") — never a silent pass.
func TestRunChecks_MissingMetricNotIndexedNotPass(t *testing.T) {
	checks := []Check{{Name: "reorg", Service: "indexer-evm", Metric: "coindex_reorgs_total", Cmp: CmpGreater, Threshold: 5}}
	results := map[string]models.ProbeResult{
		"indexer-evm": {Service: "indexer-evm", Reachable: true, Signals: map[string]float64{}},
	}
	f := RunChecks(checks, results, time.Now())
	if f[0].OK {
		t.Fatalf("missing metric must NOT pass")
	}
	if f[0].Observed != nil {
		t.Fatalf("missing metric observed must be nil, got %v", *f[0].Observed)
	}
}

func TestRunChecks_UnreachableServiceNotEvaluated(t *testing.T) {
	checks := []Check{{Name: "lag", Service: "indexer-evm", Metric: "coindex_index_lag_blocks", Cmp: CmpGreater, Threshold: 100}}
	results := map[string]models.ProbeResult{"indexer-evm": {Service: "indexer-evm", Reachable: false}}
	f := RunChecks(checks, results, time.Now())
	if f[0].OK || f[0].Observed != nil {
		t.Fatalf("unreachable service: check must not pass and observed must be nil")
	}
}

func TestAggregate_DownWhenAnyUnreachable_AndCoverage(t *testing.T) {
	results := []models.ProbeResult{
		{Service: "a", Reachable: true, Status: models.StatusUp},
		{Service: "b", Reachable: true, Status: models.StatusUp},
		{Service: "c", Reachable: false, Status: models.StatusUnreachable},
	}
	sys := Aggregate(results, time.Now())
	if sys.Overall != models.StatusDown {
		t.Fatalf("overall must be down when any unreachable, got %q", sys.Overall)
	}
	if sys.Up != 2 || sys.Unreachable != 1 {
		t.Fatalf("counts wrong: up=%d unreachable=%d", sys.Up, sys.Unreachable)
	}
	// coverage = reachable/total = 2/3
	if sys.ProbeCoverage < 0.66 || sys.ProbeCoverage > 0.67 {
		t.Fatalf("probe_coverage want ~0.6667, got %v", sys.ProbeCoverage)
	}
}

func TestAggregate_EmptyIsUnreachableNotUp(t *testing.T) {
	sys := Aggregate(nil, time.Now())
	if sys.Overall == models.StatusUp {
		t.Fatalf("no services must NOT be 'up'; got %q", sys.Overall)
	}
}

func TestOverallOf_AllUp(t *testing.T) {
	s := models.SystemStatus{Services: 3, Up: 3}
	if OverallOf(s) != models.StatusUp {
		t.Fatalf("all up must be up")
	}
}
