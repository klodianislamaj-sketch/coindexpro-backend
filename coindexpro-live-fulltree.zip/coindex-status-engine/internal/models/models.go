// Package models holds the status-engine's shared domain types. The honesty
// contract is structural: a ProbeResult records exactly what was observed when
// probing a service's real ops endpoints — Reachable is false when the endpoint
// did not respond, Healthy/Ready are pointers that stay nil when unknown, and
// Signals holds only the metrics the service actually exposed. A status is derived
// solely from these observations; nothing is assumed "up".
package models

import "time"

// Status values.
const (
	StatusUp          = "up"          // reachable, healthy, ready
	StatusDegraded    = "degraded"    // reachable + healthy but not ready, or a soft signal breach
	StatusDown        = "down"        // reachable but /healthz failed
	StatusUnreachable = "unreachable" // ops endpoint did not respond
)

// ServiceTarget is a service to probe: its name and ops base URL (host:port that
// serves /healthz, /readyz, /metrics).
type ServiceTarget struct {
	Name    string `yaml:"name" json:"name"`
	OpsBase string `yaml:"ops_base" json:"ops_base"` // e.g. http://indexer:9105
}

// ProbeResult is the observed outcome of probing one service.
type ProbeResult struct {
	Service   string             `json:"service"`
	ProbedAt  time.Time          `json:"probed_at"`
	Reachable bool               `json:"reachable"`
	Healthy   *bool              `json:"healthy,omitempty"`    // nil when unreachable
	Ready     *bool              `json:"ready,omitempty"`      // nil when unknown
	LatencyMS *int               `json:"latency_ms,omitempty"` // nil when unreachable
	Status    string             `json:"status"`
	Signals   map[string]float64 `json:"signals"`              // only metrics the service exposed
	Error     string             `json:"error,omitempty"`
}

// ServiceStatus is the latest known status for a service.
type ServiceStatus struct {
	Service   string             `json:"service"`
	Status    string             `json:"status"`
	Reachable bool               `json:"reachable"`
	Healthy   *bool              `json:"healthy,omitempty"`
	Ready     *bool              `json:"ready,omitempty"`
	LatencyMS *int               `json:"latency_ms,omitempty"`
	Signals   map[string]float64 `json:"signals"`
	Error     string             `json:"error,omitempty"`
	UpdatedAt time.Time          `json:"updated_at,omitempty"`
}

// IntegrityFinding is the result of one real cross-service check.
type IntegrityFinding struct {
	CheckName string    `json:"check_name"`
	Service   string    `json:"service"`
	OK        bool      `json:"ok"`
	Observed  *float64  `json:"observed,omitempty"`  // nil when the metric is not indexed
	Threshold *float64  `json:"threshold,omitempty"`
	Detail    string    `json:"detail"`
	CheckedAt time.Time `json:"checked_at,omitempty"`
}

// SystemStatus is the aggregate view. ProbeCoverage is the honesty field: the
// fraction of configured services that were actually reachable this cycle. Totals
// describe only what was observed.
type SystemStatus struct {
	Overall       string          `json:"overall"` // up|degraded|down
	Services      int             `json:"services"`
	Up            int             `json:"up"`
	Degraded      int             `json:"degraded"`
	Down          int             `json:"down"`
	Unreachable   int             `json:"unreachable"`
	ProbeCoverage float64         `json:"probe_coverage"` // reachable / configured
	Statuses      []ServiceStatus `json:"statuses,omitempty"`
	GeneratedAt   time.Time       `json:"generated_at"`
}
