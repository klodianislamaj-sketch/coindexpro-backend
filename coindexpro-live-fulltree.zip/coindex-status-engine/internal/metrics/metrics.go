// Package metrics holds the status-engine's own Prometheus instruments. The symbol
// set matches exactly what internal/status/engine.go and the api reference.
package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

var (
	Cycles = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_status_cycles_total", Help: "Probe cycles completed.",
	})
	Probes = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "coindex_status_probes_total", Help: "Service probes by resulting status.",
	}, []string{"status"})
	ProbeLatency = promauto.NewHistogram(prometheus.HistogramOpts{
		Name: "coindex_status_probe_seconds", Help: "Per-service probe round-trip time.",
		Buckets: []float64{0.01, 0.05, 0.1, 0.25, 0.5, 1, 3, 5},
	})
	FailingChecks = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_status_failing_checks_total", Help: "Integrity checks that failed.",
	})
	ServicesUp = promauto.NewGauge(prometheus.GaugeOpts{
		Name: "coindex_status_services_up", Help: "Services currently up.",
	})
	ServicesUnreachable = promauto.NewGauge(prometheus.GaugeOpts{
		Name: "coindex_status_services_unreachable", Help: "Services currently unreachable.",
	})
	APILatency = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name: "coindex_status_api_seconds", Help: "API latency by route + status.",
		Buckets: prometheus.DefBuckets,
	}, []string{"route", "status"})
	DBErrors = promauto.NewCounter(prometheus.CounterOpts{
		Name: "coindex_status_db_errors_total", Help: "DB errors.",
	})
	// LaunchReportAgeSeconds is the age of the last Phase 21 verification report
	// consumed by /launch-check. High values mean verification is stale. Set to a
	// large sentinel when the report is absent (never reported as fresh/0).
	LaunchReportAgeSeconds = promauto.NewGauge(prometheus.GaugeOpts{
		Name: "coindex_status_launch_report_age_seconds",
		Help: "Age in seconds of the last consumed Phase 21 launch report (sentinel when absent).",
	})
)
