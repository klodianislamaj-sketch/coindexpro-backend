// Package consumer drives the periodic probe cycle. Platform status must be fresh,
// so the scheduler runs a full real probe of every configured service on an
// interval. It performs no fabrication: each cycle issues real HTTP probes and
// stores exactly what was observed.
package consumer

import (
	"context"
	"time"

	"go.uber.org/zap"
)

// RunFunc is the probe-cycle entrypoint. main adapts status.Engine.ProbeCycle
// (which returns the aggregated status) into this signature, so the consumer stays
// decoupled from the models package and there is no import cycle.
type RunFunc func(ctx context.Context) error

// Scheduler runs the probe cycle on an interval.
type Scheduler struct {
	run      RunFunc
	interval time.Duration
	log      *zap.Logger
}

func NewScheduler(run RunFunc, interval time.Duration, log *zap.Logger) *Scheduler {
	if interval <= 0 {
		interval = 30 * time.Second
	}
	return &Scheduler{run: run, interval: interval, log: log}
}

func (s *Scheduler) Run(ctx context.Context) error {
	t := time.NewTicker(s.interval)
	defer t.Stop()
	s.once(ctx)
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-t.C:
			s.once(ctx)
		}
	}
}

func (s *Scheduler) once(ctx context.Context) {
	if err := s.run(ctx); err != nil {
		s.log.Warn("probe cycle failed", zap.Error(err))
	}
}
