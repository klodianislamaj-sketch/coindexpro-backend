// Command status-engine is the Phase 18 entrypoint. It periodically probes the
// REAL ops endpoints of every CoinDex service (/healthz, /readyz, /metrics),
// records exactly what it observed, evaluates real integrity checks, and serves the
// /status, /integrity, and /launch-check surface. Nothing is reported healthy
// without a real successful probe.
package main

import (
	"context"
	"errors"
	"flag"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/compress"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"github.com/redis/go-redis/v9"
	"go.uber.org/zap"

	"github.com/coindexpro/coindex-status-engine/config"
	"github.com/coindexpro/coindex-status-engine/internal/api"
	"github.com/coindexpro/coindex-status-engine/internal/cache"
	"github.com/coindexpro/coindex-status-engine/internal/consumer"
	"github.com/coindexpro/coindex-status-engine/internal/db"
	"github.com/coindexpro/coindex-status-engine/internal/probe"
	"github.com/coindexpro/coindex-status-engine/internal/status"
)

func main() {
	cfgPath := flag.String("config", "config/config.yaml", "config path")
	flag.Parse()

	cfg, err := config.Load(*cfgPath)
	if err != nil {
		panic(err)
	}
	log, _ := zap.NewProduction()
	defer func() { _ = log.Sync() }()
	log.Info("starting status-engine", zap.Int("targets", len(cfg.Targets)), zap.Int("checks", len(cfg.Checks)))

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	store, err := db.Open(ctx, cfg.Postgres.DSN)
	if err != nil {
		log.Fatal("db open failed", zap.Error(err))
	}
	defer store.Close()

	c := cache.New(cfg.Redis.Addr, cfg.Redis.CacheTTL)
	if err := c.Ping(ctx); err != nil {
		log.Fatal("redis ping failed", zap.Error(err))
	}
	defer func() { _ = c.Close() }()
	rdb := redis.NewClient(&redis.Options{Addr: cfg.Redis.Addr})
	defer func() { _ = rdb.Close() }()

	prober := probe.New(cfg.Probe.Timeout, cfg.Probe.WantMetrics)
	engine := status.NewEngine(prober, store, cfg.Targets, cfg.Checks, cfg.Probe.Parallelism, log)

	if cfg.Probe.Enabled {
		// adapt ProbeCycle (returns aggregated status) into the scheduler's RunFunc
		runFn := func(ctx context.Context) error {
			_, err := engine.ProbeCycle(ctx)
			return err
		}
		sched := consumer.NewScheduler(runFn, cfg.Probe.Interval, log)
		go func() {
			if err := sched.Run(ctx); err != nil && !errors.Is(err, context.Canceled) {
				log.Error("probe scheduler stopped", zap.Error(err))
			}
		}()
	}

	app := fiber.New(fiber.Config{AppName: "coindex-status-engine"})
	app.Use(compress.New())
	api.New(store).Register(app)
	go func() {
		log.Info("api listening", zap.String("addr", cfg.Server.APIAddr))
		if err := app.Listen(cfg.Server.APIAddr); err != nil {
			log.Error("api stopped", zap.Error(err))
		}
	}()

	go serveOps(cfg.Server.MetricsAddr, store, rdb, log)

	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
	<-sig
	log.Info("shutting down")
	cancel()
	sc, scCancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer scCancel()
	_ = app.ShutdownWithContext(sc)
}

func serveOps(addr string, store *db.Store, rdb *redis.Client, log *zap.Logger) {
	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ok"))
	})
	mux.HandleFunc("/readyz", func(w http.ResponseWriter, r *http.Request) {
		ctx, cancel := context.WithTimeout(r.Context(), 3*time.Second)
		defer cancel()
		if err := store.Ping(ctx); err != nil {
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte("db down"))
			return
		}
		if err := rdb.Ping(ctx).Err(); err != nil {
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte("redis down"))
			return
		}
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ready"))
	})
	mux.Handle("/metrics", promhttp.Handler())
	srv := &http.Server{Addr: addr, Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Error("ops server failed", zap.Error(err))
	}
}
