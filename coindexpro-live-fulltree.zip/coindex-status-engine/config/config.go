// Package config loads status-engine configuration from YAML with ${ENV} expansion.
package config

import (
	"fmt"
	"os"
	"time"

	"gopkg.in/yaml.v3"

	"github.com/coindexpro/coindex-status-engine/internal/models"
	"github.com/coindexpro/coindex-status-engine/internal/status"
)

type Config struct {
	Server   ServerConfig           `yaml:"server"`
	Postgres PostgresConfig         `yaml:"postgres"`
	Redis    RedisConfig            `yaml:"redis"`
	Probe    ProbeConfig            `yaml:"probe"`
	Targets  []models.ServiceTarget `yaml:"targets"`
	Checks   []status.Check         `yaml:"checks"`
	Log      LogConfig              `yaml:"log"`
}

type ServerConfig struct {
	APIAddr     string `yaml:"api_addr"`
	MetricsAddr string `yaml:"metrics_addr"`
}
type PostgresConfig struct {
	DSN string `yaml:"dsn"`
}
type RedisConfig struct {
	Addr     string        `yaml:"addr"`
	CacheTTL time.Duration `yaml:"cache_ttl"`
}
type ProbeConfig struct {
	Enabled     bool          `yaml:"enabled"`
	Interval    time.Duration `yaml:"interval"`
	Timeout     time.Duration `yaml:"timeout"`
	Parallelism int           `yaml:"parallelism"`
	WantMetrics []string      `yaml:"want_metrics"` // metric names to scrape from /metrics
}
type LogConfig struct {
	Level string `yaml:"level"`
}

func Load(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config: %w", err)
	}
	var c Config
	if err := yaml.Unmarshal([]byte(os.Expand(string(raw), os.Getenv)), &c); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}
	c.defaults()
	return &c, c.validate()
}

func (c *Config) defaults() {
	if c.Server.APIAddr == "" {
		c.Server.APIAddr = ":8104"
	}
	if c.Server.MetricsAddr == "" {
		c.Server.MetricsAddr = ":9116"
	}
	if c.Redis.CacheTTL == 0 {
		c.Redis.CacheTTL = 10 * time.Second
	}
	if c.Probe.Interval == 0 {
		c.Probe.Interval = 30 * time.Second
	}
	if c.Probe.Timeout == 0 {
		c.Probe.Timeout = 3 * time.Second
	}
	if c.Probe.Parallelism == 0 {
		c.Probe.Parallelism = 8
	}
}

func (c *Config) validate() error {
	if c.Postgres.DSN == "" {
		return fmt.Errorf("postgres.dsn empty")
	}
	if c.Redis.Addr == "" {
		return fmt.Errorf("redis.addr empty")
	}
	if len(c.Targets) == 0 {
		return fmt.Errorf("no service targets configured")
	}
	for _, t := range c.Targets {
		if t.Name == "" || t.OpsBase == "" {
			return fmt.Errorf("target missing name or ops_base")
		}
	}
	return nil
}
