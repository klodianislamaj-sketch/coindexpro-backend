# CoinDex — Distributed Tracing (Phase 26)

## What is wired now
`coindex-api/internal/tracing` provides a Fiber middleware that:
- honors an inbound W3C `traceparent` (reuses the trace id across hops),
- generates a trace id + per-hop span id when absent,
- propagates `X-Request-ID` (falling back to the trace id) so correlation always exists,
- echoes both headers on the response, and
- exposes `Propagate(c)` returning the headers an outbound inter-service call must carry.

This delivers **real cross-service correlation** (API → engine) using stdlib only —
no new heavyweight dependency, and it is a no-op risk-wise (pure header handling).

## What is NOT wired (honest)
- It does **not** export spans to a collector. Emitting OTLP spans requires adding
  the OpenTelemetry SDK (`go.opentelemetry.io/otel`, `otel/sdk`, OTLP exporter) and a
  `TracerProvider` bootstrap, plus a collector/Jaeger deployment. Header format here
  is W3C-compatible, so adding the SDK later needs no caller change.
- To complete: add the otel SDK to each service's go.mod, initialize a
  TracerProvider in main(), wrap handlers in spans, and deploy an OTel collector.

## Integration
Mount the middleware before route handlers (after RequestID), e.g.:
`app.Use(tracing.Middleware())`. Engines should add the same middleware so the
trace id flows through. (Wiring into every engine main() is a follow-up; the
package is ready.)
