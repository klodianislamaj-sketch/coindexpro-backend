# CoinDex — Risk Register (Phase 28)

Risks ranked by actual evidence from the build. The dominant theme is **execution
risk**: the system is fully authored and statically verified but has **never run
against real infrastructure** in this environment.

## CRITICAL
| ID | Risk | Evidence | Mitigation |
|---|---|---|---|
| R1 | **No runtime verification has ever succeeded.** The Phase 21 harness has only produced UNAVAILABLE (no cluster); the launch gate has never produced a real GO. | `artifacts/phase21-report.json` = `environment_available:false`; launch-gate exits 78 | Run the harness against a real staging cluster; require GO before any production cutover |
| R2 | **No code was compiled.** No Go toolchain in this environment; `go build`/`go vet`/`go test` never ran on the 17 services. Compile errors are possible despite static review. | inventory: `go: NOT INSTALLED` | CI `build.yml`/`test.yml` must pass on a real runner before deploy |

## HIGH
| ID | Risk | Evidence | Mitigation |
|---|---|---|---|
| R3 | **No restore drill performed.** Backup/restore scripts are syntax-checked only; an unproven restore path is a latent data-loss risk. | Phase 27: scripts never executed | Perform a full restore drill into a scratch namespace; verify row-count diffs |
| R4 | **Manifests never applied.** No admission controller / `kubectl apply` / `kubeconform` validation; a manifest may be rejected at apply time. | Phase 20/27: YAML-parse only | Dry-run apply (`kubectl apply --dry-run=server`) in staging |
| R5 | **Single-replica stateful infra.** postgres/timescale/clickhouse/kafka/redis are 1 replica each (self-hosted option) — no HA; node loss = outage until restore. | Phase 20 StatefulSets `replicas: 1` | Use managed HA datastores in prod, or add replicas + anti-affinity |
| R6 | **Single indexer (no sharding).** indexer-evm is a single writer (replicas=1, no HPA) — throughput ceiling + SPOF for ingestion. | Phase 20: indexer no HPA | Shard by chain/range; add standby with checkpoint handoff |

## MEDIUM
| ID | Risk | Evidence | Mitigation |
|---|---|---|---|
| R7 | **Tracing incomplete.** Correlation IDs propagate but spans are not exported (OTel SDK unwired); cross-service latency attribution is limited. | Phase 26 TRACING.md | Wire OTel SDK + collector |
| R8 | **Low test coverage.** 4/17 services have tests (23.5%); 13 services have zero behavioral tests. | `ci/test-inventory.json` | Add tests to the untested engines |
| R9 | **ClickHouse TTL data loss-by-design.** Raw events expire 12–24 months; restores reflect dump-time window. | migration TTL clauses | Document retention SLA; archive cold data if longer retention needed |
| R10 | **Kafka = metadata backup only.** No full message backup; replay depends on re-indexing + checkpoints. | Phase 27 inventory | Acceptable if re-index is reliable; document RPO bound |
| R11 | **Cloud dependency.** ESO + backups assume AWS Secrets Manager + S3 (swappable but not abstracted); region/provider outage affects both secrets and backups. | Phase 25/27 | Cross-region replication; multi-provider ESO fallback |

## LOW
| ID | Risk | Evidence | Mitigation |
|---|---|---|---|
| R12 | **22 public GET routes unauthenticated (by design).** Anonymous→free tier; acceptable but widens surface. | Phase 23 audit | Per-route rate limits already apply; monitor abuse metrics |
| R13 | **Scanners unexecuted.** gosec/CodeQL/gitleaks/govulncheck/trivy wired but never run here. | Phase 23 | First CI run on a real runner |
| R14 | **Alert thresholds untuned.** Static thresholds (e.g., lag>500) not validated against real traffic. | Phase 26 rules | Tune after observing baseline |

## Risk posture
No risk is hidden or marked resolved without evidence. The two CRITICAL risks (R1,
R2) are **execution gaps, not design defects** — they are resolved by running the
existing CI + harness against real infrastructure, which this environment cannot do.
