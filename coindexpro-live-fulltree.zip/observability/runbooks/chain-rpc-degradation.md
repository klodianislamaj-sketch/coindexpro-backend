# Runbook: Chain RPC Degradation

**Symptom:** indexer lag rising, `coindex_rpc_errors_total` climbing.

## 1. Confirm
```bash
curl -s http://indexer-evm.coindex.svc.cluster.local:9100/metrics \
  | grep -E 'coindex_(rpc_errors_total|index_lag_blocks|reorgs_total)'
```

## 2. Triage
- Primary RPC failing → indexer should fail over to `*_RPC_SECONDARY`.
- Confirm both endpoints configured (secrets, Phase 25): the RPC URLs are secrets;
  rotate/repair upstream in the canonical secret store, then:
```bash
kubectl -n coindex rollout restart deploy/indexer-evm
```

## 3. Mitigate
- Swap provider in the secret store (no code change), restart indexer-evm.
- Lag recovers as the indexer catches up; checkpoint is monotonic (verified by
  replay-verify.sh) so no data is double-written.

## 4. Verify
```bash
./scripts/replay-verify.sh   # checkpoint monotonicity + no-dup-writes
```
