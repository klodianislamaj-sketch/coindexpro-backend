# Runbook: Auth Failure / Abuse Spike

**Alerts:** `AuthFailureSpike`, `AbuseBlockedSpike`, `APIErrorRateHigh`

## 1. Confirm
```bash
curl -s http://api.coindex.svc.cluster.local:9101/metrics \
  | grep -E 'coindex_api_(auth_denied_total|abuse_blocked_total)'
```
Inspect the append-only audit trail (Phase 23) for the real actors:
```sql
SELECT actor_id, ip, action, count(*)
FROM security_events
WHERE result='deny' AND occurred_at > now() - interval '1 hour'
GROUP BY 1,2,3 ORDER BY 4 DESC LIMIT 20;
```

## 2. Triage
- Single IP dominating → the per-IP limiter (Phase 23) is already returning 429s
  (`coindex_api_abuse_blocked_total{window}`).
- Distributed credential stuffing → many `auth.denied` across IPs.

## 3. Mitigate
- Tighten per-IP limits via `security.IPLimits` (requires deploy) or add an
  upstream WAF/Ingress denylist for the offending CIDR.
- Confirm no secret leak: audit logs are redacted (Phase 23 `Redact`).

## 4. Verify
Abuse counters flatten; `security_events` deny-rate returns to baseline.
