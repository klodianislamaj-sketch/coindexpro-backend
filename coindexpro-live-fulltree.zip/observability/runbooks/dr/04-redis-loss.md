# DR Runbook 4: Redis Loss

## Key fact
Redis runs `--maxmemory-policy allkeys-lru` — it is a CACHE, not a data-of-record.
There is no "restore"; recovery is a RE-WARM from Postgres/ClickHouse.

## Procedure
1. Replace the pod (PVC may be discarded):
```bash
kubectl -n coindex delete pod -l app=redis     # StatefulSet recreates it
kubectl -n coindex rollout status statefulset/redis --timeout=120s
```
2. Confirm health:
```bash
REDISHOST=redis.coindex.svc.cluster.local ./scripts/backup-redis.sh   # RDB health
./scripts/check-redis.sh                                              # PING
```
3. Caches re-warm naturally as requests flow; no manual data restore.
## Rollback condition
- None for data (cache). If Redis cannot start, services degrade to direct DB
  reads or report NOT ready (Phase 23 limiter fails open) — never serve fabricated
  cached values.
