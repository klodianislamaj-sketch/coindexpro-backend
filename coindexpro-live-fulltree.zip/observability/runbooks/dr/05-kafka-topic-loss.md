# DR Runbook 5: Kafka Topic Loss

## Key fact
Kafka carries transient event streams. The DURABLE record is in ClickHouse (written
by the indexer). Recovery = recreate topics + resume indexing; full message replay
comes from re-indexing, not a Kafka restore.

## Procedure
1. Recreate topics from the metadata snapshot:
```bash
aws s3 cp s3://$BACKUP_S3_BUCKET/kafka/<latest>.txt /tmp/kafka-meta.txt
# review topic list/configs, then recreate:
kafka-topics.sh --bootstrap-server kafka.coindex.svc.cluster.local:9092 \
  --create --topic raw.eth --partitions 6 --replication-factor 1   # per snapshot
```
2. Restart producers/consumers:
```bash
kubectl -n coindex rollout restart deploy/indexer-evm deploy/enricher
```
3. The indexer resumes from its checkpoint (monotonic; verified by replay-verify.sh)
   and republishes; DLQ (`raw.dlq`/`enrich.dlq`) captures anything unprocessable.
## Rollback condition
- If checkpoints are also lost, re-index a bounded historical range and verify with
  `./scripts/replay-verify.sh` (idempotent, no duplicate writes).
