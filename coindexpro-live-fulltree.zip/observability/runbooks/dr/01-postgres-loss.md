# DR Runbook 1: Full Postgres Loss

## Restore order (schema before data)
1. Confirm loss + provision a fresh Postgres:
```bash
kubectl -n coindex get sts postgres pvc data-postgres-0 || echo "lost"
kubectl -n coindex rollout status statefulset/postgres --timeout=180s
```
2. Find the latest verified backup:
```bash
./scripts/verify-backup-integrity.sh   # must show postgres PASS, fresh
aws s3 ls s3://$BACKUP_S3_BUCKET/postgres/ | sort | tail -1
```
3. Download + restore SCHEMA-FIRST then DATA (the script enforces ordering + verifies):
```bash
aws s3 cp s3://$BACKUP_S3_BUCKET/postgres/<file>.dump /tmp/pg.dump
aws s3 cp s3://$BACKUP_S3_BUCKET/postgres/<file>.dump.sha256 /tmp/pg.dump.sha256
PGHOST=postgres.coindex.svc.cluster.local PGUSER=coindex PGDATABASE=coindex \
  ./scripts/restore-postgres.sh /tmp/pg.dump
```
## Verification (script does this; do not skip)
- artifact checksum verified, schema (9 core tables) present, data restored,
  optional `EXPECTED_COUNTS` row-count diff.
## Rollback condition
- If `restore-postgres.sh` exits non-zero (checksum/schema/row mismatch), DO NOT
  point services at the DB. Investigate or pick an earlier backup. Services that
  depend on Postgres report NOT ready until a verified restore completes.
