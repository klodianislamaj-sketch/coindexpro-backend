# DR Runbook 2: Timescale Corruption

## Restore order
1. Quarantine: scale readers off if writing bad data; provision clean timescale.
2. Verify + fetch latest backup:
```bash
./scripts/verify-backup-integrity.sh   # timescale PASS + fresh
aws s3 cp s3://$BACKUP_S3_BUCKET/timescale/<file>.dump /tmp/ts.dump
aws s3 cp s3://$BACKUP_S3_BUCKET/timescale/<file>.dump.sha256 /tmp/ts.dump.sha256
```
3. Restore (schema-first; re-attaches hypertables + verifies they ARE hypertables):
```bash
TSHOST=timescale.coindex.svc.cluster.local TSUSER=coindex TSDATABASE=coindex \
  ./scripts/restore-timescale.sh /tmp/ts.dump
```
## Verification
- timescaledb extension present, 4 hypertables (liquidity/trust/whale/sector_history)
  confirmed via timescaledb_information.hypertables.
## Rollback condition
- If a target is restored as a plain table (not hypertable), the script FAILS —
  do not resume writes; re-run with an earlier dump.
