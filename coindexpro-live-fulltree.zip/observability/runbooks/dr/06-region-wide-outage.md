# DR Runbook 6: Region-Wide Outage

## Strategy
Rebuild the platform in a secondary region from S3 backups (cross-region bucket or
replicated bucket required) + ESO pointing at the secret store.

## Order (dependencies first)
1. Provision cluster + install ESO; apply k8s/secrets/ (Phase 25) so coindex-secrets
   reconciles in the new region.
2. Bring up stateful infra:
```bash
kubectl apply -f k8s/deployments/postgres.yaml -f k8s/deployments/timescale.yaml \
  -f k8s/deployments/clickhouse.yaml -f k8s/deployments/redis.yaml -f k8s/deployments/kafka.yaml
```
3. Restore data-of-record stores (schema-first, verified):
```bash
./scripts/restore-postgres.sh   <latest>      # see runbook 1
./scripts/restore-timescale.sh  <latest>      # runbook 2
./scripts/restore-clickhouse.sh <latest>      # runbook 3
```
4. Recreate Kafka topics (runbook 5); Redis re-warms (runbook 4).
5. Apply migrations Jobs (Phase 20) only if restoring into an empty schema; skip if
   the dump already carries schema.
6. Deploy services + run the launch gate before cutover:
```bash
./scripts/phase21-run.sh && ./scripts/launch-gate.sh   # GO required for traffic
```
## Verification
- `verify-backup-integrity.sh` PASS for all stores before restore.
- `launch-gate.sh` must return GO (0) before DNS/traffic cutover.
## Rollback condition
- Any restore verification failure or non-GO launch gate -> keep traffic on the
  surviving region (if any); do not cut over to an unverified stack.
