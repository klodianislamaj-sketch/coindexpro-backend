# DR Runbook 3: ClickHouse Shard / Table Loss

## Restore order
1. Identify lost tables; confirm node/disk state:
```bash
kubectl -n coindex get sts clickhouse pvc data-clickhouse-0
clickhouse-client --host clickhouse.coindex.svc.cluster.local -q "SHOW TABLES FROM coindex"
```
2. Verify + restore from the latest S3 backup (server-side RESTORE + verifies tables):
```bash
./scripts/verify-backup-integrity.sh   # clickhouse fresh
CHHOST=clickhouse.coindex.svc.cluster.local CHUSER=coindex CHDATABASE=coindex \
  ./scripts/restore-clickhouse.sh clickhouse-coindex-<ts>.zip
```
## Verification
- 8 core tables (swaps, lp_events, transfers, token_mints, wallet_trades,
  wallet_positions, token_metrics, smart_money_events) confirmed present.
- Optional `MANIFEST=<file>` row-count diff.
## Important honesty note
- ClickHouse tables carry `TTL` (12–24 months). A restore reflects the dump's TTL
  window; data already aged out is gone by design. Recent events can also be
  rebuilt by re-indexing (the indexer is the upstream source of truth).
## Rollback condition
- Missing table or row-count mismatch -> script FAILS; use an earlier backup or
  re-index from chain.
