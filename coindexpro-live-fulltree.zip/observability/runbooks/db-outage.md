# Runbook: Database Outage (Postgres / Timescale / ClickHouse)

**Alerts:** `PostgresDown`, `DBErrorsHigh`, `ServicesUnreachable`

## 1. Confirm
```bash
kubectl -n coindex get pods -l app=postgres
kubectl -n coindex get statefulset postgres
./scripts/check-postgres.sh        # real schema-presence check (Phase 21A)
```
status-engine surfaces it honestly:
```bash
curl -s http://status-engine.coindex.svc.cluster.local:8104/status | jq '.services[] | select(.status!="up")'
```

## 2. Triage
- Pod not Ready: `kubectl -n coindex describe pod -l app=postgres`
- PVC full: `kubectl -n coindex exec sts/postgres -- df -h /var/lib/postgresql/data`
- Connection saturation: check `coindex_*_db_errors_total` rate per service.

## 3. Mitigate
```bash
# restart the stateful pod (data on PVC survives)
kubectl -n coindex rollout restart statefulset/postgres
kubectl -n coindex rollout status statefulset/postgres --timeout=180s
```
Dependent services report NOT ready until Postgres is back (by design — no
false-green). They recover automatically once `/readyz` passes.

## 4. Verify recovery
```bash
./scripts/check-postgres.sh && ./scripts/verify-health.sh
```
