# Runbook: Kafka Backlog / Consumer Lag

**Alerts:** `KafkaIndexLagHigh`, `EnricherQueueLagHigh`

## 1. Confirm
```bash
./scripts/check-kafka.sh           # topics, groups, lag, DLQ depth (Phase 21A)
curl -s http://indexer-evm.coindex.svc.cluster.local:9100/metrics | grep coindex_index_lag_blocks
curl -s http://enricher.coindex.svc.cluster.local:9102/metrics | grep coindex_enrich_queue_lag
```

## 2. Triage
- Consumer down → lag grows: `kubectl -n coindex get pods -l app=enricher`
- DLQ growing (`raw.dlq`/`enrich.dlq`): inspect with check-kafka.sh DLQ section.
- Broker unhealthy: `kubectl -n coindex get sts kafka`

## 3. Mitigate
```bash
# scale consumers (enricher has an HPA; bump min if sustained)
kubectl -n coindex scale deploy/enricher --replicas=4
```
The indexer is a single writer — do NOT scale it horizontally (would double-process).
Investigate RPC/throughput instead (see chain-rpc-degradation.md).

## 4. Verify
```bash
./scripts/check-kafka.sh
```
