# Runbook: Stripe Webhook Verification Failures

**Alert:** `PremiumWebhookFailures` (rejected rate >1%)

## 1. Confirm
```bash
curl -s http://premium-engine.coindex.svc.cluster.local:9114/metrics \
  | grep coindex_premium_webhook_events_total
```
Outcomes: `not_configured` | `rejected` | (accepted).

## 2. Triage
- All `not_configured` → `STRIPE_WEBHOOK_SECRET` missing. premium-engine now
  fail-fasts at startup (Phase 24), so this means a recent secret rotation gap.
- `rejected` spike → signature mismatch (wrong secret) or timestamp drift
  (clock skew / replayed events). Replay protection is working as intended if
  these are genuine replays (event_id idempotency, Phase 16).

## 3. Mitigate
```bash
# repair the secret in the canonical store (Phase 25), then:
kubectl -n coindex rollout restart deploy/premium-engine
```
Check node clock skew if drift rejections dominate.

## 4. Verify
`rejected` rate returns below 1%; new events show accepted outcomes.
