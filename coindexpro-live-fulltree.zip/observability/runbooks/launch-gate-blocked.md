# Runbook: Launch Gate Blocked / Stale

**Alerts:** `LaunchReportStale`

## 1. Confirm
```bash
curl -s http://status-engine.coindex.svc.cluster.local:8104/launch-check | jq .
curl -s http://status-engine.coindex.svc.cluster.local:9116/metrics \
  | grep coindex_status_launch_report_age_seconds
```

## 2. Triage
- `verification: unavailable` → no Phase 21 report. Re-run verification:
```bash
./scripts/phase21-run.sh
```
- `verification: blocked` → a real stage FAILed; read the report:
```bash
jq '.stages, .blockers' artifacts/phase21-report.json
```
- `verification: unverifiable` → environment unavailable (no cluster path).

## 3. Mitigate
Resolve the specific failing stage (rollout/health/deps/migrations/kafka/replay)
using the matching runbook, then re-run `./scripts/launch-gate.sh`.

## 4. Verify
```bash
./scripts/launch-gate.sh   # GO -> 0, UNAVAILABLE -> 78, FAIL -> 1
```
