# CoinDex — Production Readiness Matrix (Phase 28)

Each dimension is graded on **disk-verified evidence only**. Anything that requires
live execution to confirm and has not been executed is **PARTIAL** — never PASS.

| # | Dimension | Status | Evidence / why not higher |
|---|---|---|---|
| 1 | Code completeness | **PASS** | 17/17 services have go.mod + Dockerfile + entrypoint; migrations + engines complete |
| 2 | Build integrity | **PARTIAL** | CI `build.yml`/`test.yml` exist and reference real modules, but **no Go toolchain here** — nothing was `go build`/`go vet`-compiled in this environment |
| 3 | Deployment integrity | **PARTIAL** | 22 deployments + 22 services + 15 HPA + 17 PDB + 6 jobs + 6 cronjobs, all YAML-valid; **never `kubectl apply`-ed or schema-validated by an API server** |
| 4 | Health coverage | **PASS** | 17/17 expose `/healthz`+`/readyz` on real probe ports; encoded in deployments |
| 5 | Security coverage | **PASS** | auth, deny-by-default roles, audit trail, per-IP+per-tier rate limit, fail-fast secrets, ESO, replay protection, headers — all wired (Phase 23/24/25) |
| 6 | Test coverage | **PARTIAL** | 46 Go tests + 5 bash tests written + static-verified; **only the 5 bash tests actually executed**; Go tests never run (no toolchain); 4/17 services have tests (23.5%) |
| 7 | Observability coverage | **PARTIAL** | 17/17 code-backed metrics, alert rules, SLOs, runbooks — all real; **tracing propagates correlation IDs but does NOT export spans (OTel SDK not wired)**; nothing measured at runtime |
| 8 | Backup coverage | **PARTIAL** | backup+restore+integrity scripts for all 5 stores, CronJobs wired; **never executed against real datastores/S3** |
| 9 | DR coverage | **PARTIAL** | 6 DR runbooks with real commands; **no restore drill has ever been performed** |
| 10 | Secret management coverage | **PASS** | ESO reconciles 34 keys into `coindex-secrets`; no plaintext in repo; fail-fast at startup |
| 11 | Launch gate coverage | **PARTIAL** | launch-gate + Phase 21 harness complete (12 stages); **harness has only ever produced UNAVAILABLE (no cluster); has never produced a real GO** |

## Summary
- **PASS (5):** code completeness, health coverage, security coverage, secret management, launch gate *wiring*.
- **PARTIAL (6):** build, deployment, test, observability, backup, DR, launch gate *execution* — all because **nothing has run against real infrastructure in this environment**.
- **FAIL (0):** no dimension is broken or missing; the gaps are execution/verification, not absence.
