# CoinDex — Service Level Objectives (Phase 26)

Each SLO is tied to a **real, code-backed metric**. These define targets and how
to measure them; they make **no claim about current live compliance** (no runtime
here to measure against).

| # | SLO | Target | Signal (real metric) | PromQL (measurement) |
|---|---|---|---|---|
| 1 | API availability | ≥ 99.9% | `coindex_api_requests_total`, `coindex_api_errors_total` | `1 - (sum(rate(coindex_api_errors_total[30d])) / sum(rate(coindex_api_requests_total[30d])))` |
| 2 | API p95 latency | < 250 ms | `coindex_api_request_seconds_bucket` | `histogram_quantile(0.95, sum(rate(coindex_api_request_seconds_bucket[5m])) by (le))` |
| 3 | Launch-check freshness | < 60 s | `coindex_status_launch_report_age_seconds` | `max(coindex_status_launch_report_age_seconds)` |
| 4 | Kafka consumer lag | < 500 msgs | `coindex_enrich_queue_lag`, `coindex_index_lag_blocks` | `max(coindex_enrich_queue_lag)` / `max(coindex_index_lag_blocks)` |
| 5 | Premium webhook verification success | > 99% | `coindex_premium_webhook_events_total{outcome}` | `1 - (sum(rate(coindex_premium_webhook_events_total{outcome="rejected"}[1d])) / sum(rate(coindex_premium_webhook_events_total[1d])))` |

## Error budgets
- SLO 1 (99.9%): budget = 0.1% of requests / 30d. The `APIErrorRateHigh` alert
  (>2% for 10m) fires well before sustained budget burn.
- SLO 2 (p95 <250ms): `APILatencyP95High` alert maps directly.
- SLO 3 (freshness <60s): the `LaunchReportStale` alert uses a relaxed 1h
  threshold for paging; the 60s SLO is the dashboard target, not a page (a 60s
  page would be too noisy given the verification cadence).
- SLO 4 (<500): `KafkaIndexLagHigh` / `EnricherQueueLagHigh` alerts map directly.
- SLO 5 (>99%): `PremiumWebhookFailures` alert maps directly.

## Honesty notes
- SLO 3's alert threshold (1h) intentionally differs from the SLO target (60s):
  the SLO is the objective; the alert is tuned to avoid paging noise. This is
  documented rather than hidden.
- No SLO here asserts it is currently met. Compliance is computed by the queries
  above against a live Prometheus, which does not exist in this build environment.
