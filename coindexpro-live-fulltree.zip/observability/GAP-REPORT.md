# CoinDex — Observability Gap Report (Phase 26, pre-build)

Verified against disk before building anything. Reports what is **absent** first.

## Absent (must build)
- **Distributed tracing: ABSENT.** No OpenTelemetry/Jaeger anywhere in the repo —
  no tracer provider, no spans, no W3C traceparent propagation. This is the single
  largest gap.
- **Alerting: ABSENT.** No PrometheusRule manifests, no Alertmanager routes.
- **SLO/error-budget definitions: ABSENT.**
- **Runbooks: ABSENT.**
- **Cross-service request-ID propagation: PARTIAL/ABSENT.** The API generates and
  honors `X-Request-ID` (Phase 3), but the engines are standalone APIs that do not
  read an inbound `X-Request-ID`, so a correlation ID does not flow API→engine.
- **Audit-write metric: ABSENT.** The Phase 23 `Auditor` drops events to a log when
  its buffer is full but exposes no counter for written/dropped events.
- **Launch-check freshness metric: ABSENT.** status-engine has no gauge for the age
  of the last Phase 21 verification report.

## Already present (do NOT rebuild)
- **/metrics on all 17 services, code-backed.** Every service registers real
  `promauto` collectors (5–13 each) — no empty ports.
- **Security metrics (Phase 23):** `coindex_api_auth_denied_total`,
  `coindex_api_abuse_blocked_total{window}`, `coindex_api_abuse_failopen_total`.
- **Kafka lag gauges:** `coindex_index_lag_blocks` (indexer),
  `coindex_enrich_lag_seconds` + `coindex_enrich_queue_lag` (enricher).
- **DB error counters:** `coindex_<svc>_db_errors_total` across engines;
  `coindex_api_db_query_seconds` histogram on the API.
- **Premium webhook outcome counter:** `coindex_premium_webhook_events_total{outcome}`
  already distinguishes success/rejected/not_configured — SLO-ready, no change needed.
- **status-engine aggregation:** `coindex_status_services_up`,
  `coindex_status_services_unreachable`, `coindex_status_failing_checks_total`,
  `coindex_status_probe_seconds`.
- **Structured logging:** zap in 16/17 services (indexer uses its own structured logger).

## Build plan (additive only)
A. Metrics: add ONLY the two missing collectors (audit-write counter in api/security;
   launch-check freshness gauge in status-engine). Everything else already exists.
B. Tracing: add an optional OpenTelemetry bootstrap package + Fiber middleware that
   propagates W3C `traceparent` + `X-Request-ID`; no-op when OTEL endpoint unset
   (never forces a dependency).
C. Alerting: PrometheusRule mapping to the REAL metric names above.
D. SLOs: documented objectives, each tied to a real metric/query.
E. Runbooks: real `kubectl`/verify-harness commands.
