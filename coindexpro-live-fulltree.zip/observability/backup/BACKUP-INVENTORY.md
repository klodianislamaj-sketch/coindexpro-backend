# CoinDex — Backup & DR Inventory (Phase 27)

Derived from the real Phase 20 StatefulSets. PVC name pattern is `data-<sts>-0`
(all volumeClaimTemplates are named `data`). No values are assumed.

## Inventory

| Datastore | Kind / Image | Persistence path | PVC | Backup method | Restore method | RPO | RTO | Integrity check |
|---|---|---|---|---|---|---|---|---|
| **Postgres** | StatefulSet `postgres` / postgres:16-alpine | `/var/lib/postgresql/data` (50Gi) | `data-postgres-0` | `pg_dump -Fc` logical → S3 | `pg_restore` schema-first → data | ≤ 24h (daily) | ≤ 1h | sha256 + row-count diff |
| **Timescale** | StatefulSet `timescale` / timescaledb:2.15-pg16 | `/var/lib/postgresql/data` (50Gi) | `data-timescale-0` | `pg_dump -Fc` (+ hypertable-aware) → S3 | `pg_restore` + `create_hypertable` re-attach | ≤ 24h | ≤ 1h | sha256 + hypertable presence + row-count |
| **ClickHouse** | StatefulSet `clickhouse` / clickhouse-server:24.3 | `/var/lib/clickhouse` (200Gi) | `data-clickhouse-0` | `BACKUP ... TO Disk(...)` / partition export → S3 | `RESTORE` from S3 disk | ≤ 24h | ≤ 2–4h (volume) | sha256 + table presence + row-count |
| **Redis** | StatefulSet `redis` / redis:7-alpine | `/data` (5Gi) | `data-redis-0` | **RDB-dump verify only** (cache) | re-warm from sources | n/a (ephemeral) | minutes | RDB readability (`redis-check-rdb`) |
| **Kafka** | StatefulSet `kafka` / bitnami/kafka:3.7 | `/bitnami/kafka` (50Gi) | `data-kafka-0` | **metadata/topic-config snapshot** (+ retention) | recreate topics + replay from indexer | bounded by retention | ≤ 1h | topic-config + offset snapshot readable |

## Honest protection status (reported up front)
- **Fully backup-able (logical, restorable):** Postgres, Timescale, ClickHouse.
- **Ephemeral by design (NOT a data-of-record backup):**
  - **Redis** runs `--maxmemory-policy allkeys-lru` — it is a cache. We **verify RDB
    persistence health** but the source of truth is Postgres/ClickHouse; recovery is
    a re-warm, not a restore. Treating Redis as a durable backup would be dishonest.
  - **Kafka** topics carry transient event streams; the durable record lands in
    ClickHouse via the indexer. We snapshot **topic metadata/config + offsets** so
    topics can be recreated; full message replay comes from re-indexing, not a Kafka
    restore. This is the honest RPO ("bounded by retention").
- **ClickHouse TTL caveat:** raw event tables expire at 12–24 months (real `TTL`
  clauses in the migrations). A restored backup reflects the TTL window at dump time;
  data already aged out upstream is not recoverable from ClickHouse and is by design.

## What currently has NO backup path (pre-Phase-27)
- **Everything** — before this phase there were zero backup/restore scripts or
  CronJobs on disk. Phase 27 adds logical backup + restore-with-verification for the
  three durable stores and health/metadata snapshots for the two ephemeral ones.

## Destinations & secrets
- All backups go to an **S3-compatible** bucket via `BACKUP_S3_BUCKET` / `BACKUP_S3_ENDPOINT`
  env. Credentials come from the canonical secret store (Phase 25 ESO) — never embedded.
